# Mikser Kontrol (X32 / M32 + XR / MR)

Tek, sade arayüzle hem Behringer X32 / Midas M32 hem de XR12/16/18 / MR18 mikserlerini kontrol eden Flutter uygulaması (iOS + Android, telefon + tablet).

## v0.5 — Gate ve kompresör
Kanal sayfasında iki sekme var: **EQ · Giriş** ve **Dinamik** (sekmeler dokunarak değişir; kaydırma EQ sürüklemesiyle çakışmasın diye kapalı). Gate ya da kompresör açıksa sekmede renkli nokta görünür.
- **Gate:** aç/kapa, mod (Exp 1:2 / 1:3 / 1:4, Gate, Duck), eşik (-80…0 dB), aralık (3…60 dB), attack, hold, release
- **Kompresör:** aç/kapa, Comp/Exp, eşik (-60…0 dB), oran (1.1:1 … 100:1), knee, makeup (0…24 dB), attack, hold, release, paralel mix (%0–100), Auto, Peak/RMS, Lin/Log
- **Transfer eğrisi:** giriş-çıkış grafiği gate ve kompresörün birlikte etkisini canlı gösterir; eşikler renkli çizgilerle işaretli
- Telefonda grafik üstte, ayarlar altında; tablette ayarlar solda, grafik sağda

## v0.4 — X32'de doğru preamp (güvenlik)
- Gain ve +48V artık tahmin edilen değil, **gerçekten kullanılan** preamp'a gider. Zincir konsoldan okunur:
  kanal kaynağı (`/ch/NN/config/source`) → giriş bloğu (`/config/routing/IN/...`: Local, AES50-A/B, Kart, Kullanıcı) → gerekirse kullanıcı yönlendirmesi (`/config/userrout/in/NN`, FW 4+)
- Giriş kartında hangi preamp olduğu yazar (ör. "Preamp: AES50-A 20")
- Yönlendirme okunana kadar gain ve +48V kapalıdır; kaynak USB/Kart/FX/Bus ise preamp kontrolü gösterilmez
- Konsolda yönlendirme değişirse ekran canlı olarak yeni preamp'a geçer
- +48V açmadan önce preamp adını söyleyen bir onay penceresi çıkar
- XR'de kanal N her zaman fiziksel giriş N'nin preamp'ını kullanır, ek okuma gerekmez

## v0.3 — Kanal detay ekranı
Mikser ekranında bir kanalın **adına dokunun** (uzun basış hâlâ yeniden adlandırır).
- **EQ eğrisi:** 4 bant, numaralı noktaları sürükleyin (sağa-sola frekans, yukarı-aşağı kazanç). Eğri, Low Cut dahil gerçek filtre formülleriyle çizilir
- Bant tipi (Low Cut, Low Shelf, PEQ, VEQ, High Shelf, High Cut), frekans, kazanç ve Q kaydırıcıları; EQ aç/kapa
- **Giriş:** preamp gain (-12…+60 dB), +48V, faz çevirme, Low Cut ve frekansı (20–400 Hz); X32'de dijital trim (±18 dB)
- **Pan:** L100…C…R100, değere çift dokunarak ortalanır
- Telefonda EQ üstte sabit, ayarlar altta kayar; tablette ve yatay telefonda ayarlar solda, EQ sağda
- Mute düğmesi üst çubukta

## v0.2 — Seviye göstergeleri
- Her fader'ın yanında -60…0 dBFS metre (yeşil / sarı -18 dB'den, kırmızı -6 dB'den), üstte clip noktası
- X32: `/meters/0` (kanal, aux, FX dönüş, bus, matrix) ve `/meters/2` (Ana LR); doğrusal float değerler
- XR: `/meters/1` (kanal, aux, FX dönüş, bus, FX send, Ana LR); 1/256 dB'lik 16-bit değerler
- Abonelik 8 sn'de bir yenilenir; bağlantı koparsa metreler sıfırlanır (donmuş seviye gösterilmez)
- Stereo kaynaklarda (Ana LR, XR Aux/FX dönüş) L/R'nin yükseği gösterilir
- Demo modunda hareketli örnek metreler

## v0.1
- Ağdaki mikserleri otomatik bulma (`/xinfo` yayını) ve IP ile manuel bağlantı
- Model algılama: X32 için port 10023, XR için 10024; arayüz aynı kalır, adresler profile göre değişir
- Kanal, Aux/FX dönüş, Bus, Matrix (X32), FX Send (XR), DCA ve Ana LR faderleri
- Mute, kanal adı ve renkleri (uzun basarak yeniden adlandırma)
- **Sends on fader:** üstten bir bus seçin, giriş faderleri o mix'e gönderimi kontrol eder, sağdaki sabit fader bus master olur
- Canlı senkron (`/xremote`, 8 sn'de bir yenilenir), bağlantı kopunca uyarı ve dönünce otomatik yeniden senkron
- Göreli fader sürükleme (parmak fader'ı zıplatmaz), çift dokunuşla 0 dB
- Mikser olmadan denemek için X32 ve XR18 demo modu

## Kurulum
1. Flutter 3.27 veya üstünü kurun: https://docs.flutter.dev/get-started/install
2. Bu klasörde platform dosyalarını oluşturun (mevcut `lib/` dosyalarına dokunmaz):
   ```
   flutter create --platforms=ios,android --org com.sizinfirma .
   ```
   Oluşan `test/widget_test.dart` dosyasını silin (şablon sayaç testidir).
3. `flutter pub get`
4. `flutter test` ile OSC ve fader testlerini çalıştırın.
5. `flutter run` ile cihazda açın. Önce **Demo** ile arayüzü deneyebilirsiniz.

### Android
`android/app/src/main/AndroidManifest.xml` içinde `<manifest>` altına ekleyin (release sürüm için gerekli):
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

### iOS
`ios/Runner/Info.plist` içine ekleyin (yerel ağ izni, iOS 14+):
```xml
<key>NSLocalNetworkUsageDescription</key>
<string>Mikserinizi kontrol etmek için yerel ağa erişim gerekiyor.</string>
```
iOS'ta otomatik bulma (broadcast) için Apple'dan `com.apple.developer.networking.multicast` yetkisi istenmesi gerekir. Bu yetki gelene kadar IP ile bağlantı sorunsuz çalışır.

## Yapı
```
lib/
  osc/        OSC kodlama/çözme, UDP istemcisi, ağ taraması
  mixer/      MixerProfile (X32 ↔ XR farkları), MixerController (canlı durum)
  ui/         Bağlantı ekranı, mikser ekranı, kanal şeridi, fader
  util/       Fader/dB, parametre ölçekleri, EQ ve dinamik eğri hesapları
```
Yeni bir model eklemek ya da adres düzeltmek için yalnızca `mixer_profile.dart` değiştirilir.

## Gerçek mikserde doğrulanacaklar
- XR12'nin 12 kanal olarak listelenmesi
- XR'de FX gönderimlerinin `mix/07..10` adresleri
- Ana LR için ad/renk adresleri (`/main/st/config/...`, `/lr/config/...`)
- Metre verisinin byte sırası: belgelere göre little-endian; kod sayı alanından sırayı kendisi doğruluyor
- XR `/meters/1` içindeki 5 stereo çiftin sırası (Aux önce, sonra FX 1-4 varsayıldı)
- EQ ölçekleri: frekans 20 Hz–20 kHz log, kazanç ±15 dB, Q 10→0.3 log; gain -12…+60 dB
- X32 preamp çözümlemesi: `/config/routing/IN` ve `/config/userrout/in` değer sıraları belgeye göre; X32 Rack/Compact'ta yerel giriş sayısı 16'dır
- Gate modu sırası (Exp 1:2, 1:3, 1:4, Gate, Duck) XR FW 1.25'te teyitli; X32'de de aynı olmalı
- Transfer eğrisindeki knee genişliği yaklaşık çizilir (knee değeri başına 4 dB); sesi etkilemez, yalnızca görsel

## Sıradaki adımlar
- Gain reduction göstergeleri (gate/kompresör ne kadar kısıyor)
- Bus EQ (6 bant), bus/ana çıkış dinamikleri
- Kanal görünürlüğü/sıralama, sahne (scene/snapshot) çağırma
- Ekranın kapanmaması (wakelock) ve kişisel monitör modu
