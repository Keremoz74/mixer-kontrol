# Privacy Policy — OzMix Control

_Last updated: 5 November 2026_

OzMix Control is a remote control for Behringer X32 / Midas M32 and X Air / MR
digital mixers.

**No personal data is collected.** The app has no accounts, analytics,
advertising or tracking, and sends nothing to the developer or any third party.

**Local network.** The app communicates only with the mixer you choose, on your
local network, to read and change its settings.

**Microphone / audio input.** Used only while you record in the Recorder screen
("Record to tablet"), to capture audio from the mixer's USB audio (or the
device's microphone). Recordings are saved in the app's private storage on your
device and are shared only when you choose to share them.

**Data on your device.** Snapshots you save, the last mixer address and your
recordings are stored only on your device and are removed when you uninstall the app.

**Children.** The app is not directed at children and collects no data from anyone.

**Changes.** Updates to this policy will be published with new versions of the app.

---

# Gizlilik Politikası — OzMix Control

OzMix Control **hiçbir kişisel veri toplamaz.** Hesap, analiz, reklam veya takip
yoktur; geliştiriciye ya da üçüncü taraflara hiçbir veri gönderilmez.

- **Yerel ağ:** Uygulama yalnızca seçtiğiniz mikserle, yerel ağınız üzerinden haberleşir.
- **Mikrofon / ses girişi:** Yalnızca Recorder ekranında kayıt yaparken kullanılır.
  Kayıtlar cihazınızda, uygulamanın özel alanında saklanır; yalnızca siz paylaşırsanız dışarı çıkar.
- **Cihazdaki veriler:** Kaydettiğiniz snapshot'lar, son mikser adresi ve kayıtlar
  yalnızca cihazınızda tutulur; uygulama silinince silinir.
