# Security — OzMix Control

> **Current state: DEVELOPMENT.** Builds are signed with the shared development
> key in `ci/debug.keystore`. Before publishing: run the security review again,
> generate a new private upload key, put it in GitHub Secrets, switch to the
> release workflow and remove `ci/debug.keystore` from the repository.

## What the app does on the network
- Talks only to the mixer you connect to, on the local network, using the
  consoles' own OSC protocol over UDP (X32/M32 port 10023, X Air/MR port 10024).
- Sends nothing to the internet. No accounts, analytics, ads or tracking.

## Built-in protections
- **Only the connected mixer is listened to.** Packets from any other device
  or port are dropped, so nobody else on the network can inject values into the app.
- **Bounded input.** Oversized packets are dropped; only known X32 / X Air
  address families are stored, capped in number; texts from the mixer are clipped.
- **Safe recalls.** Device snapshots never change preamp gain or +48V; +48V
  always asks for confirmation. Copy / paste never copies gain, +48V or inserts.
- **Private files.** Recordings and snapshots stay in the app's private storage
  and leave the device only when the user shares them. Android backup is off.
- **Signed releases.** Release builds are signed with a private upload key kept
  in GitHub Secrets (never in the repository). The build fails if the key is
  missing, and refuses to publish an APK not signed with it. Dart code is obfuscated.

## Limits you should know (the mixer's protocol, not the app)
The X32 / X Air OSC protocol has **no password and no encryption**: any device on
the same network can control the mixer, with or without this app. Protect the network:
- Put the mixer on its own Wi-Fi with a strong WPA2/WPA3 password (not a public or guest network).
- Don't expose the mixer's ports to the internet (no port forwarding).
- On X32, consider the console's own remote-control restrictions where available.

## Signing secrets (repository owner)
GitHub → repository → Settings → Secrets and variables → Actions:
- `ANDROID_KEYSTORE_BASE64` — the upload keystore, base64 encoded
- `ANDROID_KEYSTORE_PASSWORD` — its password (alias `ozmix`)

Keep an offline backup of the keystore and password. If they leak, rotate: make
a new key, update the secrets (with Google Play App Signing, request an upload-key
reset in Play Console).

## Reporting a problem
Contact the developer through the app's store listing. Please don't publish
details before a fix is available.
