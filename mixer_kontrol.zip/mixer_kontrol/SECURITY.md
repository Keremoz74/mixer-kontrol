# Security — OzMix Control

> **Current state: RELEASE signing.** APKs are signed only with the private
> upload key in GitHub Secrets (`ANDROID_KEYSTORE_BASE64`,
> `ANDROID_KEYSTORE_PASSWORD`, alias `ozmix`). The repository holds no key.
> Upload certificate SHA-256:
> `a71c91452e446542c3056ee02e532f0c28f61fafd4363a2bf750f744a8d0f7ee`
> (CN=OzMix Control, O=Keremoz74, C=TR). The former development key
> (`ci/debug.keystore`, still in old commits) is retired and must not be trusted.

## What the app does on the network
- Talks only to the mixer you connect to, on the local network, with that
  console's own control protocol:
  X32 / M32 OSC UDP 10023 · X Air / MR OSC UDP 10024 · Yamaha RCP TCP 49280 ·
  Allen & Heath MIDI over TCP 51325 · Behringer WING OSC UDP 2223 + native TCP 2222
  (meters back on a UDP port of the app) · TASCAM Sonicview Ember+ TCP 9000
  (meters to UDP 41624) · PreSonus StudioLive UCNet TCP 53000 (meters to a UDP port of the app).
- Sends nothing to the internet. No accounts, analytics, ads or tracking.

## Built-in protections
- **Only the connected mixer is listened to.** Packets from any other device
  or port are dropped (meter streams too, checked against the console's real
  address), so nobody else on the network can inject values into the app.
- **Impossible values are refused.** Texts over 256 characters and numbers far
  outside a control's range are ignored, not clipped into place.
- **Hostile-peer limits.** Every driver bounds what a peer can make it hold:
  packet and message sizes, nesting depth (Ember+ BER), the inflated size of a
  compressed state (PreSonus, 64 MB), and the number of stored keys / tree elements.
- **Photos stay local.** A photo of your mixer is copied into the app's private
  storage and never sent anywhere.
- **Bounded input.** Oversized packets are dropped; only known X32 / X Air
  address families are stored, capped in number; texts from the mixer are clipped.
- **Safe recalls.** Device snapshots never change preamp gain or +48V; +48V
  always asks for confirmation. Copy / paste never copies gain, +48V or inserts.
- **Private files.** Recordings and snapshots stay in the app's private storage
  and leave the device only when the user shares them. Android backup is off.
- **Signed releases.** Builds are signed with a private upload key kept in
  GitHub Secrets (never in the repository). The build fails if the key is
  missing, and refuses to publish an APK not signed with it. Dart code is obfuscated.
- **Build supply chain.** Third-party GitHub Actions are pinned to exact commits;
  the checkout keeps no credentials; the temporary key file is deleted after signing.

## Limits you should know (the mixer's protocol, not the app)
None of these consoles' remote protocols (X32 / X Air / WING OSC, Yamaha RCP,
A&H MIDI over TCP, Ember+, UCNet) has encryption, and most have no password:
any device on the same network can control the mixer, with or without this app.
Protect the network:
- Put the mixer on its own Wi-Fi with a strong WPA2/WPA3 password (not a public or guest network).
- Don't expose the mixer's ports to the internet (no port forwarding).
- Use the console's own remote restrictions where available (e.g. WING
  Setup → Remote → Remote lock, StudioLive permissions).

## Signing secrets (repository owner)
GitHub → repository → Settings → Secrets and variables → Actions:
- `ANDROID_KEYSTORE_BASE64` — the upload keystore, base64 encoded
- `ANDROID_KEYSTORE_PASSWORD` — its password (alias `ozmix`)

Keep an offline backup of the keystore and password (losing them means
installed copies can no longer be updated). If they leak, rotate: make a new
key, update the secrets and `EXPECTED_CERT_SHA256` in the workflow (with Google
Play App Signing, request an upload-key reset in Play Console).

## Reporting a problem
Contact the developer through the app's store listing. Please don't publish
details before a fix is available.
