"""Point the release build at an explicit signing key (dev key or the secret upload key).

Run by prepare_android.sh after `flutter create`. Exits with an error if the
Gradle file can't be patched, so a build can never silently fall back to the
public debug key.
"""
import pathlib
import sys

KTS_BLOCK = '''    signingConfigs {
        create("release") {
            storeFile = file(System.getenv("OZMIX_KEYSTORE") ?: "missing-upload.jks")
            storePassword = System.getenv("OZMIX_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("OZMIX_KEY_ALIAS") ?: "ozmix"
            keyPassword = System.getenv("OZMIX_KEY_PASSWORD") ?: System.getenv("OZMIX_KEYSTORE_PASSWORD")
        }
    }

'''

GROOVY_BLOCK = '''    signingConfigs {
        release {
            storeFile file(System.getenv("OZMIX_KEYSTORE") ?: "missing-upload.jks")
            storePassword System.getenv("OZMIX_KEYSTORE_PASSWORD")
            keyAlias System.getenv("OZMIX_KEY_ALIAS") ?: "ozmix"
            keyPassword System.getenv("OZMIX_KEY_PASSWORD") ?: System.getenv("OZMIX_KEYSTORE_PASSWORD")
        }
    }

'''


def patch(path: pathlib.Path) -> None:
    src = path.read_text()
    kts = path.suffix == '.kts'
    if 'OZMIX_KEYSTORE' in src:
        return
    i = src.find('    buildTypes {')
    if i < 0:
        sys.exit(f'sign_release: no buildTypes block in {path}')
    src = src[:i] + (KTS_BLOCK if kts else GROOVY_BLOCK) + src[i:]
    if kts:
        old, new = 'signingConfigs.getByName("debug")', 'signingConfigs.getByName("release")'
    else:
        old, new = 'signingConfig signingConfigs.debug', 'signingConfig signingConfigs.release'
    if old not in src:
        sys.exit(f'sign_release: release signing line not found in {path}')
    src = src.replace(old, new)
    path.write_text(src)
    print(f'sign_release: {path} now signs release builds with the upload key')


if __name__ == '__main__':
    for name in ('android/app/build.gradle.kts', 'android/app/build.gradle'):
        p = pathlib.Path(name)
        if p.exists():
            patch(p)
            break
    else:
        sys.exit('sign_release: no app Gradle file found')
