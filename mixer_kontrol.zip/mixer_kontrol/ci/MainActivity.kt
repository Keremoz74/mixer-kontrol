package com.mixerkontrol.mixer_kontrol

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.KeyEvent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

// Lets the app see what any music app is playing (YouTube, YouTube Music,
// Spotify...). Android only hands out the playing sessions to an app the
// user has given "notification access"; the service itself does nothing.
class MediaListener : NotificationListenerService()

// The music panel: what is playing (title, artist, app, cover), play /
// pause / next / previous for that app, and the Bluetooth output in use.
class MainActivity : FlutterActivity() {
    private fun hasAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    /** The session that is playing, or else the most recent one. */
    private fun session(): MediaController? {
        if (!hasAccess()) return null
        return try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        } catch (e: Exception) {
            null
        }
    }

    private fun cover(md: MediaMetadata?): ByteArray? {
        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON) ?: return null
        return try {
            val side = 160
            val scaled = Bitmap.createScaledBitmap(bmp, side, (side * bmp.height / bmp.width.coerceAtLeast(1)).coerceAtLeast(1), true)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    private fun mediaKey(am: AudioManager, code: Int) {
        val t = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ozmix/media").setMethodCallHandler { call, result ->
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            when (call.method) {
                "key" -> {
                    val key = call.argument<String>("key")
                    val s = session()
                    if (s != null) {
                        // straight to the app that is playing
                        val tc = s.transportControls
                        when (key) {
                            "play" -> if (s.playbackState?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
                            "next" -> tc.skipToNext()
                            "prev" -> tc.skipToPrevious()
                        }
                        result.success(true)
                    } else {
                        val code = when (key) {
                            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                            else -> null
                        }
                        if (code != null) mediaKey(am, code)
                        result.success(code != null)
                    }
                }
                "state" -> {
                    var out: String? = null
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        out = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                            .firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }?.productName?.toString()
                    }
                    val s = session()
                    val md = s?.metadata
                    var app: String? = null
                    if (s != null) {
                        app = try {
                            packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.packageName, 0)).toString()
                        } catch (e: Exception) {
                            s.packageName
                        }
                    }
                    result.success(
                        mapOf(
                            "access" to hasAccess(),
                            "playing" to (s?.playbackState?.state == PlaybackState.STATE_PLAYING || (s == null && am.isMusicActive)),
                            "output" to out,
                            "title" to (md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)),
                            "artist" to (md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)),
                            "app" to app,
                            "package" to s?.packageName,
                            "art" to cover(md),
                        )
                    )
                }
                "access" -> {
                    try {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                "open" -> {
                    try {
                        // the app that is playing, else the default music app
                        val pkg = call.argument<String>("package")
                        val i = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                            ?: Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
