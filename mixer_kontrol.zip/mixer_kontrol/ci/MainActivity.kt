package com.mixerkontrol.mixer_kontrol

import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

// Media keys for the music panel: play / pause / next / previous go to the
// music app playing on this device (standard media key events, no special
// permission), plus which Bluetooth output the sound goes to.
class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ozmix/media").setMethodCallHandler { call, result ->
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            when (call.method) {
                "key" -> {
                    val code = when (call.argument<String>("key")) {
                        "play" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                        "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                        "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        else -> null
                    }
                    if (code == null) {
                        result.success(false)
                    } else {
                        val t = SystemClock.uptimeMillis()
                        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
                        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
                        result.success(true)
                    }
                }
                "state" -> {
                    var out: String? = null
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val bt = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
                            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                        }
                        out = bt?.productName?.toString()
                    }
                    result.success(mapOf("playing" to am.isMusicActive, "output" to out))
                }
                "open" -> {
                    try {
                        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
