#!/usr/bin/env bash
# Run once on the Mac, inside the mixer_kontrol folder:   bash ci/prepare_ios.sh
# Creates the iOS project, sets the app name, permissions and icon.
set -euo pipefail

if ! command -v flutter >/dev/null; then
  echo "Flutter is not installed. See the steps in README (Mac)."; exit 1
fi

flutter create --platforms=ios --org com.mixerkontrol .
rm -f test/widget_test.dart

PLIST=ios/Runner/Info.plist
APP_NAME="$(cat branding/app_name.txt)"
pb() { /usr/libexec/PlistBuddy -c "$1" "$PLIST" 2>/dev/null || true; }
setstr() { pb "Delete :$1"; pb "Add :$1 string $2"; }

setstr CFBundleDisplayName "$APP_NAME"
setstr CFBundleName "$APP_NAME"
# The mixer is on the local network (iOS asks the user once).
setstr NSLocalNetworkUsageDescription "OzMix Control connects to your X32 / X Air mixer on the local network."
# Record to iPad / iPhone through the mixer's USB audio (or the microphone).
setstr NSMicrophoneUsageDescription "Used only when you record the mix to this device."
# Optional photo of your own mixer on the mixer picker.
setstr NSPhotoLibraryUsageDescription "Choose a photo of your mixer to show on the mixer picker."
setstr NSCameraUsageDescription "Take a photo of your mixer to show on the mixer picker."
# Wireless control on stage: keep the screen layout in all orientations on iPad.
pb "Delete :UIRequiresFullScreen"; pb "Add :UIRequiresFullScreen bool true"

# App icon: every size in the icon set, from one 1024 px image.
ICONSET=ios/Runner/Assets.xcassets/AppIcon.appiconset
for f in "$ICONSET"/*.png; do
  px=$(sips -g pixelWidth "$f" | awk '/pixelWidth/ {print $2}')
  sips -z "$px" "$px" branding/ios/icon_1024.png --out "$f" >/dev/null
done

flutter pub get
echo
echo "Done. Next: open ios/Runner.xcworkspace in Xcode and choose your Team (see README)."
