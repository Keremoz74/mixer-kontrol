#!/usr/bin/env bash
# Prepares the generated Android project. Lives in the zip, so permissions,
# app name and icons can change without touching the GitHub workflow file.
set -euo pipefail

flutter create --platforms=android --org com.mixerkontrol .
rm -f test/widget_test.dart

MANIFEST=android/app/src/main/AndroidManifest.xml

# Permissions: network (mixer control) and audio input (record to tablet).
PERMS='<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <uses-feature android:name="android.hardware.microphone" android:required="false"/>\n    <uses-feature android:name="android.hardware.usb.host" android:required="false"/>\n    <application'
sed -i "s#<application#${PERMS}#" "$MANIFEST"

# Minimum Android version: the audio recording library needs API 23+;
# 24 (Android 7) covers practically every tablet in use.
for G in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$G" ]; then
    sed -i -E 's/minSdk(Version)? *=? *flutter\.minSdkVersion/minSdk = 24/' "$G"
    grep -n "minSdk" "$G" || true
  fi
done

# Security: no Android backup of app data (it stays on the device).
sed -i 's#<application#<application android:allowBackup="false"#' "$MANIFEST"

# Signing: always an explicit key, never Android's implicit debug key (that
# one can differ from build to build, and then updates won't install).
#  OZMIX_KEYSTORE = the private upload key from GitHub Secrets, written to a
#  temporary file by the workflow (there is no key in the repository).
if [ -z "${OZMIX_KEYSTORE:-}" ]; then
  echo "::error::OZMIX_KEYSTORE is not set (see the workflow)"; exit 1
fi
python3 ci/sign_release.py

# App name and launcher icon.
cp -r branding/android/res/. android/app/src/main/res/
APP_NAME="$(cat branding/app_name.txt)"
sed -i "s#android:label=\"[^\"]*\"#android:label=\"$APP_NAME\"#" "$MANIFEST"

echo "---- AndroidManifest.xml ----"
cat "$MANIFEST"
