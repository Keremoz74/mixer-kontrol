/// Shown on the connect screen so it is easy to see which build is installed.
const appVersion = 'v0.10.1';
