/// Shown on the connect screen so it is easy to see which build is installed.
const appVersion = 'v0.22';

const appName = 'OzMix Control';

/// Compatibility line (descriptive use of the console names, not part of the app name).
const appTagline = 'for X32 · M32 · X Air · MR';
