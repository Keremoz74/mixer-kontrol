/// Shown on the connect screen so it is easy to see which build is installed.
const appVersion = 'v0.59';

const appName = 'OzMix Control';

/// Compatibility line (descriptive use of the console names, not part of the app name).
const appTagline = 'X32 · M32 · XR · MR · Yamaha · A&H · WING · TASCAM · PreSonus';
