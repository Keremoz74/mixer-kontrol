// Translation between the app's own (X32-style) addresses and the Behringer
// WING OSC tree (UDP 2223), from Behringer's "WING Remote Protocols" and the
// WING property map (libwing, MIT):
//
//   /ch/1/fdr  ,f -3.0         set (native units: dB, Hz, ms, %)
//   /ch/1/fdr                  get → ,sff "-3.0" 0.71 -3.0  (text, raw, value)
//   /*S                        subscription: changes come back as ,f / ,i / ,s
//
// App → WING strips: /ch/NN → /ch/N (1-40), /auxin/NN → /aux/N (1-8),
// /bus/NN → /bus/N (1-16), /mtx/NN → /mtx/N (1-8), /main/st → /main/1,
// /dca/N → /dca/N (1-16), mute groups /config/mute/N → /mgrp/N (1-8).
//
// EQ: the app shows 6 bands; WING has LOW, 1-4 (inputs; buses 1-6) and HIGH.
// App band 1 = LOW, 2-5 = PEQ 1-4, 6 = HIGH.

import '../util/fader_math.dart';
import '../util/param_law.dart';

enum WingKind {
  level,
  muteInv, // app "on" (1 = playing) ↔ WING mute (1 = muted)
  onOff,
  name,
  color,
  pan,
  freq,
  lowCut,
  eqGain,
  q,
  eqTypeLow,
  eqTypeHigh,
  haGain,
  trim,
  gateThr,
  gateRange,
  gateMode,
  attack,
  holdMs,
  releaseMs,
  compThr,
  ratio,
  knee,
  makeup,
  mix,
  detect,
  envelope,
  dynMode,
  intValue,
  dcaMask,
  muteMask,
}

class WingParam {
  const WingParam(this.path, this.kind);
  final String path;
  final WingKind kind;
}

class WingLayout {
  static const channels = 40, auxes = 8, buses = 16, mains = 4, matrices = 8, dcas = 16, muteGroups = 8;
  static const fxSlots = 16;
  static const scenes = 99;

  /// Models offered on the connect screen.
  static const models = ['WING', 'WING Compact', 'WING Rack'];
}

class WingMap {
  const WingMap();

  static final _strip = RegExp(r'^/(ch|auxin|bus|mtx)/(\d{2,3})(/.+)$');
  static final _main = RegExp(r'^/main/st(/.+)$');
  static final _dca = RegExp(r'^/dca/(\d{1,2})(/.+)$');
  static final _headamp = RegExp(r'^/headamp/(\d{2,3})/(gain|phantom)$');
  static final _mute = RegExp(r'^/config/mute/(\d{1,2})$');
  static final _send = RegExp(r'^/mix/(\d{2})/(level|on)$');
  static final _eq = RegExp(r'^/eq/(\d)/(f|g|q|type)$');

  static const _cats = {'ch': 'ch', 'auxin': 'aux', 'bus': 'bus', 'mtx': 'mtx'};
  static const _max = {'ch': WingLayout.channels, 'aux': WingLayout.auxes, 'bus': WingLayout.buses, 'mtx': WingLayout.matrices};

  static const sceneCurrent = '/\$ctl/lib/\$actidx';
  static const sceneIndex = '/\$ctl/lib/\$actionidx';
  static const sceneAction = '/\$ctl/lib/\$action';
  static const monitorLevel = '/cfg/mon/1/\$lvl';

  /// The WING parameter behind an app address; null = no such control.
  WingParam? toWing(String addr) {
    if (addr == '/config/solo/level') return const WingParam(monitorLevel, WingKind.level);
    var m = _mute.firstMatch(addr);
    if (m != null) {
      final g = int.parse(m[1]!);
      // app mute group "on" = muted, same as WING
      return g < 1 || g > WingLayout.muteGroups ? null : WingParam('/mgrp/$g/mute', WingKind.onOff);
    }
    m = _headamp.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > WingLayout.channels) return null;
      return m[2] == 'gain'
          ? WingParam('/ch/$n/in/set/\$g', WingKind.haGain)
          : WingParam('/ch/$n/in/set/\$vph', WingKind.onOff);
    }
    m = _strip.firstMatch(addr);
    if (m != null) {
      final cat = _cats[m[1]]!;
      final n = int.parse(m[2]!);
      if (n < 1 || n > _max[cat]!) return null;
      return _forStrip(cat, n, m[3]!);
    }
    m = _main.firstMatch(addr);
    if (m != null) return _forStrip('main', 1, m[1]!);
    m = _dca.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > WingLayout.dcas) return null;
      final d = '/dca/$n';
      return switch (m[2]) {
        '/fader' => WingParam('$d/fdr', WingKind.level),
        '/on' => WingParam('$d/mute', WingKind.muteInv),
        '/config/name' => WingParam('$d/name', WingKind.name),
        '/config/color' => WingParam('$d/col', WingKind.color),
        '/cue' => WingParam('$d/\$solo', WingKind.onOff),
        _ => null,
      };
    }
    return null;
  }

  WingParam? _forStrip(String cat, int n, String rest) {
    final p = '/$cat/$n';
    final input = cat == 'ch' || cat == 'aux';
    switch (rest) {
      case '/mix/fader':
        return WingParam('$p/fdr', WingKind.level);
      case '/mix/on':
        return WingParam('$p/mute', WingKind.muteInv);
      case '/config/name':
        return WingParam('$p/name', WingKind.name);
      case '/config/color':
        return WingParam('$p/col', WingKind.color);
      case '/mix/pan':
        return WingParam('$p/pan', WingKind.pan);
      case '/mix/st':
        return input || cat == 'bus' ? WingParam('$p/main/1/on', WingKind.onOff) : null;
      case '/cue':
        return WingParam('$p/\$solo', WingKind.onOff);
      case '/eq/on':
        return WingParam('$p/eq/on', WingKind.onOff);
      case '/preamp/hpon':
        return cat == 'ch' ? WingParam('$p/flt/lc', WingKind.onOff) : null;
      case '/preamp/hpf':
        return cat == 'ch' ? WingParam('$p/flt/lcf', WingKind.lowCut) : null;
      case '/preamp/invert':
        return WingParam('$p/in/set/inv', WingKind.onOff);
      case '/preamp/trim':
        return WingParam('$p/in/set/trim', WingKind.trim);
      case '/grp/dca':
        return WingParam('$p/tags', WingKind.dcaMask);
      case '/grp/mute':
        return WingParam('$p/tags', WingKind.muteMask);
    }
    final eq = _eq.firstMatch(rest);
    if (eq != null) {
      final band = int.parse(eq[1]!);
      if (band < 1 || band > 6) return null;
      final b = band == 1 ? 'l' : (band == 6 ? 'h' : '${band - 1}');
      return switch (eq[2]) {
        'f' => WingParam('$p/eq/${b}f', WingKind.freq),
        'g' => WingParam('$p/eq/${b}g', WingKind.eqGain),
        'q' => WingParam('$p/eq/${b}q', WingKind.q),
        _ => band == 1
            ? WingParam('$p/eq/leq', WingKind.eqTypeLow)
            : band == 6
                ? WingParam('$p/eq/heq', WingKind.eqTypeHigh)
                : null, // bands 2-5 are always bell
      };
    }
    if (rest.startsWith('/gate/')) {
      if (cat != 'ch') return null; // gates exist on input channels only
      final g = '$p/gate';
      return switch (rest.substring(6)) {
        'on' => WingParam('$g/on', WingKind.onOff),
        'mode' => WingParam('$g/ratio', WingKind.gateMode),
        'thr' => WingParam('$g/thr', WingKind.gateThr),
        'range' => WingParam('$g/range', WingKind.gateRange),
        'attack' => WingParam('$g/att', WingKind.attack),
        'hold' => WingParam('$g/hld', WingKind.holdMs),
        'release' => WingParam('$g/rel', WingKind.releaseMs),
        _ => null,
      };
    }
    if (rest.startsWith('/dyn/')) {
      final d = '$p/dyn';
      return switch (rest.substring(5)) {
        'on' => WingParam('$d/on', WingKind.onOff),
        'mode' => WingParam('$d/mdl', WingKind.dynMode),
        'det' => WingParam('$d/det', WingKind.detect),
        'env' => WingParam('$d/env', WingKind.envelope),
        'thr' => WingParam('$d/thr', WingKind.compThr),
        'ratio' => WingParam('$d/ratio', WingKind.ratio),
        'knee' => WingParam('$d/knee', WingKind.knee),
        'mgain' => WingParam('$d/gain', WingKind.makeup),
        'attack' => WingParam('$d/att', WingKind.attack),
        'hold' => WingParam('$d/hld', WingKind.holdMs),
        'release' => WingParam('$d/rel', WingKind.releaseMs),
        'mix' => WingParam('$d/mix', WingKind.mix),
        'auto' => WingParam('$d/auto', WingKind.intValue),
        _ => null,
      };
    }
    final s = _send.firstMatch(rest);
    if (s != null) {
      final k = int.parse(s[1]!);
      final level = s[2] == 'level';
      final kind = level ? WingKind.level : WingKind.onOff;
      final leaf = level ? 'lvl' : 'on';
      if (input) {
        return k >= 1 && k <= WingLayout.buses ? WingParam('$p/send/$k/$leaf', kind) : null;
      }
      // buses and Main 1 feed the matrices
      if (cat == 'bus' || cat == 'main') {
        return k >= 1 && k <= WingLayout.matrices ? WingParam('$p/send/MX$k/$leaf', kind) : null;
      }
    }
    return null;
  }

  static final _fixedEqType = RegExp(r'/eq/[2-5]/type$');

  /// App values the console can't change (answered by the link itself):
  /// WING EQ bands 1-4 are always bell filters.
  static Object? constantFor(String addr) => _fixedEqType.hasMatch(addr) ? 2 : null;

  // ---------------------------------------------------------------- values

  static double _num(Object v) => v is num ? v.toDouble() : double.nan;
  static double _clamp(double v, double lo, double hi) => v.clamp(lo, hi).toDouble();

  /// App value → OSC argument (null = can't be sent).
  Object? encode(WingKind kind, Object v) {
    if (kind == WingKind.name) return v.toString().replaceAll(RegExp(r'[\x00-\x1f]'), ' ');
    final f = _num(v);
    if (!f.isFinite) return null;
    final n = f.clamp(0.0, 1.0);
    switch (kind) {
      case WingKind.level:
        if (n <= 0) return -144.0;
        return _clamp(faderToDb(n), -144, 10);
      case WingKind.muteInv:
        return f != 0 ? 0 : 1;
      case WingKind.onOff:
        return f != 0 ? 1 : 0;
      case WingKind.intValue:
        return f.round();
      case WingKind.color:
        return colorOut(f.toInt());
      case WingKind.pan:
        return _clamp(panLaw.toReal(n), -100, 100);
      case WingKind.freq:
        return _clamp(freqLaw.toReal(n), 20, 20000);
      case WingKind.lowCut:
        return _clamp(hpfLaw.toReal(n), 20, 2000);
      case WingKind.eqGain:
        return _clamp(eqGainLaw.toReal(n), -15, 15);
      case WingKind.q:
        return _clamp(qLaw.toReal(n), 0.442, 10);
      case WingKind.eqTypeLow:
        return f.toInt() <= 1 ? 'SHV' : 'PEQ';
      case WingKind.eqTypeHigh:
        return f.toInt() >= 4 ? 'SHV' : 'PEQ';
      case WingKind.haGain:
        return _clamp(headampGainLaw.toReal(n), -3, 45.5);
      case WingKind.trim:
        return _clamp(trimLaw.toReal(n), -18, 18);
      case WingKind.gateThr:
        return _clamp(gateThrLaw.toReal(n), -80, 0);
      case WingKind.gateRange:
        return _clamp(gateRangeLaw.toReal(n), 3, 60);
      case WingKind.gateMode:
        // app: 0 exp 1:2, 1 exp 1:3, 2 exp 1:4, 3 gate, 4 duck (→ gate)
        return switch (f.toInt()) { 0 => '1:2', 1 => '1:3', 2 => '1:4', _ => 'gate' };
      case WingKind.attack:
        return _clamp(attackLaw.toReal(n), 0, 120);
      case WingKind.holdMs:
        return _clamp(holdLaw.toReal(n), 1, 200);
      case WingKind.releaseMs:
        return _clamp(releaseLaw.toReal(n), 4, 4000);
      case WingKind.compThr:
        return _clamp(compThrLaw.toReal(n), -60, 0);
      case WingKind.ratio:
        return compRatios[f.toInt().clamp(0, compRatios.length - 1)];
      case WingKind.knee:
        return kneeLaw.toReal(n).round().clamp(0, 5);
      case WingKind.makeup:
        return _clamp(makeupLaw.toReal(n), -6, 12);
      case WingKind.mix:
        return _clamp(mixLaw.toReal(n), 0, 100);
      case WingKind.detect:
        return f.toInt() == 1 ? 'RMS' : 'PEAK';
      case WingKind.envelope:
        return f.toInt() == 1 ? 'LOG' : 'LIN';
      case WingKind.dynMode:
        return f.toInt() == 1 ? 'EXP' : 'COMP';
      case WingKind.name:
      case WingKind.dcaMask:
      case WingKind.muteMask:
        return null;
    }
  }

  /// The value inside a WING reply: a get answers `,sff` / `,sfi` (text,
  /// raw 0..1, value) or `,s`; a subscription sends a single native value.
  static Object? valueOf(List<Object> args) {
    if (args.isEmpty) return null;
    if (args.length >= 3 && args[0] is String && args[2] is num) return args[2];
    return args[0];
  }

  /// WING value → app value (null = not understood).
  Object? decode(WingKind kind, Object v) {
    switch (kind) {
      case WingKind.name:
        return v is String ? v : null;
      case WingKind.eqTypeLow:
        return '$v'.toUpperCase() == 'SHV' ? 1 : 2;
      case WingKind.eqTypeHigh:
        return '$v'.toUpperCase() == 'SHV' ? 4 : 2;
      case WingKind.gateMode:
        return switch ('$v'.toLowerCase()) { '1:1.5' || '1:2' => 0, '1:3' => 1, '1:4' => 2, _ => 3 };
      case WingKind.detect:
        return '$v'.toUpperCase() == 'RMS' ? 1 : 0;
      case WingKind.envelope:
        return '$v'.toUpperCase() == 'LOG' ? 1 : 0;
      case WingKind.dynMode:
        return '$v'.toUpperCase() == 'EXP' ? 1 : 0;
      case WingKind.dcaMask:
      case WingKind.muteMask:
        return v is String ? tagMask(v, kind == WingKind.dcaMask ? 'D' : 'M') : null;
      default:
        break;
    }
    final d = v is num ? v.toDouble() : _parse('$v');
    if (d == null) return null;
    switch (kind) {
      case WingKind.level:
        if (d <= -144 || d.isInfinite) return 0.0;
        return dbToFader(d.clamp(-144, 10).toDouble());
      case WingKind.muteInv:
        return d != 0 ? 0 : 1;
      case WingKind.onOff:
        return d != 0 ? 1 : 0;
      case WingKind.intValue:
        return d.round();
      case WingKind.color:
        return colorIn(d.round());
      case WingKind.pan:
        return panLaw.toNorm(d);
      case WingKind.freq:
        return freqLaw.toNorm(d.clamp(20, 20000).toDouble());
      case WingKind.lowCut:
        return hpfLaw.toNorm(d.clamp(20, 2000).toDouble());
      case WingKind.eqGain:
        return eqGainLaw.toNorm(d);
      case WingKind.q:
        return qLaw.toNorm(d.clamp(0.3, 10).toDouble());
      case WingKind.haGain:
        return headampGainLaw.toNorm(d);
      case WingKind.trim:
        return trimLaw.toNorm(d);
      case WingKind.gateThr:
        return gateThrLaw.toNorm(d);
      case WingKind.gateRange:
        return gateRangeLaw.toNorm(d);
      case WingKind.attack:
        return attackLaw.toNorm(d);
      case WingKind.holdMs:
        return holdLaw.toNorm(d.clamp(0.02, 2000).toDouble());
      case WingKind.releaseMs:
        return releaseLaw.toNorm(d.clamp(5, 4000).toDouble());
      case WingKind.compThr:
        return compThrLaw.toNorm(d);
      case WingKind.ratio:
        var best = 0;
        for (var k = 1; k < compRatios.length; k++) {
          if ((compRatios[k] - d).abs() < (compRatios[best] - d).abs()) best = k;
        }
        return best;
      case WingKind.knee:
        return kneeLaw.toNorm(d);
      case WingKind.makeup:
        return makeupLaw.toNorm(d);
      case WingKind.mix:
        return mixLaw.toNorm(d);
      default:
        return null;
    }
  }

  static double? _parse(String s) {
    final t = s.trim().toLowerCase();
    if (t == '-oo' || t == '-inf') return double.negativeInfinity;
    if (t == 'on') return 1;
    if (t == 'off') return 0;
    return double.tryParse(t.replaceAll(RegExp(r'[^0-9eE+\-.]'), ''));
  }

  // ---------------------------------------------------------------- tags
  //
  // DCA and mute group membership live in a strip's tags: "#D1,#D3,#M2".

  static final _tag = RegExp(r'#([DM])(\d{1,2})', caseSensitive: false);

  static int tagMask(String tags, String letter) {
    var mask = 0;
    for (final m in _tag.allMatches(tags)) {
      if (m[1]!.toUpperCase() != letter) continue;
      final n = int.parse(m[2]!);
      if (n >= 1 && n <= 30) mask |= 1 << (n - 1);
    }
    return mask;
  }

  /// [tags] with its #D (or #M) entries replaced by [mask]; other tags stay.
  static String withMask(String tags, String letter, int mask, int count) {
    final keep = [
      for (final t in tags.split(RegExp(r'[,\s]+')))
        if (t.isNotEmpty && !(t.length >= 3 && t[0] == '#' && t[1].toUpperCase() == letter && int.tryParse(t.substring(2)) != null)) t,
    ];
    final add = [for (var i = 0; i < count; i++) if ((mask >> i) & 1 == 1) '#$letter${i + 1}'];
    // keep the D entries before the M entries, as the console writes them
    final all = letter == 'D' ? [...add, ...keep] : [...keep, ...add];
    final out = all.join(',');
    return out.length <= 80 ? out : out.substring(0, 80);
  }

  // ---------------------------------------------------------------- colours
  //
  // App colours (X32 numbering): 0 off, 1 red, 2 green, 3 yellow, 4 blue,
  // 5 magenta, 6 cyan, 7 white. WING 1-12: grey-blue, blue, dark blue,
  // turquoise, green, olive, yellow, orange, red, coral, pink, mauve.

  static int colorOut(int app) => const [1, 9, 5, 7, 2, 11, 4, 1][(app % 8).clamp(0, 7)];

  static int colorIn(int wing) => switch (wing) {
        2 || 3 => 4,
        4 => 6,
        5 || 6 => 2,
        7 || 8 => 3,
        9 || 10 => 1,
        11 || 12 => 5,
        _ => 7,
      };

  // ---------------------------------------------------------------- meters
  //
  // One meter collection (TCP 2222, channel 3) covering every strip. Each
  // channel / aux / bus / main / matrix section is 8 words (in L/R, out L/R,
  // gate key / gain, dyn key / gain); a DCA section 4 words. 1/256 dB.

  /// App meter blob layout: ch 1-40 [0-39], aux 1-8 [40-47], bus 1-16 [48-63],
  /// mtx 1-8 [64-71], main 1 L/R [72, 73].
  static const meterCount = 74;

  /// Meter request body (tokens + zero-based indexes).
  static List<int> meterRequestTokens() => [
        for (var i = 0; i < WingLayout.channels; i++) ...[0xa0, i],
        for (var i = 0; i < WingLayout.auxes; i++) ...[0xa1, i],
        for (var i = 0; i < WingLayout.buses; i++) ...[0xa2, i],
        for (var i = 0; i < WingLayout.matrices; i++) ...[0xa4, i],
        0xa3, 0,
      ];

  /// Picks the app meter values out of a WING meter report (words after the
  /// 4-byte report id): inputs show their input level, mixes their output.
  static List<int> meterValues(List<int> words) {
    final out = List<int>.filled(meterCount, -32768);
    var o = 0, w = 0;
    void take(int sections, int word) {
      for (var i = 0; i < sections; i++) {
        final base = w + i * 8;
        if (base + 3 < words.length) out[o] = words[base + word];
        o++;
      }
      w += sections * 8;
    }

    take(WingLayout.channels, 0);
    take(WingLayout.auxes, 0);
    take(WingLayout.buses, 2);
    take(WingLayout.matrices, 2);
    if (w + 3 < words.length) {
      out[72] = words[w + 2];
      out[73] = words[w + 3];
    }
    return out;
  }
}
