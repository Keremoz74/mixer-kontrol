import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import 'wing_map.dart';

/// Connection to a Behringer WING (WING, Compact, Rack).
///
/// Values travel as OSC over UDP 2223 (translated by [WingMap]); changes made
/// on the console arrive through the "/*S" subscription, renewed with the
/// app's keep-alive. Meters need WING's native protocol: a TCP connection on
/// 2222 asks for a meter collection, which then streams to a local UDP port.
class WingLink implements MixerLink {
  WingLink._(this._socket, this.host, {this.port = defaultPort, this.nativePort = defaultNativePort}) {
    _socket.listen((e) {
      if (e != RawSocketEvent.read) return;
      final dg = _socket.receive();
      if (dg == null) return;
      // only the console we connected to may talk to us
      if (dg.address != host || dg.port != port || dg.data.length > 16384) return;
      final m = OscMessage.decode(dg.data);
      if (m != null) _onOsc(m);
    });
  }

  final RawDatagramSocket _socket;
  final InternetAddress host;
  final int port;
  final int nativePort;
  final _out = StreamController<OscMessage>.broadcast();
  final _raw = StreamController<OscMessage>.broadcast();
  bool _closed = false;

  final WingMap map = const WingMap();

  /// WING path → app addresses it answers (filled as the app asks).
  final Map<String, Map<String, WingKind>> _back = {};

  /// Last known tags per strip (DCA / mute group membership lives there).
  final Map<String, String> _tags = {};

  static const defaultPort = 2223;
  static const defaultNativePort = 2222;
  static const meterId = '/meters/wing';

  static Future<WingLink> open(String host, {int port = defaultPort, int nativePort = defaultNativePort}) async {
    final addr = InternetAddress.tryParse(host) ??
        (await InternetAddress.lookup(host, type: InternetAddressType.IPv4)).first;
    final s = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    return WingLink._(s, addr, port: port, nativePort: nativePort);
  }

  /// Asks the console who it is ("WING,ip,name,model,serial,firmware").
  /// Null if nothing answered.
  Future<({String name, String model})?> identify({Duration timeout = const Duration(milliseconds: 1200)}) async {
    // "/?" names the console; a fader answer alone still proves it's a WING
    var answered = false;
    final watch = _raw.stream.listen((m) {
      if (m.address == '/main/1/fdr') answered = true;
    });
    final reply = _raw.stream.firstWhere((m) => m.address == '/?').timeout(timeout);
    _sendRaw(const OscMessage('/?'));
    _sendRaw(const OscMessage('/main/1/fdr'));
    try {
      final m = await reply;
      final text = m.args.isNotEmpty && m.args.first is String ? m.args.first as String : '';
      final parts = text.split(',');
      if (parts.length >= 4 && parts[0].toUpperCase().contains('WING')) {
        return (name: parts[2].trim().isEmpty ? 'WING' : parts[2].trim(), model: _modelName(parts[3]));
      }
      return (name: 'WING', model: 'WING');
    } catch (_) {
      return answered ? (name: 'WING', model: 'WING') : null;
    } finally {
      await watch.cancel();
    }
  }

  /// Local UDP port (tests).
  int get localPort => _socket.port;

  static String _modelName(String raw) {
    final r = raw.toUpperCase();
    if (r.contains('COMPACT')) return 'WING Compact';
    if (r.contains('RACK')) return 'WING Rack';
    return 'WING';
  }

  void _sendRaw(OscMessage m) {
    if (_closed) return;
    try {
      _socket.send(m.encode(), host, port);
    } catch (_) {}
  }

  void _emit(String addr, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(addr, [v]));
  }

  void _onOsc(OscMessage m) {
    if (!_raw.isClosed) _raw.add(m);
    final v = WingMap.valueOf(m.args);
    if (v == null) return;
    if (m.address == WingMap.sceneCurrent) {
      if (v is num) _emit(MixerProfile.yamahaSceneCurrentAddr, v.toInt());
      return;
    }
    final hits = _back[m.address];
    if (hits == null) return;
    if (m.address.endsWith('/tags') && v is String) _tags[m.address] = v;
    hits.forEach((addr, kind) {
      final out = map.decode(kind, v);
      if (out != null) _emit(addr, out);
    });
  }

  void _register(String addr, WingParam p) => (_back[p.path] ??= {})[addr] = p.kind;

  @override
  Stream<OscMessage> get messages => _out.stream;

  @override
  void send(OscMessage m) {
    final a = m.address;
    switch (a) {
      case '/xremote':
        _sendRaw(const OscMessage('/*S'));
        return;
      case '/xinfo':
        // keep-alive: any answer proves the console is still there
        _sendRaw(const OscMessage('/main/1/fdr'));
        return;
      case '/meters':
        if (m.args.isNotEmpty && m.args.first == meterId) _wantMeters();
        return;
      case '/-snap/load':
        if (m.args.isNotEmpty && m.args.first is num) {
          _sendRaw(OscMessage(WingMap.sceneIndex, [(m.args.first as num).toInt()]));
          _sendRaw(const OscMessage(WingMap.sceneAction, ['GO']));
        }
        return;
      case MixerProfile.yamahaSceneCurrentAddr:
        if (m.args.isEmpty) _sendRaw(const OscMessage(WingMap.sceneCurrent));
        return;
    }
    final fixed = WingMap.constantFor(a);
    if (fixed != null) {
      if (m.args.isEmpty) _emit(a, fixed);
      return;
    }
    final p = map.toWing(a);
    if (p == null) return; // the console has no such control
    _register(a, p);
    if (m.args.isEmpty) {
      _sendRaw(OscMessage(p.path));
      return;
    }
    if (p.kind == WingKind.dcaMask || p.kind == WingKind.muteMask) {
      final mask = m.args.first;
      if (mask is! num) return;
      final dca = p.kind == WingKind.dcaMask;
      final next = WingMap.withMask(_tags[p.path] ?? '', dca ? 'D' : 'M', mask.toInt(),
          dca ? WingLayout.dcas : WingLayout.muteGroups);
      _tags[p.path] = next;
      _sendRaw(OscMessage(p.path, [next]));
      return;
    }
    final v = map.encode(p.kind, m.args.first);
    if (v != null) _sendRaw(OscMessage(p.path, [v]));
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  /// Registers app addresses up front, so changes made on the console are
  /// understood even for controls the app hasn't asked about.
  void learn(Iterable<String> addrs) {
    for (final a in addrs) {
      final p = map.toWing(a);
      if (p != null) _register(a, p);
    }
  }

  /// Every app address a WING profile can show.
  static Iterable<String> profileAddresses(MixerProfile p) sync* {
    yield* p.queryAddresses;
    yield* p.snapshotAddresses();
    for (final s in p.allStrips) {
      yield* p.detailAddresses(s);
    }
    for (final s in p.inputs) {
      if (s.type == StripType.channel) {
        yield '/headamp/${two(s.index)}/gain';
        yield '/headamp/${two(s.index)}/phantom';
      }
    }
  }

  // ---------------------------------------------------------------- meters

  Socket? _native;
  RawDatagramSocket? _meterSock;
  Timer? _meterTimer;
  DateTime _meterWanted = DateTime.fromMillisecondsSinceEpoch(0);
  bool _opening = false;
  static const _reportId = 1;

  /// Called on every app meter renewal (about every 4 s while meters show).
  void _wantMeters() {
    _meterWanted = DateTime.now();
    if (_native != null || _opening || _closed) return;
    _openMeters();
  }

  Future<void> _openMeters() async {
    _opening = true;
    try {
      // a UDP port whose bytes never collide with the protocol's escape byte
      RawDatagramSocket u;
      do {
        u = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
        if ((u.port >> 8) != 0xdf && (u.port & 0xff) != 0xdf) break;
        u.close();
      } while (true);
      final t = await Socket.connect(host, nativePort, timeout: const Duration(seconds: 3));
      if (_closed) {
        u.close();
        t.destroy();
        return;
      }
      t.setOption(SocketOption.tcpNoDelay, true);
      // the console's control channel talks back; nothing in it is needed
      t.listen((_) {}, onError: (_) => _dropMeters(), onDone: _dropMeters, cancelOnError: true);
      u.listen((e) {
        if (e != RawSocketEvent.read) return;
        final dg = u.receive();
        if (dg == null || dg.address != host || dg.data.length < 6 || dg.data.length > 8192) return;
        _onMeters(dg.data);
      });
      _native = t;
      _meterSock = u;
      t.add([0xdf, 0xd1, ...meterRequest(u.port)]);
      _meterTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        if (DateTime.now().difference(_meterWanted) > const Duration(seconds: 9)) {
          _dropMeters(); // the app stopped asking (meters off / screen closed)
          return;
        }
        try {
          _native?.add(meterKeepAlive(u.port));
        } catch (_) {
          _dropMeters();
        }
      });
    } catch (_) {
      _dropMeters();
    } finally {
      _opening = false;
    }
  }

  void _dropMeters() {
    _meterTimer?.cancel();
    _meterTimer = null;
    try {
      _native?.destroy();
    } catch (_) {}
    _native = null;
    _meterSock?.close();
    _meterSock = null;
  }

  /// Native request: "send meter collection [id] to UDP [port]".
  static List<int> meterRequest(int port) => [
        0xdf, 0xd3, //
        0xd3, port >> 8, port & 0xff,
        0xd4, _reportId >> 8, _reportId & 0xff, port >> 8, port & 0xff,
        0xdc, ...WingMap.meterRequestTokens(), 0xde,
        0xdf, 0xd1,
      ];

  static List<int> meterKeepAlive(int port) =>
      [0xdf, 0xd3, 0xd4, _reportId >> 8, _reportId & 0xff, port >> 8, port & 0xff, 0xdf, 0xd1];

  void _onMeters(Uint8List data) {
    final bd = ByteData.sublistView(data);
    final words = [for (var i = 4; i + 1 < data.length; i += 2) bd.getInt16(i, Endian.big)];
    final vals = WingMap.meterValues(words);
    final out = ByteData(4 + vals.length * 2);
    out.setInt32(0, vals.length, Endian.little);
    for (var i = 0; i < vals.length; i++) {
      out.setInt16(4 + i * 2, vals[i], Endian.little);
    }
    if (!_out.isClosed) _out.add(OscMessage(meterId, [out.buffer.asUint8List()]));
  }

  @override
  void close() {
    _closed = true;
    _dropMeters();
    _socket.close();
    _out.close();
    _raw.close();
  }
}
