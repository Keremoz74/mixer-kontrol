import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import 'wing_ids.dart';
import 'wing_map.dart';

/// Connection to a Behringer WING (WING, Compact, Rack).
///
/// Values travel as OSC over UDP 2223 (translated by [WingMap]); changes made
/// on the console arrive through the "/*S" subscription, renewed with the
/// app's keep-alive. Meters need WING's native protocol: a TCP connection on
/// 2222 asks for a meter collection, which then streams to a local UDP port.
class WingLink implements MixerLink {
  WingLink._(this._socket, this.host, {this.port = defaultPort, this.nativePort = defaultNativePort}) {
    _socket.listen((e) {
      if (e != RawSocketEvent.read) return;
      final dg = _socket.receive();
      if (dg == null) return;
      // only the console we connected to may talk to us
      if (dg.address != host || dg.port != port || dg.data.length > 16384) return;
      final m = OscMessage.decode(dg.data);
      if (m != null) _onOsc(m);
    });
  }

  final RawDatagramSocket _socket;
  final InternetAddress host;
  final int port;
  final int nativePort;
  final _out = StreamController<OscMessage>.broadcast();
  final _raw = StreamController<OscMessage>.broadcast();
  bool _closed = false;

  final WingMap map = const WingMap();

  /// WING path → app addresses it answers (filled as the app asks).
  final Map<String, Map<String, WingKind>> _back = {};

  /// Last known tags per strip (DCA / mute group membership lives there).
  final Map<String, String> _tags = {};

  static const defaultPort = 2223;
  static const defaultNativePort = 2222;
  static const meterId = '/meters/wing';

  static Future<WingLink> open(String host, {int port = defaultPort, int nativePort = defaultNativePort}) async {
    final addr = InternetAddress.tryParse(host) ??
        (await InternetAddress.lookup(host, type: InternetAddressType.IPv4)).first;
    final s = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    return WingLink._(s, addr, port: port, nativePort: nativePort);
  }

  /// Asks the console who it is ("WING,ip,name,model,serial,firmware").
  /// Null if nothing answered.
  Future<({String name, String model})?> identify({Duration timeout = const Duration(milliseconds: 1200)}) async {
    // "/?" names the console; a fader answer alone still proves it's a WING
    var answered = false;
    final watch = _raw.stream.listen((m) {
      if (m.address == '/main/1/fdr') answered = true;
    });
    final reply = _raw.stream.firstWhere((m) => m.address == '/?').timeout(timeout);
    _sendRaw(const OscMessage('/?'));
    _sendRaw(const OscMessage('/main/1/fdr'));
    try {
      final m = await reply;
      final text = m.args.isNotEmpty && m.args.first is String ? m.args.first as String : '';
      final parts = text.split(',');
      if (parts.length >= 4 && parts[0].toUpperCase().contains('WING')) {
        return (name: parts[2].trim().isEmpty ? 'WING' : parts[2].trim(), model: _modelName(parts[3]));
      }
      return (name: 'WING', model: 'WING');
    } catch (_) {
      return answered ? (name: 'WING', model: 'WING') : null;
    } finally {
      await watch.cancel();
    }
  }

  /// Local UDP port (tests).
  int get localPort => _socket.port;

  static String _modelName(String raw) {
    final r = raw.toUpperCase();
    if (r.contains('COMPACT')) return 'WING Compact';
    if (r.contains('RACK')) return 'WING Rack';
    return 'WING';
  }

  void _sendRaw(OscMessage m) {
    if (_closed) return;
    try {
      _socket.send(m.encode(), host, port);
    } catch (_) {}
  }

  void _emit(String addr, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(addr, [v]));
  }

  void _onOsc(OscMessage m) {
    if (!_raw.isClosed) _raw.add(m);
    final v = WingMap.valueOf(m.args);
    if (v != null) _onValue(m.address, v);
  }

  /// A value of WING [path] (from an OSC reply or the native connection).
  void _onValue(String path, Object v) {
    if (path == WingMap.sceneCurrent) {
      if (v is num) _emit(MixerProfile.yamahaSceneCurrentAddr, v.toInt());
      return;
    }
    final hits = _back[path];
    if (hits == null) return;
    if (path.endsWith('/tags') && v is String) _tags[path] = v;
    hits.forEach((addr, kind) {
      final out = map.decode(kind, v);
      if (out != null) _emit(addr, out);
    });
  }

  void _register(String addr, WingParam p) => (_back[p.path] ??= {})[addr] = p.kind;

  @override
  Stream<OscMessage> get messages => _out.stream;

  @override
  void send(OscMessage m) {
    final a = m.address;
    switch (a) {
      case '/xremote':
        // changes come over the native connection; only without it is the
        // (single, shared) OSC subscription used
        if (_native == null) {
          _sendRaw(const OscMessage('/*S'));
          openNative();
        }
        return;
      case '/xinfo':
        // keep-alive: any answer proves the console is still there
        _sendRaw(const OscMessage('/main/1/fdr'));
        return;
      case '/meters':
        if (m.args.isNotEmpty && m.args.first == meterId) _wantMeters();
        return;
      case '/-snap/load':
        if (m.args.isNotEmpty && m.args.first is num) {
          _sendRaw(OscMessage(WingMap.sceneIndex, [(m.args.first as num).toInt()]));
          _sendRaw(const OscMessage(WingMap.sceneAction, ['GO']));
        }
        return;
      case MixerProfile.yamahaSceneCurrentAddr:
        if (m.args.isEmpty) _sendRaw(const OscMessage(WingMap.sceneCurrent));
        return;
    }
    final fixed = WingMap.constantFor(a);
    if (fixed != null) {
      if (m.args.isEmpty) _emit(a, fixed);
      return;
    }
    final p = map.toWing(a);
    if (p == null) return; // the console has no such control
    _register(a, p);
    if (m.args.isEmpty) {
      _sendRaw(OscMessage(p.path));
      return;
    }
    if (p.kind == WingKind.dcaMask || p.kind == WingKind.muteMask) {
      final mask = m.args.first;
      if (mask is! num) return;
      final dca = p.kind == WingKind.dcaMask;
      final next = WingMap.withMask(_tags[p.path] ?? '', dca ? 'D' : 'M', mask.toInt(),
          dca ? WingLayout.dcas : WingLayout.muteGroups);
      _tags[p.path] = next;
      _sendRaw(OscMessage(p.path, [next]));
      return;
    }
    final v = map.encode(p.kind, m.args.first);
    if (v != null) _sendRaw(OscMessage(p.path, [v]));
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  /// Registers app addresses up front, so changes made on the console are
  /// understood even for controls the app hasn't asked about.
  void learn(Iterable<String> addrs) {
    for (final a in addrs) {
      final p = map.toWing(a);
      if (p != null) _register(a, p);
    }
  }

  /// Every app address a WING profile can show.
  static Iterable<String> profileAddresses(MixerProfile p) sync* {
    yield* p.queryAddresses;
    yield* p.snapshotAddresses();
    for (final s in p.allStrips) {
      yield* p.detailAddresses(s);
    }
    for (final s in p.inputs) {
      if (s.type == StripType.channel) {
        yield '/headamp/${two(s.index)}/gain';
        yield '/headamp/${two(s.index)}/phantom';
      }
    }
  }

  // ---------------------------------------------------------------- native connection
  //
  // TCP 2222 (WING "native" protocol). Up to 16 apps can hold one, and the
  // console reports every parameter change on it, so changes are followed
  // here rather than through the OSC subscription (which only one app at a
  // time can have). Meters are requested on the same connection.

  Socket? _native;
  bool _nativeOpening = false;
  Timer? _nativeTimer;
  final _nativeDecoder = WingNativeDecoder();
  RawDatagramSocket? _meterSock;
  DateTime _meterWanted = DateTime.fromMillisecondsSinceEpoch(0);
  bool _meterOpening = false;
  static const _reportId = 1;

  /// True while change notifications come over the native connection.
  bool get nativeConnected => _native != null;

  /// Opens the native connection; false if the console refused it.
  Future<bool> openNative() async {
    if (_native != null) return true;
    if (_nativeOpening || _closed) return false;
    _nativeOpening = true;
    try {
      final t = await Socket.connect(host, nativePort, timeout: const Duration(seconds: 3));
      if (_closed) {
        t.destroy();
        return false;
      }
      t.setOption(SocketOption.tcpNoDelay, true);
      t.listen(_onNativeBytes, onError: (_) => _dropNative(), onDone: _dropNative, cancelOnError: true);
      _native = t;
      t.add(const [0xdf, 0xd1]);
      _nativeTimer = Timer.periodic(const Duration(seconds: 2), (_) => _nativeTick());
      return true;
    } catch (_) {
      return false;
    } finally {
      _nativeOpening = false;
    }
  }

  void _nativeTick() {
    final t = _native;
    if (t == null) return;
    final u = _meterSock;
    try {
      if (u != null && DateTime.now().difference(_meterWanted) > const Duration(seconds: 9)) {
        _dropMeters(); // the app stopped asking (meters off / screen closed)
      }
      // keeps the connection (10 s timeout) and the meter collection alive
      t.add(_meterSock != null ? meterKeepAlive(_meterSock!.port) : const [0xdf, 0xd1]);
    } catch (_) {
      _dropNative();
    }
  }

  void _dropNative() {
    _nativeTimer?.cancel();
    _nativeTimer = null;
    try {
      _native?.destroy();
    } catch (_) {}
    _native = null;
    _nativeDecoder.reset();
    _dropMeters();
  }

  void _onNativeBytes(List<int> data) {
    for (final (id, value) in _nativeDecoder.add(data)) {
      final path = wingIds[id & 0xffffffff];
      if (path != null) _onValue(path, value);
    }
  }

  /// Called on every app meter renewal (about every 4 s while meters show).
  void _wantMeters() {
    _meterWanted = DateTime.now();
    if (_meterSock != null || _meterOpening || _closed) return;
    _openMeters();
  }

  Future<void> _openMeters() async {
    _meterOpening = true;
    try {
      if (!await openNative()) return;
      // a UDP port whose bytes never collide with the protocol's escape byte
      RawDatagramSocket u;
      do {
        u = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
        if ((u.port >> 8) != 0xdf && (u.port & 0xff) != 0xdf) break;
        u.close();
      } while (true);
      if (_closed || _native == null) {
        u.close();
        return;
      }
      u.listen((e) {
        if (e != RawSocketEvent.read) return;
        final dg = u.receive();
        if (dg == null || dg.address != host || dg.data.length < 6 || dg.data.length > 8192) return;
        _onMeters(dg.data);
      });
      _meterSock = u;
      _native!.add(meterRequest(u.port));
    } catch (_) {
      _dropMeters();
    } finally {
      _meterOpening = false;
    }
  }

  void _dropMeters() {
    _meterSock?.close();
    _meterSock = null;
  }

  /// Native request: "send meter collection [id] to UDP [port]".
  static List<int> meterRequest(int port) => [
        0xdf, 0xd3, //
        0xd3, port >> 8, port & 0xff,
        0xd4, _reportId >> 8, _reportId & 0xff, port >> 8, port & 0xff,
        0xdc, ...WingMap.meterRequestTokens(), 0xde,
        0xdf, 0xd1,
      ];

  static List<int> meterKeepAlive(int port) =>
      [0xdf, 0xd3, 0xd4, _reportId >> 8, _reportId & 0xff, port >> 8, port & 0xff, 0xdf, 0xd1];

  void _onMeters(Uint8List data) {
    final bd = ByteData.sublistView(data);
    final words = [for (var i = 4; i + 1 < data.length; i += 2) bd.getInt16(i, Endian.big)];
    final vals = WingMap.meterValues(words);
    final out = ByteData(4 + vals.length * 2);
    out.setInt32(0, vals.length, Endian.little);
    for (var i = 0; i < vals.length; i++) {
      out.setInt16(4 + i * 2, vals[i], Endian.little);
    }
    if (!_out.isClosed) _out.add(OscMessage(meterId, [out.buffer.asUint8List()]));
  }

  @override
  void close() {
    _closed = true;
    _dropNative();
    _socket.close();
    _out.close();
    _raw.close();
  }
}


/// Reads the WING native byte stream (escape byte 0xdf, channel selects
/// 0xd0-0xdd) and returns the parameter values reported on the control
/// channel as (id, value). After libwing (MIT).
class WingNativeDecoder {
  bool _esc = false;
  int _channel = -1;
  int _node = 0;
  final List<int> _q = [];
  static const maxQueue = 1 << 16;

  void reset() {
    _esc = false;
    _channel = -1;
    _node = 0;
    _q.clear();
  }

  List<(int, Object)> add(List<int> data) {
    final out = <(int, Object)>[];
    for (final b in data) {
      if (!_esc) {
        if (b == 0xdf) {
          _esc = true;
        } else {
          _token(b);
        }
        continue;
      }
      _esc = false;
      if (b == 0xdf) {
        _token(0xdf);
      } else if (b == 0xde) {
        _token(0xdf);
      } else if (b >= 0xd0 && b < 0xde) {
        _channel = b - 0xd0;
      } else if (_channel >= 0) {
        _token(0xdf);
        _token(b);
      } else {
        _token(b);
      }
    }
    _parse(out);
    if (_q.length > maxQueue) _q.clear();
    return out;
  }

  void _token(int b) {
    if (_channel == 1) _q.add(b);
  }

  int _u(int i, int n) {
    var v = 0;
    for (var k = 0; k < n; k++) {
      v = (v << 8) | _q[i + k];
    }
    return v;
  }

  void _parse(List<(int, Object)> out) {
    var i = 0;
    while (i < _q.length) {
      final c = _q[i];
      final left = _q.length - i;
      int need;
      Object? value;
      if (c <= 0x3f) {
        need = 1;
        value = c;
      } else if (c <= 0x7f) {
        need = 1;
      } else if (c <= 0xcf) {
        final len = (c <= 0xbf ? c - 0x80 : c - 0xc0) + 1;
        need = 1 + len;
        if (left >= need) value = utf8.decode(_q.sublist(i + 1, i + need), allowMalformed: true);
      } else {
        switch (c) {
          case 0xd0:
            need = 1;
            value = '';
          case 0xd1:
            if (left < 2) return _keep(i);
            final len = _q[i + 1] + 1;
            need = 2 + len;
            if (left >= need) value = utf8.decode(_q.sublist(i + 2, i + need), allowMalformed: true);
          case 0xd2:
            need = 3;
          case 0xd3:
            need = 3;
            if (left >= need) value = _u(i + 1, 2).toSigned(16);
          case 0xd4:
            need = 5;
            if (left >= need) value = _u(i + 1, 4).toSigned(32);
          case 0xd5:
          case 0xd6:
            need = 5;
            if (left >= need) {
              value = (ByteData(4)..setUint32(0, _u(i + 1, 4))).getFloat32(0).toDouble();
            }
          case 0xd7:
            need = 5;
            if (left >= need) _node = _u(i + 1, 4);
          case 0xd9:
            need = 2;
          case 0xdf:
            // node definition: u16 length (0 → u32 length follows)
            if (left < 3) return _keep(i);
            final n = _u(i + 1, 2);
            if (n == 0) {
              if (left < 7) return _keep(i);
              need = 7 + _u(i + 3, 4);
            } else {
              need = 3 + n;
            }
            if (need > maxQueue) {
              _q.clear();
              return;
            }
          default:
            need = 1;
        }
      }
      if (left < need) return _keep(i);
      if (value != null && _node != 0) out.add((_node, value));
      i += need;
    }
    _q.clear();
  }

  void _keep(int i) => _q.removeRange(0, i);
}
