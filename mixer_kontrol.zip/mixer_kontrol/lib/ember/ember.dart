// A small Ember+ consumer: S101 framing, BER encoding and the parts of the
// Glow DTD a mixer remote needs (nodes, parameters, GetDirectory, setting
// values, provider updates). Ember+ is Lawo's open control protocol
// (https://github.com/Lawo/ember-plus).

import 'dart:convert';
import 'dart:typed_data';

// ------------------------------------------------------------------ BER

class BerTag {
  const BerTag(this.cls, this.number, {this.constructed = false});
  final int cls; // 0 universal, 1 application, 2 context
  final int number;
  final bool constructed;

  static const universal = 0, application = 1, context = 2;

  bool isApp(int n) => cls == application && number == n;
  bool isCtx(int n) => cls == context && number == n;
}

/// One decoded BER element: its tag and raw content.
class BerNode {
  BerNode(this.tag, this.content);
  final BerTag tag;
  final Uint8List content;

  List<BerNode>? _kids;

  /// Children of a constructed element.
  List<BerNode> get children => _kids ??= BerReader(content).readAll();

  BerNode? ctx(int n) {
    for (final c in children) {
      if (c.tag.isCtx(n)) return c;
    }
    return null;
  }

  /// Content of an explicit context tag ([n] wrapping one universal value).
  BerNode? inner() => children.isEmpty ? null : children.first;
}

class BerFormatException implements Exception {
  BerFormatException(this.message);
  final String message;
  @override
  String toString() => 'BER: $message';
}

class BerReader {
  BerReader(this.data, [this._depth = 0]);
  final Uint8List data;
  int pos = 0;
  final int _depth;

  /// Deeper nesting than any real Glow message is refused (no stack overflow
  /// from a hostile peer).
  static const maxDepth = 64;

  bool get done => pos >= data.length;

  int _byte() {
    if (pos >= data.length) throw BerFormatException('truncated');
    return data[pos++];
  }

  List<BerNode> readAll() {
    final out = <BerNode>[];
    while (!done) {
      // end-of-contents of an indefinite length
      if (pos + 1 < data.length && data[pos] == 0 && data[pos + 1] == 0) {
        pos += 2;
        continue;
      }
      out.add(read());
      if (out.length > 100000) throw BerFormatException('too many elements');
    }
    return out;
  }

  BerNode read() {
    final b = _byte();
    final cls = (b >> 6) & 3;
    final constructed = (b & 0x20) != 0;
    var number = b & 0x1f;
    if (number == 0x1f) {
      number = 0;
      int x;
      var n = 0;
      do {
        x = _byte();
        number = (number << 7) | (x & 0x7f);
        if (++n > 4) throw BerFormatException('tag too long');
      } while (x & 0x80 != 0);
    }
    final tag = BerTag(cls, number, constructed: constructed);
    final l = _byte();
    if (l == 0x80) {
      // indefinite: find the matching end-of-contents
      if (!constructed) throw BerFormatException('indefinite primitive');
      if (_depth >= maxDepth) throw BerFormatException('nested too deep');
      final start = pos;
      var depth = 1;
      final r = BerReader(data, _depth + 1)..pos = pos;
      while (depth > 0) {
        if (r.pos + 1 >= data.length) throw BerFormatException('unterminated');
        if (data[r.pos] == 0 && data[r.pos + 1] == 0) {
          depth--;
          r.pos += 2;
          continue;
        }
        r.read(); // skips a whole element (handles nested indefinite ones)
      }
      pos = r.pos;
      return BerNode(tag, Uint8List.sublistView(data, start, pos - 2));
    }
    var len = l;
    if (l & 0x80 != 0) {
      final n = l & 0x7f;
      if (n > 4) throw BerFormatException('length too long');
      len = 0;
      for (var i = 0; i < n; i++) {
        len = (len << 8) | _byte();
      }
    }
    if (len < 0 || pos + len > data.length) throw BerFormatException('length past end');
    final node = BerNode(tag, Uint8List.sublistView(data, pos, pos + len));
    pos += len;
    return node;
  }
}

/// Values of universal types.
class Ber {
  static const tBool = 1, tInt = 2, tOctets = 4, tNull = 5, tReal = 9, tUtf8 = 12, tRelOid = 13;
  static const tSequence = 16, tSet = 17;

  static int decodeInt(Uint8List c) {
    if (c.isEmpty) return 0;
    var v = c[0] & 0x80 != 0 ? -1 : 0;
    for (final b in c.take(8)) {
      v = (v << 8) | b;
    }
    return v;
  }

  static List<int> encodeInt(int v) {
    final out = <int>[];
    var x = v;
    do {
      out.insert(0, x & 0xff);
      x >>= 8;
    } while (!((x == 0 && out.first & 0x80 == 0) || (x == -1 && out.first & 0x80 != 0)));
    return out;
  }

  static double decodeReal(Uint8List c) {
    if (c.isEmpty) return 0;
    final f = c[0];
    if (f == 0x40) return double.infinity;
    if (f == 0x41) return double.negativeInfinity;
    if (f == 0x42) return double.nan;
    if (f & 0x80 == 0) {
      // decimal (ISO 6093) text
      return double.tryParse(ascii.decode(c.sublist(1), allowInvalid: true).trim()) ?? 0;
    }
    final sign = f & 0x40 != 0 ? -1 : 1;
    final base = switch ((f >> 4) & 3) { 0 => 2, 1 => 8, _ => 16 };
    final scale = (f >> 2) & 3;
    var p = 1;
    int expLen;
    switch (f & 3) {
      case 0:
        expLen = 1;
      case 1:
        expLen = 2;
      case 2:
        expLen = 3;
      default:
        expLen = c[1];
        p = 2;
    }
    final exp = decodeInt(Uint8List.sublistView(c, p, p + expLen));
    p += expLen;
    var m = 0;
    for (final b in c.sublist(p)) {
      m = (m << 8) | b;
    }
    final e = exp * (base == 2 ? 1 : (base == 8 ? 3 : 4)) + scale;
    return sign * m * _pow2(e);
  }

  static double _pow2(int e) {
    var r = 1.0;
    if (e >= 0) {
      for (var i = 0; i < e && i < 2000; i++) {
        r *= 2;
      }
    } else {
      for (var i = 0; i < -e && i < 2000; i++) {
        r /= 2;
      }
    }
    return r;
  }

  static List<int> encodeReal(double v) {
    if (v == 0) return const [];
    if (v.isInfinite) return [v > 0 ? 0x40 : 0x41];
    if (v.isNaN) return const [0x42];
    final bd = ByteData(8)..setFloat64(0, v);
    final bits = bd.getUint64(0);
    final sign = (bits >> 63) & 1;
    var exp = ((bits >> 52) & 0x7ff) - 1075;
    var mant = bits & 0xfffffffffffff;
    if ((bits >> 52) & 0x7ff != 0) mant |= 1 << 52;
    while (mant != 0 && mant & 1 == 0) {
      mant >>= 1;
      exp++;
    }
    final e = encodeInt(exp);
    final m = <int>[];
    var x = mant;
    while (x != 0) {
      m.insert(0, x & 0xff);
      x >>= 8;
    }
    final first = 0x80 | (sign << 6) | (e.length == 1 ? 0 : (e.length == 2 ? 1 : 2));
    return [first, ...e, ...m];
  }

  static List<int> decodeRelOid(Uint8List c) {
    final out = <int>[];
    var v = 0;
    for (final b in c) {
      v = (v << 7) | (b & 0x7f);
      if (b & 0x80 == 0) {
        out.add(v);
        v = 0;
      }
    }
    return out;
  }

  static List<int> encodeRelOid(List<int> path) {
    final out = <int>[];
    for (final n in path) {
      final parts = <int>[n & 0x7f];
      var x = n >> 7;
      while (x > 0) {
        parts.insert(0, (x & 0x7f) | 0x80);
        x >>= 7;
      }
      out.addAll(parts);
    }
    return out;
  }

  /// A Glow Value (integer, real, string, boolean, octets, null).
  static Object? decodeValue(BerNode n) {
    if (n.tag.cls != BerTag.universal) return null;
    return switch (n.tag.number) {
      tInt => decodeInt(n.content),
      tReal => decodeReal(n.content),
      tUtf8 => utf8.decode(n.content, allowMalformed: true),
      tBool => n.content.isNotEmpty && n.content[0] != 0,
      tOctets => Uint8List.fromList(n.content),
      _ => null,
    };
  }
}

/// Builds BER bytes with definite lengths.
class BerWriter {
  static List<int> tag(int cls, int number, {bool constructed = false}) {
    final first = (cls << 6) | (constructed ? 0x20 : 0);
    if (number < 31) return [first | number];
    final parts = <int>[number & 0x7f];
    var x = number >> 7;
    while (x > 0) {
      parts.insert(0, (x & 0x7f) | 0x80);
      x >>= 7;
    }
    return [first | 0x1f, ...parts];
  }

  static List<int> length(int n) {
    if (n < 0x80) return [n];
    final b = <int>[];
    var x = n;
    while (x > 0) {
      b.insert(0, x & 0xff);
      x >>= 8;
    }
    return [0x80 | b.length, ...b];
  }

  static List<int> tlv(List<int> tagBytes, List<int> content) => [...tagBytes, ...length(content.length), ...content];

  static List<int> app(int n, List<int> content) => tlv(tag(1, n, constructed: true), content);
  static List<int> ctx(int n, List<int> content) => tlv(tag(2, n, constructed: true), content);
  static List<int> set(List<int> content) => tlv(tag(0, Ber.tSet, constructed: true), content);
  static List<int> seq(List<int> content) => tlv(tag(0, Ber.tSequence, constructed: true), content);

  static List<int> integer(int v) => tlv(tag(0, Ber.tInt), Ber.encodeInt(v));
  static List<int> real(double v) => tlv(tag(0, Ber.tReal), Ber.encodeReal(v));
  static List<int> utf8String(String s) => tlv(tag(0, Ber.tUtf8), utf8.encode(s));
  static List<int> boolean(bool b) => tlv(tag(0, Ber.tBool), [b ? 0xff : 0]);
  static List<int> relOid(List<int> p) => tlv(tag(0, Ber.tRelOid), Ber.encodeRelOid(p));

  static List<int> value(Object v) => switch (v) {
        bool b => boolean(b),
        int i => integer(i),
        double d => real(d),
        String s => utf8String(s),
        _ => throw ArgumentError('unsupported Ember+ value ${v.runtimeType}'),
      };
}

// ------------------------------------------------------------------ Glow

/// Glow application tags.
class Glow {
  static const root = 0, parameter = 1, command = 2, node = 3, elementCollection = 4;
  static const qualifiedParameter = 9, qualifiedNode = 10, rootElementCollection = 11;
  static const matrix = 13, function = 19, qualifiedMatrix = 17, qualifiedFunction = 20;
  static const invocationResult = 23, template = 24, qualifiedTemplate = 25;

  static const cmdSubscribe = 30, cmdUnsubscribe = 31, cmdGetDirectory = 32;

  /// GetDirectory on the root.
  static List<int> getRootDirectory() => _root([_cmd(cmdGetDirectory)]);

  /// GetDirectory on the node at [path].
  static List<int> getDirectory(List<int> path) => _root([
        BerWriter.app(qualifiedNode, [
          ...BerWriter.ctx(0, BerWriter.relOid(path)),
          ...BerWriter.ctx(2, BerWriter.app(elementCollection, BerWriter.ctx(0, _cmd(cmdGetDirectory)))),
        ]),
      ]);

  /// Sets the parameter at [path] to [value].
  static List<int> setValue(List<int> path, Object value) => _root([
        BerWriter.app(qualifiedParameter, [
          ...BerWriter.ctx(0, BerWriter.relOid(path)),
          ...BerWriter.ctx(1, BerWriter.set(BerWriter.ctx(2, BerWriter.value(value)))),
        ]),
      ]);

  static List<int> _cmd(int n) => BerWriter.app(command, BerWriter.ctx(0, BerWriter.integer(n)));

  static List<int> _root(List<List<int>> elements) => BerWriter.app(
        root,
        BerWriter.app(rootElementCollection, [for (final e in elements) ...BerWriter.ctx(0, e)]),
      );
}

/// A node or parameter reported by the provider.
class EmberElement {
  EmberElement({required this.path, required this.isNode, this.identifier, this.value, this.enumeration, this.hasValue = false});
  final List<int> path;
  final bool isNode;
  final String? identifier;
  final Object? value;
  final bool hasValue;

  /// Enum names, index = value.
  final List<String>? enumeration;
}

/// Flattens a Glow message into the nodes and parameters it describes
/// (paths resolved from nesting or given as qualified paths).
List<EmberElement> parseGlow(Uint8List ber) {
  final out = <EmberElement>[];
  final top = BerReader(ber).readAll();
  for (final r in top) {
    if (!r.tag.isApp(Glow.root)) continue;
    for (final coll in r.children) {
      if (!coll.tag.isApp(Glow.rootElementCollection)) continue;
      for (final wrap in coll.children) {
        final e = wrap.inner();
        if (e != null) _element(e, const [], out, 0);
      }
    }
  }
  return out;
}

void _element(BerNode e, List<int> parent, List<EmberElement> out, int depth) {
  if (depth > 32) return;
  final t = e.tag;
  if (t.cls != BerTag.application) return;
  final qualified = t.number == Glow.qualifiedNode || t.number == Glow.qualifiedParameter;
  final isNode = t.number == Glow.node || t.number == Glow.qualifiedNode;
  final isParam = t.number == Glow.parameter || t.number == Glow.qualifiedParameter;
  if (!isNode && !isParam) return;
  List<int> path;
  final id = e.ctx(0)?.inner();
  if (id == null) return;
  if (qualified) {
    path = Ber.decodeRelOid(id.content);
  } else {
    path = [...parent, Ber.decodeInt(id.content)];
  }
  String? identifier;
  Object? value;
  var hasValue = false;
  List<String>? enumeration;
  final contents = e.ctx(1)?.inner();
  if (contents != null) {
    final idn = contents.ctx(0)?.inner();
    if (idn != null) identifier = Ber.decodeValue(idn) as String?;
    if (isParam) {
      final v = contents.ctx(2)?.inner();
      if (v != null) {
        value = Ber.decodeValue(v);
        hasValue = true;
      }
      final en = contents.ctx(7)?.inner();
      if (en != null) {
        final s = Ber.decodeValue(en);
        if (s is String) enumeration = s.split('\n');
      }
      final map = contents.ctx(15)?.inner();
      if (map != null && enumeration == null) enumeration = _enumMap(map);
    }
  }
  out.add(EmberElement(path: path, isNode: isNode, identifier: identifier, value: value, hasValue: hasValue, enumeration: enumeration));
  final kids = e.ctx(2)?.inner();
  if (kids != null && kids.tag.isApp(Glow.elementCollection)) {
    for (final w in kids.children) {
      final k = w.inner();
      if (k != null) _element(k, path, out, depth + 1);
    }
  }
}

/// StringIntegerCollection [APPLICATION 8] of StringIntegerPair [APPLICATION 7].
List<String>? _enumMap(BerNode n) {
  final out = <int, String>{};
  for (final w in n.children) {
    final pair = w.inner();
    if (pair == null) continue;
    final k = pair.ctx(0)?.inner();
    final v = pair.ctx(1)?.inner();
    if (k == null || v == null) continue;
    final s = Ber.decodeValue(k), i = Ber.decodeValue(v);
    if (s is String && i is int && i >= 0 && i < 4096) out[i] = s;
  }
  if (out.isEmpty) return null;
  final max = out.keys.reduce((a, b) => a > b ? a : b);
  return [for (var i = 0; i <= max; i++) out[i] ?? ''];
}

// ------------------------------------------------------------------ S101

/// S101 framing of Ember+ over TCP.
class S101 {
  static const bof = 0xfe, eof = 0xff, ce = 0xfd, invalid = 0xf8;
  static const slot = 0x00, msgEmber = 0x0e;
  static const cmdEmber = 0x00, cmdKeepAliveRequest = 0x01, cmdKeepAliveResponse = 0x02;
  static const version = 0x01;
  static const flagSingle = 0xc0, flagFirst = 0x80, flagLast = 0x40, flagEmpty = 0x20;
  static const dtdGlow = 0x01;

  static final List<int> _table = List<int>.generate(256, (i) {
    var c = i;
    for (var k = 0; k < 8; k++) {
      c = c & 1 != 0 ? (c >> 1) ^ 0x8408 : c >> 1;
    }
    return c;
  });

  static int crc(Iterable<int> data) {
    var c = 0xffff;
    for (final b in data) {
      c = (c >> 8) ^ _table[(c ^ b) & 0xff];
    }
    return c;
  }

  static List<int> _frame(List<int> body) {
    final c = (~crc(body)) & 0xffff;
    final all = [...body, c & 0xff, c >> 8];
    final out = <int>[bof];
    for (final b in all) {
      if (b >= invalid) {
        out..add(ce)..add(b ^ 0x20);
      } else {
        out.add(b);
      }
    }
    out.add(eof);
    return out;
  }

  /// One Glow message as a single-packet EmBER frame.
  static List<int> ember(List<int> glow) =>
      _frame([slot, msgEmber, cmdEmber, version, flagSingle, dtdGlow, 2, 0x28, 0x02, ...glow]);

  static List<int> keepAliveRequest() => _frame([slot, msgEmber, cmdKeepAliveRequest, version]);
  static List<int> keepAliveResponse() => _frame([slot, msgEmber, cmdKeepAliveResponse, version]);
}

/// A decoded S101 frame.
class S101Frame {
  S101Frame(this.command, this.flags, this.payload);
  final int command;
  final int flags;
  final Uint8List payload;
}

/// Splits a TCP byte stream into S101 frames (checking CRCs) and joins
/// multi-packet EmBER messages.
class S101Decoder {
  final List<int> _cur = [];
  bool _inFrame = false, _esc = false;
  final List<int> _multi = [];

  static const maxFrame = 1 << 20;
  static const maxMessage = 8 << 20;

  /// Feeds bytes; returns complete EmBER payloads (Glow BER) and keep-alive
  /// requests (as frames with command 1).
  List<S101Frame> add(List<int> data) {
    final out = <S101Frame>[];
    for (final b in data) {
      if (b == S101.bof) {
        _cur.clear();
        _inFrame = true;
        _esc = false;
        continue;
      }
      if (!_inFrame) continue;
      if (b == S101.eof) {
        _inFrame = false;
        final f = _finish();
        if (f != null) out.add(f);
        continue;
      }
      if (b == S101.ce) {
        _esc = true;
        continue;
      }
      _cur.add(_esc ? b ^ 0x20 : b);
      _esc = false;
      if (_cur.length > maxFrame) {
        _inFrame = false;
        _cur.clear();
      }
    }
    return out;
  }

  S101Frame? _finish() {
    final d = _cur;
    if (d.length < 6 || S101.crc(d) != 0xf0b8) return null;
    final body = d.sublist(0, d.length - 2);
    if (body[1] != S101.msgEmber) return null;
    final cmd = body[2];
    if (cmd != S101.cmdEmber) return S101Frame(cmd, 0, Uint8List(0));
    if (body.length < 7) return null;
    final flags = body[4];
    final appLen = body[6];
    final start = 7 + appLen;
    if (start > body.length) return null;
    final payload = body.sublist(start);
    if (flags & S101.flagFirst != 0) _multi.clear();
    if (flags & S101.flagEmpty == 0) _multi.addAll(payload);
    if (_multi.length > maxMessage) {
      _multi.clear();
      return null;
    }
    if (flags & S101.flagLast == 0) return null; // more packets follow
    final msg = Uint8List.fromList(_multi);
    _multi.clear();
    return S101Frame(cmd, flags, msg);
  }
}
