// Allen & Heath consoles over MIDI-over-TCP (port 51325): SQ, CQ, Qu,
// dLive and Avantis. The app keeps its own (X32-style) addresses; this link
// turns them into the console's MIDI messages and back.
//
// Protocol details follow Allen & Heath's MIDI protocol documents as used by
// the Bitfocus Companion modules for these consoles (MIT licence).

import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import '../util/fader_math.dart';
import '../util/param_law.dart';
import 'ah_layout.dart';

enum AhKind { level, mute, assign, name, color, muteGroup, pafl, eqFreq, eqGain, eqWidth, hpfFreq, hpfOn, haGain, phantom }

enum _Msg { nrpn, note, sysexSend, sysexAssign, sysexName, sysexColour, pitch, sysex48v }

/// One console control behind an app address.
class AhParam {
  const AhParam(this.kind, this.msg, {this.ch = 0, this.a = 0, this.b = 0, this.c = 0, this.d = 0});
  final AhKind kind;
  final _Msg msg;

  /// MIDI channel (0-15).
  final int ch;

  /// Message fields: NRPN msb/lsb (+ Qu send index in c), note, SysEx bytes.
  final int a, b, c, d;

  String get key => switch (msg) {
        _Msg.nrpn => 'N/$ch/$a/$b/$c',
        _Msg.note => 'M/$ch/$a',
        _Msg.sysexSend => 'SD/$ch/$a/$b/$c',
        _Msg.sysexAssign => 'SE/$ch/$a/$b/$c',
        _Msg.sysexName => 'S2/$ch/$a',
        _Msg.sysexColour => 'S5/$ch/$a',
        _Msg.pitch => 'E/$ch/$a',
        _Msg.sysex48v => 'S48/$a',
      };
}

class AhMap {
  AhMap(this.model) : dialect = ahDialectFor(model), layout = AhLayout.forModel(model);

  final String model;
  final AhDialect dialect;
  final AhLayout layout;

  static const dliveHeader = [0xF0, 0x00, 0x00, 0x1A, 0x50, 0x10, 0x01, 0x00];
  static const quHeader = [0xF0, 0x00, 0x00, 0x1A, 0x50, 0x11, 0x01, 0x00, 0x00];

  bool get _sqLike => dialect == AhDialect.sq || dialect == AhDialect.cq;

  // SQ sink counts (CQ uses the same numbering).
  static const _sqMix = 12, _sqFx = 4, _sqMtx = 3;

  static final _strip = RegExp(r'^/(ch|auxin|fxrtn|bus|mtx)/(\d{2})(/.+)$');
  static final _main = RegExp(r'^/main/st(/.+)$');
  static final _dca = RegExp(r'^/dca/(\d{1,2})(/.+)$');
  static final _fxsend = RegExp(r'^/fxsend/(\d{1,2})(/.+)$');
  static final _mute = RegExp(r'^/config/mute/(\d{1,2})$');
  static final _headamp = RegExp(r'^/headamp/(\d{2})/(gain|phantom)$');
  static final _send = RegExp(r'^/mix/(\d{2})/(level|on)$');
  static final _eq = RegExp(r'^/eq/([1-4])/(f|g|q)$');

  /// SQ / CQ input number of an app input strip (0-based).
  int? _sqInput(String cat, int i) {
    if (cat == 'ch') return i < layout.inputs ? i : null;
    if (cat == 'auxin') return dialect == AhDialect.cq && i < 4 ? 24 + i * 2 : null;
    return null;
  }

  AhParam _sqNrpn(AhKind k, int msb, int lsb, int offset) {
    final n = (msb << 7) + lsb + offset;
    return AhParam(k, _Msg.nrpn, a: (n >> 7) & 0x7F, b: n & 0x7F);
  }

  /// The console control behind an app address, or null if there is none.
  AhParam? toAh(String addr) {
    var m = _mute.firstMatch(addr);
    if (m != null) {
      final g = int.parse(m[1]!) - 1;
      if (g < 0 || g >= layout.muteGroups) return null;
      return switch (dialect) {
        AhDialect.sq || AhDialect.cq => _sqNrpn(AhKind.muteGroup, 0x04, 0x00, g),
        AhDialect.qu => AhParam(AhKind.muteGroup, _Msg.note, a: 0x50 + g),
        AhDialect.dlive => AhParam(AhKind.muteGroup, _Msg.note, ch: 4, a: 0x4E + g),
      };
    }
    m = _headamp.firstMatch(addr);
    if (m != null) {
      if (dialect != AhDialect.dlive) return null;
      final socket = int.parse(m[1]!) - 1;
      if (socket < 0 || socket > 63) return null;
      return m[2] == 'gain' ? AhParam(AhKind.haGain, _Msg.pitch, a: socket) : AhParam(AhKind.phantom, _Msg.sysex48v, a: socket);
    }
    m = _strip.firstMatch(addr);
    if (m != null) {
      final i = int.parse(m[2]!) - 1;
      return i < 0 ? null : _forStrip(m[1]!, i, m[3]!);
    }
    m = _main.firstMatch(addr);
    if (m != null) return _forStrip('main', 0, m[1]!);
    m = _dca.firstMatch(addr);
    if (m != null) {
      final i = int.parse(m[1]!) - 1;
      if (i < 0 || i >= layout.dcas) return null;
      final rest = m[2]!;
      final what = rest == '/fader' ? 'fader' : (rest == '/on' ? 'on' : rest);
      return _forStrip('dca', i, what == 'fader' ? '/mix/fader' : (what == 'on' ? '/mix/on' : rest));
    }
    m = _fxsend.firstMatch(addr);
    if (m != null) {
      final i = int.parse(m[1]!) - 1;
      return i < 0 || i >= layout.fxSends ? null : _forStrip('fxsend', i, m[2]!);
    }
    return null;
  }

  AhParam? _forStrip(String cat, int i, String rest) {
    switch (dialect) {
      case AhDialect.dlive:
        return _dlive(cat, i, rest);
      case AhDialect.qu:
        return _qu(cat, i, rest);
      case AhDialect.sq:
      case AhDialect.cq:
        return _sq(cat, i, rest);
    }
  }

  // ---------------------------------------------------------------- dLive / Avantis

  (int, int)? _dliveCode(String cat, int i) => switch (cat) {
        'ch' => i < layout.inputs ? (0, i) : null,
        'bus' => i < layout.mixes ? (2, i) : null,
        'mtx' => i < layout.matrices ? (3, i) : null,
        'fxsend' => i < layout.fxSends ? (4, i) : null,
        'fxrtn' => i < layout.fxReturns ? (4, 0x20 + i) : null,
        'main' => (4, 0x30),
        'dca' => (4, 0x36 + i),
        _ => null,
      };

  AhParam? _dlive(String cat, int i, String rest) {
    final code = _dliveCode(cat, i);
    if (code == null) return null;
    final (k, n) = code;
    switch (rest) {
      case '/mix/fader':
        return AhParam(AhKind.level, _Msg.nrpn, ch: k, a: n, b: 0x17);
      case '/mix/on':
        return AhParam(AhKind.mute, _Msg.note, ch: k, a: n);
      case '/mix/st':
        return cat == 'main' || cat == 'dca' ? null : AhParam(AhKind.assign, _Msg.nrpn, ch: k, a: n, b: 0x18);
      case '/config/name':
        return AhParam(AhKind.name, _Msg.sysexName, ch: k, a: n);
      case '/config/color':
        return AhParam(AhKind.color, _Msg.sysexColour, ch: k, a: n);
      case '/preamp/hpf':
        return cat == 'ch' ? AhParam(AhKind.hpfFreq, _Msg.nrpn, ch: k, a: n, b: 0x30) : null;
      case '/preamp/hpon':
        return cat == 'ch' ? AhParam(AhKind.hpfOn, _Msg.nrpn, ch: k, a: n, b: 0x31) : null;
    }
    final eq = _eq.firstMatch(rest);
    if (eq != null && cat == 'ch') {
      final band = int.parse(eq[1]!) - 1;
      return switch (eq[2]) {
        'f' => AhParam(AhKind.eqFreq, _Msg.nrpn, ch: k, a: n, b: 0x1B + band * 4),
        'q' => AhParam(AhKind.eqWidth, _Msg.nrpn, ch: k, a: n, b: 0x1C + band * 4),
        _ => AhParam(AhKind.eqGain, _Msg.nrpn, ch: k, a: n, b: 0x1D + band * 4),
      };
    }
    final s = _send.firstMatch(rest);
    if (s != null) {
      final to = int.parse(s[1]!) - 1;
      final dest = to < layout.mixes
          ? _dliveCode('bus', to)
          : (cat == 'bus' ? null : _dliveCode('fxsend', to - layout.mixes));
      // buses feed matrices
      final target = cat == 'bus' || cat == 'main' ? _dliveCode('mtx', to) : dest;
      if (target == null) return null;
      if (s[2] == 'level') {
        return AhParam(AhKind.level, _Msg.sysexSend, ch: k, a: n, b: target.$1, c: target.$2);
      }
      return cat == 'ch' ? AhParam(AhKind.assign, _Msg.sysexAssign, ch: k, a: n, b: target.$1, c: target.$2) : null;
    }
    return null;
  }

  // ---------------------------------------------------------------- Qu

  int? _quCode(String cat, int i) => switch (cat) {
        'ch' => i < layout.inputs ? 0x20 + i : null,
        'auxin' => i < layout.stereoInputs ? 0x40 + i : null,
        'fxrtn' => i < layout.fxReturns ? 0x08 + i : null,
        'fxsend' => i < layout.fxSends ? 0x00 + i : null,
        'bus' => i < layout.mixes ? 0x60 + i : null,
        'mtx' => i < layout.matrices ? 0x6C + i : null,
        'main' => 0x67,
        'dca' => i < layout.dcas ? 0x10 + i : null,
        _ => null,
      };

  AhParam? _qu(String cat, int i, String rest) {
    final n = _quCode(cat, i);
    if (n == null) return null;
    switch (rest) {
      case '/mix/fader':
        return AhParam(AhKind.level, _Msg.nrpn, a: n, b: 0x17, c: 0x07);
      case '/mix/on':
        return AhParam(AhKind.mute, _Msg.note, a: n);
      case '/mix/st':
        return cat == 'main' || cat == 'dca' ? null : AhParam(AhKind.assign, _Msg.nrpn, a: n, b: 0x18, c: 0x07);
      case '/cue':
        return AhParam(AhKind.pafl, _Msg.nrpn, a: n, b: 0x51, c: 0x07);
      case '/config/name':
        return AhParam(AhKind.name, _Msg.sysexName, a: n);
    }
    final s = _send.firstMatch(rest);
    if (s != null && s[2] == 'level' && (cat == 'ch' || cat == 'auxin' || cat == 'fxrtn')) {
      final to = int.parse(s[1]!) - 1;
      final idx = to < layout.mixes ? to : (to - layout.mixes < layout.fxSends ? 16 + to - layout.mixes : null);
      return idx == null ? null : AhParam(AhKind.level, _Msg.nrpn, a: n, b: 0x20, c: idx);
    }
    return null;
  }

  // ---------------------------------------------------------------- SQ / CQ

  AhParam? _sq(String cat, int i, String rest) {
    final input = _sqInput(cat, i);
    final isIn = input != null;
    final isFxr = cat == 'fxrtn' && i < layout.fxReturns;
    switch (rest) {
      case '/mix/fader':
        if (isIn) return _sqNrpn(AhKind.level, 0x40, 0x00, input);
        if (isFxr) return _sqNrpn(AhKind.level, 0x40, 0x3C, i);
        return switch (cat) {
          'main' => _sqNrpn(AhKind.level, 0x4F, 0x00, 0),
          'bus' => i < layout.mixes ? _sqNrpn(AhKind.level, 0x4F, 0x01, i) : null,
          'mtx' => i < layout.matrices ? _sqNrpn(AhKind.level, 0x4F, 0x11, i) : null,
          'fxsend' => _sqNrpn(AhKind.level, 0x4F, 0x0D, i),
          'dca' => _sqNrpn(AhKind.level, 0x4F, 0x20, i),
          _ => null,
        };
      case '/mix/on':
        if (isIn) return _sqNrpn(AhKind.mute, 0x00, 0x00, input);
        if (isFxr) return _sqNrpn(AhKind.mute, 0x00, 0x3C, i);
        return switch (cat) {
          'main' => _sqNrpn(AhKind.mute, 0x00, 0x44, 0),
          'bus' => i < layout.mixes ? _sqNrpn(AhKind.mute, 0x00, 0x45, i) : null,
          'mtx' => i < layout.matrices ? _sqNrpn(AhKind.mute, 0x00, 0x55, i) : null,
          'fxsend' => _sqNrpn(AhKind.mute, 0x00, 0x51, i),
          'dca' => _sqNrpn(AhKind.mute, 0x02, 0x00, i),
          _ => null,
        };
      case '/mix/st':
        if (isIn) return _sqNrpn(AhKind.assign, 0x60, 0x00, input);
        if (isFxr) return _sqNrpn(AhKind.assign, 0x60, 0x3C, i);
        return null;
    }
    final s = _send.firstMatch(rest);
    if (s == null) return null;
    final to = int.parse(s[1]!) - 1;
    final level = s[2] == 'level';
    final k = level ? AhKind.level : AhKind.assign;
    if (isIn || isFxr) {
      final src = isIn ? input : i;
      if (to < layout.mixes) {
        return isIn
            ? _sqNrpn(k, level ? 0x40 : 0x60, 0x44, _sqMix * src + to)
            : _sqNrpn(k, level ? 0x46 : 0x66, 0x14, _sqMix * src + to);
      }
      final fx = to - layout.mixes;
      if (fx >= layout.fxSends) return null;
      return isIn
          ? _sqNrpn(k, level ? 0x4C : 0x6C, 0x14, _sqFx * src + fx)
          : _sqNrpn(k, level ? 0x4E : 0x6E, 0x04, _sqFx * src + fx);
    }
    if (to >= layout.matrices) return null;
    if (cat == 'bus' && i < layout.mixes) return _sqNrpn(k, level ? 0x4E : 0x6E, 0x27, _sqMtx * i + to);
    if (cat == 'main') return _sqNrpn(k, level ? 0x4E : 0x6E, 0x24, to);
    return null;
  }

  // ---------------------------------------------------------------- values

  static double _dbOf(Object v) => v is num ? faderToDb(v.toDouble().clamp(0.0, 1.0)) : double.nan;

  /// Qu fader steps (dB, 7-bit value).
  static const quLevels = <(double, int)>[
    (10, 0x7F), (9.5, 0x7D), (9, 0x7C), (8.5, 0x7B), (8, 0x7A), (7.5, 0x79), (7, 0x78), (6.5, 0x77), (6, 0x76), //
    (5.5, 0x74), (5, 0x73), (4.5, 0x72), (4, 0x71), (3.5, 0x6F), (3, 0x6D), (2.5, 0x6B), (2, 0x69), (1.5, 0x67), //
    (1, 0x65), (0.5, 0x63), (0, 0x62), (-1, 0x5F), (-1.5, 0x5D), (-2, 0x5B), (-2.5, 0x58), (-3, 0x55), //
    (-3.5, 0x53), (-4, 0x52), (-4.5, 0x51), (-5, 0x4F), (-5.5, 0x4E), (-6, 0x4C), (-6.5, 0x4A), (-7, 0x48), (-7.5, 0x46), //
    (-8, 0x44), (-8.5, 0x42), (-9, 0x3F), (-10, 0x3E), (-11, 0x3C), (-12, 0x3A), (-13, 0x39), (-14, 0x38), (-15, 0x36), //
    (-16, 0x35), (-17, 0x33), (-18, 0x31), (-19, 0x30), (-20, 0x2F), (-21, 0x2D), (-22, 0x2B), (-23, 0x29), (-24, 0x28), //
    (-25, 0x27), (-26, 0x25), (-27, 0x23), (-28, 0x21), (-29, 0x20), (-30, 0x1F), (-31, 0x1D), (-32, 0x1B), (-33, 0x19), //
    (-34, 0x18), (-35, 0x17), (-36, 0x15), (-37, 0x13), (-38, 0x11), (-39, 0x10), (-40, 0x0F), (-45, 0x0C), (-50, 0x08), //
    (-55, 0x07),
  ];

  /// CQ fader steps (dB, 14-bit value).
  static const cqLevels = <(double, int)>[
    (10, 0x3FC0), (9, 0x3E80), (8, 0x3D40), (7, 0x3C00), (6, 0x3AC0), (5, 0x39C0), (4, 0x3800), (3, 0x3640), //
    (2, 0x3480), (1, 0x32C0), (0, 0x3100), (-1, 0x2F00), (-2, 0x2D00), (-3, 0x2B40), (-4, 0x2940), (-5, 0x2740), //
    (-6, 0x2580), (-7, 0x2400), (-8, 0x2240), (-9, 0x20C0), (-10, 0x1F00), (-11, 0x1E40), (-12, 0x1D80), //
    (-13, 0x1CC0), (-14, 0x1C00), (-15, 0x1B00), (-16, 0x1A40), (-17, 0x1980), (-18, 0x18C0), (-19, 0x1800), //
    (-20, 0x1740), (-21, 0x1680), (-22, 0x15C0), (-23, 0x1500), (-24, 0x1440), (-25, 0x1340), (-26, 0x1280), //
    (-27, 0x11C0), (-28, 0x1100), (-29, 0x1040), (-30, 0x0F80), (-31, 0x0EC0), (-32, 0x0E00), (-33, 0x0D40), //
    (-34, 0x0C80), (-35, 0x0B80), (-36, 0x0AC0), (-38, 0x0940), (-40, 0x07C0), (-45, 0x0600), (-50, 0x0400), //
    (-55, 0x0380), (-60, 0x0300), (-65, 0x0280), (-70, 0x0200), (-75, 0x01C0), (-80, 0x0140), (-85, 0x0100), (-89, 0x00C0),
  ];

  static int _fromTable(List<(double, int)> t, double db) {
    if (db >= t.first.$1) return t.first.$2;
    for (var k = 1; k < t.length; k++) {
      final (d1, v1) = t[k - 1];
      final (d2, v2) = t[k];
      if (db >= d2) return (v2 + (v1 - v2) * (db - d2) / (d1 - d2)).round();
    }
    return 0;
  }

  static double _toTable(List<(double, int)> t, int v) {
    if (v <= 0) return double.negativeInfinity;
    if (v >= t.first.$2) return t.first.$1;
    for (var k = 1; k < t.length; k++) {
      final (d1, v1) = t[k - 1];
      final (d2, v2) = t[k];
      if (v >= v2) return v1 == v2 ? d2 : d2 + (d1 - d2) * (v - v2) / (v1 - v2);
    }
    return double.negativeInfinity;
  }

  /// dB → console level value (7-bit for dLive / Qu, 14-bit for SQ / CQ).
  int levelValue(double db) {
    switch (dialect) {
      case AhDialect.dlive:
        return db.isInfinite || db <= -54 ? 0 : ((db + 54) / 64 * 127).round().clamp(1, 127);
      case AhDialect.qu:
        return db.isInfinite || db < -57 ? 0 : _fromTable(quLevels, db);
      case AhDialect.sq:
        return db.isInfinite || db <= -89 ? 0 : (15196 + math.min(db, 10) * 118.775).floor().clamp(1, 16383);
      case AhDialect.cq:
        return db.isInfinite || db <= -89.5 ? 0 : _fromTable(cqLevels, db);
    }
  }

  double levelDb(int v) {
    switch (dialect) {
      case AhDialect.dlive:
        return v <= 0 ? double.negativeInfinity : v * 64 / 127 - 54;
      case AhDialect.qu:
        return _toTable(quLevels, v);
      case AhDialect.sq:
        if (v <= 0) return double.negativeInfinity;
        final db = (v - 15196) / 118.775;
        return db < -89 ? double.negativeInfinity : math.min(db, 10);
      case AhDialect.cq:
        return _toTable(cqLevels, v);
    }
  }

  /// dLive EQ width (octaves) steps, value = index.
  static const widths = [1.5, 1.4, 1.3, 1.2, 1.1, 1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 2 / 3, 0.6, 0.55, 0.5, //
    0.45, 0.4, 1 / 3, 0.3, 0.25, 0.2, 1 / 6, 0.13, 1 / 9];

  static double _qToWidth(double q) {
    final x = 1 / (2 * q);
    return 2 / math.ln2 * math.log(x + math.sqrt(x * x + 1));
  }

  static double _widthToQ(double w) {
    final p = math.pow(2, w).toDouble();
    return math.sqrt(p) / (p - 1);
  }

  /// App value → value to send (7 / 14-bit), null if not sendable.
  int? encode(AhKind k, Object v) {
    if (v is! num || !v.toDouble().isFinite) return null;
    final n = v.toDouble().clamp(0.0, 1.0);
    switch (k) {
      case AhKind.level:
        return levelValue(_dbOf(n));
      case AhKind.mute:
        return v != 0 ? 0 : 1; // app: 1 = on (unmuted)
      case AhKind.assign:
      case AhKind.muteGroup:
      case AhKind.pafl:
      case AhKind.hpfOn:
      case AhKind.phantom:
        return v != 0 ? 1 : 0;
      case AhKind.color:
        return v.toInt().clamp(0, 7);
      case AhKind.eqFreq:
        return (n * 127).round();
      case AhKind.eqGain:
        return (n * 127).round();
      case AhKind.eqWidth:
        final w = _qToWidth(qLaw.toReal(n));
        var best = 0;
        for (var i = 1; i < widths.length; i++) {
          if ((widths[i] - w).abs() < (widths[best] - w).abs()) best = i;
        }
        return best;
      case AhKind.hpfFreq:
        final hz = hpfLaw.toReal(n);
        return (127 * math.log(hz / 20) / math.log(100)).round().clamp(0, 127);
      case AhKind.haGain:
        final db = headampGainLaw.toReal(n);
        return ((db - 5) / 55 * 127).round().clamp(0, 127);
      case AhKind.name:
        return null;
    }
  }

  /// Received value → app value.
  Object? decode(AhKind k, int v) {
    switch (k) {
      case AhKind.level:
        final db = levelDb(v);
        return db.isInfinite ? 0.0 : dbToFader(db);
      case AhKind.mute:
        return v != 0 ? 0 : 1;
      case AhKind.assign:
      case AhKind.hpfOn:
        // dLive sends 7F / 40 for on and 3F / 00 for off
        return dialect == AhDialect.dlive ? (v >= 0x40 ? 1 : 0) : (v != 0 ? 1 : 0);
      case AhKind.muteGroup:
      case AhKind.pafl:
      case AhKind.phantom:
        return v != 0 ? 1 : 0;
      case AhKind.color:
        return v.clamp(0, 7);
      case AhKind.eqFreq:
      case AhKind.eqGain:
        return (v / 127).clamp(0.0, 1.0);
      case AhKind.eqWidth:
        return qLaw.toNorm(_widthToQ(widths[v.clamp(0, widths.length - 1)]));
      case AhKind.hpfFreq:
        return hpfLaw.toNorm(20 * math.pow(100, v / 127).toDouble());
      case AhKind.haGain:
        return headampGainLaw.toNorm(5 + v / 127 * 55);
      case AhKind.name:
        return null;
    }
  }

  // ---------------------------------------------------------------- bytes

  int get _base => 0; // MIDI channel 1

  List<int> _nrpnBytes(int ch, int msb, int lsb, int vc, [int? vf]) {
    final s = 0xB0 | ((_base + ch) & 0x0F);
    return [s, 0x63, msb & 0x7F, s, 0x62, lsb & 0x7F, s, 0x06, vc & 0x7F, if (vf != null) ...[s, 0x26, vf & 0x7F]];
  }

  /// Message(s) that set [p] to the console value [v] (or the name [text]).
  List<int> setBytes(AhParam p, int v, {String? text}) {
    final h = dialect == AhDialect.qu ? quHeader : dliveHeader;
    switch (p.msg) {
      case _Msg.nrpn:
        if (_sqLike) {
          // level: 14-bit; mute / assign: VC 0, VF 0|1
          final big = p.kind == AhKind.level;
          return _nrpnBytes(0, p.a, p.b, big ? v >> 7 : 0, big ? v & 0x7F : v);
        }
        final vc = switch (p.kind) {
          AhKind.assign => dialect == AhDialect.dlive ? (v != 0 ? 0x7F : 0x3F) : v,
          AhKind.hpfOn => v != 0 ? 0x40 : 0x00,
          _ => v,
        };
        return _nrpnBytes(p.ch, p.a, p.b, vc, dialect == AhDialect.qu ? p.c : null);
      case _Msg.note:
        final s = 0x90 | ((_base + p.ch) & 0x0F);
        return [s, p.a, v != 0 ? 0x7F : 0x3F, s, p.a, 0x00];
      case _Msg.sysexSend:
        return [...h, (_base + p.ch) & 0x0F, 0x0D, p.a, (_base + p.b) & 0x0F, p.c, v & 0x7F, 0xF7];
      case _Msg.sysexAssign:
        return [...h, (_base + p.ch) & 0x0F, 0x0E, p.a, (_base + p.b) & 0x0F, p.c, v != 0 ? 0x40 : 0x00, 0xF7];
      case _Msg.sysexName:
        final t = (text ?? '').replaceAll(RegExp(r'[^\x20-\x7E]'), '');
        final bytes = t.substring(0, math.min(t.length, 8)).codeUnits;
        return dialect == AhDialect.qu ? const [] : [...h, (_base + p.ch) & 0x0F, 0x03, p.a, ...bytes, 0xF7];
      case _Msg.sysexColour:
        return [...h, (_base + p.ch) & 0x0F, 0x06, p.a, v & 0x07, 0xF7];
      case _Msg.pitch:
        return [0xE0 | (_base & 0x0F), p.a & 0x7F, v & 0x7F];
      case _Msg.sysex48v:
        return [...h, 0x0C, p.a & 0x7F, v != 0 ? 0x40 : 0x00, 0xF7];
    }
  }

  /// Message that asks the console for [p] (empty if it can't be asked).
  List<int> getBytes(AhParam p) {
    switch (dialect) {
      case AhDialect.sq:
      case AhDialect.cq:
        if (p.msg != _Msg.nrpn) return const [];
        const s = 0xB0;
        return [s, 0x63, p.a, s, 0x62, p.b, s, 0x60, 0x7F];
      case AhDialect.qu:
        return p.msg == _Msg.sysexName ? [...quHeader, 0x01, p.a, 0xF7] : const [];
      case AhDialect.dlive:
        final n = (_base + p.ch) & 0x0F;
        return switch (p.msg) {
          _Msg.note => [...dliveHeader, n, 0x05, 0x09, p.a, 0xF7],
          _Msg.nrpn when p.b == 0x17 => [...dliveHeader, n, 0x05, 0x0B, 0x17, p.a, 0xF7],
          _Msg.sysexName => [...dliveHeader, n, 0x01, p.a, 0xF7],
          _Msg.sysexColour => [...dliveHeader, n, 0x04, p.a, 0xF7],
          _ => const [],
        };
    }
  }

  /// Scene recall (1-based scene number).
  List<int> sceneBytes(int scene) {
    final n = (scene - 1).clamp(0, 16383);
    return switch (dialect) {
      AhDialect.dlive => [0xB0, 0x00, n ~/ 128, 0xC0, n % 128],
      AhDialect.qu => [0xB0, 0x00, 0x00, 0xC0, n % 128],
      _ => [0xB0, 0x00, (n >> 7) & 0x0F, 0xC0, n & 0x7F],
    };
  }

  /// Something cheap the console always answers (keep-alive).
  List<int> pingBytes() => switch (dialect) {
        AhDialect.qu => [...quHeader, 0x01, 0x20, 0xF7],
        _ => getBytes(toAh('/main/st/mix/fader')!),
      };

  /// Ask for everything at once (Qu); empty when not supported.
  List<int> syncAllBytes() => dialect == AhDialect.qu ? [...quHeader, 0x10, 0x01, 0xF7] : const [];
}

/// Connection to an Allen & Heath console (TCP, MIDI byte stream).
class AhLink implements MixerLink {
  AhLink._(this.host, this.port, this.map);

  final String host;
  final int port;
  final AhMap map;
  Socket? _socket;
  StreamSubscription<Uint8List>? _sub;
  bool _closed = false;
  Timer? _retry;
  final _out = StreamController<OscMessage>.broadcast();

  /// Console message key → app address (filled by [learn] and as the app asks).
  final Map<String, (String, AhKind)> _back = {};
  bool _syncedAll = false;

  static const defaultPort = 51325;

  static Future<AhLink> connect(String host, String model,
      {int port = defaultPort, Duration timeout = const Duration(seconds: 3)}) async {
    final l = AhLink._(host, port, AhMap(model));
    await l._open(timeout);
    return l;
  }

  Future<void> _open(Duration timeout) async {
    final s = await Socket.connect(host, port, timeout: timeout);
    s.setOption(SocketOption.tcpNoDelay, true);
    _socket = s;
    _sub = s.listen(_onBytes, onError: (_) => _lost(), onDone: _lost, cancelOnError: true);
  }

  void _lost() {
    _sub?.cancel();
    _sub = null;
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _syncedAll = false;
    if (_closed) return;
    _retry ??= Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_closed || _socket != null) return;
      try {
        await _open(const Duration(seconds: 2));
        _retry?.cancel();
        _retry = null;
      } catch (_) {}
    });
  }

  void _write(List<int> bytes) {
    final s = _socket;
    if (s == null || bytes.isEmpty) return;
    try {
      s.add(bytes);
    } catch (_) {
      _lost();
    }
  }

  void _emit(String addr, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(addr, [v]));
  }

  /// Registers app addresses so console messages can be understood.
  void learn(Iterable<String> addrs) {
    for (final a in addrs) {
      final p = map.toAh(a);
      if (p != null) _back.putIfAbsent(p.key, () => (a, p.kind));
    }
  }

  static Iterable<String> profileAddresses(MixerProfile p) sync* {
    yield* p.queryAddresses;
    yield* p.snapshotAddresses();
    for (final s in p.allStrips) {
      yield* p.detailAddresses(s);
    }
    for (final s in p.inputs) {
      if (s.type == StripType.channel) {
        yield '/headamp/${two(s.index)}/gain';
        yield '/headamp/${two(s.index)}/phantom';
      }
    }
  }

  // ---------------------------------------------------------------- receiving

  final List<int> _sysex = [];
  bool _inSysex = false;
  int _status = 0;
  final List<int> _data = [];
  final _nrpnMsb = List<int>.filled(16, -1), _nrpnLsb = List<int>.filled(16, -1), _vc = List<int>.filled(16, -1);
  int _bank = 0;

  void _onBytes(Uint8List bytes) {
    for (final b in bytes) {
      if (_inSysex) {
        if (b == 0xF7) {
          _inSysex = false;
          _onSysex(_sysex);
          _sysex.clear();
        } else if (b < 0x80) {
          if (_sysex.length < 512) _sysex.add(b);
        } else {
          _inSysex = false; // broken SysEx
          _sysex.clear();
        }
        continue;
      }
      if (b == 0xF0) {
        _inSysex = true;
        _sysex
          ..clear()
          ..add(b);
        continue;
      }
      if (b >= 0xF8) continue; // real-time (active sensing…)
      if (b >= 0x80) {
        _status = b;
        _data.clear();
        continue;
      }
      if (_status == 0) continue;
      _data.add(b);
      final type = _status & 0xF0;
      final need = type == 0xC0 || type == 0xD0 ? 1 : 2;
      if (_data.length < need) continue;
      _onMessage(_status, List.of(_data));
      _data.clear(); // running status keeps _status
    }
  }

  void _onMessage(int status, List<int> d) {
    final type = status & 0xF0, ch = status & 0x0F;
    switch (type) {
      case 0x90:
        if (d[1] == 0) return; // the note-off half
        _value('M/$ch/${d[0]}', d[1] >= 0x40 ? 1 : 0);
      case 0xB0:
        switch (d[0]) {
          case 0x63:
            _nrpnMsb[ch] = d[1];
          case 0x62:
            _nrpnLsb[ch] = d[1];
          case 0x06:
            _vc[ch] = d[1];
            if (map.dialect == AhDialect.dlive && _nrpnMsb[ch] >= 0) {
              _value('N/$ch/${_nrpnMsb[ch]}/${_nrpnLsb[ch]}/0', d[1]);
            }
          case 0x26:
            if (_nrpnMsb[ch] < 0 || _vc[ch] < 0) return;
            if (map.dialect == AhDialect.qu) {
              _value('N/0/${_nrpnMsb[ch]}/${_nrpnLsb[ch]}/${d[1]}', _vc[ch]);
            } else if (map.dialect != AhDialect.dlive) {
              final hit = _back['N/0/${_nrpnMsb[ch]}/${_nrpnLsb[ch]}/0'];
              // SQ / CQ: levels are 14-bit; switches are in the low byte
              _value('N/0/${_nrpnMsb[ch]}/${_nrpnLsb[ch]}/0',
                  hit != null && hit.$2 == AhKind.level ? (_vc[ch] << 7) | d[1] : d[1]);
            }
          case 0x00:
            _bank = d[1];
        }
      case 0xC0:
        final scene = map.dialect == AhDialect.qu ? d[0] : _bank * 128 + d[0];
        _emit(MixerProfile.yamahaSceneCurrentAddr, scene + 1);
      case 0xE0:
        _value('E/0/${d[0]}', d[1]);
    }
  }

  void _value(String key, int v) {
    final hit = _back[key];
    if (hit == null) return;
    final (addr, kind) = hit;
    final out = map.decode(kind, v);
    if (out != null) _emit(addr, out);
  }

  void _onSysex(List<int> s) {
    final dl = AhMap.dliveHeader, qu = AhMap.quHeader;
    bool starts(List<int> h) {
      if (s.length < h.length) return false;
      for (var i = 0; i < h.length; i++) {
        if (s[i] != h[i]) return false;
      }
      return true;
    }

    if (map.dialect == AhDialect.qu && starts(qu)) {
      final r = s.sublist(qu.length);
      if (r.length >= 2 && r[0] == 0x02) {
        final hit = _back['S2/0/${r[1]}'];
        if (hit != null) _emit(hit.$1, String.fromCharCodes(r.sublist(2).where((c) => c >= 0x20 && c < 0x7F)));
      }
      return;
    }
    if (map.dialect == AhDialect.dlive && starts(dl)) {
      final r = s.sublist(dl.length);
      if (r.length < 3) return;
      final n = r[0] & 0x0F;
      switch (r[1]) {
        case 0x02: // name
          final hit = _back['S2/$n/${r[2]}'];
          if (hit != null) _emit(hit.$1, String.fromCharCodes(r.sublist(3).where((c) => c >= 0x20 && c < 0x7F)));
        case 0x05: // colour
          if (r.length >= 4) _value('S5/$n/${r[2]}', r[3]);
        case 0x0D: // send level
          if (r.length >= 6) _value('SD/$n/${r[2]}/${r[3] & 0x0F}/${r[4]}', r[5]);
        case 0x0E:
          if (r.length >= 6) _value('SE/$n/${r[2]}/${r[3] & 0x0F}/${r[4]}', r[5] >= 0x40 ? 1 : 0);
      }
    }
  }

  // ---------------------------------------------------------------- sending

  @override
  Stream<OscMessage> get messages => _out.stream;

  @override
  void send(OscMessage m) {
    final a = m.address;
    switch (a) {
      case '/xinfo':
        _write(map.pingBytes());
        return;
      case '/xremote':
      case '/meters':
        return;
      case '/-snap/load':
        if (m.args.isNotEmpty && m.args.first is num) {
          final n = (m.args.first as num).toInt();
          _write(map.sceneBytes(n));
          _emit(MixerProfile.yamahaSceneCurrentAddr, n);
        }
        return;
    }
    final p = map.toAh(a);
    if (p == null) return; // the console has no such control
    _back[p.key] = (a, p.kind);
    if (m.args.isEmpty) {
      final g = map.getBytes(p);
      if (g.isNotEmpty) {
        _write(g);
      } else if (!_syncedAll) {
        // Qu: one request returns the whole state
        _syncedAll = true;
        _write(map.syncAllBytes());
      }
      return;
    }
    final arg = m.args.first;
    if (p.kind == AhKind.name) {
      _write(map.setBytes(p, 0, text: arg.toString()));
      return;
    }
    final v = map.encode(p.kind, arg);
    if (v != null) _write(map.setBytes(p, v));
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  @override
  void close() {
    _closed = true;
    _retry?.cancel();
    _sub?.cancel();
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _out.close();
  }
}
