/// Allen & Heath console families: their MIDI protocols differ.
enum AhDialect { sq, cq, qu, dlive }

AhDialect ahDialectFor(String model) {
  final m = model.toUpperCase();
  if (m.startsWith('SQ')) return AhDialect.sq;
  if (m.startsWith('CQ')) return AhDialect.cq;
  if (m.startsWith('QU')) return AhDialect.qu;
  return AhDialect.dlive; // dLive, Avantis
}

/// Sizes of an Allen & Heath console. The MIDI protocol can't report them,
/// so they come from the model (dLive / Avantis: a common bus setup).
class AhLayout {
  const AhLayout({
    required this.inputs,
    this.stereoInputs = 0,
    required this.fxReturns,
    required this.mixes,
    required this.fxSends,
    this.matrices = 0,
    required this.dcas,
    required this.muteGroups,
    required this.scenes,
    this.mixWord = 'Mix',
    this.stereoLabels = const [],
  });

  final int inputs;
  final int stereoInputs;
  final int fxReturns;
  final int mixes;
  final int fxSends;
  final int matrices;
  final int dcas;
  final int muteGroups;
  final int scenes;
  final String mixWord;
  final List<String> stereoLabels;

  String stereoLabel(int i) => i <= stereoLabels.length ? stereoLabels[i - 1] : 'St $i';

  /// Models offered on the connect screen (label, model id).
  static const models = [
    ('SQ-5 / SQ-6 / SQ-7', 'SQ'),
    ('CQ-12T / CQ-18T / CQ-20B', 'CQ'),
    ('Qu-16', 'QU16'),
    ('Qu-24', 'QU24'),
    ('Qu-32 / Qu-SB / Qu-Pac', 'QU32'),
    ('dLive', 'DLIVE'),
    ('Avantis', 'AVANTIS'),
  ];

  static String labelFor(String model) {
    for (final (label, id) in models) {
      if (id == model) return label;
    }
    return model;
  }

  factory AhLayout.forModel(String model) {
    final m = model.toUpperCase();
    switch (ahDialectFor(m)) {
      case AhDialect.sq:
        return const AhLayout(inputs: 48, fxReturns: 8, mixes: 12, fxSends: 4, matrices: 3, dcas: 8, muteGroups: 8, scenes: 300);
      case AhDialect.cq:
        // CQ inputs 1-16 plus stereo ST1, ST2, USB and Bluetooth; outputs 1-6.
        return const AhLayout(
          inputs: 16,
          stereoInputs: 4,
          fxReturns: 0,
          mixes: 6,
          fxSends: 4,
          dcas: 4,
          muteGroups: 4,
          scenes: 100,
          mixWord: 'Out',
          stereoLabels: ['ST1', 'ST2', 'USB', 'BT'],
        );
      case AhDialect.qu:
        final ch = m.contains('16') ? 16 : (m.contains('24') ? 24 : 32);
        return AhLayout(
          inputs: ch,
          stereoInputs: 3,
          fxReturns: 4,
          mixes: 7, // Mix 1-4 mono, 5/6, 7/8, 9/10 stereo
          fxSends: ch == 16 ? 2 : 4,
          matrices: ch == 16 ? 0 : 2,
          dcas: 4,
          muteGroups: 4,
          scenes: 100,
          stereoLabels: const ['ST1', 'ST2', 'ST3'],
        );
      case AhDialect.dlive:
        final avantis = m.contains('AVANTIS');
        return AhLayout(
          inputs: avantis ? 64 : 128,
          fxReturns: 16,
          mixes: 16,
          fxSends: 16,
          matrices: 8,
          dcas: avantis ? 16 : 24,
          muteGroups: 8,
          scenes: 500,
          mixWord: 'Aux',
        );
    }
  }
}
