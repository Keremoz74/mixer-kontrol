import 'dart:math' as math;

/// Band types in console order (eq/N/type values 0..5).
enum EqType { lowCut, lowShelf, peq, veq, highShelf, highCut }

const eqTypeLabels = ['Low Cut', 'Low Shelf', 'PEQ', 'VEQ', 'High Shelf', 'High Cut'];

bool isCut(EqType t) => t == EqType.lowCut || t == EqType.highCut;

EqType eqTypeOf(int v) => EqType.values[v.clamp(0, EqType.values.length - 1)];

/// Magnitude (dB) of one band at frequency [f], using RBJ cookbook biquads.
/// Used only to draw the curve; the console does the actual filtering.
double bandResponseDb(EqType type, double f0, double gainDb, double q, double f,
    {double fs = 48000}) {
  f0 = f0.clamp(10.0, fs * 0.45);
  final w0 = 2 * math.pi * f0 / fs;
  final cw = math.cos(w0);
  final alpha = math.sin(w0) / (2 * q);
  final a = math.pow(10, gainDb / 40).toDouble();
  double b0, b1, b2, a0, a1, a2;

  switch (type) {
    case EqType.peq:
    case EqType.veq:
      b0 = 1 + alpha * a;
      b1 = -2 * cw;
      b2 = 1 - alpha * a;
      a0 = 1 + alpha / a;
      a1 = -2 * cw;
      a2 = 1 - alpha / a;
    case EqType.lowShelf:
      final s = 2 * math.sqrt(a) * alpha;
      b0 = a * ((a + 1) - (a - 1) * cw + s);
      b1 = 2 * a * ((a - 1) - (a + 1) * cw);
      b2 = a * ((a + 1) - (a - 1) * cw - s);
      a0 = (a + 1) + (a - 1) * cw + s;
      a1 = -2 * ((a - 1) + (a + 1) * cw);
      a2 = (a + 1) + (a - 1) * cw - s;
    case EqType.highShelf:
      final s = 2 * math.sqrt(a) * alpha;
      b0 = a * ((a + 1) + (a - 1) * cw + s);
      b1 = -2 * a * ((a - 1) + (a + 1) * cw);
      b2 = a * ((a + 1) + (a - 1) * cw - s);
      a0 = (a + 1) - (a - 1) * cw + s;
      a1 = 2 * ((a - 1) - (a + 1) * cw);
      a2 = (a + 1) - (a - 1) * cw - s;
    case EqType.lowCut: // high-pass
      b0 = (1 + cw) / 2;
      b1 = -(1 + cw);
      b2 = (1 + cw) / 2;
      a0 = 1 + alpha;
      a1 = -2 * cw;
      a2 = 1 - alpha;
    case EqType.highCut: // low-pass
      b0 = (1 - cw) / 2;
      b1 = 1 - cw;
      b2 = (1 - cw) / 2;
      a0 = 1 + alpha;
      a1 = -2 * cw;
      a2 = 1 - alpha;
  }

  final w = 2 * math.pi * f / fs;
  final c1 = math.cos(w), s1 = math.sin(w);
  final c2 = math.cos(2 * w), s2 = math.sin(2 * w);
  final nr = b0 + b1 * c1 + b2 * c2;
  final ni = -(b1 * s1 + b2 * s2);
  final dr = a0 + a1 * c1 + a2 * c2;
  final di = -(a1 * s1 + a2 * s2);
  final mag2 = (nr * nr + ni * ni) / (dr * dr + di * di);
  if (mag2 <= 0) return -120;
  return 10 * math.log(mag2) / math.ln10;
}

/// Console-like starting point for band [b] (1-based) of an [n]-band EQ,
/// used until the real value arrives (and in demo mode).
int eqDefaultType(int b, int n) => b == 1 ? 1 : (b == n ? 4 : 2); // LShv … PEQ … HShv

double eqDefaultFreq(int b, int n) => n == 4
    ? const [100.0, 400.0, 2500.0, 10000.0][b - 1]
    : const [80.0, 200.0, 500.0, 1500.0, 4000.0, 10000.0][(b - 1).clamp(0, 5)];
