import 'dart:math' as math;

/// Static input → output curves for drawing; the console does the real work.

/// Gate / expander. [mode]: 0-2 expander 1:2..1:4, 3 gate, 4 duck (not a
/// static curve, drawn as unity).
double gateOut(double inDb, {required int mode, required double thr, required double range}) {
  if (inDb >= thr) return inDb;
  switch (mode) {
    case 0:
    case 1:
    case 2:
      final k = (mode + 2).toDouble();
      return math.max(thr + (inDb - thr) * k, inDb - range);
    case 3:
      return inDb - range;
    default:
      return inDb;
  }
}

/// Compressor ([mode] 0) or downward expander ([mode] 1) with soft knee.
/// The console's knee value (0-5) is drawn as a knee width of 4 dB per step.
double compOut(
  double inDb, {
  required int mode,
  required double thr,
  required double ratio,
  required double knee,
  required double makeup,
}) {
  if (mode == 1) {
    if (inDb >= thr) return inDb + makeup;
    return math.max(thr + (inDb - thr) * ratio, inDb - 60) + makeup;
  }
  final w = knee * 4;
  final d = inDb - thr;
  double y;
  if (2 * d < -w) {
    y = inDb;
  } else if (w > 0 && 2 * d.abs() <= w) {
    y = inDb + (1 / ratio - 1) * math.pow(d + w / 2, 2) / (2 * w);
  } else {
    y = thr + d / ratio;
  }
  return y + makeup;
}
