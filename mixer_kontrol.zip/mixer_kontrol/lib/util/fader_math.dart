/// X32 / XR fader law: 0..1 float mapped to -inf..+10 dB in four linear segments.
double faderToDb(double f) {
  if (f <= 0) return double.negativeInfinity;
  if (f >= 0.5) return f * 40 - 30;
  if (f >= 0.25) return f * 80 - 50;
  if (f >= 0.0625) return f * 160 - 70;
  return f * 480 - 90;
}

double dbToFader(double db) {
  if (db.isInfinite && db.isNegative) return 0;
  double f;
  if (db >= -10) {
    f = (db + 30) / 40;
  } else if (db >= -30) {
    f = (db + 50) / 80;
  } else if (db >= -60) {
    f = (db + 70) / 160;
  } else {
    f = (db + 90) / 480;
  }
  return f.clamp(0.0, 1.0);
}

String formatDb(double f) {
  final db = faderToDb(f);
  if (db.isInfinite || db <= -89.5) return '-∞';
  final sign = db > 0.05 ? '+' : '';
  return '$sign${db.toStringAsFixed(1)}';
}

/// Unity (0 dB) position.
const double unityFader = 0.75;
