import 'dart:math' as math;

/// Maps the console's 0..1 OSC floats to real units and back.
abstract class Law {
  const Law();
  double toReal(double norm);
  double toNorm(double real);
}

class LinLaw extends Law {
  const LinLaw(this.min, this.max);
  final double min, max;
  @override
  double toReal(double v) => min + v.clamp(0.0, 1.0) * (max - min);
  @override
  double toNorm(double x) => ((x - min) / (max - min)).clamp(0.0, 1.0);
}

/// Logarithmic law; also works when max < min (e.g. Q runs 10 → 0.3).
class LogLaw extends Law {
  const LogLaw(this.min, this.max);
  final double min, max;
  @override
  double toReal(double v) => min * math.pow(max / min, v.clamp(0.0, 1.0));
  @override
  double toNorm(double x) => (math.log(x / min) / math.log(max / min)).clamp(0.0, 1.0);
}

const freqLaw = LogLaw(20, 20000); // EQ band frequency
const eqGainLaw = LinLaw(-15, 15); // EQ band gain, dB
const qLaw = LogLaw(10, 0.3); // EQ band Q
const hpfLaw = LogLaw(20, 400); // preamp low cut, Hz
const panLaw = LinLaw(-100, 100);
const headampGainLaw = LinLaw(-12, 60); // dB
const trimLaw = LinLaw(-18, 18); // X32 digital trim, dB

// Dynamics (same on X32 and XR)
const gateThrLaw = LinLaw(-80, 0);
const gateRangeLaw = LinLaw(3, 60);
const compThrLaw = LinLaw(-60, 0);
const attackLaw = LinLaw(0, 120); // ms
const holdLaw = LogLaw(0.02, 2000); // ms
const releaseLaw = LogLaw(5, 4000); // ms
const kneeLaw = LinLaw(0, 5);
const makeupLaw = LinLaw(0, 24); // dB
const mixLaw = LinLaw(0, 100); // %

/// dyn/ratio enum values 0..11.
const compRatios = [1.1, 1.3, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 7.0, 10.0, 20.0, 100.0];

/// gate/mode enum values 0..4.
const gateModeLabels = ['Exp 1:2', 'Exp 1:3', 'Exp 1:4', 'Gate', 'Duck'];

String formatRatio(double r) => r >= 10 ? '${r.round()}:1' : '${r.toStringAsFixed(1)}:1';

String formatMs(double ms) {
  if (ms >= 1000) return '${(ms / 1000).toStringAsFixed(2)} s';
  if (ms >= 10) return '${ms.round()} ms';
  return '${ms.toStringAsFixed(ms < 1 ? 2 : 1)} ms';
}

String formatHz(double hz) {
  if (hz >= 10000) return '${(hz / 1000).toStringAsFixed(1)} kHz';
  if (hz >= 1000) return '${(hz / 1000).toStringAsFixed(2)} kHz';
  return '${hz.round()} Hz';
}

String formatDbValue(double db) => '${db > 0.05 ? '+' : ''}${db.toStringAsFixed(1)} dB';

String formatPan(double p) {
  if (p.abs() < 1) return 'C';
  return p < 0 ? 'L${(-p).round()}' : 'R${p.round()}';
}
