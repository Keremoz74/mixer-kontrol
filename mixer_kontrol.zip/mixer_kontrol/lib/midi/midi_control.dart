import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter_midi_command/flutter_midi_command.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';

/// What a MIDI control drives.
enum MidiAction { fader, mute, solo, muteGroup }

class MidiTarget {
  const MidiTarget(this.action, this.ref, this.label);
  final MidiAction action;

  /// Strip prefix, or mute group number for [MidiAction.muteGroup].
  final String ref;
  final String label;

  String get id => '${action.name}:$ref';
}

/// A received control: CC or note, on a channel.
class MidiSource {
  const MidiSource(this.isNote, this.channel, this.number);
  final bool isNote;
  final int channel; // 0-15
  final int number;

  String get key => '${isNote ? 'n' : 'c'}:$channel:$number';
  String get label => '${isNote ? 'Note' : 'CC'} $number · ch ${channel + 1}';

  static MidiSource? fromKey(String k) {
    final p = k.split(':');
    if (p.length != 3) return null;
    final ch = int.tryParse(p[1]), n = int.tryParse(p[2]);
    if (ch == null || n == null || ch < 0 || ch > 15 || n < 0 || n > 127) return null;
    return MidiSource(p[0] == 'n', ch, n);
  }
}

/// USB MIDI controllers driving faders, mutes, solos and mute groups.
/// Mappings ("MIDI learn") are stored per console family.
class MidiControl extends ChangeNotifier {
  MidiControl(this.mixer) {
    _load();
  }

  final MixerController mixer;
  final MidiCommand _midi = MidiCommand();
  StreamSubscription<MidiPacket>? _sub;

  /// source key → target id
  final Map<String, String> mappings = {};

  /// Set while waiting for the user to move a control.
  MidiTarget? learning;
  MidiSource? lastSource;
  String? connectedName;
  MidiDevice? _device;
  String? error;

  String get _prefsKey => 'midi_map_${mixer.profile.family.name}';

  List<MidiTarget> get targets {
    final p = mixer.profile;
    String name(Strip s) {
      final n = mixer.param(s.nameAddr).value;
      return n is String && n.trim().isNotEmpty ? '${s.defaultLabel} (${n.trim()})' : s.defaultLabel;
    }

    return [
      for (final s in p.allStrips) ...[
        MidiTarget(MidiAction.fader, s.prefix, '${name(s)} fader'),
        MidiTarget(MidiAction.mute, s.prefix, '${name(s)} mute'),
        if (p.soloAddr(s) != null) MidiTarget(MidiAction.solo, s.prefix, '${name(s)} solo'),
      ],
      for (var g = 1; g <= p.muteGroupCount; g++) MidiTarget(MidiAction.muteGroup, '$g', 'Mute group $g'),
    ];
  }

  MidiTarget? targetById(String id) {
    for (final t in targets) {
      if (t.id == id) return t;
    }
    return null;
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_prefsKey);
      if (raw == null || raw.length > 100000) return;
      final m = jsonDecode(raw);
      if (m is Map) {
        m.forEach((k, v) {
          if (k is String && v is String && MidiSource.fromKey(k) != null && v.length < 64) mappings[k] = v;
        });
      }
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, jsonEncode(mappings));
    } catch (_) {}
  }

  Future<List<MidiDevice>> devices() async {
    try {
      return (await _midi.devices) ?? const [];
    } catch (e) {
      error = '$e';
      notifyListeners();
      return const [];
    }
  }

  Future<void> connect(MidiDevice d) async {
    error = null;
    try {
      await _midi.connectToDevice(d);
      connectedName = d.name;
      _device = d;
      _sub ??= _midi.onMidiPacketReceived?.listen((p) => _onPacket(p.data));
    } catch (e) {
      error = 'Could not connect: $e';
    }
    notifyListeners();
  }

  void disconnectAll() {
    final d = _device;
    if (d != null) {
      try {
        // Called dynamically: the method name differs between plugin versions.
        (_midi as dynamic).disconnectDevice(d);
      } catch (_) {}
    }
    _device = null;
    _sub?.cancel();
    _sub = null;
    connectedName = null;
    notifyListeners();
  }

  void startLearn(MidiTarget t) {
    learning = t;
    notifyListeners();
  }

  void cancelLearn() {
    learning = null;
    notifyListeners();
  }

  void unmap(String sourceKey) {
    mappings.remove(sourceKey);
    _save();
    notifyListeners();
  }

  void _onPacket(Uint8List data) {
    var i = 0;
    while (i < data.length) {
      final status = data[i];
      if (status < 0x80) {
        i++;
        continue;
      }
      final type = status & 0xF0;
      final ch = status & 0x0F;
      if ((type == 0xB0 || type == 0x90 || type == 0x80) && i + 2 < data.length) {
        final num = data[i + 1] & 0x7F, val = data[i + 2] & 0x7F;
        final note = type != 0xB0;
        _handle(MidiSource(note, ch, num), type == 0x80 ? 0 : val);
        i += 3;
      } else {
        i++;
      }
    }
  }

  void _handle(MidiSource src, int value) {
    lastSource = src;
    final l = learning;
    if (l != null) {
      mappings.removeWhere((k, v) => v == l.id);
      mappings[src.key] = l.id;
      learning = null;
      _save();
      notifyListeners();
      return;
    }
    final id = mappings[src.key];
    if (id == null) return;
    final t = targetById(id);
    if (t == null) return;
    final p = mixer.profile;
    Strip? strip;
    for (final s in p.allStrips) {
      if (s.prefix == t.ref) strip = s;
    }
    final press = src.isNote ? value > 0 : value >= 64;
    switch (t.action) {
      case MidiAction.fader:
        if (strip != null) mixer.setFader(strip.faderAddr, value / 127.0);
      case MidiAction.mute:
        if (strip != null && press && !mixer.muteLock.value) mixer.toggleOn(strip.onAddr);
      case MidiAction.solo:
        if (strip != null && press) mixer.toggleSolo(strip);
      case MidiAction.muteGroup:
        final g = int.tryParse(t.ref);
        if (g != null && press && !mixer.muteLock.value) {
          final a = p.muteGroupAddr(g);
          mixer.setFlag(a, !mixer.flagOf(a));
        }
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
