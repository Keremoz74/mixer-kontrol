import 'osc_message.dart';

/// The connection to one mixer, whatever protocol it speaks. The rest of the
/// app talks in its own (X32-style) OSC addresses; a link for another brand
/// translates them to and from that console's protocol.
abstract class MixerLink {
  /// Messages from the mixer, in app addresses.
  Stream<OscMessage> get messages;

  /// A value change ([OscMessage] with one argument) or a query (no args).
  void send(OscMessage m);

  /// Sends [address] with no args and waits for the reply with that address.
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)});

  void close();
}
