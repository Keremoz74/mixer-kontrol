import 'dart:async';
import 'dart:io';

import 'mixer_link.dart';
import 'osc_message.dart';

/// UDP OSC client bound to one mixer (host + port).
class OscClient implements MixerLink {
  OscClient._(this._socket, this.host, this.port) {
    _socket.listen((event) {
      if (event != RawSocketEvent.read) return;
      final dg = _socket.receive();
      if (dg == null) return;
      // Security: only the mixer we connected to may talk to us. Packets from
      // any other device or port on the network are dropped, so nobody else
      // can inject fake fader values, names or meters.
      if (dg.address != host || dg.port != port) return;
      // An OSC message from the mixer is never anywhere near this big.
      if (dg.data.length > 16384) return;
      final msg = OscMessage.decode(dg.data);
      if (msg != null && !_controller.isClosed) _controller.add(msg);
    });
  }

  final RawDatagramSocket _socket;
  final InternetAddress host;
  final int port;
  final _controller = StreamController<OscMessage>.broadcast();

  @override
  Stream<OscMessage> get messages => _controller.stream;

  static Future<OscClient> open(String host, int port) async {
    final addr = InternetAddress.tryParse(host) ??
        (await InternetAddress.lookup(host, type: InternetAddressType.IPv4)).first;
    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    return OscClient._(socket, addr, port);
  }

  @override
  void send(OscMessage m) {
    try {
      _socket.send(m.encode(), host, port);
    } catch (_) {
      // Network temporarily unavailable; keep-alive will recover.
    }
  }

  /// Sends [address] with no args and waits for the reply with the same address.
  @override
  Future<OscMessage?> request(String address,
      {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  @override
  void close() {
    _controller.close();
    _socket.close();
  }
}
