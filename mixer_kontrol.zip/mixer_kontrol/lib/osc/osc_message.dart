import 'dart:convert';
import 'dart:typed_data';

/// Minimal OSC 1.0 message (X32 / XR use int32, float32, string and blob).
class OscMessage {
  const OscMessage(this.address, [this.args = const []]);

  final String address;
  final List<Object> args;

  Uint8List encode() {
    final b = BytesBuilder();
    _writeString(b, address);
    final tags = StringBuffer(',');
    for (final a in args) {
      if (a is int) {
        tags.write('i');
      } else if (a is double) {
        tags.write('f');
      } else if (a is String) {
        tags.write('s');
      } else if (a is Uint8List) {
        tags.write('b');
      } else {
        throw ArgumentError('Unsupported OSC argument: ${a.runtimeType}');
      }
    }
    _writeString(b, tags.toString());
    for (final a in args) {
      if (a is int) {
        b.add((ByteData(4)..setInt32(0, a)).buffer.asUint8List());
      } else if (a is double) {
        b.add((ByteData(4)..setFloat32(0, a)).buffer.asUint8List());
      } else if (a is String) {
        _writeString(b, a);
      } else if (a is Uint8List) {
        b.add((ByteData(4)..setInt32(0, a.length)).buffer.asUint8List());
        b.add(a);
        final pad = (4 - a.length % 4) % 4;
        if (pad > 0) b.add(Uint8List(pad));
      }
    }
    return b.toBytes();
  }

  /// Returns null for bundles or malformed packets.
  static OscMessage? decode(Uint8List data) {
    try {
      final bd = ByteData.sublistView(data);
      var pos = 0;

      String readString() {
        var end = pos;
        while (end < data.length && data[end] != 0) {
          end++;
        }
        final s = utf8.decode(data.sublist(pos, end), allowMalformed: true);
        pos = (end + 4) & ~3; // skip terminator + padding
        return s;
      }

      final address = readString();
      if (!address.startsWith('/')) return null;
      if (pos >= data.length) return OscMessage(address);

      final tags = readString();
      if (!tags.startsWith(',')) return OscMessage(address);

      final args = <Object>[];
      for (final t in tags.substring(1).split('')) {
        switch (t) {
          case 'i':
            args.add(bd.getInt32(pos));
            pos += 4;
          case 'f':
            args.add(bd.getFloat32(pos));
            pos += 4;
          case 's':
            args.add(readString());
          case 'b':
            final len = bd.getInt32(pos);
            pos += 4;
            args.add(Uint8List.fromList(data.sublist(pos, pos + len)));
            pos += (len + 3) & ~3;
          default:
            return OscMessage(address, args); // unknown tag: stop here
        }
      }
      return OscMessage(address, args);
    } catch (_) {
      return null;
    }
  }

  static void _writeString(BytesBuilder b, String s) {
    final bytes = utf8.encode(s);
    b.add(bytes);
    b.add(Uint8List(4 - bytes.length % 4)); // at least one null terminator
  }

  @override
  String toString() => '$address $args';
}
