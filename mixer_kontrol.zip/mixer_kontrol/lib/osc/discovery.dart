import 'dart:async';
import 'dart:io';

import 'osc_message.dart';

class DiscoveredMixer {
  const DiscoveredMixer({
    required this.ip,
    required this.port,
    required this.name,
    required this.model,
    required this.firmware,
  });

  final String ip;
  final int port;
  final String name;
  final String model;
  final String firmware;
}

/// Broadcasts /xinfo on the X32 (10023) and XR (10024) ports and collects replies.
/// Note: on iOS, broadcast needs the multicast networking entitlement; manual IP
/// connection works without it.
class MixerDiscovery {
  static Future<List<DiscoveredMixer>> scan(
      {Duration timeout = const Duration(seconds: 2)}) async {
    final found = <String, DiscoveredMixer>{};
    RawDatagramSocket? socket;
    try {
      socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      socket.broadcastEnabled = true;
      final s = socket;
      s.listen((event) {
        if (event != RawSocketEvent.read) return;
        final dg = s.receive();
        if (dg == null) return;
        final m = OscMessage.decode(dg.data);
        if (m == null || m.address != '/xinfo' || m.args.length < 3) return;
        found[dg.address.address] = DiscoveredMixer(
          ip: dg.address.address,
          port: dg.port,
          name: m.args[1].toString(),
          model: m.args[2].toString(),
          firmware: m.args.length > 3 ? m.args[3].toString() : '',
        );
      });
      final packet = const OscMessage('/xinfo').encode();
      final bcast = InternetAddress('255.255.255.255');
      for (var i = 0; i < 2; i++) {
        for (final port in const [10023, 10024]) {
          try {
            s.send(packet, bcast, port);
          } catch (_) {}
        }
        await Future<void>.delayed(const Duration(milliseconds: 300));
      }
      await Future<void>.delayed(timeout);
    } catch (_) {
      // Ignore: discovery is best effort.
    } finally {
      socket?.close();
    }
    return found.values.toList();
  }
}
