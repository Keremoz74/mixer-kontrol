import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

/// How a console encodes the values inside a /meters blob.
enum MeterFormat {
  /// X32 / M32: 32-bit floats, linear level (1.0 = 0 dBFS).
  float32Linear,

  /// XR / MR: signed 16-bit, 1/256 dB per step.
  int16Db,
}

/// Decodes a /meters blob into dBFS values.
///
/// Layout: a 32-bit value count followed by the values. Both are documented as
/// little-endian; the count is used to confirm the byte order, and the values
/// are read with the same order.
List<double> decodeMeterBlob(Uint8List blob, MeterFormat format) {
  if (blob.length < 4) return const [];
  final bd = ByteData.sublistView(blob);
  final size = format == MeterFormat.float32Linear ? 4 : 2;
  final maxCount = (blob.length - 4) ~/ size;

  final le = bd.getInt32(0, Endian.little);
  final be = bd.getInt32(0, Endian.big);
  Endian endian;
  int count;
  if (le > 0 && le <= maxCount) {
    endian = Endian.little;
    count = le;
  } else if (be > 0 && be <= maxCount) {
    endian = Endian.big;
    count = be;
  } else {
    endian = Endian.little;
    count = maxCount;
  }

  final out = List<double>.filled(count, double.negativeInfinity);
  for (var i = 0; i < count; i++) {
    if (format == MeterFormat.float32Linear) {
      final v = bd.getFloat32(4 + i * 4, endian);
      out[i] = v > 0 && v.isFinite ? 20 * math.log(v) / math.ln10 : double.negativeInfinity;
    } else {
      final s = bd.getInt16(4 + i * 2, endian);
      out[i] = s <= -32768 ? double.negativeInfinity : s / 256.0;
    }
  }
  return out;
}

/// Latest meter level (dBFS) per strip, keyed by the strip's OSC prefix.
/// One notification per meter packet; painters listen to it directly so the
/// strips themselves never rebuild for metering.
class MeterLevels extends ChangeNotifier {
  final Map<String, double> _db = {};

  double db(String key) => _db[key] ?? double.negativeInfinity;

  void update(Map<String, double> values) {
    _db.addAll(values);
    notifyListeners();
  }

  void clear() {
    _db.clear();
    notifyListeners();
  }
}
