import 'fx_catalog.dart';
import 'mixer_controller.dart';
import 'mixer_profile.dart';

// Channel inserts: put one of the console's own effects "on" a channel,
// like a plugin.
//
// XR (verified): /ch/NN/insert/on, /ch/NN/insert/fxslot 0-8 =
//   OFF, FX1A, FX1B, FX2A, FX2B, FX3A, FX3B, FX4A, FX4B. Buses: /bus/N/insert/...
// X32: /ch/NN/insert/on, /insert/pos (PRE, POST), /insert/sel 0-22 =
//   OFF, FX1L, FX1R … FX8L, FX8R, AUX1 … AUX6 (AUX = external insert).
//   Buses, matrices and Main LR have the same insert block.
//
// Value for FX slot s (1-based), side h (0 = A/L, 1 = B/R) is 1 + (s-1)*2 + h
// on both families.

extension InsertAddresses on MixerProfile {
  bool supportsInsert(Strip s) => isExternal
      ? false
      : family == MixerFamily.x32
      ? const {StripType.channel, StripType.bus, StripType.matrix, StripType.main}.contains(s.type)
      : const {StripType.channel, StripType.bus}.contains(s.type);

  String insertOnAddr(Strip s) => '${s.prefix}/insert/on';
  String insertSelAddr(Strip s) => family == MixerFamily.x32 ? '${s.prefix}/insert/sel' : '${s.prefix}/insert/fxslot';
  String? insertPosAddr(Strip s) => family == MixerFamily.x32 ? '${s.prefix}/insert/pos' : null;

  List<Strip> get insertStrips => [for (final s in allStrips) if (supportsInsert(s)) s];

  int insertValue(int slot, int side) => 1 + (slot - 1) * 2 + side;

  /// FX slot (1-based) for an insert value, or null (OFF / external aux).
  int? insertSlot(int v) => v >= 1 && v <= fxSlots * 2 ? (v - 1) ~/ 2 + 1 : null;
  int insertSide(int v) => (v - 1) % 2;

  String sideName(int side) => family == MixerFamily.x32 ? (side == 0 ? 'L' : 'R') : (side == 0 ? 'A' : 'B');

  String insertLabel(int v) {
    if (v <= 0) return 'Off';
    final slot = insertSlot(v);
    if (slot != null) return 'FX$slot ${sideName(insertSide(v))}';
    if (family == MixerFamily.x32 && v >= 17 && v <= 22) return 'Aux ${v - 16} (external)';
    return '—';
  }

  /// Everything needed to know which slots are free.
  List<String> get insertAddresses => [
        for (var slot = 1; slot <= fxSlots; slot++) fxTypeAddr(slot),
        if (family == MixerFamily.x32)
          for (var slot = 1; slot <= 4; slot++) fxSourceAddr(slot),
        for (final s in insertStrips) ...[
          insertOnAddr(s),
          insertSelAddr(s),
          if (insertPosAddr(s) != null) insertPosAddr(s)!,
        ],
      ];
}

/// Effects that process each half (A/L, B/R) independently: one slot can
/// serve two mono channels.
const dualFxCodes = {
  'GEQ2', 'TEQ2', 'DES2', 'P1A2', 'PQ5S', 'CMB2', 'FAC2', 'LEC2', 'ULC2', //
  'ENH2', 'EXC2', 'AMP2', 'DRV2', 'PIT2',
};

/// A console effect offered as a channel "plugin".
class PluginDef {
  const PluginDef(this.code, this.name, this.blurb, this.goodFor);
  final String code;
  final String name;
  final String blurb;
  final List<String> goodFor;
}

const pluginGroups = ['Vocals', 'Guitars', 'Bass', 'Drums', 'Any source'];

const pluginCatalog = <PluginDef>[
  PluginDef('DES2', 'De-Esser', 'Tames harsh "s" and "t" sounds', ['Vocals']),
  PluginDef('FAC2', 'Fair Compressor', 'Smooth, vintage-style vocal compression', ['Vocals', 'Bass']),
  PluginDef('LEC2', 'Leisure Compressor', 'Simple, musical leveling (opto style)', ['Vocals', 'Bass', 'Guitars']),
  PluginDef('ULC2', 'Ultimo Compressor', 'Fast, punchy (FET style)', ['Drums', 'Vocals', 'Bass']),
  PluginDef('PIT2', 'Pitch Shifter', 'Doubling / octave effects', ['Vocals', 'Guitars']),
  PluginDef('ENH2', 'Enhancer', 'Adds clarity and presence', ['Vocals', 'Guitars', 'Any source']),
  PluginDef('EXC2', 'Exciter', 'Brightness and air', ['Vocals', 'Any source']),
  PluginDef('AMP2', 'Guitar Amp', 'Amp simulation for DI guitars', ['Guitars']),
  PluginDef('DRV2', 'Tube Stage', 'Warmth and saturation', ['Guitars', 'Bass', 'Vocals']),
  PluginDef('CMB2', 'Combinator', 'Multiband compressor', ['Any source', 'Bass']),
  PluginDef('WAVD', 'Wave Designer', 'Shapes attack and sustain (stereo, uses whole slot)', ['Drums']),
  PluginDef('LIM', 'Precision Limiter', 'Brick-wall limiting (stereo, uses whole slot)', ['Any source']),
  PluginDef('GEQ2', 'Graphic EQ', '31-band graphic EQ', ['Any source']),
  PluginDef('TEQ2', 'TruEQ', 'Corrected 31-band graphic EQ', ['Any source']),
  PluginDef('P1A2', 'Xtec EQ1', 'Vintage passive-style EQ', ['Vocals', 'Bass', 'Any source']),
  PluginDef('PQ5S', 'Xtec EQ5', 'Vintage mid-range EQ', ['Vocals', 'Guitars', 'Any source']),
];

/// Who uses an FX slot right now.
class SlotUse {
  SlotUse(this.slot);
  final int slot;
  FxType? type;

  /// Strips inserting this slot, by side (0 = A/L, 1 = B/R).
  final Map<int, List<Strip>> insertedBy = {0: [], 1: []};

  /// X32 slots 1-4: mix bus feeding it as a send effect (null = none / INS).
  SendTarget? sendFeed;

  bool get hasInserts => insertedBy[0]!.isNotEmpty || insertedBy[1]!.isNotEmpty;
  bool sideFree(int side) => insertedBy[side]!.isEmpty;
}

Map<int, SlotUse> slotUses(MixerController c) {
  final p = c.profile;
  final out = <int, SlotUse>{};
  for (var slot = 1; slot <= p.fxSlots; slot++) {
    final u = SlotUse(slot);
    final list = p.fxTypesForSlot(slot);
    final v = c.param(p.fxTypeAddr(slot)).value;
    if (v is num && v.toInt() >= 0 && v.toInt() < list.length) u.type = fxCatalog[list[v.toInt()]];
    if (p.family == MixerFamily.x32 && slot <= 4) {
      final src = c.param(p.fxSourceAddr(slot)).value;
      if (src is num && src.toInt() >= 1 && src.toInt() <= p.sendTargets.length) {
        u.sendFeed = p.sendTargets[src.toInt() - 1];
      }
    }
    out[slot] = u;
  }
  for (final s in p.insertStrips) {
    final v = c.param(p.insertSelAddr(s)).value;
    if (v is! num) continue;
    final slot = p.insertSlot(v.toInt());
    if (slot == null) continue;
    out[slot]?.insertedBy[p.insertSide(v.toInt())]!.add(s);
  }
  return out;
}

/// A place where [plugin] could go for [strip], with what it would cost.
class SlotOption {
  SlotOption({required this.slot, required this.side, required this.changesType, required this.warning, required this.score});
  final int slot;
  final int side;

  /// The slot's current effect would be replaced.
  final bool changesType;

  /// Human-readable consequence, empty if none.
  final String warning;

  /// Higher is better; the best option is suggested.
  final int score;
}

List<SlotOption> slotOptions(MixerController c, Strip strip, PluginDef plugin) {
  final p = c.profile;
  final uses = slotUses(c);
  final dual = dualFxCodes.contains(plugin.code);
  final out = <SlotOption>[];
  for (var slot = 1; slot <= p.fxSlots; slot++) {
    if (!p.fxTypesForSlot(slot).contains(plugin.code)) continue;
    final u = uses[slot]!;
    final sameType = u.type?.code == plugin.code;
    final others = [...u.insertedBy[0]!, ...u.insertedBy[1]!].where((s) => s.prefix != strip.prefix).toList();
    for (final side in dual ? const [0, 1] : const [0]) {
      final sideTaken = u.insertedBy[side]!.any((s) => s.prefix != strip.prefix);
      if (sideTaken) continue;
      final changesType = !sameType;
      // Changing the effect type would break any other channel using this slot.
      if (changesType && others.isNotEmpty) continue;
      // A stereo effect needs the whole slot.
      if (!dual && others.isNotEmpty) continue;
      final warns = <String>[];
      var score = 0;
      if (sameType && dual) {
        score += 100; // share a slot that already runs this effect
      } else if (u.type == null) {
        score += 50;
      }
      if (u.sendFeed != null) {
        warns.add('FX$slot is the send effect for ${u.sendFeed!.label}${u.type == null ? '' : ' (${u.type!.name})'}');
        score -= 80;
      } else if (p.family == MixerFamily.xr && !u.hasInserts && changesType) {
        warns.add('FX$slot may be in use as a send effect${u.type == null ? '' : ' (${u.type!.name})'}');
        score -= 40;
      }
      if (changesType && u.type != null) warns.add('replaces ${u.type!.name}');
      if (p.family == MixerFamily.x32 && slot > 4) score += 30; // insert-only slots first
      out.add(SlotOption(
        slot: slot,
        side: side,
        changesType: changesType,
        warning: warns.join('; '),
        score: score - slot,
      ));
    }
  }
  out.sort((a, b) => b.score.compareTo(a.score));
  return out;
}

/// Loads [plugin] into [opt] (if needed) and inserts it on [strip].
Future<void> insertPlugin(MixerController c, Strip strip, PluginDef plugin, SlotOption opt) async {
  final p = c.profile;
  if (opt.changesType) {
    c.set(p.fxTypeAddr(opt.slot), p.fxTypesForSlot(opt.slot).indexOf(plugin.code));
    if (!c.isDemo) await Future<void>.delayed(const Duration(milliseconds: 300));
  }
  c.set(p.insertSelAddr(strip), p.insertValue(opt.slot, opt.side));
  c.set(p.insertOnAddr(strip), 1);
}

void removeInsert(MixerController c, Strip strip) {
  c.set(c.profile.insertOnAddr(strip), 0);
  c.set(c.profile.insertSelAddr(strip), 0);
}
