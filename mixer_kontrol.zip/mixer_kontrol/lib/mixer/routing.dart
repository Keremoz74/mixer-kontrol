import 'mixer_profile.dart';

// Routing, output patch, output delay, talkback / oscillator and automix.
//
// X32 / M32
//   Channel source      /ch/NN/config/source 0 OFF, 1-32 In 1-32, 33-38 Aux 1-6,
//                       39-40 USB L/R, 41-48 FX 1L-4R, 49-64 Bus 1-16
//   Input blocks        /config/routing/IN/1-8 … 25-32  (AN / AES50 A / B / CARD)
//   Output patch        /outputs/{main 01-16, aux 01-06, p16 01-16, aes 01-02, rec 01-02}/src
//                       0 OFF, 1 Main L, 2 Main R, 3 M/C, 4-19 Bus 1-16,
//                       20-25 Matrix 1-6, 26-57 Ch 1-32 (direct), 58-65 Aux 1-8,
//                       66-73 FX 1L-4R, 74 Mon L, 75 Mon R, 76 Talkback
//                       …/pos  tap point (IN … POST)
//   Output delay        /outputs/main/NN/delay/on, …/delay/time (0.3-500 ms)
//   Talkback            /-stat/talk/A|B (engage), /config/talk/A|B/level, …/destmap
//                       (bit 0-15 Bus 1-16, 16 Main LR, 17 M/C)
//   Oscillator          /-stat/osc/on, /config/osc/level, /config/osc/f1,
//                       /config/osc/type (0 sine, 1 pink, 2 white), /config/osc/dest
//   Automix (FW 4+)     /ch/01-08/automix/group (0 off, 1 X, 2 Y), …/weight,
//                       /config/amixenable/X|Y
// XR / MR
//   Channel source      /ch/NN/config/insrc 0-15 In 1-16, 16-17 Aux L/R, 18-35 USB 1-18
//   Output patch        /routing/aux/01-06/src, /routing/p16/01-16/src, /routing/usb/01-18/src
//                       0-15 Ch 1-16, 16-17 Aux L/R, 18-25 FX 1L-4R, 26-31 Bus 1-6,
//                       32-35 FX send 1-4, 36-37 L/R, 38-55 USB 1-18
//                       …/pos tap point
//   Main outs           /routing/main/01|02/src (0 LR, 1 MON, 2-10 USB pairs)
//   Automix             /ch/NN/automix/group, …/weight, /config/amixenable/X|Y

class OutputPort {
  const OutputPort(this.group, this.label, this.srcAddr, this.posAddr, {this.delayOn, this.delayTime});
  final String group;
  final String label;
  final String srcAddr;
  final String? posAddr;
  final String? delayOn;
  final String? delayTime;
}

const routingTapLabels = ['IN', 'IN+M', '<EQ', '<EQ+M', 'EQ>', 'EQ>+M', 'PRE', 'PRE+M', 'POST'];

extension RoutingAddresses on MixerProfile {
  bool get isX32 => family == MixerFamily.x32;

  // ------------------------------------------------------------ input source

  String channelSourceAddr(Strip s) => isX32 ? '${s.prefix}/config/source' : '${s.prefix}/config/insrc';

  List<String> get channelSourceLabels => isX32
      ? [
          'Off',
          for (var i = 1; i <= 32; i++) 'In $i',
          for (var i = 1; i <= 6; i++) 'Aux $i',
          'USB L', 'USB R',
          for (var i = 1; i <= 4; i++) ...['FX ${i}L', 'FX ${i}R'],
          for (var i = 1; i <= 16; i++) 'Bus $i',
        ]
      : [
          for (var i = 1; i <= 16; i++) 'In $i',
          'Aux L', 'Aux R',
          for (var i = 1; i <= 18; i++) 'USB $i',
        ];

  List<Strip> get channelStrips => [for (final s in inputs) if (s.type == StripType.channel) s];

  // X32 input blocks
  static const x32BlockLabels = [
    'Local 1-8', 'Local 9-16', 'Local 17-24', 'Local 25-32',
    'AES50-A 1-8', 'AES50-A 9-16', 'AES50-A 17-24', 'AES50-A 25-32', 'AES50-A 33-40', 'AES50-A 41-48',
    'AES50-B 1-8', 'AES50-B 9-16', 'AES50-B 17-24', 'AES50-B 25-32', 'AES50-B 33-40', 'AES50-B 41-48',
    'Card 1-8', 'Card 9-16', 'Card 17-24', 'Card 25-32',
    'User In 1-8', 'User In 9-16', 'User In 17-24', 'User In 25-32',
  ];

  // ------------------------------------------------------------ output patch

  List<String> get outputSourceLabels => isX32
      ? [
          'Off', 'Main L', 'Main R', 'M/C',
          for (var i = 1; i <= 16; i++) 'Bus $i',
          for (var i = 1; i <= 6; i++) 'Matrix $i',
          for (var i = 1; i <= 32; i++) 'Ch $i (direct)',
          for (var i = 1; i <= 8; i++) 'Aux $i (direct)',
          for (var i = 1; i <= 4; i++) ...['FX ${i}L', 'FX ${i}R'],
          'Monitor L', 'Monitor R', 'Talkback',
        ]
      : [
          for (var i = 1; i <= 16; i++) 'Ch $i',
          'Aux L', 'Aux R',
          for (var i = 1; i <= 4; i++) ...['FX ${i}L', 'FX ${i}R'],
          for (var i = 1; i <= 6; i++) 'Bus $i',
          for (var i = 1; i <= 4; i++) 'FX send $i',
          'Main L', 'Main R',
          for (var i = 1; i <= 18; i++) 'USB $i',
        ];

  List<OutputPort> get outputPorts {
    if (isX32) {
      return [
        for (var i = 1; i <= 16; i++)
          OutputPort('Local outputs', 'Out $i', '/outputs/main/${two(i)}/src', '/outputs/main/${two(i)}/pos',
              delayOn: '/outputs/main/${two(i)}/delay/on', delayTime: '/outputs/main/${two(i)}/delay/time'),
        for (var i = 1; i <= 6; i++)
          OutputPort('Aux outputs', 'Aux out $i', '/outputs/aux/${two(i)}/src', '/outputs/aux/${two(i)}/pos'),
        for (var i = 1; i <= 16; i++)
          OutputPort('P16 / Ultranet', 'P16 $i', '/outputs/p16/${two(i)}/src', '/outputs/p16/${two(i)}/pos'),
        for (var i = 1; i <= 2; i++)
          OutputPort('AES/EBU', 'AES ${i == 1 ? 'L' : 'R'}', '/outputs/aes/${two(i)}/src', '/outputs/aes/${two(i)}/pos'),
        for (var i = 1; i <= 2; i++)
          OutputPort('2-track recorder', 'Rec ${i == 1 ? 'L' : 'R'}', '/outputs/rec/${two(i)}/src', '/outputs/rec/${two(i)}/pos'),
      ];
    }
    return [
      for (var i = 1; i <= 6; i++)
        OutputPort('Aux outputs', 'Aux out $i', '/routing/aux/${two(i)}/src', '/routing/aux/${two(i)}/pos'),
      for (var i = 1; i <= 16; i++)
        OutputPort('P16 / Ultranet', 'P16 $i', '/routing/p16/${two(i)}/src', '/routing/p16/${two(i)}/pos'),
      for (var i = 1; i <= 18; i++)
        OutputPort('USB to computer', 'USB $i', '/routing/usb/${two(i)}/src', '/routing/usb/${two(i)}/pos'),
    ];
  }

  /// Output delay time 0..1 ↔ 0.3..500 ms (X32).
  static double delayMs(double norm) => 0.3 + norm * 499.7;
  static double delayNorm(double ms) => ((ms - 0.3) / 499.7).clamp(0.0, 1.0);

  List<String> get routingAddresses => [
        for (final s in channelStrips) channelSourceAddr(s),
        if (isX32) ...MixerProfile.x32RoutingBlocks,
        for (final o in outputPorts) ...[
          o.srcAddr,
          if (o.posAddr != null) o.posAddr!,
          if (o.delayOn != null) ...[o.delayOn!, o.delayTime!],
        ],
      ];

  // ------------------------------------------------------------ talkback / oscillator (X32)

  bool get hasTalkback => isX32;
  String talkEngageAddr(String ab) => '/-stat/talk/$ab';
  String talkLevelAddr(String ab) => '/config/talk/$ab/level';
  String talkDestAddr(String ab) => '/config/talk/$ab/destmap';
  List<String> get talkDestLabels => [for (var i = 1; i <= 16; i++) 'Bus $i', 'Main LR', 'M/C'];

  static const oscOnAddr = '/-stat/osc/on';
  static const oscLevelAddr = '/config/osc/level';
  static const oscFreqAddr = '/config/osc/f1';
  static const oscTypeAddr = '/config/osc/type';
  static const oscDestAddr = '/config/osc/dest';
  static const oscTypeLabels = ['Sine', 'Pink noise', 'White noise'];
  static final oscDestLabels = [
    for (var i = 1; i <= 16; i++) 'Bus $i',
    'Main L', 'Main R', 'Main LR', 'M/C',
    for (var i = 1; i <= 6; i++) 'Matrix $i',
  ];

  List<String> get talkOscAddresses => !hasTalkback
      ? const []
      : [
          for (final ab in const ['A', 'B']) ...[talkEngageAddr(ab), talkLevelAddr(ab), talkDestAddr(ab)],
          oscOnAddr, oscLevelAddr, oscFreqAddr, oscTypeAddr, oscDestAddr,
        ];

  // ------------------------------------------------------------ automix

  /// X32 automix covers channels 1-8; XR all input channels.
  List<Strip> get automixStrips => [
        for (final s in channelStrips)
          if (!isX32 || s.index <= 8) s,
      ];
  String automixGroupAddr(Strip s) => '${s.prefix}/automix/group';
  String automixWeightAddr(Strip s) => '${s.prefix}/automix/weight';
  String automixEnableAddr(String xy) => '/config/amixenable/$xy';

  List<String> get automixAddresses => [
        automixEnableAddr('X'),
        automixEnableAddr('Y'),
        for (final s in automixStrips) ...[automixGroupAddr(s), automixWeightAddr(s)],
      ];
}
