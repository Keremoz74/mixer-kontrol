import '../util/eq_math.dart';
import '../util/param_law.dart';
import 'mixer_controller.dart';
import 'mixer_profile.dart';

/// Starting-point EQ settings for common sources. These are this app's own
/// presets, based on common live-mixing practice — not the console's factory
/// library. Every source and room is different: apply, then adjust by ear.

class EqBandSetting {
  const EqBandSetting(this.type, this.hz, this.db, [this.q = 1.5]);
  final EqType type;
  final double hz, db, q;
}

class EqPreset {
  const EqPreset(this.name, this.category, this.lowCutHz, this.bands, [this.note = '']);
  final String name;
  final String category;

  /// Preamp low cut in Hz (input channels), null = low cut off.
  final double? lowCutHz;

  /// Four bands for input channels.
  final List<EqBandSetting> bands;
  final String note;
}

const _peq = EqType.peq;
const _ls = EqType.lowShelf;
const _hs = EqType.highShelf;
const _hc = EqType.highCut;

const eqPresetCategories = ['Vocals', 'Guitars', 'Bass', 'Drums', 'Keys', 'Other'];

const channelEqPresets = <EqPreset>[
  // Vocals
  EqPreset('Lead vocal (male)', 'Vocals', 90, [
    EqBandSetting(_peq, 200, -2, 1.2),
    EqBandSetting(_peq, 450, -2, 2.0),
    EqBandSetting(_peq, 3000, 2.5, 1.5),
    EqBandSetting(_hs, 10000, 2),
  ], 'Less mud, more presence and air'),
  EqPreset('Lead vocal (female)', 'Vocals', 120, [
    EqBandSetting(_peq, 250, -2, 1.2),
    EqBandSetting(_peq, 900, -1.5, 2.0),
    EqBandSetting(_peq, 4000, 2, 1.5),
    EqBandSetting(_hs, 12000, 2.5),
  ]),
  EqPreset('Backing vocal', 'Vocals', 140, [
    EqBandSetting(_peq, 250, -3, 1.2),
    EqBandSetting(_peq, 1000, -1, 1.5),
    EqBandSetting(_peq, 3500, 1, 1.5),
    EqBandSetting(_hs, 10000, 1.5),
  ], 'Thinner, sits behind the lead'),
  EqPreset('Speech / pastor', 'Vocals', 120, [
    EqBandSetting(_peq, 200, -3, 1.0),
    EqBandSetting(_peq, 500, -2, 2.0),
    EqBandSetting(_peq, 3000, 3, 1.2),
    EqBandSetting(_hs, 8000, 1),
  ], 'Clarity and intelligibility'),
  EqPreset('Choir mic', 'Vocals', 150, [
    EqBandSetting(_peq, 250, -3, 1.0),
    EqBandSetting(_peq, 1000, -1, 1.5),
    EqBandSetting(_peq, 3500, 2, 1.5),
    EqBandSetting(_hs, 10000, 1.5),
  ]),
  // Guitars
  EqPreset('Acoustic guitar', 'Guitars', 100, [
    EqBandSetting(_peq, 200, -3, 1.2),
    EqBandSetting(_peq, 800, -1.5, 2.0),
    EqBandSetting(_peq, 5000, 2, 1.5),
    EqBandSetting(_hs, 12000, 2),
  ], 'Less boom, more sparkle'),
  EqPreset('Electric guitar', 'Guitars', 90, [
    EqBandSetting(_peq, 200, -2, 1.0),
    EqBandSetting(_peq, 600, -1, 2.0),
    EqBandSetting(_peq, 2500, 2, 1.5),
    EqBandSetting(_hc, 8000, 0, 0.7),
  ], 'Bite, with harsh top end removed'),
  // Bass
  EqPreset('Bass guitar', 'Bass', 35, [
    EqBandSetting(_ls, 80, 2, 0.7),
    EqBandSetting(_peq, 250, -3, 1.4),
    EqBandSetting(_peq, 800, 2, 1.5),
    EqBandSetting(_hs, 5000, -2),
  ], 'Solid low end and definition'),
  // Drums
  EqPreset('Kick', 'Drums', 30, [
    EqBandSetting(_peq, 60, 4, 1.4),
    EqBandSetting(_peq, 350, -5, 1.4),
    EqBandSetting(_peq, 3500, 4, 1.5),
    EqBandSetting(_hs, 10000, -3),
  ], 'Thump and beater click, no boxiness'),
  EqPreset('Snare', 'Drums', 80, [
    EqBandSetting(_peq, 200, 2, 1.4),
    EqBandSetting(_peq, 500, -2, 2.0),
    EqBandSetting(_peq, 5000, 3, 1.5),
    EqBandSetting(_hs, 10000, 1),
  ]),
  EqPreset('Toms', 'Drums', 60, [
    EqBandSetting(_peq, 100, 3, 1.4),
    EqBandSetting(_peq, 400, -4, 1.4),
    EqBandSetting(_peq, 4000, 3, 1.5),
    EqBandSetting(_hs, 10000, -1),
  ]),
  EqPreset('Overheads', 'Drums', 200, [
    EqBandSetting(_ls, 300, -2, 0.7),
    EqBandSetting(_peq, 1000, -1, 1.0),
    EqBandSetting(_peq, 5000, 1, 1.5),
    EqBandSetting(_hs, 12000, 3),
  ], 'Cymbals and room, not the kick'),
  // Keys
  EqPreset('Piano / keys', 'Keys', 60, [
    EqBandSetting(_peq, 250, -2, 1.2),
    EqBandSetting(_peq, 1000, -1, 1.5),
    EqBandSetting(_peq, 3000, 1.5, 1.5),
    EqBandSetting(_hs, 10000, 2),
  ]),
  EqPreset('Synth pad', 'Keys', 100, [
    EqBandSetting(_peq, 300, -2, 1.0),
    EqBandSetting(_peq, 1000, 0, 1.5),
    EqBandSetting(_peq, 3000, -1, 1.5),
    EqBandSetting(_hs, 10000, 1),
  ], 'Leaves room for vocals'),
  // Other
  EqPreset('Playback / media', 'Other', 30, [
    EqBandSetting(_ls, 100, 0, 0.7),
    EqBandSetting(_peq, 400, 0, 2.0),
    EqBandSetting(_peq, 2500, 0, 2.0),
    EqBandSetting(_hs, 10000, 0),
  ], 'Clean, only rumble removed'),
];

/// Flat EQ (all gains 0, console-like default bands) for any band count.
List<EqBandSetting> flatBands(int n) => [
      for (var b = 1; b <= n; b++) EqBandSetting(eqTypeOf(eqDefaultType(b, n)), eqDefaultFreq(b, n), 0, 2.0),
    ];

/// Every address a preset touches on [s].
List<String> eqPresetAddresses(Strip s) => [
      ...s.eqAddresses,
      if (s.hasDetail) ...[s.hpOnAddr, s.hpfAddr],
    ];

/// Applies [bands] (and, on input channels, the low cut) to [s].
/// Returns the previous values so the change can be undone.
Map<String, Object> applyEq(MixerController c, Strip s, List<EqBandSetting> bands, {double? lowCutHz}) {
  final before = <String, Object>{};
  for (final a in eqPresetAddresses(s)) {
    final v = c.param(a).value;
    if (v != null) before[a] = v;
  }
  c.set(s.eqOnAddr, 1);
  for (var b = 1; b <= s.eqBands && b <= bands.length; b++) {
    final x = bands[b - 1];
    c.set(s.eqAddr(b, 'type'), x.type.index);
    c.set(s.eqAddr(b, 'f'), freqLaw.toNorm(x.hz));
    c.set(s.eqAddr(b, 'g'), eqGainLaw.toNorm(x.db));
    c.set(s.eqAddr(b, 'q'), qLaw.toNorm(x.q));
  }
  if (s.hasDetail) {
    c.set(s.hpOnAddr, lowCutHz == null ? 0 : 1);
    if (lowCutHz != null) c.set(s.hpfAddr, hpfLaw.toNorm(lowCutHz));
  }
  return before;
}

void restoreEq(MixerController c, Map<String, Object> before) {
  before.forEach(c.set);
}

// ---------------------------------------------------------------- channel strip presets
// Same presets, plus gate and compressor: a full channel starting point.

class GateSetting {
  /// [mode]: 0-2 expander 1:2…1:4, 3 gate, 4 duck. Times in ms.
  const GateSetting(this.mode, this.thr, this.range, this.attack, this.hold, this.release);
  final int mode;
  final double thr, range, attack, hold, release;
}

class CompSetting {
  /// [ratioIdx] indexes compRatios (3 = 2:1, 5 = 3:1, 6 = 4:1). Times in ms.
  const CompSetting(this.thr, this.ratioIdx, this.attack, this.release, {this.knee = 2, this.makeup = 0});
  final double thr, attack, release, knee, makeup;
  final int ratioIdx;
}

class StripDyn {
  const StripDyn({this.gate, this.comp});
  final GateSetting? gate;
  final CompSetting? comp;
}

/// Dynamics per preset name; presets not listed get gate and compressor off.
const presetDynamics = <String, StripDyn>{
  'Lead vocal (male)': StripDyn(comp: CompSetting(-18, 5, 10, 120, makeup: 3)),
  'Lead vocal (female)': StripDyn(comp: CompSetting(-18, 5, 10, 120, makeup: 3)),
  'Backing vocal': StripDyn(comp: CompSetting(-20, 6, 10, 100, makeup: 3)),
  'Speech / pastor': StripDyn(
    gate: GateSetting(0, -55, 10, 2, 50, 300),
    comp: CompSetting(-20, 5, 8, 150, knee: 3, makeup: 4),
  ),
  'Choir mic': StripDyn(comp: CompSetting(-20, 3, 15, 200, makeup: 2)),
  'Acoustic guitar': StripDyn(comp: CompSetting(-18, 5, 15, 150, makeup: 2)),
  'Electric guitar': StripDyn(comp: CompSetting(-15, 3, 20, 150, makeup: 1)),
  'Bass guitar': StripDyn(comp: CompSetting(-20, 6, 15, 120, makeup: 3)),
  'Kick': StripDyn(
    gate: GateSetting(3, -40, 40, 0.5, 50, 120),
    comp: CompSetting(-15, 6, 10, 80, makeup: 2),
  ),
  'Snare': StripDyn(
    gate: GateSetting(3, -35, 25, 0.5, 40, 150),
    comp: CompSetting(-15, 6, 5, 100, makeup: 2),
  ),
  'Toms': StripDyn(
    gate: GateSetting(3, -35, 40, 0.5, 80, 250),
    comp: CompSetting(-15, 5, 10, 150, makeup: 2),
  ),
  'Piano / keys': StripDyn(comp: CompSetting(-18, 3, 20, 200, makeup: 1)),
  'Playback / media': StripDyn(comp: CompSetting(-10, 3, 20, 200)),
};

String presetSummary(EqPreset p) {
  final d = presetDynamics[p.name];
  return [
    'EQ',
    if (p.lowCutHz != null) 'low cut ${p.lowCutHz!.round()} Hz',
    if (d?.gate != null) 'gate',
    if (d?.comp != null) 'comp ${formatRatio(compRatios[d!.comp!.ratioIdx])}',
  ].join(' · ');
}

List<String> stripPresetAddresses(Strip s) => [
      ...eqPresetAddresses(s),
      for (final f in gateFields) s.gateAddr(f),
      for (final f in dynFields) s.dynAddr(f),
    ];

/// Applies EQ, low cut, gate and compressor of [preset] (null = reset the
/// channel: flat EQ, low cut, gate and compressor off). Returns previous
/// values for undo.
Map<String, Object> applyChannelPreset(MixerController c, Strip s, EqPreset? preset) {
  final before = <String, Object>{};
  for (final a in stripPresetAddresses(s)) {
    final v = c.param(a).value;
    if (v != null) before[a] = v;
  }
  applyEq(c, s, preset?.bands ?? flatBands(s.eqBands), lowCutHz: preset?.lowCutHz);
  final d = preset == null ? null : presetDynamics[preset.name];
  final g = d?.gate;
  c.set(s.gateAddr('on'), g == null ? 0 : 1);
  if (g != null) {
    c.set(s.gateAddr('mode'), g.mode);
    c.set(s.gateAddr('thr'), gateThrLaw.toNorm(g.thr));
    c.set(s.gateAddr('range'), gateRangeLaw.toNorm(g.range));
    c.set(s.gateAddr('attack'), attackLaw.toNorm(g.attack));
    c.set(s.gateAddr('hold'), holdLaw.toNorm(g.hold));
    c.set(s.gateAddr('release'), releaseLaw.toNorm(g.release));
  }
  final k = d?.comp;
  c.set(s.dynAddr('on'), k == null ? 0 : 1);
  if (k != null) {
    c.set(s.dynAddr('mode'), 0); // compressor
    c.set(s.dynAddr('thr'), compThrLaw.toNorm(k.thr));
    c.set(s.dynAddr('ratio'), k.ratioIdx);
    c.set(s.dynAddr('knee'), kneeLaw.toNorm(k.knee));
    c.set(s.dynAddr('attack'), attackLaw.toNorm(k.attack));
    c.set(s.dynAddr('release'), releaseLaw.toNorm(k.release));
    c.setMakeupDb(s, k.makeup); // also gives back any negative make-up
    c.set(s.dynAddr('mix'), 1.0);
    c.set(s.dynAddr('auto'), 0);
  }
  return before;
}
