import '../util/eq_math.dart';
import '../util/param_law.dart';
import 'mixer_controller.dart';
import 'mixer_profile.dart';

/// Starting-point EQ settings for common sources. These are this app's own
/// presets, based on common live-mixing practice — not the console's factory
/// library. Every source and room is different: apply, then adjust by ear.

class EqBandSetting {
  const EqBandSetting(this.type, this.hz, this.db, [this.q = 1.5]);
  final EqType type;
  final double hz, db, q;
}

class EqPreset {
  const EqPreset(this.name, this.category, this.lowCutHz, this.bands, [this.note = '']);
  final String name;
  final String category;

  /// Preamp low cut in Hz (input channels), null = low cut off.
  final double? lowCutHz;

  /// Four bands for input channels.
  final List<EqBandSetting> bands;
  final String note;
}

const _peq = EqType.peq;
const _ls = EqType.lowShelf;
const _hs = EqType.highShelf;
const _hc = EqType.highCut;

const eqPresetCategories = ['Vocals', 'Guitars', 'Bass', 'Drums', 'Keys', 'Other'];

const channelEqPresets = <EqPreset>[
  // Vocals
  EqPreset('Lead vocal (male)', 'Vocals', 90, [
    EqBandSetting(_peq, 200, -2, 1.2),
    EqBandSetting(_peq, 450, -2, 2.0),
    EqBandSetting(_peq, 3000, 2.5, 1.5),
    EqBandSetting(_hs, 10000, 2),
  ], 'Less mud, more presence and air'),
  EqPreset('Lead vocal (female)', 'Vocals', 120, [
    EqBandSetting(_peq, 250, -2, 1.2),
    EqBandSetting(_peq, 900, -1.5, 2.0),
    EqBandSetting(_peq, 4000, 2, 1.5),
    EqBandSetting(_hs, 12000, 2.5),
  ]),
  EqPreset('Backing vocal', 'Vocals', 140, [
    EqBandSetting(_peq, 250, -3, 1.2),
    EqBandSetting(_peq, 1000, -1, 1.5),
    EqBandSetting(_peq, 3500, 1, 1.5),
    EqBandSetting(_hs, 10000, 1.5),
  ], 'Thinner, sits behind the lead'),
  EqPreset('Speech / pastor', 'Vocals', 120, [
    EqBandSetting(_peq, 200, -3, 1.0),
    EqBandSetting(_peq, 500, -2, 2.0),
    EqBandSetting(_peq, 3000, 3, 1.2),
    EqBandSetting(_hs, 8000, 1),
  ], 'Clarity and intelligibility'),
  EqPreset('Choir mic', 'Vocals', 150, [
    EqBandSetting(_peq, 250, -3, 1.0),
    EqBandSetting(_peq, 1000, -1, 1.5),
    EqBandSetting(_peq, 3500, 2, 1.5),
    EqBandSetting(_hs, 10000, 1.5),
  ]),
  // Guitars
  EqPreset('Acoustic guitar', 'Guitars', 100, [
    EqBandSetting(_peq, 200, -3, 1.2),
    EqBandSetting(_peq, 800, -1.5, 2.0),
    EqBandSetting(_peq, 5000, 2, 1.5),
    EqBandSetting(_hs, 12000, 2),
  ], 'Less boom, more sparkle'),
  EqPreset('Electric guitar', 'Guitars', 90, [
    EqBandSetting(_peq, 200, -2, 1.0),
    EqBandSetting(_peq, 600, -1, 2.0),
    EqBandSetting(_peq, 2500, 2, 1.5),
    EqBandSetting(_hc, 8000, 0, 0.7),
  ], 'Bite, with harsh top end removed'),
  // Bass
  EqPreset('Bass guitar', 'Bass', 35, [
    EqBandSetting(_ls, 80, 2, 0.7),
    EqBandSetting(_peq, 250, -3, 1.4),
    EqBandSetting(_peq, 800, 2, 1.5),
    EqBandSetting(_hs, 5000, -2),
  ], 'Solid low end and definition'),
  // Drums
  EqPreset('Kick', 'Drums', 30, [
    EqBandSetting(_peq, 60, 4, 1.4),
    EqBandSetting(_peq, 350, -5, 1.4),
    EqBandSetting(_peq, 3500, 4, 1.5),
    EqBandSetting(_hs, 10000, -3),
  ], 'Thump and beater click, no boxiness'),
  EqPreset('Snare', 'Drums', 80, [
    EqBandSetting(_peq, 200, 2, 1.4),
    EqBandSetting(_peq, 500, -2, 2.0),
    EqBandSetting(_peq, 5000, 3, 1.5),
    EqBandSetting(_hs, 10000, 1),
  ]),
  EqPreset('Toms', 'Drums', 60, [
    EqBandSetting(_peq, 100, 3, 1.4),
    EqBandSetting(_peq, 400, -4, 1.4),
    EqBandSetting(_peq, 4000, 3, 1.5),
    EqBandSetting(_hs, 10000, -1),
  ]),
  EqPreset('Overheads', 'Drums', 200, [
    EqBandSetting(_ls, 300, -2, 0.7),
    EqBandSetting(_peq, 1000, -1, 1.0),
    EqBandSetting(_peq, 5000, 1, 1.5),
    EqBandSetting(_hs, 12000, 3),
  ], 'Cymbals and room, not the kick'),
  // Keys
  EqPreset('Piano / keys', 'Keys', 60, [
    EqBandSetting(_peq, 250, -2, 1.2),
    EqBandSetting(_peq, 1000, -1, 1.5),
    EqBandSetting(_peq, 3000, 1.5, 1.5),
    EqBandSetting(_hs, 10000, 2),
  ]),
  EqPreset('Synth pad', 'Keys', 100, [
    EqBandSetting(_peq, 300, -2, 1.0),
    EqBandSetting(_peq, 1000, 0, 1.5),
    EqBandSetting(_peq, 3000, -1, 1.5),
    EqBandSetting(_hs, 10000, 1),
  ], 'Leaves room for vocals'),
  // Other
  EqPreset('Playback / media', 'Other', 30, [
    EqBandSetting(_ls, 100, 0, 0.7),
    EqBandSetting(_peq, 400, 0, 2.0),
    EqBandSetting(_peq, 2500, 0, 2.0),
    EqBandSetting(_hs, 10000, 0),
  ], 'Clean, only rumble removed'),
];

/// Flat EQ (all gains 0, console-like default bands) for any band count.
List<EqBandSetting> flatBands(int n) => [
      for (var b = 1; b <= n; b++) EqBandSetting(eqTypeOf(eqDefaultType(b, n)), eqDefaultFreq(b, n), 0, 2.0),
    ];

/// Every address a preset touches on [s].
List<String> eqPresetAddresses(Strip s) => [
      ...s.eqAddresses,
      if (s.hasDetail) ...[s.hpOnAddr, s.hpfAddr],
    ];

/// Applies [bands] (and, on input channels, the low cut) to [s].
/// Returns the previous values so the change can be undone.
Map<String, Object> applyEq(MixerController c, Strip s, List<EqBandSetting> bands, {double? lowCutHz}) {
  final before = <String, Object>{};
  for (final a in eqPresetAddresses(s)) {
    final v = c.param(a).value;
    if (v != null) before[a] = v;
  }
  c.set(s.eqOnAddr, 1);
  for (var b = 1; b <= s.eqBands && b <= bands.length; b++) {
    final x = bands[b - 1];
    c.set(s.eqAddr(b, 'type'), x.type.index);
    c.set(s.eqAddr(b, 'f'), freqLaw.toNorm(x.hz));
    c.set(s.eqAddr(b, 'g'), eqGainLaw.toNorm(x.db));
    c.set(s.eqAddr(b, 'q'), qLaw.toNorm(x.q));
  }
  if (s.hasDetail) {
    c.set(s.hpOnAddr, lowCutHz == null ? 0 : 1);
    if (lowCutHz != null) c.set(s.hpfAddr, hpfLaw.toNorm(lowCutHz));
  }
  return before;
}

void restoreEq(MixerController c, Map<String, Object> before) {
  before.forEach(c.set);
}
