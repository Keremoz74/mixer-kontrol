import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

/// Real-time analyser and gain-reduction data from the console.
///
/// RTA (both families): 100 log-spaced bins, 20 Hz - 20 kHz, signed 16-bit
/// values in 1/256 dB after the 4-byte count of the /meters blob.
///   X32 / M32: /meters/15, follows the console's selected strip (/-stat/selidx)
///   XR / MR:   /meters/4,  source /-stat/rta/source, tap /-stat/rta/pos
/// Gain reduction:
///   X32 / M32: /meters/1 = 96 floats: ch 1-32 input, gate GR, comp GR (linear gain)
///   XR / MR:   /meters/6 = int16 dB/256: ch 1-16 gate GR, ch 1-16 comp GR, …

const rtaBins = 100;

List<double> decodeRtaBlob(Uint8List blob) {
  if (blob.length < 6) return const [];
  final bd = ByteData.sublistView(blob);
  final n = math.min((blob.length - 4) ~/ 2, 1024);
  return [
    for (var i = 0; i < n; i++)
      () {
        final v = bd.getInt16(4 + i * 2, Endian.little);
        return v <= -32768 ? -120.0 : v / 256.0;
      }(),
  ];
}

/// Centre frequency of RTA bin [i] of [n].
double rtaBinHz(int i, int n) => 20.0 * math.pow(1000.0, i / (n - 1)).toDouble();

/// Smoothed RTA spectrum (dB per bin) with a slow peak hold.
class RtaData extends ChangeNotifier {
  List<double> _db = const [];
  List<double> _peak = const [];
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  List<double> get db => _db;
  List<double> get peak => _peak;
  bool get hasData => _db.isNotEmpty && DateTime.now().difference(_last) < const Duration(seconds: 2);

  void update(List<double> values) {
    if (values.isEmpty) return;
    _last = DateTime.now();
    if (_db.length != values.length) {
      _db = List.of(values);
      _peak = List.of(values);
    } else {
      for (var i = 0; i < values.length; i++) {
        final v = values[i];
        // fast rise, gentle fall
        _db[i] = v > _db[i] ? v : _db[i] + (v - _db[i]) * 0.35;
        _peak[i] = v > _peak[i] ? v : _peak[i] - 0.25;
      }
    }
    notifyListeners();
  }

  void clear() {
    _db = const [];
    _peak = const [];
    notifyListeners();
  }
}

/// A sustained narrow peak in the spectrum: a likely feedback frequency.
class FeedbackPeak {
  const FeedbackPeak(this.hz, this.db, this.above);
  final double hz;
  final double db;

  /// How far the peak stands above the surrounding spectrum (dB).
  final double above;
}

/// Finds narrow peaks that stand [minAbove] dB over their neighbourhood and
/// are loud enough to matter. Strongest first, at most [max].
List<FeedbackPeak> findFeedbackPeaks(List<double> db, {double minAbove = 12, double floor = -60, int max = 5}) {
  final n = db.length;
  if (n < 10) return const [];
  final out = <FeedbackPeak>[];
  for (var i = 2; i < n - 2; i++) {
    final v = db[i];
    if (v < floor) continue;
    if (v < db[i - 1] || v < db[i + 1]) continue;
    // median-ish level of the neighbourhood, skipping the peak itself
    final around = <double>[
      for (var k = math.max(0, i - 8); k <= math.min(n - 1, i + 8); k++)
        if ((k - i).abs() > 1) db[k],
    ]..sort();
    final ref = around[around.length ~/ 2];
    final above = v - ref;
    if (above >= minAbove) out.add(FeedbackPeak(rtaBinHz(i, n), v, above));
  }
  out.sort((a, b) => b.above.compareTo(a.above));
  return out.take(max).toList();
}
