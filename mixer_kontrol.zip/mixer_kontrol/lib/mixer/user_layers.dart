import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'mixer_profile.dart';

/// A fader layer the user builds from any strips (e.g. "Vocals": Ch 1-4,
/// FX 1, Bus 3). Stored on the device per console family.
class UserLayer {
  UserLayer(this.name, this.prefixes);
  String name;
  List<String> prefixes;

  Map<String, Object> toJson() => {'name': name, 'strips': prefixes};

  static UserLayer? fromJson(Object? j) {
    if (j is! Map) return null;
    final name = j['name'];
    final strips = j['strips'];
    if (name is! String || strips is! List) return null;
    return UserLayer(
      name.length > 24 ? name.substring(0, 24) : name,
      [for (final s in strips.take(64)) if (s is String && s.length <= 32) s],
    );
  }

  List<Strip> stripsIn(MixerProfile p) {
    final byPrefix = {for (final s in p.allStrips) s.prefix: s};
    return [for (final x in prefixes) if (byPrefix[x] != null) byPrefix[x]!];
  }
}

class UserLayerStore {
  static String _key(MixerFamily f) => 'user_layers_${f.name}';

  static Future<List<UserLayer>> load(MixerFamily f) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key(f));
      if (raw == null || raw.length > 200000) return [];
      final list = jsonDecode(raw);
      if (list is! List) return [];
      return [for (final j in list.take(32)) if (UserLayer.fromJson(j) != null) UserLayer.fromJson(j)!];
    } catch (_) {
      return [];
    }
  }

  static Future<void> save(MixerFamily f, List<UserLayer> layers) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key(f), jsonEncode([for (final l in layers) l.toJson()]));
    } catch (_) {}
  }
}
