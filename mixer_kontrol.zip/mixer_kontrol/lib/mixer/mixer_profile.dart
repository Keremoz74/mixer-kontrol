/// Describes what a given console has and where each control lives in its OSC tree.
/// The UI only talks to [Strip] / [SendTarget]; X32 vs XR differences live here.

import '../osc/meters.dart';
import 'fx_catalog.dart';

enum MixerFamily { x32, xr }

enum StripType { channel, auxIn, fxReturn, bus, fxSend, matrix, dca, main }

String two(int n) => n.toString().padLeft(2, '0');

class Strip {
  const Strip({
    required this.type,
    required this.index,
    required this.prefix,
    required this.defaultLabel,
    this.hasSends = false,
    this.meterId,
    this.meterIdx = const [],
  });

  final StripType type;
  final int index;
  final String prefix; // e.g. /ch/01, /bus/1, /main/st, /lr
  final String defaultLabel;
  final bool hasSends;

  /// Meter block carrying this strip's level (e.g. /meters/0), null = no meter.
  final String? meterId;

  /// Value index(es) inside that block; stereo strips list L and R.
  final List<int> meterIdx;

  bool get hasMeter => meterId != null && meterIdx.isNotEmpty;
  bool get isDca => type == StripType.dca;
  String get faderAddr => isDca ? '$prefix/fader' : '$prefix/mix/fader';
  String get onAddr => isDca ? '$prefix/on' : '$prefix/mix/on';
  String get nameAddr => '$prefix/config/name';
  String get colorAddr => '$prefix/config/color';
  String sendLevelAddr(SendTarget t) => '$prefix/mix/${two(t.mixIndex)}/level';
  String sendOnAddr(SendTarget t) => '$prefix/mix/${two(t.mixIndex)}/on';

  // ---- Channel detail (input channels) ----
  bool get hasDetail => type == StripType.channel;

  /// Parametric EQ bands: 4 on input channels, 6 on buses, matrices and
  /// Main LR (both X32 and XR); 0 = no EQ page for this strip.
  int get eqBands => switch (type) {
        StripType.channel => 4,
        StripType.bus || StripType.matrix || StripType.main => 6,
        _ => 0,
      };
  bool get hasEq => eqBands > 0;
  List<String> get eqAddresses => [
        eqOnAddr,
        for (var b = 1; b <= eqBands; b++)
          for (final f in const ['type', 'f', 'g', 'q']) eqAddr(b, f),
      ];
  String get panAddr => '$prefix/mix/pan';
  String get eqOnAddr => '$prefix/eq/on';
  String eqAddr(int band, String field) => '$prefix/eq/$band/$field'; // type, f, g, q
  String get hpOnAddr => '$prefix/preamp/hpon';
  String get hpfAddr => '$prefix/preamp/hpf';
  String get invertAddr => '$prefix/preamp/invert';
  String get trimAddr => '$prefix/preamp/trim';
  String gateAddr(String field) => '$prefix/gate/$field';
  String dynAddr(String field) => '$prefix/dyn/$field';
}

const gateFields = ['on', 'mode', 'thr', 'range', 'attack', 'hold', 'release'];
const dynFields = [
  'on', 'mode', 'det', 'env', 'thr', 'ratio', 'knee', 'mgain', 'attack', 'hold', 'release', 'mix', 'auto',
];

/// A page of up to 8 strips, like a fader layer on the console.
class StripBank {
  const StripBank(this.label, this.strips);
  final String label;
  final List<Strip> strips;
}

/// Groups strips into layers of 8: channels "1-8", "9-16"…, returns
/// "Aux/FX" (or "Aux 1-8", "FX 1-8" when there are more), buses "Bus 1-8",
/// matrix, FX sends and DCAs.
List<StripBank> makeBanks(List<Strip> strips) {
  String groupOf(StripType t) => switch (t) {
        StripType.channel => 'ch',
        StripType.auxIn || StripType.fxReturn => 'rtn',
        StripType.bus => 'bus',
        StripType.matrix => 'mtx',
        StripType.fxSend => 'fxs',
        StripType.dca => 'dca',
        StripType.main => 'main',
      };

  final groups = <String, List<Strip>>{};
  for (final s in strips) {
    (groups[groupOf(s.type)] ??= []).add(s);
  }

  final banks = <StripBank>[];
  groups.forEach((key, list) {
    for (var i = 0; i < list.length; i += 8) {
      final chunk = list.sublist(i, i + 8 > list.length ? list.length : i + 8);
      final a = chunk.first.index, b = chunk.last.index;
      final range = a == b ? '$a' : '$a-$b';
      final label = switch (key) {
        'ch' => range,
        'rtn' => chunk.every((s) => s.type == StripType.auxIn)
            ? 'Aux $range'
            : chunk.every((s) => s.type == StripType.fxReturn)
                ? 'FX $range'
                : 'Aux/FX',
        'bus' => 'Bus $range',
        'mtx' => 'Matrix',
        'fxs' => 'FX Send',
        'dca' => 'DCA',
        _ => range,
      };
      banks.add(StripBank(label, chunk));
    }
  });
  return banks;
}

/// A mix bus that inputs can send to ("sends on fader").
class SendTarget {
  const SendTarget({required this.mixIndex, required this.label, required this.master});
  final int mixIndex;
  final String label;
  final Strip master;
}

class MixerProfile {
  MixerProfile._({
    required this.family,
    required this.model,
    required this.port,
    required this.inputs,
    required this.buses,
    required this.dcas,
    required this.main,
    required this.sendTargets,
    required this.meterFormat,
    required this.meterRequests,
  });

  final MixerFamily family;
  final String model;
  final int port;
  final List<Strip> inputs;
  final List<Strip> buses;
  final List<Strip> dcas;
  final Strip main;
  final List<SendTarget> sendTargets;
  final MeterFormat meterFormat;

  /// Meter blocks to subscribe to (each lasts ~10 s and must be renewed).
  final List<String> meterRequests;

  List<Strip> get allStrips => [...inputs, ...buses, ...dcas, main];

  /// Every address to query when syncing the full state.
  List<String> get queryAddresses {
    final out = <String>[];
    for (final s in allStrips) {
      out
        ..add(s.nameAddr)
        ..add(s.colorAddr)
        ..add(s.onAddr)
        ..add(s.faderAddr);
      if (s.hasSends) {
        for (final t in sendTargets) {
          out
            ..add(s.sendLevelAddr(t))
            ..add(s.sendOnAddr(t));
        }
      }
    }
    return out;
  }

  /// Digital trim exists on X32/M32 channels only.
  bool get hasTrim => family == MixerFamily.x32;

  // ---------------------------------------------------------------- preamps
  //
  // XR: input channel N is hard-wired to preamp N → /headamp/NN.
  //
  // X32 / M32: a channel's preamp depends on routing, so it is worked out from
  //   /ch/NN/config/source  0 OFF, 1-32 "In 1-32", 33+ aux/USB/FX/bus (no preamp)
  //   /config/routing/IN/{1-8,9-16,17-24,25-32}  which block feeds In 1-32:
  //       0-3 AN (local), 4-9 AES50-A, 10-15 AES50-B, 16-19 CARD, 20-23 UIN
  //   /config/userrout/in/NN (FW 4+, for UIN)  0 OFF, 1-32 local,
  //       33-80 AES50-A, 81-128 AES50-B, 129+ card/aux/talkback
  // Preamp numbers: local 1-32 → 000-031, AES50-A 1-48 → 032-079, AES50-B → 080-127.

  static const x32RoutingBlocks = [
    '/config/routing/IN/1-8',
    '/config/routing/IN/9-16',
    '/config/routing/IN/17-24',
    '/config/routing/IN/25-32',
  ];

  static String x32SourceAddr(int channel) => '/ch/${two(channel)}/config/source';
  static String x32UserRoutAddr(int n) => '/config/userrout/in/${two(n)}';

  /// Preamp index (0-127) feeding X32 [channel]; -1 if the source has no
  /// preamp; null while a value needed to decide is still unknown.
  static int? x32HeadampIndex(int channel, int? Function(String addr) read) {
    final src = read(x32SourceAddr(channel));
    if (src == null) return null;
    if (src < 1 || src > 32) return -1;
    final block = (src - 1) ~/ 8;
    final within = (src - 1) % 8;
    final r = read(x32RoutingBlocks[block]);
    if (r == null) return null;
    if (r >= 0 && r <= 3) return r * 8 + within;
    if (r >= 4 && r <= 9) return 32 + (r - 4) * 8 + within;
    if (r >= 10 && r <= 15) return 80 + (r - 10) * 8 + within;
    if (r >= 20 && r <= 23) {
      final v = read(x32UserRoutAddr((r - 20) * 8 + within + 1));
      if (v == null) return null;
      if (v >= 1 && v <= 32) return v - 1;
      if (v >= 33 && v <= 80) return 32 + (v - 33);
      if (v >= 81 && v <= 128) return 80 + (v - 81);
      return -1;
    }
    return -1; // card or unknown
  }

  static String x32HeadampPrefix(int index) => '/headamp/${index.toString().padLeft(3, '0')}';

  /// Human name for an X32 preamp index.
  static String x32HeadampName(int index) {
    if (index < 32) return 'Local ${index + 1}';
    if (index < 80) return 'AES50-A ${index - 31}';
    return 'AES50-B ${index - 79}';
  }

  /// Values the preamp resolution depends on (empty for XR).
  List<String> headampDependencies(Strip s) {
    if (family != MixerFamily.x32 || s.type != StripType.channel) return const [];
    return [
      x32SourceAddr(s.index),
      ...x32RoutingBlocks,
      for (var n = 1; n <= 32; n++) x32UserRoutAddr(n),
    ];
  }

  /// Everything the channel detail screen shows, for an initial query.
  /// Preamp gain/phantom are queried once the preamp is known.
  List<String> detailAddresses(Strip s) => !s.hasDetail
      ? s.eqAddresses
      : [
        ...headampDependencies(s),
        s.panAddr,
        ...s.eqAddresses,
        s.hpOnAddr,
        s.hpfAddr,
        s.invertAddr,
        if (hasTrim) s.trimAddr,
        for (final f in gateFields) s.gateAddr(f),
        for (final f in dynFields) s.dynAddr(f),
      ];

  // ---------------------------------------------------------------- FX

  /// X32 has 8 FX slots (5-8 insert-only), XR has 4.
  int get fxSlots => family == MixerFamily.x32 ? 8 : 4;

  /// Effect codes selectable in [slot] (1-based); index = /fx/N/type value.
  List<String> fxTypesForSlot(int slot) =>
      family == MixerFamily.x32 && slot > 4 ? fxInsertList : fxFullList;

  String fxTypeAddr(int slot) => '/fx/$slot/type';
  String fxParAddr(int slot, int par) => '/fx/$slot/par/${two(par)}';

  /// X32 only: mix bus feeding FX slot 1-4 (0 = insert, 1-16 = MIX 1-16).
  String fxSourceAddr(int slot) => '/fx/$slot/source/l';

  // ---------------------------------------------------------------- snapshots

  /// Everything a snapshot stores and recalls.
  ///
  /// Deliberately left out: preamp gain and +48V (a recall must never switch
  /// phantom power or jump gain), and input routing.
  List<String> snapshotAddresses() {
    final out = <String>[];
    for (var slot = 1; slot <= fxSlots; slot++) {
      out.add(fxTypeAddr(slot));
      for (var p = 1; p <= fxParamsMax; p++) {
        out.add(fxParAddr(slot, p));
      }
    }
    for (final s in allStrips) {
      out
        ..add(s.nameAddr)
        ..add(s.colorAddr)
        ..add(s.onAddr)
        ..add(s.faderAddr);
      if (s.hasSends) {
        for (final t in sendTargets) {
          out
            ..add(s.sendLevelAddr(t))
            ..add(s.sendOnAddr(t));
        }
      }
      out.addAll(s.eqAddresses);
      if (s.hasDetail) {
        out
          ..add(s.panAddr)
          ..add(s.hpOnAddr)
          ..add(s.hpfAddr)
          ..add(s.invertAddr);
        if (hasTrim) out.add(s.trimAddr);
        for (final f in gateFields) {
          out.add(s.gateAddr(f));
        }
        for (final f in dynFields) {
          out.add(s.dynAddr(f));
        }
      }
    }
    return out;
  }

  static MixerFamily? familyFromModel(String model) {
    final m = model.toUpperCase();
    if (m.contains('XR') || m.contains('MR1') || m.contains('X18')) return MixerFamily.xr;
    if (m.contains('X32') || m.contains('M32')) return MixerFamily.x32;
    return null;
  }

  static int defaultPort(MixerFamily f) => f == MixerFamily.x32 ? 10023 : 10024;

  factory MixerProfile.forFamily(MixerFamily family, String model) =>
      family == MixerFamily.x32 ? _x32(model) : _xr(model);

  // X32 meters:
  //   /meters/0 (70): ch 1-32 [0-31], aux in 1-8 [32-39], fx rtn 1-8 [40-47],
  //                   bus 1-16 [48-63], matrix 1-6 [64-69]
  //   /meters/2 (49): bus [0-15], matrix [16-21], main L/R [22-23], mono [24], ...
  static MixerProfile _x32(String model) {
    const m0 = '/meters/0';
    final inputs = <Strip>[
      for (var i = 1; i <= 32; i++)
        Strip(type: StripType.channel, index: i, prefix: '/ch/${two(i)}', defaultLabel: 'Ch $i',
            hasSends: true, meterId: m0, meterIdx: [i - 1]),
      for (var i = 1; i <= 8; i++)
        Strip(type: StripType.auxIn, index: i, prefix: '/auxin/${two(i)}', defaultLabel: 'Aux $i',
            hasSends: true, meterId: m0, meterIdx: [31 + i]),
      for (var i = 1; i <= 8; i++)
        Strip(type: StripType.fxReturn, index: i, prefix: '/fxrtn/${two(i)}', defaultLabel: 'FX $i',
            hasSends: true, meterId: m0, meterIdx: [39 + i]),
    ];
    final busList = [
      for (var i = 1; i <= 16; i++)
        Strip(type: StripType.bus, index: i, prefix: '/bus/${two(i)}', defaultLabel: 'Bus $i',
            meterId: m0, meterIdx: [47 + i]),
    ];
    final buses = <Strip>[
      ...busList,
      for (var i = 1; i <= 6; i++)
        Strip(type: StripType.matrix, index: i, prefix: '/mtx/${two(i)}', defaultLabel: 'Mtx $i',
            meterId: m0, meterIdx: [63 + i]),
    ];
    return MixerProfile._(
      family: MixerFamily.x32,
      model: model,
      port: 10023,
      inputs: inputs,
      buses: buses,
      dcas: [
        for (var i = 1; i <= 8; i++)
          Strip(type: StripType.dca, index: i, prefix: '/dca/$i', defaultLabel: 'DCA $i'),
      ],
      main: const Strip(type: StripType.main, index: 0, prefix: '/main/st', defaultLabel: 'Main LR',
          meterId: '/meters/2', meterIdx: [22, 23]),
      sendTargets: [
        for (var i = 1; i <= 16; i++) SendTarget(mixIndex: i, label: 'Bus $i', master: busList[i - 1]),
      ],
      meterFormat: MeterFormat.float32Linear,
      meterRequests: const ['/meters/0', '/meters/2'],
    );
  }

  // XR meters, /meters/1 (40): ch 1-16 [0-15], aux L/R [16-17],
  //   fx rtn 1-4 L/R [18-25], bus 1-6 [26-31], fx send 1-4 [32-35],
  //   main L/R [36-37], monitor L/R [38-39]
  static MixerProfile _xr(String model) {
    const m1 = '/meters/1';
    // XR12 exposes 12 input channels, XR16/XR18/MR18 expose 16.
    final channels = model.contains('12') ? 12 : 16;
    final inputs = <Strip>[
      for (var i = 1; i <= channels; i++)
        Strip(type: StripType.channel, index: i, prefix: '/ch/${two(i)}', defaultLabel: 'Ch $i',
            hasSends: true, meterId: m1, meterIdx: [i - 1]),
      const Strip(type: StripType.auxIn, index: 1, prefix: '/rtn/aux', defaultLabel: 'Aux In',
          hasSends: true, meterId: m1, meterIdx: [16, 17]),
      for (var i = 1; i <= 4; i++)
        Strip(type: StripType.fxReturn, index: i, prefix: '/rtn/$i', defaultLabel: 'FX $i',
            hasSends: true, meterId: m1, meterIdx: [16 + 2 * i, 17 + 2 * i]),
    ];
    final busList = [
      for (var i = 1; i <= 6; i++)
        Strip(type: StripType.bus, index: i, prefix: '/bus/$i', defaultLabel: 'Bus $i',
            meterId: m1, meterIdx: [25 + i]),
    ];
    final fxSends = [
      for (var i = 1; i <= 4; i++)
        Strip(type: StripType.fxSend, index: i, prefix: '/fxsend/$i', defaultLabel: 'FX Snd $i',
            meterId: m1, meterIdx: [31 + i]),
    ];
    return MixerProfile._(
      family: MixerFamily.xr,
      model: model,
      port: 10024,
      inputs: inputs,
      buses: [...busList, ...fxSends],
      dcas: [
        for (var i = 1; i <= 4; i++)
          Strip(type: StripType.dca, index: i, prefix: '/dca/$i', defaultLabel: 'DCA $i'),
      ],
      main: const Strip(type: StripType.main, index: 0, prefix: '/lr', defaultLabel: 'Main LR',
          meterId: m1, meterIdx: [36, 37]),
      sendTargets: [
        for (var i = 1; i <= 6; i++) SendTarget(mixIndex: i, label: 'Bus $i', master: busList[i - 1]),
        // On XR, mix sends 07..10 feed FX 1..4.
        for (var i = 1; i <= 4; i++) SendTarget(mixIndex: 6 + i, label: 'FX $i', master: fxSends[i - 1]),
      ],
      meterFormat: MeterFormat.int16Db,
      meterRequests: const [m1],
    );
  }
}
