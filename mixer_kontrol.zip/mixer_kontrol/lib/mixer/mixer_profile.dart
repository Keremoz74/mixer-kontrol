/// Describes what a given console has and where each control lives in its OSC tree.
/// The UI only talks to [Strip] / [SendTarget]; X32 vs XR differences live here.

import '../osc/meters.dart';
import 'fx_catalog.dart';

/// x32 = X32 / M32, xr = X Air / MR (both OSC), yamaha = Yamaha consoles
/// over their remote control protocol (TF, DM3, DM7, QL, CL; experimental).
enum MixerFamily { x32, xr, yamaha }

enum StripType { channel, auxIn, fxReturn, bus, fxSend, matrix, dca, main, mono }

String two(int n) => n.toString().padLeft(2, '0');

class Strip {
  const Strip({
    required this.type,
    required this.index,
    required this.prefix,
    required this.defaultLabel,
    this.hasSends = false,
    this.meterId,
    this.meterIdx = const [],
    this.simple = false,
  });

  /// Basic strip: fader, mute, name, colour and sends only (no channel
  /// detail page, no EQ). Used where a driver doesn't map more yet.
  final bool simple;

  final StripType type;
  final int index;
  final String prefix; // e.g. /ch/01, /bus/1, /main/st, /lr
  final String defaultLabel;
  final bool hasSends;

  /// Meter block carrying this strip's level (e.g. /meters/0), null = no meter.
  final String? meterId;

  /// Value index(es) inside that block; stereo strips list L and R.
  final List<int> meterIdx;

  bool get hasMeter => meterId != null && meterIdx.isNotEmpty;
  bool get isDca => type == StripType.dca;
  String get faderAddr => isDca ? '$prefix/fader' : '$prefix/mix/fader';
  String get onAddr => isDca ? '$prefix/on' : '$prefix/mix/on';
  String get nameAddr => '$prefix/config/name';
  String get colorAddr => '$prefix/config/color';
  String sendLevelAddr(SendTarget t) => '$prefix/mix/${two(t.mixIndex)}/level';
  String sendOnAddr(SendTarget t) => '$prefix/mix/${two(t.mixIndex)}/on';

  // ---- Channel detail (input channels) ----
  bool get hasDetail => !simple && type == StripType.channel;

  /// Parametric EQ bands: 4 on input channels, 6 on buses, matrices and
  /// Main LR (both X32 and XR); 0 = no EQ page for this strip.
  int get eqBands => simple ? 0 : switch (type) {
        StripType.channel => 4,
        StripType.bus || StripType.matrix || StripType.main || StripType.mono => 6,
        _ => 0,
      };
  bool get hasEq => eqBands > 0;
  List<String> get eqAddresses => eqBands == 0
      ? const []
      : [
        eqOnAddr,
        for (var b = 1; b <= eqBands; b++)
          for (final f in const ['type', 'f', 'g', 'q']) eqAddr(b, f),
      ];
  String get panAddr => '$prefix/mix/pan';
  String get eqOnAddr => '$prefix/eq/on';
  String eqAddr(int band, String field) => '$prefix/eq/$band/$field'; // type, f, g, q
  String get hpOnAddr => '$prefix/preamp/hpon';
  String get hpfAddr => '$prefix/preamp/hpf';
  String get invertAddr => '$prefix/preamp/invert';
  String get trimAddr => '$prefix/preamp/trim';
  String gateAddr(String field) => '$prefix/gate/$field';
  String dynAddr(String field) => '$prefix/dyn/$field';
}

const gateFields = ['on', 'mode', 'thr', 'range', 'attack', 'hold', 'release'];
const dynFields = [
  'on', 'mode', 'det', 'env', 'thr', 'ratio', 'knee', 'mgain', 'attack', 'hold', 'release', 'mix', 'auto',
];

/// A page of up to 8 strips, like a fader layer on the console.
class StripBank {
  const StripBank(this.label, this.strips);
  final String label;
  final List<Strip> strips;
}

/// Groups strips into layers of 8: channels "1-8", "9-16"…, returns
/// "Aux/FX" (or "Aux 1-8", "FX 1-8" when there are more), buses "Bus 1-8",
/// matrix, FX sends and DCAs.
List<StripBank> makeBanks(List<Strip> strips) {
  String groupOf(StripType t) => switch (t) {
        StripType.channel => 'ch',
        StripType.auxIn || StripType.fxReturn => 'rtn',
        StripType.bus => 'bus',
        StripType.matrix => 'mtx',
        StripType.fxSend => 'fxs',
        StripType.dca => 'dca',
        StripType.main => 'main',
        StripType.mono => 'mono',
      };

  final groups = <String, List<Strip>>{};
  for (final s in strips) {
    (groups[groupOf(s.type)] ??= []).add(s);
  }

  final banks = <StripBank>[];
  groups.forEach((key, list) {
    for (var i = 0; i < list.length; i += 8) {
      final chunk = list.sublist(i, i + 8 > list.length ? list.length : i + 8);
      final a = chunk.first.index, b = chunk.last.index;
      final range = a == b ? '$a' : '$a-$b';
      final label = switch (key) {
        'ch' => range,
        'rtn' => chunk.every((s) => s.type == StripType.auxIn)
            ? 'Aux $range'
            : chunk.every((s) => s.type == StripType.fxReturn)
                ? 'FX $range'
                : 'Aux/FX',
        'bus' => 'Bus $range',
        'mtx' => 'Matrix',
        'fxs' => 'FX Send',
        'dca' => 'DCA',
        'main' => 'Main LR',
        'mono' => 'M/C',
        _ => range,
      };
      banks.add(StripBank(label, chunk));
    }
  });
  return banks;
}

/// A mix bus that inputs can send to ("sends on fader").
class SendTarget {
  const SendTarget({required this.mixIndex, required this.label, required this.master});
  final int mixIndex;
  final String label;
  final Strip master;
}

class MixerProfile {
  MixerProfile._({
    required this.family,
    required this.model,
    required this.port,
    required this.inputs,
    required this.buses,
    required this.dcas,
    required this.main,
    required this.sendTargets,
    required this.meterFormat,
    required this.meterRequests,
    this.mono,
  });

  final MixerFamily family;
  final String model;
  final int port;
  final List<Strip> inputs;
  final List<Strip> buses;
  final List<Strip> dcas;
  final Strip main;

  /// X32 / M32 mono / centre bus (M/C); XR has none.
  final Strip? mono;
  final List<SendTarget> sendTargets;
  final MeterFormat meterFormat;

  /// Meter blocks to subscribe to (each lasts ~10 s and must be renewed).
  final List<String> meterRequests;

  List<Strip> get allStrips => [...inputs, ...buses, ...dcas, main, if (mono != null) mono!];

  // ---------------------------------------------------------------- features
  //
  // What this console offers in the app. X32 / XR have everything; the
  // Yamaha driver (experimental) maps faders, mutes, names, colours, sends
  // and DCAs for now.

  bool get isYamaha => family == MixerFamily.yamaha;
  bool get hasFx => !isYamaha;
  bool get hasRouting => !isYamaha;
  bool get hasSolo => !isYamaha;
  bool get hasRecorder => !isYamaha;
  bool get hasAnalyzer => !isYamaha;
  bool get hasMeters => meterRequests.isNotEmpty;
  bool get hasConsoleLibrary => !isYamaha;
  bool get hasBusOptions => !isYamaha;

  /// DCA / mute group membership (DCA spill needs it).
  bool get hasGroupMembership => !isYamaha;

  /// Shown as experimental (not yet confirmed on real hardware).
  bool get experimental => isYamaha;

  /// What the console calls its mix buses and main mix.
  String get busWord => isYamaha ? 'AUX' : 'Buses';
  String get mainWord => main.defaultLabel;

  /// Every address to query when syncing the full state.
  List<String> get queryAddresses {
    final out = <String>[];
    for (final s in allStrips) {
      out
        ..add(s.nameAddr)
        ..add(s.colorAddr)
        ..add(s.onAddr)
        ..add(s.faderAddr);
      if (s.hasSends) {
        for (final t in sendTargets) {
          out
            ..add(s.sendLevelAddr(t))
            ..add(s.sendOnAddr(t));
        }
      }
      // EQ on/off and bands, for the EQ thumbnails on the strips.
      out.addAll(s.eqAddresses);
    }
    out.addAll(matrixSendAddresses);
    out.addAll(busOptionAddresses);
    out.addAll(groupAddresses);
    out.addAll(soloAddresses);
    // X32: preamp routing, so the gain knobs on the strips know which
    // preamp each channel uses (XR needs nothing: channel N = preamp N).
    if (family == MixerFamily.x32) {
      out
        ..addAll([for (final s in inputs) if (s.type == StripType.channel) x32SourceAddr(s.index)])
        ..addAll(x32RoutingBlocks)
        ..addAll([for (var n = 1; n <= 32; n++) x32UserRoutAddr(n)]);
    }
    return out;
  }

  /// Digital trim exists on X32/M32 channels only.
  bool get hasTrim => family == MixerFamily.x32;

  // ---------------------------------------------------------------- preamps
  //
  // XR: input channel N is hard-wired to preamp N → /headamp/NN.
  //
  // X32 / M32: a channel's preamp depends on routing, so it is worked out from
  //   /ch/NN/config/source  0 OFF, 1-32 "In 1-32", 33+ aux/USB/FX/bus (no preamp)
  //   /config/routing/IN/{1-8,9-16,17-24,25-32}  which block feeds In 1-32:
  //       0-3 AN (local), 4-9 AES50-A, 10-15 AES50-B, 16-19 CARD, 20-23 UIN
  //   /config/userrout/in/NN (FW 4+, for UIN)  0 OFF, 1-32 local,
  //       33-80 AES50-A, 81-128 AES50-B, 129+ card/aux/talkback
  // Preamp numbers: local 1-32 → 000-031, AES50-A 1-48 → 032-079, AES50-B → 080-127.

  static const x32RoutingBlocks = [
    '/config/routing/IN/1-8',
    '/config/routing/IN/9-16',
    '/config/routing/IN/17-24',
    '/config/routing/IN/25-32',
  ];

  static String x32SourceAddr(int channel) => '/ch/${two(channel)}/config/source';
  static String x32UserRoutAddr(int n) => '/config/userrout/in/${two(n)}';

  /// Preamp index (0-127) feeding X32 [channel]; -1 if the source has no
  /// preamp; null while a value needed to decide is still unknown.
  static int? x32HeadampIndex(int channel, int? Function(String addr) read) {
    final src = read(x32SourceAddr(channel));
    if (src == null) return null;
    if (src < 1 || src > 32) return -1;
    final block = (src - 1) ~/ 8;
    final within = (src - 1) % 8;
    final r = read(x32RoutingBlocks[block]);
    if (r == null) return null;
    if (r >= 0 && r <= 3) return r * 8 + within;
    if (r >= 4 && r <= 9) return 32 + (r - 4) * 8 + within;
    if (r >= 10 && r <= 15) return 80 + (r - 10) * 8 + within;
    if (r >= 20 && r <= 23) {
      final v = read(x32UserRoutAddr((r - 20) * 8 + within + 1));
      if (v == null) return null;
      if (v >= 1 && v <= 32) return v - 1;
      if (v >= 33 && v <= 80) return 32 + (v - 33);
      if (v >= 81 && v <= 128) return 80 + (v - 81);
      return -1;
    }
    return -1; // card or unknown
  }

  static String x32HeadampPrefix(int index) => '/headamp/${index.toString().padLeft(3, '0')}';

  /// Human name for an X32 preamp index.
  static String x32HeadampName(int index) {
    if (index < 32) return 'Local ${index + 1}';
    if (index < 80) return 'AES50-A ${index - 31}';
    return 'AES50-B ${index - 79}';
  }

  /// Values the preamp resolution depends on (empty for XR).
  List<String> headampDependencies(Strip s) {
    if (family != MixerFamily.x32 || s.type != StripType.channel) return const [];
    return [
      x32SourceAddr(s.index),
      ...x32RoutingBlocks,
      for (var n = 1; n <= 32; n++) x32UserRoutAddr(n),
    ];
  }

  /// Everything the channel detail screen shows, for an initial query.
  /// Preamp gain/phantom are queried once the preamp is known.
  List<String> detailAddresses(Strip s) => !s.hasDetail
      ? s.eqAddresses
      : [
        ...headampDependencies(s),
        s.panAddr,
        ...s.eqAddresses,
        s.hpOnAddr,
        s.hpfAddr,
        s.invertAddr,
        if (hasTrim) s.trimAddr,
        for (final f in gateFields) s.gateAddr(f),
        for (final f in dynFields) s.dynAddr(f),
      ];

  // ---------------------------------------------------------------- FX

  /// X32 has 8 FX slots (5-8 insert-only), XR has 4.
  int get fxSlots => isYamaha ? 0 : (family == MixerFamily.x32 ? 8 : 4);

  /// Effect codes selectable in [slot] (1-based); index = /fx/N/type value.
  List<String> fxTypesForSlot(int slot) =>
      family == MixerFamily.x32 && slot > 4 ? fxInsertList : fxFullList;

  String fxTypeAddr(int slot) => '/fx/$slot/type';
  String fxParAddr(int slot, int par) => '/fx/$slot/par/${two(par)}';

  /// X32 only: mix bus feeding FX slot 1-4 (0 = insert, 1-16 = MIX 1-16).
  String fxSourceAddr(int slot) => '/fx/$slot/source/l';

  // ---------------------------------------------------------------- bus send point & link
  //
  // Where a channel's send to a bus is taken from (same 6 choices on both):
  //   0 In (input / low cut), 1 Pre EQ, 2 Post EQ, 3 Pre fader, 4 Post fader, 5 Group
  // X32: per bus PAIR, on the odd send:  /ch/NN/mix/01|03|…|15/type
  // XR:  per bus:                         /ch/NN/mix/01…06/tap
  // Stereo link of bus pairs (both):      /config/buslink/1-2, 3-4, …

  /// Mix buses (not FX sends) that inputs send to.
  List<SendTarget> get busTargets => [
        for (final t in sendTargets)
          if (t.master.type == StripType.bus) t,
      ];

  /// Send point address of [s]'s send to bus [mixIndex].
  String tapAddr(Strip s, int mixIndex) => family == MixerFamily.x32
      ? '${s.prefix}/mix/${two(mixIndex.isOdd ? mixIndex : mixIndex - 1)}/type'
      : '${s.prefix}/mix/${two(mixIndex)}/tap';

  /// On X32 the send point is shared by a bus pair.
  bool get tapPerPair => family == MixerFamily.x32;

  int pairStart(int mixIndex) => mixIndex.isOdd ? mixIndex : mixIndex - 1;

  String busLinkAddr(int mixIndex) {
    final a = pairStart(mixIndex);
    return '/config/buslink/$a-${a + 1}';
  }

  /// Inputs whose sends have a send point.
  List<Strip> get tapStrips => [for (final s in inputs) if (s.hasSends) s];

  List<String> get busOptionAddresses {
    if (isYamaha) return const [];
    final out = <String>{};
    for (final t in busTargets) {
      out.add(busLinkAddr(t.mixIndex));
      for (final s in tapStrips) {
        out.add(tapAddr(s, t.mixIndex));
      }
    }
    return out.toList();
  }

  // ---------------------------------------------------------------- solo / monitor
  //
  // /-stat/solosw/NN 0|1 per strip; /-stat/solo 1 while anything is soloed;
  // /-action/clearsolo 1; /config/solo/level = monitor / phones level.
  // X32 numbering: ch 01-32, aux 33-40, fx rtn 41-48, bus 49-64, mtx 65-70,
  //   Main LR 71, M/C 72, DCA 73-80.
  // XR numbering (same scheme, smaller console): ch 01-16, aux 17,
  //   fx rtn 18-21, bus 22-27, fx send 28-31, LR 32, DCA 33-36.

  int? soloIndex(Strip s) {
    if (!hasSolo) return null;
    final x32 = family == MixerFamily.x32;
    return switch (s.type) {
      StripType.channel => s.index,
      StripType.auxIn => x32 ? 32 + s.index : 17,
      StripType.fxReturn => x32 ? 40 + s.index : 17 + s.index,
      StripType.bus => x32 ? 48 + s.index : 21 + s.index,
      StripType.fxSend => x32 ? null : 27 + s.index,
      StripType.matrix => x32 ? 64 + s.index : null,
      StripType.main => x32 ? 71 : 32,
      StripType.mono => x32 ? 72 : null,
      StripType.dca => x32 ? 72 + s.index : 32 + s.index,
    };
  }

  String? soloAddr(Strip s) {
    final i = soloIndex(s);
    return i == null ? null : '/-stat/solosw/${two(i)}';
  }

  static const soloAnyAddr = '/-stat/solo';
  static const clearSoloAddr = '/-action/clearsolo';
  static const monitorLevelAddr = '/config/solo/level';

  List<String> get soloAddresses => !hasSolo ? const [] : [
        soloAnyAddr,
        monitorLevelAddr,
        for (final s in allStrips)
          if (soloAddr(s) != null) soloAddr(s)!,
      ];

  // ---------------------------------------------------------------- groups & assign
  //
  // Mute groups: X32 6, XR 4, on/off /config/mute/N.
  // Membership bitmasks (bit 0 = group / DCA 1):
  //   <strip>/grp/dca, <strip>/grp/mute   (inputs, buses, XR FX sends)
  // Main LR assign: X32 <strip>/mix/st, XR <strip>/mix/lr (inputs, buses).
  // X32 mono / centre: <strip>/mix/mono (on), <strip>/mix/mlevel;
  //   /config/mono/mode 0 LR+M, 1 LCR;  /config/mono/link (M/C follows LR fader).

  int get muteGroupCount => isYamaha ? 0 : (family == MixerFamily.x32 ? 6 : 4);
  String muteGroupAddr(int g) => '/config/mute/$g';

  bool hasGroups(Strip s) => !isYamaha && (switch (s.type) {
        StripType.channel || StripType.auxIn || StripType.fxReturn || StripType.bus => true,
        StripType.fxSend => family == MixerFamily.xr,
        _ => false,
      });

  String dcaMaskAddr(Strip s) => '${s.prefix}/grp/dca';
  String muteMaskAddr(Strip s) => '${s.prefix}/grp/mute';

  String? mainAssignAddr(Strip s) => isYamaha ? null : switch (s.type) {
        StripType.channel || StripType.auxIn || StripType.fxReturn || StripType.bus =>
          family == MixerFamily.x32 ? '${s.prefix}/mix/st' : '${s.prefix}/mix/lr',
        _ => null,
      };

  bool get hasMono => mono != null;
  String? monoAssignAddr(Strip s) => hasMono && mainAssignAddr(s) != null ? '${s.prefix}/mix/mono' : null;
  String? monoLevelAddr(Strip s) => hasMono && mainAssignAddr(s) != null ? '${s.prefix}/mix/mlevel' : null;
  static const monoModeAddr = '/config/mono/mode';
  static const monoLinkAddr = '/config/mono/link';

  /// Strips that can sit in a DCA / mute group.
  List<Strip> get groupStrips => [for (final s in allStrips) if (hasGroups(s)) s];

  // ---------------------------------------------------------------- stereo link
  //
  // Odd/even pairs: /config/chlink/1-2 … (X32 31-32, XR 15-16),
  // X32 also auxlink 1-2…7-8, fxlink 1-2…7-8, mtxlink 1-2…5-6; buslink as above.
  // XR aux / FX returns are always stereo.

  String? linkAddr(Strip s) {
    if (isYamaha) return null;
    final x32 = family == MixerFamily.x32;
    final a = s.index.isOdd ? s.index : s.index - 1;
    final pair = '$a-${a + 1}';
    return switch (s.type) {
      StripType.channel => (x32 || s.index <= 16) &&
              inputs.any((o) => o.type == StripType.channel && o.index == a + 1)
          ? '/config/chlink/$pair'
          : null,
      StripType.auxIn => x32 ? '/config/auxlink/$pair' : null,
      StripType.fxReturn => x32 ? '/config/fxlink/$pair' : null,
      StripType.bus => '/config/buslink/$pair',
      StripType.matrix => x32 ? '/config/mtxlink/$pair' : null,
      _ => null,
    };
  }

  /// The other strip of [s]'s stereo pair.
  Strip? linkPartner(Strip s) {
    final other = s.index.isOdd ? s.index + 1 : s.index - 1;
    for (final o in allStrips) {
      if (o.type == s.type && o.index == other) return o;
    }
    return null;
  }

  List<String> get groupAddresses {
    final out = <String>{
      for (var g = 1; g <= muteGroupCount; g++) muteGroupAddr(g),
      if (hasMono) ...[monoModeAddr, monoLinkAddr],
    };
    for (final s in allStrips) {
      if (hasGroups(s)) out..add(dcaMaskAddr(s))..add(muteMaskAddr(s));
      final m = mainAssignAddr(s);
      if (m != null) out.add(m);
      if (monoAssignAddr(s) != null) out..add(monoAssignAddr(s)!)..add(monoLevelAddr(s)!);
      final l = linkAddr(s);
      if (l != null) out.add(l);
    }
    return out.toList();
  }

  /// Assignments and links belong in a snapshot; mute group on/off does not
  /// (that is a live switch).
  List<String> get groupSnapshotAddresses => [
        for (final a in groupAddresses)
          if (!a.startsWith('/config/mute/')) a,
      ];

  // ---------------------------------------------------------------- matrix (X32)
  //
  // Buses and Main LR send to Matrix 1-6: /bus/NN/mix/MM/level|on,
  // /main/st/mix/MM/level|on (MM = 01-06). XR has no matrices.

  List<Strip> get mixBuses => [for (final s in buses) if (s.type == StripType.bus) s];
  List<Strip> get matrices => [for (final s in buses) if (s.type == StripType.matrix) s];
  bool get hasMatrix => matrices.isNotEmpty;

  List<SendTarget> get matrixTargets => [
        for (var i = 0; i < matrices.length; i++)
          SendTarget(mixIndex: i + 1, label: 'Matrix ${i + 1}', master: matrices[i]),
      ];

  /// What can feed a matrix: the mix buses and Main LR.
  List<Strip> get matrixSources => hasMatrix ? [...mixBuses, main, if (mono != null) mono!] : const [];

  List<String> get matrixSendAddresses => [
        for (final s in matrixSources)
          for (final t in matrixTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)],
      ];

  // ---------------------------------------------------------------- USB recorder
  //
  // The console's own stereo USB-stick recorder: X32 / M32 (top panel) and
  // XR12 / XR16. The XR18 / MR18 don't have one.
  //   /-stat/tape/state 0 STOP, 1 PLAY-PAUSE, 2 PLAY, 3 REC-PAUSE, 4 RECORD,
  //                     5 FF, 6 REW   (0 and 2 confirmed on an XR12)
  //   /-stat/tape/file  current file name

  bool get hasUsbRecorder =>
      family == MixerFamily.x32 || (family == MixerFamily.xr && (model.contains('12') || model.contains('16')));

  static const tapeStateAddr = '/-stat/tape/state';
  static const tapeFileAddr = '/-stat/tape/file';

  // ---------------------------------------------------------------- console library
  //
  // The mixer's own memory (kept on the console, independent of this app):
  //   XR: 64 snapshots, 1-64. Name /-snap/NN/name; /-snap/load|save|delete N;
  //       current /-snap/index. Saving: set /-snap/name, then /-snap/save N.
  //   X32: 100 scenes, 0-99. Name /-show/showfile/scene/NNN/name, filled flag
  //       .../hasdata; load /-action/goscene N; current /-show/prepos/current;
  //       save /save "scene" N name note 0; delete /delete "scene" N.

  int get consoleSlotFirst => family == MixerFamily.x32 ? 0 : 1;
  int get consoleSlotCount => isYamaha ? 0 : (family == MixerFamily.x32 ? 100 : 64);
  Iterable<int> get consoleSlots => Iterable.generate(consoleSlotCount, (i) => consoleSlotFirst + i);

  /// What the console calls these: "Scene" on X32, "Snapshot" on XR.
  String get consoleItemName => family == MixerFamily.x32 ? 'Scene' : 'Snapshot';

  String consoleSlotLabel(int slot) => two(slot);

  String consoleNameAddr(int slot) => family == MixerFamily.x32
      ? '/-show/showfile/scene/${slot.toString().padLeft(3, '0')}/name'
      : '/-snap/${two(slot)}/name';

  /// X32 only: 1 if the scene slot holds data.
  String? consoleHasDataAddr(int slot) => family == MixerFamily.x32
      ? '/-show/showfile/scene/${slot.toString().padLeft(3, '0')}/hasdata'
      : null;

  String get consoleCurrentAddr => family == MixerFamily.x32 ? '/-show/prepos/current' : '/-snap/index';

  List<String> get consoleLibraryAddresses => !hasConsoleLibrary ? const [] : [
        consoleCurrentAddr,
        for (final i in consoleSlots) ...[
          consoleNameAddr(i),
          if (consoleHasDataAddr(i) != null) consoleHasDataAddr(i)!,
        ],
      ];

  // ---------------------------------------------------------------- snapshots

  /// Everything a snapshot stores and recalls.
  ///
  /// Deliberately left out: preamp gain and +48V (a recall must never switch
  /// phantom power or jump gain), and input routing.
  List<String> snapshotAddresses() {
    final out = <String>[...matrixSendAddresses, ...busOptionAddresses, ...groupSnapshotAddresses];
    for (var slot = 1; slot <= fxSlots; slot++) {
      out.add(fxTypeAddr(slot));
      for (var p = 1; p <= fxParamsMax; p++) {
        out.add(fxParAddr(slot, p));
      }
    }
    for (final s in allStrips) {
      out
        ..add(s.nameAddr)
        ..add(s.colorAddr)
        ..add(s.onAddr)
        ..add(s.faderAddr);
      if (s.hasSends) {
        for (final t in sendTargets) {
          out
            ..add(s.sendLevelAddr(t))
            ..add(s.sendOnAddr(t));
        }
      }
      out.addAll(s.eqAddresses);
      if (s.hasDetail) {
        out
          ..add(s.panAddr)
          ..add(s.hpOnAddr)
          ..add(s.hpfAddr)
          ..add(s.invertAddr);
        if (hasTrim) out.add(s.trimAddr);
        for (final f in gateFields) {
          out.add(s.gateAddr(f));
        }
        for (final f in dynFields) {
          out.add(s.dynAddr(f));
        }
      }
    }
    return out;
  }

  static MixerFamily? familyFromModel(String model) {
    final m = model.toUpperCase();
    if (m.contains('XR') || m.contains('MR1') || m.contains('X18')) return MixerFamily.xr;
    if (m.contains('X32') || m.contains('M32')) return MixerFamily.x32;
    return null;
  }

  static int defaultPort(MixerFamily f) => switch (f) {
        MixerFamily.x32 => 10023,
        MixerFamily.xr => 10024,
        MixerFamily.yamaha => 49280,
      };

  factory MixerProfile.forFamily(MixerFamily family, String model, {YamahaLayout? layout}) => switch (family) {
        MixerFamily.x32 => _x32(model),
        MixerFamily.xr => _xr(model),
        MixerFamily.yamaha => yamaha(model, layout ?? YamahaLayout.forModel(model)),
      };

  // ---------------------------------------------------------------- Yamaha
  //
  // The app keeps its own (X32-style) addresses; the Yamaha link translates
  // them to the console's remote control protocol:
  //   /ch/NN     InCh      /auxin/NN  StInCh     /fxrtn/NN  FxRtnCh
  //   /bus/NN    Mix (AUX) /main/st   St         /dca/N     DCA
  // Counts come from the console itself (probed at connect).

  static MixerProfile yamaha(String model, YamahaLayout l) {
    final inputs = <Strip>[
      for (var i = 1; i <= l.inputs; i++)
        Strip(type: StripType.channel, index: i, prefix: '/ch/${two(i)}', defaultLabel: 'CH $i',
            hasSends: true, simple: true),
      for (var i = 1; i <= l.stereoInputs; i++)
        Strip(type: StripType.auxIn, index: i, prefix: '/auxin/${two(i)}', defaultLabel: 'ST IN $i',
            hasSends: true, simple: true),
      for (var i = 1; i <= l.fxReturns; i++)
        Strip(type: StripType.fxReturn, index: i, prefix: '/fxrtn/${two(i)}', defaultLabel: 'FX RTN $i',
            hasSends: true, simple: true),
    ];
    final busList = [
      for (var i = 1; i <= l.mixes; i++)
        Strip(type: StripType.bus, index: i, prefix: '/bus/${two(i)}', defaultLabel: '${l.mixWord} $i', simple: true),
    ];
    return MixerProfile._(
      family: MixerFamily.yamaha,
      model: model,
      port: 49280,
      inputs: inputs,
      buses: busList,
      dcas: [
        for (var i = 1; i <= l.dcas; i++)
          Strip(type: StripType.dca, index: i, prefix: '/dca/$i', defaultLabel: 'DCA $i', simple: true),
      ],
      main: const Strip(type: StripType.main, index: 0, prefix: '/main/st', defaultLabel: 'STEREO', simple: true),
      sendTargets: [
        for (var i = 1; i <= l.mixes; i++)
          SendTarget(mixIndex: i, label: '${l.mixWord} $i', master: busList[i - 1]),
      ],
      meterFormat: MeterFormat.int16Db,
      meterRequests: const [],
    );
  }

  // X32 meters:
  //   /meters/0 (70): ch 1-32 [0-31], aux in 1-8 [32-39], fx rtn 1-8 [40-47],
  //                   bus 1-16 [48-63], matrix 1-6 [64-69]
  //   /meters/2 (49): bus [0-15], matrix [16-21], main L/R [22-23], mono [24], ...
  static MixerProfile _x32(String model) {
    const m0 = '/meters/0';
    final inputs = <Strip>[
      for (var i = 1; i <= 32; i++)
        Strip(type: StripType.channel, index: i, prefix: '/ch/${two(i)}', defaultLabel: 'Ch $i',
            hasSends: true, meterId: m0, meterIdx: [i - 1]),
      for (var i = 1; i <= 8; i++)
        Strip(type: StripType.auxIn, index: i, prefix: '/auxin/${two(i)}', defaultLabel: 'Aux $i',
            hasSends: true, meterId: m0, meterIdx: [31 + i]),
      for (var i = 1; i <= 8; i++)
        Strip(type: StripType.fxReturn, index: i, prefix: '/fxrtn/${two(i)}', defaultLabel: 'FX $i',
            hasSends: true, meterId: m0, meterIdx: [39 + i]),
    ];
    final busList = [
      for (var i = 1; i <= 16; i++)
        Strip(type: StripType.bus, index: i, prefix: '/bus/${two(i)}', defaultLabel: 'Bus $i',
            meterId: m0, meterIdx: [47 + i]),
    ];
    final buses = <Strip>[
      ...busList,
      for (var i = 1; i <= 6; i++)
        Strip(type: StripType.matrix, index: i, prefix: '/mtx/${two(i)}', defaultLabel: 'Mtx $i',
            meterId: m0, meterIdx: [63 + i]),
    ];
    return MixerProfile._(
      family: MixerFamily.x32,
      model: model,
      port: 10023,
      inputs: inputs,
      buses: buses,
      dcas: [
        for (var i = 1; i <= 8; i++)
          Strip(type: StripType.dca, index: i, prefix: '/dca/$i', defaultLabel: 'DCA $i'),
      ],
      main: const Strip(type: StripType.main, index: 0, prefix: '/main/st', defaultLabel: 'Main LR',
          meterId: '/meters/2', meterIdx: [22, 23]),
      sendTargets: [
        for (var i = 1; i <= 16; i++) SendTarget(mixIndex: i, label: 'Bus $i', master: busList[i - 1]),
      ],
      mono: const Strip(type: StripType.mono, index: 0, prefix: '/main/m', defaultLabel: 'M/C',
          meterId: '/meters/2', meterIdx: [24]),
      meterFormat: MeterFormat.float32Linear,
      meterRequests: const ['/meters/0', '/meters/2'],
    );
  }

  // XR meters, /meters/1 (40): ch 1-16 [0-15], aux L/R [16-17],
  //   fx rtn 1-4 L/R [18-25], bus 1-6 [26-31], fx send 1-4 [32-35],
  //   main L/R [36-37], monitor L/R [38-39]
  static MixerProfile _xr(String model) {
    const m1 = '/meters/1';
    // XR12 exposes 12 input channels, XR16/XR18/MR18 expose 16.
    final channels = model.contains('12') ? 12 : 16;
    final inputs = <Strip>[
      for (var i = 1; i <= channels; i++)
        Strip(type: StripType.channel, index: i, prefix: '/ch/${two(i)}', defaultLabel: 'Ch $i',
            hasSends: true, meterId: m1, meterIdx: [i - 1]),
      const Strip(type: StripType.auxIn, index: 1, prefix: '/rtn/aux', defaultLabel: 'Aux In',
          hasSends: true, meterId: m1, meterIdx: [16, 17]),
      for (var i = 1; i <= 4; i++)
        Strip(type: StripType.fxReturn, index: i, prefix: '/rtn/$i', defaultLabel: 'FX $i',
            hasSends: true, meterId: m1, meterIdx: [16 + 2 * i, 17 + 2 * i]),
    ];
    final busList = [
      for (var i = 1; i <= 6; i++)
        Strip(type: StripType.bus, index: i, prefix: '/bus/$i', defaultLabel: 'Bus $i',
            meterId: m1, meterIdx: [25 + i]),
    ];
    final fxSends = [
      for (var i = 1; i <= 4; i++)
        Strip(type: StripType.fxSend, index: i, prefix: '/fxsend/$i', defaultLabel: 'FX Snd $i',
            meterId: m1, meterIdx: [31 + i]),
    ];
    return MixerProfile._(
      family: MixerFamily.xr,
      model: model,
      port: 10024,
      inputs: inputs,
      buses: [...busList, ...fxSends],
      dcas: [
        for (var i = 1; i <= 4; i++)
          Strip(type: StripType.dca, index: i, prefix: '/dca/$i', defaultLabel: 'DCA $i'),
      ],
      main: const Strip(type: StripType.main, index: 0, prefix: '/lr', defaultLabel: 'Main LR',
          meterId: m1, meterIdx: [36, 37]),
      sendTargets: [
        for (var i = 1; i <= 6; i++) SendTarget(mixIndex: i, label: 'Bus $i', master: busList[i - 1]),
        // On XR, mix sends 07..10 feed FX 1..4.
        for (var i = 1; i <= 4; i++) SendTarget(mixIndex: 6 + i, label: 'FX $i', master: fxSends[i - 1]),
      ],
      meterFormat: MeterFormat.int16Db,
      meterRequests: const [m1],
    );
  }
}


/// How many of each strip a Yamaha console has (read from the console at
/// connect; [forModel] is the fallback for demo mode and old firmware).
class YamahaLayout {
  const YamahaLayout({
    required this.inputs,
    required this.stereoInputs,
    required this.fxReturns,
    required this.mixes,
    required this.dcas,
    this.mixWord = 'AUX',
  });

  final int inputs;
  final int stereoInputs;
  final int fxReturns;
  final int mixes;
  final int dcas;

  /// TF calls its buses AUX, the DM / QL / CL series MIX.
  final String mixWord;

  /// Upper limits the app shows (the largest consoles have more).
  static const maxInputs = 72, maxStereo = 8, maxFxReturns = 8, maxMixes = 48, maxDcas = 24;

  static String mixWordFor(String model) => model.toUpperCase().contains('TF') ? 'AUX' : 'MIX';

  /// Estimates when the console can't be asked (demo).
  factory YamahaLayout.forModel(String model) {
    final m = model.toUpperCase();
    if (m.contains('DM3')) {
      return const YamahaLayout(inputs: 16, stereoInputs: 1, fxReturns: 2, mixes: 6, dcas: 8, mixWord: 'MIX');
    }
    if (m.contains('TF')) {
      return const YamahaLayout(inputs: 32, stereoInputs: 2, fxReturns: 2, mixes: 20, dcas: 8);
    }
    return YamahaLayout(inputs: 32, stereoInputs: 2, fxReturns: 2, mixes: 16, dcas: 8, mixWord: mixWordFor(model));
  }
}
