import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'mixer_profile.dart';

/// One saved mix.
class Snapshot {
  Snapshot({
    required this.id,
    required this.name,
    required this.family,
    required this.model,
    required this.savedAt,
    required this.values,
  });

  final String id;
  String name;
  final MixerFamily family;
  final String model;
  DateTime savedAt;
  Map<String, Object> values;

  Map<String, Object?> toJson() => {
        'id': id,
        'name': name,
        'family': family.name,
        'model': model,
        'savedAt': savedAt.millisecondsSinceEpoch,
        'values': values,
      };

  static Snapshot? fromJson(Map<String, dynamic> j) {
    try {
      final fam = MixerFamily.values.firstWhere((f) => f.name == j['family']);
      final raw = (j['values'] as Map).cast<String, dynamic>();
      final values = <String, Object>{};
      raw.forEach((k, v) {
        if (v is int || v is double || v is String) values[k] = v as Object;
      });
      return Snapshot(
        id: j['id'] as String,
        name: j['name'] as String,
        family: fam,
        model: j['model'] as String? ?? '',
        savedAt: DateTime.fromMillisecondsSinceEpoch(j['savedAt'] as int),
        values: values,
      );
    } catch (_) {
      return null;
    }
  }
}

/// Snapshots kept on the phone (SharedPreferences, one JSON list).
class SnapshotStore {
  static const _key = 'snapshots_v1';

  static Future<List<Snapshot>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List;
      return [
        for (final e in list)
          if (e is Map) Snapshot.fromJson(e.cast<String, dynamic>()),
      ].whereType<Snapshot>().toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> save(List<Snapshot> all) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode([for (final s in all) s.toJson()]));
  }

  static String newId() => DateTime.now().microsecondsSinceEpoch.toRadixString(36);
}
