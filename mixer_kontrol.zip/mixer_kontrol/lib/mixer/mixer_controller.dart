import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../osc/meters.dart';
import '../osc/osc_client.dart';
import '../osc/osc_message.dart';
import '../util/eq_math.dart';
import '../util/param_law.dart';
import 'fx_catalog.dart';
import 'inserts.dart';
import 'mixer_profile.dart';
import 'rta.dart';

enum ConnState { connected, lost }

enum HeadampStatus { resolved, pending, none }

/// Which preamp an input channel uses right now.
class HeadampInfo {
  const HeadampInfo(this.status, [this.prefix, this.name]);
  final HeadampStatus status;
  final String? prefix; // e.g. /headamp/004
  final String? name; // e.g. Local 5
  String? get gainAddr => prefix == null ? null : '$prefix/gain';
  String? get phantomAddr => prefix == null ? null : '$prefix/phantom';
}

class MixerConnectException implements Exception {
  MixerConnectException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Holds the live state of one console. Every OSC address has its own
/// ValueNotifier, so a fader move only rebuilds that one fader.
class MixerController extends ChangeNotifier {
  MixerController._(this.profile, this._client, {required this.mixerName, required this.host}) {
    for (final s in profile.allStrips) {
      if (s.hasMeter) (_meterStrips[s.meterId!] ??= []).add(s);
    }
  }

  final MixerProfile profile;
  final OscClient? _client; // null = demo mode
  final String host;
  String mixerName;

  ConnState _state = ConnState.connected;
  ConnState get state => _state;
  bool get isDemo => _client == null;

  final Map<String, ValueNotifier<Object?>> _params = {};
  final Set<String> _touched = {};
  StreamSubscription<OscMessage>? _sub;
  Timer? _keepAlive;
  Timer? _demoMeters;

  /// Live meter levels (dBFS) keyed by strip prefix.
  final MeterLevels meters = MeterLevels();
  final Map<String, List<Strip>> _meterStrips = {};
  DateTime _lastRx = DateTime.now();
  bool _disposed = false;

  // ---------------------------------------------------------------- connect

  /// Connects to [host]. If [family] is null the model is detected via /xinfo,
  /// trying the X32 port first and then the XR port.
  static Future<MixerController> connect(String host, {MixerFamily? family}) async {
    final ports = family == null
        ? const [10023, 10024]
        : [MixerProfile.defaultPort(family)];
    for (final port in ports) {
      final client = await OscClient.open(host, port);
      final info = await client.request('/xinfo');
      if (info != null && info.args.length >= 3) {
        final model = info.args[2].toString();
        final fam = MixerProfile.familyFromModel(model) ??
            family ??
            (port == 10023 ? MixerFamily.x32 : MixerFamily.xr);
        final c = MixerController._(
          MixerProfile.forFamily(fam, model),
          client,
          mixerName: info.args[1].toString(),
          host: host,
        );
        c._start();
        return c;
      }
      client.close();
    }
    throw MixerConnectException('No mixer answered at $host.');
  }

  factory MixerController.demo(MixerFamily family) {
    final c = MixerController._(
      MixerProfile.forFamily(family, family == MixerFamily.x32 ? 'X32' : 'XR18'),
      null,
      mixerName: 'Demo',
      host: '',
    );
    c._seedDemo();
    return c;
  }

  void _start() {
    final client = _client!;
    _sub = client.messages.listen(_onMessage);
    client.send(const OscMessage('/xremote'));
    _subscribeMeters();
    // Consoles drop /xremote and /meters subscriptions after ~10 s, so renew every 8 s.
    _keepAlive = Timer.periodic(const Duration(seconds: 8), (_) {
      client.send(const OscMessage('/xremote'));
      _subscribeMeters();
      client.send(const OscMessage('/xinfo'));
      if (_state == ConnState.connected &&
          DateTime.now().difference(_lastRx) > const Duration(seconds: 20)) {
        _state = ConnState.lost;
        meters.clear(); // don't show frozen levels
        notifyListeners();
      }
    });
    refreshAll();
  }

  void _subscribeMeters() {
    for (final id in {...profile.meterRequests, ..._extraMeters}) {
      _client?.send(OscMessage('/meters', [id]));
    }
  }

  // ---------------------------------------------------------------- RTA & gain reduction

  /// Spectrum of the strip being analysed (see [watchRta]).
  final RtaData rta = RtaData();

  /// Gate / compressor gain reduction in dB (≤ 0), keyed '<prefix>/gate'
  /// and '<prefix>/dyn'. Only fed while [watchGainReduction] is active.
  final MeterLevels gainReduction = MeterLevels();

  final Set<String> _extraMeters = {};
  Strip? _rtaStrip;
  int _grWatchers = 0;

  String get _rtaMeterId => profile.family == MixerFamily.x32 ? '/meters/15' : '/meters/4';
  String get _grMeterId => profile.family == MixerFamily.x32 ? '/meters/1' : '/meters/6';

  /// X32 strip index used by /-stat/selidx (the console's selected strip,
  /// which its RTA follows).
  int? _x32SelIdx(Strip s) => switch (s.type) {
        StripType.channel => s.index - 1,
        StripType.auxIn => 31 + s.index,
        StripType.fxReturn => 39 + s.index,
        StripType.bus => 47 + s.index,
        StripType.matrix => 63 + s.index,
        StripType.main => 70,
        StripType.mono => 71,
        _ => null,
      };

  /// XR RTA source (/-stat/rta/source).
  int? _xrRtaSource(Strip s) => switch (s.type) {
        StripType.channel => s.index - 1,
        StripType.auxIn => 16,
        StripType.fxReturn => 16 + s.index,
        StripType.bus => 20 + s.index,
        StripType.fxSend => 26 + s.index,
        StripType.main => 31,
        _ => null,
      };

  Strip? get rtaStrip => _rtaStrip;

  /// Starts the analyser on [s] (replacing any other). On the X32 this also
  /// selects [s] on the console, because its RTA follows the selection.
  void watchRta(Strip s) {
    _rtaStrip = s;
    rta.clear();
    if (profile.family == MixerFamily.x32) {
      final i = _x32SelIdx(s);
      if (i != null) set('/-stat/selidx', i);
    } else {
      final i = _xrRtaSource(s);
      if (i != null) set('/-stat/rta/source', i);
    }
    _extraMeters.add(_rtaMeterId);
    _client?.send(OscMessage('/meters', [_rtaMeterId]));
  }

  void unwatchRta() {
    _rtaStrip = null;
    _extraMeters.remove(_rtaMeterId);
    rta.clear();
  }

  void watchGainReduction() {
    _grWatchers++;
    _extraMeters.add(_grMeterId);
    _client?.send(OscMessage('/meters', [_grMeterId]));
  }

  void unwatchGainReduction() {
    _grWatchers = math.max(0, _grWatchers - 1);
    if (_grWatchers == 0) _extraMeters.remove(_grMeterId);
  }

  void _onGainReduction(Uint8List blob) {
    final update = <String, double>{};
    final channels = profile.inputs.where((s) => s.type == StripType.channel).toList();
    if (profile.family == MixerFamily.x32) {
      final v = decodeMeterBlob(blob, MeterFormat.float32Linear); // dBFS of a gain factor
      for (final s in channels) {
        final g = 31 + s.index, d = 63 + s.index;
        if (d < v.length) {
          update['${s.prefix}/gate'] = math.min(0, v[g]);
          update['${s.prefix}/dyn'] = math.min(0, v[d]);
        }
      }
    } else {
      final v = decodeRtaBlob(blob);
      for (final s in channels) {
        final g = s.index - 1, d = 15 + s.index;
        if (d < v.length) {
          update['${s.prefix}/gate'] = -v[g].abs();
          update['${s.prefix}/dyn'] = -v[d].abs();
        }
      }
    }
    gainReduction.update(update);
  }

  void _onMeters(String id, Uint8List blob) {
    final strips = _meterStrips[id];
    if (strips == null) return;
    final values = decodeMeterBlob(blob, profile.meterFormat);
    final update = <String, double>{};
    for (final s in strips) {
      var db = double.negativeInfinity;
      for (final i in s.meterIdx) {
        if (i < values.length && values[i] > db) db = values[i];
      }
      update[s.prefix] = db;
    }
    meters.update(update);
  }

  // ---------------------------------------------------------------- state

  /// Diagnostics: how many addresses are held, and which.
  int get paramCount => _params.length;
  Iterable<String> get knownAddresses => _params.keys;

  ValueNotifier<Object?> param(String addr) =>
      _params.putIfAbsent(addr, () => ValueNotifier<Object?>(null));

  double faderOf(String addr) {
    final v = param(addr).value;
    return v is num ? v.toDouble() : 0.0;
  }

  double numOf(String addr, double fallback) {
    final v = param(addr).value;
    return v is num ? v.toDouble() : fallback;
  }

  int intOf(String addr, int fallback) {
    final v = param(addr).value;
    return v is num ? v.toInt() : fallback;
  }

  /// For switches whose "off" is the safe default (phantom, phase, low cut).
  bool flagOf(String addr) {
    final v = param(addr).value;
    return v is num && v != 0;
  }

  void setFlag(String addr, bool on) => set(addr, on ? 1 : 0);

  int? _intOrNull(String addr) {
    final v = param(addr).value;
    return v is num ? v.toInt() : null;
  }

  /// Resolves the preamp for [s]. On X32 this follows source → routing →
  /// user routing, and stays [HeadampStatus.pending] until every value it
  /// needs has arrived, so gain/+48V are never sent to a guessed preamp.
  HeadampInfo headampFor(Strip s) {
    if (s.type != StripType.channel) return const HeadampInfo(HeadampStatus.none);
    if (profile.family == MixerFamily.xr) {
      return HeadampInfo(HeadampStatus.resolved, '/headamp/${two(s.index)}', 'Input ${s.index}');
    }
    final idx = MixerProfile.x32HeadampIndex(s.index, _intOrNull);
    if (idx == null) return const HeadampInfo(HeadampStatus.pending);
    if (idx < 0) return const HeadampInfo(HeadampStatus.none);
    return HeadampInfo(
      HeadampStatus.resolved,
      MixerProfile.x32HeadampPrefix(idx),
      MixerProfile.x32HeadampName(idx),
    );
  }

  // ---------------------------------------------------------------- bus send point & link

  static const tapLabels = ['In', 'Pre EQ', 'Post EQ', 'Pre fader', 'Post fader', 'Group'];
  static const tapShort = ['IN', '<EQ', 'EQ>', 'PRE', 'POST', 'GRP'];

  /// Send point of every input's send to [t]: the common value, -1 if the
  /// channels differ, null while unknown.
  int? busTap(SendTarget t) {
    int? common;
    for (final s in profile.tapStrips) {
      final v = param(profile.tapAddr(s, t.mixIndex)).value;
      if (v is! num) continue;
      if (common == null) {
        common = v.toInt();
      } else if (common != v.toInt()) {
        return -1;
      }
    }
    return common;
  }

  bool busLinked(SendTarget t) => flagOf(profile.busLinkAddr(t.mixIndex));

  /// Sets the send point of all inputs' sends to [t] (on XR, both buses of
  /// a linked pair).
  void setBusTap(SendTarget t, int tap) {
    final p = profile;
    final mixes = <int>{t.mixIndex};
    if (!p.tapPerPair && busLinked(t)) {
      final a = p.pairStart(t.mixIndex);
      mixes.addAll([a, a + 1]);
    }
    for (final s in p.tapStrips) {
      for (final m in mixes) {
        set(p.tapAddr(s, m), tap);
      }
    }
  }

  void setBusLinked(SendTarget t, bool on) => set(profile.busLinkAddr(t.mixIndex), on ? 1 : 0);

  // ---------------------------------------------------------------- mute lock

  /// While on, MUTE buttons in the app don't respond (guards against
  /// accidental taps during a show). App-side only; the console is unaffected.
  final ValueNotifier<bool> muteLock = ValueNotifier<bool>(false);

  // ---------------------------------------------------------------- solo / monitor

  bool soloOn(Strip s) {
    final a = profile.soloAddr(s);
    return a != null && flagOf(a);
  }

  void toggleSolo(Strip s) {
    final a = profile.soloAddr(s);
    if (a == null) return;
    set(a, soloOn(s) ? 0 : 1);
    _updateAnySolo();
  }

  /// True while any strip is soloed (from the console's flag or our own).
  bool get anySolo {
    if (flagOf(MixerProfile.soloAnyAddr)) return true;
    for (final s in profile.allStrips) {
      if (soloOn(s)) return true;
    }
    return false;
  }

  void _updateAnySolo() {
    var any = false;
    for (final s in profile.allStrips) {
      if (soloOn(s)) any = true;
    }
    param(MixerProfile.soloAnyAddr).value = any ? 1 : 0;
  }

  void clearSolo() {
    command(MixerProfile.clearSoloAddr, [1]);
    for (final s in profile.allStrips) {
      final a = profile.soloAddr(s);
      if (a != null && flagOf(a)) set(a, 0);
    }
    param(MixerProfile.soloAnyAddr).value = 0;
  }

  // ---------------------------------------------------------------- groups & assign

  bool maskBit(String addr, int bit) => (intOf(addr, 0) >> bit) & 1 == 1;

  void setMaskBit(String addr, int bit, bool on) {
    final v = intOf(addr, 0);
    set(addr, on ? (v | (1 << bit)) : (v & ~(1 << bit)));
  }

  bool inDca(Strip s, int dca) => profile.hasGroups(s) && maskBit(profile.dcaMaskAddr(s), dca - 1);
  void setInDca(Strip s, int dca, bool on) => setMaskBit(profile.dcaMaskAddr(s), dca - 1, on);
  bool inMuteGroup(Strip s, int g) => profile.hasGroups(s) && maskBit(profile.muteMaskAddr(s), g - 1);
  void setInMuteGroup(Strip s, int g, bool on) => setMaskBit(profile.muteMaskAddr(s), g - 1, on);

  /// Strips assigned to DCA [dca] (1-based), in console order.
  List<Strip> dcaMembers(int dca) => [for (final s in profile.groupStrips) if (inDca(s, dca)) s];

  /// Mute groups and DCA assignments have to be known for the spill view.
  Future<void> queryGroups() => query(profile.groupAddresses);

  // ---------------------------------------------------------------- console library

  /// Sends a command that is not a stored parameter (load, save, delete…).
  void command(String addr, [List<Object> args = const []]) {
    _client?.send(OscMessage(addr, args));
  }

  /// True if console slot [slot] holds a snapshot / scene.
  bool consoleSlotUsed(int slot) {
    final hd = profile.consoleHasDataAddr(slot);
    if (hd != null) {
      final v = param(hd).value;
      if (v is num) return v != 0;
    }
    final n = param(profile.consoleNameAddr(slot)).value;
    return n is String && n.trim().isNotEmpty;
  }

  String consoleSlotName(int slot) {
    final n = param(profile.consoleNameAddr(slot)).value;
    return n is String ? n.trim() : '';
  }

  int? get consoleCurrent {
    final v = param(profile.consoleCurrentAddr).value;
    return v is num ? v.toInt() : null;
  }

  /// Recalls a console snapshot / scene, then re-reads everything, since a
  /// recall changes far more than the console reports one by one.
  Future<void> consoleLoad(int slot) async {
    param(profile.consoleCurrentAddr).value = slot;
    if (isDemo) return;
    command(profile.family == MixerFamily.x32 ? '/-action/goscene' : '/-snap/load', [slot]);
    await Future<void>.delayed(const Duration(milliseconds: 800));
    await refreshAll();
  }

  void consoleSave(int slot, String name) {
    param(profile.consoleNameAddr(slot)).value = name;
    final hd = profile.consoleHasDataAddr(slot);
    if (hd != null) param(hd).value = 1;
    param(profile.consoleCurrentAddr).value = slot;
    if (isDemo) return;
    if (profile.family == MixerFamily.x32) {
      command('/save', ['scene', slot, name, '', 0]);
    } else {
      command('/-snap/name', [name]);
      command('/-snap/save', [slot]);
    }
    Future<void>.delayed(const Duration(milliseconds: 500), () => query(profile.consoleLibraryAddresses));
  }

  void consoleDelete(int slot) {
    param(profile.consoleNameAddr(slot)).value = '';
    final hd = profile.consoleHasDataAddr(slot);
    if (hd != null) param(hd).value = 0;
    if (isDemo) return;
    if (profile.family == MixerFamily.x32) {
      command('/delete', ['scene', slot]);
    } else {
      command('/-snap/delete', [slot]);
    }
    Future<void>.delayed(const Duration(milliseconds: 500), () => query(profile.consoleLibraryAddresses));
  }

  // ---------------------------------------------------------------- snapshots

  /// Fetches every snapshot value from the console (no-op in demo), then
  /// waits briefly for the last replies.
  Future<void> syncForSnapshot({void Function(double)? onProgress}) async {
    final addrs = profile.snapshotAddresses();
    final client = _client;
    if (client == null) {
      onProgress?.call(1);
      return;
    }
    for (var i = 0; i < addrs.length; i++) {
      if (_disposed) return;
      client.send(OscMessage(addrs[i]));
      if (i % 16 == 15) {
        onProgress?.call(i / addrs.length * 0.9);
        await Future<void>.delayed(const Duration(milliseconds: 12));
      }
    }
    await Future<void>.delayed(const Duration(milliseconds: 700));
    onProgress?.call(1);
  }

  /// Current known values of everything a snapshot stores.
  Map<String, Object> captureSnapshot() {
    final out = <String, Object>{};
    for (final a in profile.snapshotAddresses()) {
      final v = _params[a]?.value;
      if (v is int || v is double || v is String) out[a] = v!;
    }
    return out;
  }

  static final _fxTypeRe = RegExp(r'^/fx/\d+/type$');

  /// Recalls [values]: effect types first (changing a type resets that
  /// slot's parameters), a short pause, then everything else.
  Future<void> recallSnapshot(Map<String, Object> values, {void Function(double)? onProgress}) async {
    final types = values.entries.where((e) => _fxTypeRe.hasMatch(e.key)).toList();
    final rest = values.entries.where((e) => !_fxTypeRe.hasMatch(e.key)).toList();
    final total = types.length + rest.length;
    var done = 0;
    Future<void> sendAll(List<MapEntry<String, Object>> list) async {
      for (final e in list) {
        if (_disposed) return;
        param(e.key).value = e.value;
        _client?.send(OscMessage(e.key, [e.value]));
        done++;
        if (done % 16 == 0) {
          onProgress?.call(done / total);
          if (_client != null) await Future<void>.delayed(const Duration(milliseconds: 12));
        }
      }
    }

    await sendAll(types);
    if (_client != null && types.isNotEmpty) {
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    await sendAll(rest);
    onProgress?.call(1);
  }

  /// Asks the console for the current value of each address.
  Future<void> query(List<String> addrs) async {
    final client = _client;
    if (client == null) return;
    for (var i = 0; i < addrs.length; i++) {
      if (_disposed) return;
      client.send(OscMessage(addrs[i]));
      if (i % 16 == 15) await Future<void>.delayed(const Duration(milliseconds: 12));
    }
  }

  bool isOn(String addr) {
    final v = param(addr).value;
    return v is num ? v != 0 : true;
  }

  /// Queries every control on the console. Sent in small batches so the
  /// console's UDP buffer is not flooded.
  Future<void> refreshAll() async {
    final client = _client;
    if (client == null) return;
    final addrs = profile.queryAddresses;
    for (var i = 0; i < addrs.length; i++) {
      if (_disposed) return;
      client.send(OscMessage(addrs[i]));
      if (i % 16 == 15) await Future<void>.delayed(const Duration(milliseconds: 12));
    }
  }

  void _onMessage(OscMessage m) {
    _lastRx = DateTime.now();
    if (_state == ConnState.lost) {
      _state = ConnState.connected;
      notifyListeners();
      refreshAll(); // something may have changed while we were away
    }
    if (m.args.isEmpty) return;
    if (m.address.startsWith('/meters/')) {
      final blob = m.args.first;
      if (blob is! Uint8List) return;
      if (m.address == _rtaMeterId && _extraMeters.contains(_rtaMeterId)) {
        rta.update(decodeRtaBlob(blob));
      } else if (m.address == _grMeterId && _extraMeters.contains(_grMeterId) && !_meterStrips.containsKey(m.address)) {
        _onGainReduction(blob);
      } else {
        _onMeters(m.address, blob);
      }
      return;
    }
    if (m.address == '/xinfo') {
      final name = m.args.length >= 2 ? _clip(m.args[1].toString()) : mixerName;
      if (name != mixerName) {
        mixerName = name;
        notifyListeners();
      }
      return;
    }
    // Don't let incoming values fight a finger that is on the fader.
    if (_touched.contains(m.address)) return;
    // Security: keep state only for addresses this app uses, and cap it, so
    // a flood of made-up addresses can't exhaust memory.
    if (!_params.containsKey(m.address) &&
        (!acceptsAddress(m.address) || _params.length >= maxParams)) {
      return;
    }
    var v = m.args.first;
    if (v is Uint8List) return; // blobs are only meaningful as meters
    if (v is String) v = _clip(v);
    param(m.address).value = v;
  }

  /// Upper bound on stored parameters (the largest console needs ~10 000).
  static const maxParams = 30000;

  /// Longest text kept from the mixer (names are 12-32 characters there).
  static const maxText = 64;

  static String _clip(String s) => s.length > maxText ? s.substring(0, maxText) : s;

  /// OSC address families this app reads from X32 / X Air consoles.
  static const _allowedPrefixes = [
    '/ch/', '/bus/', '/mtx/', '/main/', '/lr/', '/dca/', '/auxin/', '/fxrtn/', '/rtn/', //
    '/fxsend/', '/fx/', '/headamp/', '/config/', '/-snap/', '/-show/', '/-stat/',
    '/-prefs/', '/outputs/', '/routing/', '/-urec/', '/-usb/',
  ];

  static bool acceptsAddress(String a) =>
      a.length <= 64 && !a.contains('..') && _allowedPrefixes.any(a.startsWith);

  // ---------------------------------------------------------------- actions

  void set(String addr, Object value) {
    param(addr).value = value;
    _client?.send(OscMessage(addr, [value]));
  }

  void setFader(String addr, double v) => set(addr, v.clamp(0.0, 1.0).toDouble());

  void toggleOn(String addr) => set(addr, isOn(addr) ? 0 : 1);

  void rename(Strip s, String name) => set(s.nameAddr, name.length > 12 ? name.substring(0, 12) : name);

  void beginTouch(String addr) => _touched.add(addr);
  void endTouch(String addr) => _touched.remove(addr);

  void _seedDemo() {
    var color = 1;
    for (final s in profile.allStrips) {
      param(s.nameAddr).value = '';
      param(s.colorAddr).value = s.type == StripType.main ? 7 : (color++ % 7) + 1;
      param(s.onAddr).value = 1;
      param(s.faderAddr).value = s.type == StripType.channel ? 0.6 : 0.75;
      if (s.hasSends) {
        for (final t in profile.sendTargets) {
          param(s.sendLevelAddr(t)).value = 0.0;
          param(s.sendOnAddr(t)).value = 1;
        }
      }
      if (s.hasEq) _seedDemoEq(s);
      if (s.hasDetail) _seedDemoDetail(s);
    }
    // X32: FX 1-4 fed from buses 13-16 (a common console layout).
    if (profile.family == MixerFamily.x32) {
      for (var slot = 1; slot <= 4; slot++) {
        param(profile.fxSourceAddr(slot)).value = 12 + slot;
      }
    }
    // FX: reverbs and a delay in the send slots, a GEQ / comps as inserts.
    const demoFx = ['HALL', 'PLAT', 'DLY', 'CRS', 'GEQ2', 'FAC', 'LEC', 'ULC'];
    for (var slot = 1; slot <= profile.fxSlots; slot++) {
      final list = profile.fxTypesForSlot(slot);
      final idx = list.indexOf(demoFx[slot - 1]);
      param(profile.fxTypeAddr(slot)).value = idx < 0 ? 0 : idx;
      for (var p = 1; p <= fxParamsShown; p++) {
        param(profile.fxParAddr(slot, p)).value = 0.5;
      }
    }
    // Matrix sends (X32): Main LR feeds Matrix 1-2 at 0 dB, the rest off.
    for (final src in profile.matrixSources) {
      for (final t in profile.matrixTargets) {
        final feeds = src.type == StripType.main && t.mixIndex <= 2;
        param(src.sendLevelAddr(t)).value = feeds ? 0.75 : 0.0;
        param(src.sendOnAddr(t)).value = 1;
      }
    }
    // Bus send points: X32 post fader, XR pre fader (monitor style); unlinked.
    for (final a in profile.busOptionAddresses) {
      param(a).value = a.startsWith('/config/buslink') ? 0 : (profile.family == MixerFamily.x32 ? 4 : 3);
    }
    // Inserts: nothing inserted yet; X32 insert point post-EQ.
    for (final st in profile.insertStrips) {
      param(profile.insertOnAddr(st)).value = 0;
      param(profile.insertSelAddr(st)).value = 0;
      final pos = profile.insertPosAddr(st);
      if (pos != null) param(pos).value = 1;
    }
    // The console's own library: a few saved shows so the "On mixer" tab
    // has something to show.
    const demoShows = ['Sunday Service', 'Band Rehearsal', 'Acoustic Set', 'Speech Only', 'Wedding'];
    for (final slot in profile.consoleSlots) {
      final i = slot - profile.consoleSlotFirst;
      param(profile.consoleNameAddr(slot)).value = i < demoShows.length ? demoShows[i] : '';
      final hd = profile.consoleHasDataAddr(slot);
      if (hd != null) param(hd).value = i < demoShows.length ? 1 : 0;
    }
    param(profile.consoleCurrentAddr).value = profile.consoleSlotFirst;
    _seedDemoGroups();
    _startDemoMeters();
  }

  /// Demo: vocals in DCA 1, drums in DCA 2 and mute group 1, everything on
  /// Main LR, nothing linked or soloed, monitor level at -10 dB.
  void _seedDemoGroups() {
    final p = profile;
    for (final a in p.groupAddresses) {
      param(a).value = 0;
    }
    for (final s in p.allStrips) {
      final m = p.mainAssignAddr(s);
      if (m != null) param(m).value = s.type == StripType.bus ? 0 : 1;
      final ml = p.monoLevelAddr(s);
      if (ml != null) param(ml).value = 0.0;
      final so = p.soloAddr(s);
      if (so != null) param(so).value = 0;
      if (s.type == StripType.channel && p.hasGroups(s)) {
        if (s.index <= 4) param(p.dcaMaskAddr(s)).value = 1;
        if (s.index >= 5 && s.index <= 10) {
          param(p.dcaMaskAddr(s)).value = 2;
          param(p.muteMaskAddr(s)).value = 1;
        }
      }
    }
    param(MixerProfile.soloAnyAddr).value = 0;
    param(MixerProfile.monitorLevelAddr).value = 0.6;
  }

  /// Flat EQ, plus a gentle shape on the first few channels so the
  /// thumbnails on the strips have something to show.
  void _seedDemoEq(Strip s) {
    final n = s.eqBands;
    param(s.eqOnAddr).value = 1;
    for (var b = 1; b <= n; b++) {
      param(s.eqAddr(b, 'type')).value = eqDefaultType(b, n);
      param(s.eqAddr(b, 'f')).value = freqLaw.toNorm(eqDefaultFreq(b, n));
      param(s.eqAddr(b, 'g')).value = 0.5;
      param(s.eqAddr(b, 'q')).value = qLaw.toNorm(2.0);
    }
    if (s.type == StripType.channel && s.index <= 4) {
      const shapes = [
        [3.0, -2.0, 2.0, 4.0], // vocal: air, a bit of presence
        [5.0, -4.0, 0.0, -2.0], // kick: low end, scoop
        [-3.0, 0.0, 3.0, 2.0], // guitar
        [0.0, 2.0, -3.0, 3.0], // keys
      ];
      for (var b = 1; b <= 4; b++) {
        param(s.eqAddr(b, 'g')).value = eqGainLaw.toNorm(shapes[s.index - 1][b - 1]);
      }
    }
  }

  void _seedDemoDetail(Strip s) {
    param(s.panAddr).value = 0.5;
    param(s.hpOnAddr).value = 0;
    param(s.hpfAddr).value = hpfLaw.toNorm(80);
    param(s.invertAddr).value = 0;
    if (profile.hasTrim) param(s.trimAddr).value = 0.5;
    if (profile.family == MixerFamily.x32) {
      // Default X32 routing: channel N ← In N ← local blocks AN1-8 … AN25-32.
      param(MixerProfile.x32SourceAddr(s.index)).value = s.index;
      for (var b = 0; b < MixerProfile.x32RoutingBlocks.length; b++) {
        param(MixerProfile.x32RoutingBlocks[b]).value = b;
      }
    }
    // Gate and compressor: present but off, with typical vocal-ish settings.
    param(s.gateAddr('on')).value = 0;
    param(s.gateAddr('mode')).value = 3; // GATE
    param(s.gateAddr('thr')).value = gateThrLaw.toNorm(-50);
    param(s.gateAddr('range')).value = gateRangeLaw.toNorm(40);
    param(s.gateAddr('attack')).value = attackLaw.toNorm(1);
    param(s.gateAddr('hold')).value = holdLaw.toNorm(50);
    param(s.gateAddr('release')).value = releaseLaw.toNorm(200);
    param(s.dynAddr('on')).value = 0;
    param(s.dynAddr('mode')).value = 0; // COMP
    param(s.dynAddr('det')).value = 0; // PEAK
    param(s.dynAddr('env')).value = 1; // LOG
    param(s.dynAddr('thr')).value = compThrLaw.toNorm(-20);
    param(s.dynAddr('ratio')).value = 6; // 4:1
    param(s.dynAddr('knee')).value = kneeLaw.toNorm(2);
    param(s.dynAddr('mgain')).value = 0.0;
    param(s.dynAddr('attack')).value = attackLaw.toNorm(10);
    param(s.dynAddr('hold')).value = holdLaw.toNorm(20);
    param(s.dynAddr('release')).value = releaseLaw.toNorm(150);
    param(s.dynAddr('mix')).value = 1.0;
    param(s.dynAddr('auto')).value = 0;
    final ha = headampFor(s);
    if (ha.gainAddr != null) param(ha.gainAddr!).value = headampGainLaw.toNorm(20);
    if (ha.phantomAddr != null) param(ha.phantomAddr!).value = 0;
  }

  /// Plausible moving levels so the demo looks like a live console:
  /// the first 10 inputs carry signal, outputs follow the input faders.
  void _startDemoMeters() {
    final rnd = math.Random();
    final level = <String, double>{};
    _demoMeters = Timer.periodic(const Duration(milliseconds: 60), (_) {
      final update = <String, double>{};
      for (final s in profile.allStrips) {
        if (!s.hasMeter) continue;
        final live = s.type != StripType.channel || s.index <= 10;
        double target;
        if (!live || !isOn(s.onAddr)) {
          target = -90;
        } else {
          final base = s.type == StripType.channel ? -18.0 : -12.0;
          final gain = s.type == StripType.channel ? 0.0 : (faderOf(s.faderAddr) - 0.75) * 30;
          target = base + gain + (rnd.nextDouble() * 14 - 7);
        }
        final prev = level[s.prefix] ?? -90;
        // Fast attack, slower release, like a real meter.
        final next = target > prev ? prev + (target - prev) * 0.7 : prev + (target - prev) * 0.25;
        level[s.prefix] = next;
        update[s.prefix] = next < -80 ? double.negativeInfinity : math.min(next, 0);
      }
      meters.update(update);
      _demoAnalysis(rnd, level);
    });
  }

  /// Demo: a pink-ish spectrum with a "ringing" peak near 2.5 kHz, and some
  /// compressor reduction on the loud channels.
  void _demoAnalysis(math.Random rnd, Map<String, double> level) {
    if (_rtaStrip != null) {
      rta.update([
        for (var i = 0; i < rtaBins; i++)
          -30 - i * 0.25 + rnd.nextDouble() * 8 + (i >= 66 && i <= 67 ? 18 : 0),
      ]);
    }
    if (_grWatchers > 0) {
      final gr = <String, double>{};
      for (final s in profile.inputs) {
        if (s.type != StripType.channel) continue;
        final l = level[s.prefix] ?? -90;
        gr['${s.prefix}/dyn'] = flagOf(s.dynAddr('on')) || s.index <= 3 ? math.min(0, -(l + 22) * 0.6) : 0;
        gr['${s.prefix}/gate'] = s.index == 5 ? -12 + rnd.nextDouble() * 4 : 0;
      }
      gainReduction.update(gr);
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _keepAlive?.cancel();
    _demoMeters?.cancel();
    _sub?.cancel();
    _client?.close();
    muteLock.dispose();
    rta.dispose();
    gainReduction.dispose();
    super.dispose();
  }
}
