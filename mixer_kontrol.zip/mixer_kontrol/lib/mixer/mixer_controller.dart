import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../osc/meters.dart';
import '../ah/ah_layout.dart';
import '../ah/ah_link.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_client.dart';
import '../yamaha/yamaha_link.dart';
import '../osc/osc_message.dart';
import '../util/eq_math.dart';
import '../util/param_law.dart';
import 'fx_catalog.dart';
import 'inserts.dart';
import 'mixer_profile.dart';
import 'rta.dart';

enum ConnState { connected, lost }

enum HeadampStatus { resolved, pending, none }

/// Which preamp an input channel uses right now.
class HeadampInfo {
  const HeadampInfo(this.status, [this.prefix, this.name, this.phantom = true]);
  final HeadampStatus status;
  final String? prefix; // e.g. /headamp/004
  final String? name; // e.g. Local 5

  /// False where +48 V can't be switched from the app.
  final bool phantom;
  String? get gainAddr => prefix == null ? null : '$prefix/gain';
  String? get phantomAddr => prefix == null || !phantom ? null : '$prefix/phantom';
}

class MixerConnectException implements Exception {
  MixerConnectException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Holds the live state of one console. Every OSC address has its own
/// ValueNotifier, so a fader move only rebuilds that one fader.
/// Meter traffic a device asks for (see [MixerController.meterRate]).
enum MeterRate { full, light, off }

class MixerController extends ChangeNotifier {
  MixerController._(this.profile, this._client, {required this.mixerName, required this.host}) {
    for (final s in profile.allStrips) {
      if (s.hasMeter) (_meterStrips[s.meterId!] ??= []).add(s);
    }
  }

  final MixerProfile profile;
  final MixerLink? _client; // null = demo mode
  final String host;
  String mixerName;

  ConnState _state = ConnState.connected;
  ConnState get state => _state;
  bool get isDemo => _client == null;

  final Map<String, ValueNotifier<Object?>> _params = {};
  final Set<String> _touched = {};
  StreamSubscription<OscMessage>? _sub;
  Timer? _keepAlive;
  Timer? _demoMeters;

  /// Live meter levels (dBFS) keyed by strip prefix.
  final MeterLevels meters = MeterLevels();
  final Map<String, List<Strip>> _meterStrips = {};
  DateTime _lastRx = DateTime.now();
  bool _disposed = false;

  /// Round trip time measured at connect (used to pace query retries).
  int _rttMs = 50;

  /// Addresses asked for that haven't been answered yet (one set per batch).
  final List<Set<String>> _awaiting = [];

  // ---------------------------------------------------------------- connect

  /// Connects to [host]. If [family] is null the model is detected via /xinfo,
  /// trying the X32 port first and then the XR port.
  static Future<MixerController> connect(String host, {MixerFamily? family, String? model}) async {
    if (family == MixerFamily.yamaha) return _connectYamaha(host);
    if (family == MixerFamily.allenHeath) return _connectAh(host, model ?? 'SQ');
    final ports = family == null
        ? const [10023, 10024]
        : [MixerProfile.defaultPort(family)];
    for (final port in ports) {
      final client = await OscClient.open(host, port);
      // Several tries with growing patience: a slow or lossy link (far from
      // the mixer's own Wi-Fi) may need more than one /xinfo.
      final sw = Stopwatch()..start();
      OscMessage? info;
      for (final ms in const [800, 1500, 2500]) {
        info = await client.request('/xinfo', timeout: Duration(milliseconds: ms));
        if (info != null) break;
      }
      final rtt = sw.elapsedMilliseconds;
      if (info != null && info.args.length >= 3) {
        final model = info.args[2].toString();
        final fam = MixerProfile.familyFromModel(model) ??
            family ??
            (port == 10023 ? MixerFamily.x32 : MixerFamily.xr);
        final c = MixerController._(
          MixerProfile.forFamily(fam, model),
          client,
          mixerName: info.args[1].toString(),
          host: host,
        );
        c._rttMs = rtt.clamp(5, 2000);
        c._start();
        return c;
      }
      client.close();
    }
    // Auto-detect: last, try a Yamaha console (TCP).
    if (family == null) {
      try {
        return await _connectYamaha(host, timeout: const Duration(seconds: 2));
      } on MixerConnectException {
        // fall through
      }
    }
    throw MixerConnectException('No mixer answered at $host.');
  }

  /// Allen & Heath: the model can't be read over MIDI, so it is chosen on the
  /// connect screen. The console answering a request proves the link.
  static Future<MixerController> _connectAh(String host, String model) async {
    final AhLink link;
    try {
      link = await AhLink.connect(host, model);
    } catch (_) {
      throw MixerConnectException('No Allen & Heath console answered at $host (TCP ${AhLink.defaultPort}).');
    }
    final profile = MixerProfile.allenHeath(model);
    link.learn(AhLink.profileAddresses(profile));
    final c = MixerController._(profile, link, mixerName: AhLayout.labelFor(model), host: host);
    c._start();
    return c;
  }

  static Future<MixerController> _connectYamaha(String host, {Duration timeout = const Duration(seconds: 3)}) async {
    final YamahaLink link;
    try {
      link = await YamahaLink.connect(host, timeout: timeout);
    } catch (_) {
      throw MixerConnectException('No Yamaha console answered at $host (TCP ${YamahaLink.defaultPort}).');
    }
    final model = await link.askProductName() ?? 'Yamaha';
    final layout = await link.readLayout(model);
    final profile = MixerProfile.yamaha(model, layout);
    link.learn(YamahaLink.profileAddresses(profile));
    final c = MixerController._(
      profile,
      link,
      mixerName: model,
      host: host,
    );
    c._start();
    return c;
  }

  factory MixerController.demo(MixerFamily family, {String? model}) {
    final c = MixerController._(
      MixerProfile.forFamily(family, model ?? switch (family) {
        MixerFamily.x32 => 'X32',
        MixerFamily.xr => 'XR18',
        MixerFamily.yamaha => 'TF5',
        MixerFamily.allenHeath => 'SQ',
      }),
      null,
      mixerName: 'Demo',
      host: '',
    );
    c._seedDemo();
    return c;
  }

  void _start() {
    final client = _client!;
    _sub = client.messages.listen(_onMessage);
    client.send(const OscMessage('/xremote'));
    _subscribeMeters();
    // Consoles drop /xremote and /meters subscriptions after ~10 s. Renewing
    // every 4 s means one lost renewal (lossy Wi-Fi) leaves no gap in which
    // meters freeze or changes made on the desk are missed.
    _keepAlive = Timer.periodic(const Duration(seconds: 4), (_) {
      client.send(const OscMessage('/xremote'));
      _subscribeMeters();
      client.send(const OscMessage('/xinfo'));
      if (_state == ConnState.connected &&
          DateTime.now().difference(_lastRx) > const Duration(seconds: 20)) {
        _state = ConnState.lost;
        meters.clear(); // don't show frozen levels
        notifyListeners();
      }
    });
    refreshAll();
  }

  void _subscribeMeters() {
    final rate = _meterRate;
    if (rate != MeterRate.off) {
      for (final id in profile.meterRequests) {
        // X32: the optional time factor stretches the 50 ms update interval.
        _client?.send(OscMessage('/meters', [
          id,
          if (rate == MeterRate.light && profile.family == MixerFamily.x32) lightMeterFactor,
        ]));
      }
    }
    for (final id in _extraMeters) {
      _client?.send(OscMessage('/meters', [id]));
    }
  }

  /// X32 light meters: 50 ms x 4 = 5 updates a second instead of 20.
  static const lightMeterFactor = 4;

  MeterRate _meterRate = MeterRate.full;
  MeterRate get meterRate => _meterRate;

  /// How much meter traffic this device asks the console for. Lower rates
  /// leave more room for other devices on the same Wi-Fi (personal mixes).
  /// [MeterRate.light] is X32 only; on XR it behaves like [MeterRate.full].
  set meterRate(MeterRate r) {
    if (r == _meterRate || _disposed) return;
    _meterRate = r;
    if (r == MeterRate.off) meters.clear();
    _subscribeMeters();
    notifyListeners();
  }

  /// Whether [MeterRate.light] is available on this console.
  bool get supportsLightMeters => profile.family == MixerFamily.x32;

  // ---------------------------------------------------------------- RTA & gain reduction

  /// Spectrum of the strip being analysed (see [watchRta]).
  final RtaData rta = RtaData();

  /// Gate / compressor gain reduction in dB (≤ 0), keyed '<prefix>/gate'
  /// and '<prefix>/dyn'. Only fed while [watchGainReduction] is active.
  final MeterLevels gainReduction = MeterLevels();

  final Set<String> _extraMeters = {};
  Strip? _rtaStrip;
  int _grWatchers = 0;

  String get _rtaMeterId => profile.family == MixerFamily.x32 ? '/meters/15' : '/meters/4';
  String get _grMeterId => profile.family == MixerFamily.x32 ? '/meters/1' : '/meters/6';

  /// X32 strip index used by /-stat/selidx (the console's selected strip,
  /// which its RTA follows).
  int? _x32SelIdx(Strip s) => switch (s.type) {
        StripType.channel => s.index - 1,
        StripType.auxIn => 31 + s.index,
        StripType.fxReturn => 39 + s.index,
        StripType.bus => 47 + s.index,
        StripType.matrix => 63 + s.index,
        StripType.main => 70,
        StripType.mono => 71,
        _ => null,
      };

  /// XR RTA source (/-stat/rta/source).
  int? _xrRtaSource(Strip s) => switch (s.type) {
        StripType.channel => s.index - 1,
        StripType.auxIn => 16,
        StripType.fxReturn => 16 + s.index,
        StripType.bus => 20 + s.index,
        StripType.fxSend => 26 + s.index,
        StripType.main => 31,
        _ => null,
      };

  Strip? get rtaStrip => _rtaStrip;

  /// Starts the analyser on [s] (replacing any other). On the X32 this also
  /// selects [s] on the console, because its RTA follows the selection.
  void watchRta(Strip s) {
    if (_disposed) return;
    _rtaStrip = s;
    rta.clear();
    if (profile.family == MixerFamily.x32) {
      final i = _x32SelIdx(s);
      if (i != null) set('/-stat/selidx', i);
    } else {
      final i = _xrRtaSource(s);
      if (i != null) set('/-stat/rta/source', i);
    }
    _extraMeters.add(_rtaMeterId);
    _client?.send(OscMessage('/meters', [_rtaMeterId]));
  }

  void unwatchRta() {
    // Screens may close after the console page has already disposed us.
    if (_disposed) return;
    _rtaStrip = null;
    _extraMeters.remove(_rtaMeterId);
    rta.clear();
  }

  void watchGainReduction() {
    if (_disposed) return;
    _grWatchers++;
    _extraMeters.add(_grMeterId);
    _client?.send(OscMessage('/meters', [_grMeterId]));
  }

  void unwatchGainReduction() {
    if (_disposed) return;
    _grWatchers = math.max(0, _grWatchers - 1);
    if (_grWatchers == 0) _extraMeters.remove(_grMeterId);
  }

  void _onGainReduction(Uint8List blob) {
    final update = <String, double>{};
    final channels = profile.inputs.where((s) => s.type == StripType.channel).toList();
    if (profile.family == MixerFamily.x32) {
      final v = decodeMeterBlob(blob, MeterFormat.float32Linear); // dBFS of a gain factor
      for (final s in channels) {
        final g = 31 + s.index, d = 63 + s.index;
        if (d < v.length) {
          update['${s.prefix}/gate'] = math.min(0, v[g]);
          update['${s.prefix}/dyn'] = math.min(0, v[d]);
        }
      }
    } else {
      final v = decodeRtaBlob(blob);
      for (final s in channels) {
        final g = s.index - 1, d = 15 + s.index;
        if (d < v.length) {
          update['${s.prefix}/gate'] = -v[g].abs();
          update['${s.prefix}/dyn'] = -v[d].abs();
        }
      }
    }
    gainReduction.update(update);
  }

  void _onMeters(String id, Uint8List blob) {
    if (_meterRate == MeterRate.off) return; // the console may send until the subscription runs out
    final strips = _meterStrips[id];
    if (strips == null) return;
    final values = decodeMeterBlob(blob, profile.meterFormat);
    final update = <String, double>{};
    for (final s in strips) {
      var db = double.negativeInfinity;
      for (final i in s.meterIdx) {
        if (i < values.length && values[i] > db) db = values[i];
      }
      update[s.prefix] = db;
    }
    meters.update(update);
  }

  // ---------------------------------------------------------------- state

  /// Diagnostics: how many addresses are held, and which.
  int get paramCount => _params.length;
  Iterable<String> get knownAddresses => _params.keys;

  ValueNotifier<Object?> param(String addr) =>
      _params.putIfAbsent(addr, () => ValueNotifier<Object?>(null));

  double faderOf(String addr) {
    final v = param(addr).value;
    return v is num ? v.toDouble() : 0.0;
  }

  double numOf(String addr, double fallback) {
    final v = param(addr).value;
    return v is num ? v.toDouble() : fallback;
  }

  int intOf(String addr, int fallback) {
    final v = param(addr).value;
    return v is num ? v.toInt() : fallback;
  }

  /// For switches whose "off" is the safe default (phantom, phase, low cut).
  bool flagOf(String addr) {
    final v = param(addr).value;
    return v is num && v != 0;
  }

  void setFlag(String addr, bool on) => set(addr, on ? 1 : 0);

  int? _intOrNull(String addr) {
    final v = param(addr).value;
    return v is num ? v.toInt() : null;
  }

  /// Resolves the preamp for [s]. On X32 this follows source → routing →
  /// user routing, and stays [HeadampStatus.pending] until every value it
  /// needs has arrived, so gain/+48V are never sent to a guessed preamp.
  HeadampInfo headampFor(Strip s) {
    if (s.type != StripType.channel) return const HeadampInfo(HeadampStatus.none);
    if (profile.family == MixerFamily.xr) {
      return HeadampInfo(HeadampStatus.resolved, '/headamp/${two(s.index)}', 'Input ${s.index}');
    }
    if (profile.isYamaha ||
        (profile.isAh && (profile.ahDialect == AhDialect.dlive || profile.ahDialect == AhDialect.qu))) {
      return HeadampInfo(HeadampStatus.resolved, '/headamp/${two(s.index)}', 'Input ${s.index}', profile.hasPhantom);
    }
    if (profile.isAh) return const HeadampInfo(HeadampStatus.none);
    final idx = MixerProfile.x32HeadampIndex(s.index, _intOrNull);
    if (idx == null) return const HeadampInfo(HeadampStatus.pending);
    if (idx < 0) return const HeadampInfo(HeadampStatus.none);
    return HeadampInfo(
      HeadampStatus.resolved,
      MixerProfile.x32HeadampPrefix(idx),
      MixerProfile.x32HeadampName(idx),
    );
  }

  // ---------------------------------------------------------------- bus send point & link

  static const tapLabels = ['In', 'Pre EQ', 'Post EQ', 'Pre fader', 'Post fader', 'Group'];
  static const tapShort = ['IN', '<EQ', 'EQ>', 'PRE', 'POST', 'GRP'];

  /// Send point of every input's send to [t]: the common value, -1 if the
  /// channels differ, null while unknown.
  int? busTap(SendTarget t) {
    int? common;
    for (final s in profile.tapStrips) {
      final v = param(profile.tapAddr(s, t.mixIndex)).value;
      if (v is! num) continue;
      if (common == null) {
        common = v.toInt();
      } else if (common != v.toInt()) {
        return -1;
      }
    }
    return common;
  }

  bool busLinked(SendTarget t) => flagOf(profile.busLinkAddr(t.mixIndex));

  /// Sets the send point of all inputs' sends to [t] (on XR, both buses of
  /// a linked pair).
  void setBusTap(SendTarget t, int tap) {
    final p = profile;
    final mixes = <int>{t.mixIndex};
    if (!p.tapPerPair && busLinked(t)) {
      final a = p.pairStart(t.mixIndex);
      mixes.addAll([a, a + 1]);
    }
    for (final s in p.tapStrips) {
      for (final m in mixes) {
        set(p.tapAddr(s, m), tap);
      }
    }
  }

  void setBusLinked(SendTarget t, bool on) => set(profile.busLinkAddr(t.mixIndex), on ? 1 : 0);

  // ---------------------------------------------------------------- mute lock

  /// While on, MUTE buttons in the app don't respond (guards against
  /// accidental taps during a show). App-side only; the console is unaffected.
  final ValueNotifier<bool> muteLock = ValueNotifier<bool>(false);

  // ---------------------------------------------------------------- solo / monitor

  bool soloOn(Strip s) {
    final a = profile.soloAddr(s);
    return a != null && flagOf(a);
  }

  void toggleSolo(Strip s) {
    final a = profile.soloAddr(s);
    if (a == null) return;
    set(a, soloOn(s) ? 0 : 1);
    _updateAnySolo();
  }

  /// True while any strip is soloed (from the console's flag or our own).
  bool get anySolo {
    if (!profile.isExternal && flagOf(MixerProfile.soloAnyAddr)) return true;
    for (final s in profile.allStrips) {
      if (soloOn(s)) return true;
    }
    return false;
  }

  void _updateAnySolo() {
    var any = false;
    for (final s in profile.allStrips) {
      if (soloOn(s)) any = true;
    }
    param(MixerProfile.soloAnyAddr).value = any ? 1 : 0;
  }

  void clearSolo() {
    command(MixerProfile.clearSoloAddr, [1]);
    for (final s in profile.allStrips) {
      final a = profile.soloAddr(s);
      if (a != null && flagOf(a)) set(a, 0);
    }
    param(MixerProfile.soloAnyAddr).value = 0;
  }

  // ---------------------------------------------------------------- groups & assign

  bool maskBit(String addr, int bit) => (intOf(addr, 0) >> bit) & 1 == 1;

  void setMaskBit(String addr, int bit, bool on) {
    final v = intOf(addr, 0);
    set(addr, on ? (v | (1 << bit)) : (v & ~(1 << bit)));
  }

  bool inDca(Strip s, int dca) => profile.hasGroups(s) && maskBit(profile.dcaMaskAddr(s), dca - 1);
  void setInDca(Strip s, int dca, bool on) => setMaskBit(profile.dcaMaskAddr(s), dca - 1, on);
  bool inMuteGroup(Strip s, int g) => profile.hasGroups(s) && maskBit(profile.muteMaskAddr(s), g - 1);
  void setInMuteGroup(Strip s, int g, bool on) => setMaskBit(profile.muteMaskAddr(s), g - 1, on);

  /// Strips assigned to DCA [dca] (1-based), in console order.
  List<Strip> dcaMembers(int dca) => [for (final s in profile.groupStrips) if (inDca(s, dca)) s];

  /// Mute groups and DCA assignments have to be known for the spill view.
  Future<void> queryGroups() => query(profile.groupAddresses);

  // ---------------------------------------------------------------- console library

  /// Sends a command that is not a stored parameter (load, save, delete…).
  void command(String addr, [List<Object> args = const []]) {
    if (_disposed) return;
    _client?.send(OscMessage(addr, args));
  }

  /// True if console slot [slot] holds a snapshot / scene.
  bool consoleSlotUsed(int slot) {
    // A&H: scene names can't be read over MIDI; every slot can be recalled.
    if (profile.isAh) return true;
    final hd = profile.consoleHasDataAddr(slot);
    if (hd != null) {
      final v = param(hd).value;
      if (v is num) return v != 0;
    }
    final n = param(profile.consoleNameAddr(slot)).value;
    return n is String && n.trim().isNotEmpty;
  }

  String consoleSlotName(int slot) {
    final n = param(profile.consoleNameAddr(slot)).value;
    return n is String ? n.trim() : '';
  }

  int? get consoleCurrent {
    final v = param(profile.consoleCurrentAddr).value;
    return v is num ? v.toInt() : null;
  }

  /// Recalls a console snapshot / scene, then re-reads everything, since a
  /// recall changes far more than the console reports one by one.
  Future<void> consoleLoad(int slot) async {
    param(profile.consoleCurrentAddr).value = slot;
    if (isDemo) return;
    command(profile.family == MixerFamily.x32 ? '/-action/goscene' : '/-snap/load', [slot]);
    await Future<void>.delayed(const Duration(milliseconds: 800));
    await refreshAll();
  }

  void consoleSave(int slot, String name) {
    param(profile.consoleNameAddr(slot)).value = name;
    final hd = profile.consoleHasDataAddr(slot);
    if (hd != null) param(hd).value = 1;
    param(profile.consoleCurrentAddr).value = slot;
    if (isDemo) return;
    if (profile.family == MixerFamily.x32) {
      command('/save', ['scene', slot, name, '', 0]);
    } else {
      command('/-snap/name', [name]);
      command('/-snap/save', [slot]);
    }
    Future<void>.delayed(const Duration(milliseconds: 500), () => query(profile.consoleLibraryAddresses));
  }

  void consoleDelete(int slot) {
    param(profile.consoleNameAddr(slot)).value = '';
    final hd = profile.consoleHasDataAddr(slot);
    if (hd != null) param(hd).value = 0;
    if (isDemo) return;
    if (profile.family == MixerFamily.x32) {
      command('/delete', ['scene', slot]);
    } else {
      command('/-snap/delete', [slot]);
    }
    Future<void>.delayed(const Duration(milliseconds: 500), () => query(profile.consoleLibraryAddresses));
  }

  // ---------------------------------------------------------------- snapshots

  /// Fetches every snapshot value from the console (no-op in demo), then
  /// waits briefly for the last replies.
  Future<void> syncForSnapshot({void Function(double)? onProgress}) async {
    final addrs = profile.snapshotAddresses();
    if (_client == null) {
      onProgress?.call(1);
      return;
    }
    final pending = await _askOnce(addrs, onProgress: (f) => onProgress?.call(f * 0.8));
    if (pending == null) return;
    // wait for the stragglers (re-asked if lost) so the snapshot is complete
    await _retry(pending, passes: 2);
    onProgress?.call(1);
  }

  /// Current known values of everything a snapshot stores.
  Map<String, Object> captureSnapshot() {
    final out = <String, Object>{};
    for (final a in profile.snapshotAddresses()) {
      final v = _params[a]?.value;
      if (v is int || v is double || v is String) out[a] = v!;
    }
    return out;
  }

  static final _fxTypeRe = RegExp(r'^/fx/\d+/type$');

  /// Recalls [values]: effect types first (changing a type resets that
  /// slot's parameters), a short pause, then everything else.
  Future<void> recallSnapshot(Map<String, Object> values, {void Function(double)? onProgress}) async {
    final types = values.entries.where((e) => _fxTypeRe.hasMatch(e.key)).toList();
    final rest = values.entries.where((e) => !_fxTypeRe.hasMatch(e.key)).toList();
    final total = types.length + rest.length;
    var done = 0;
    Future<void> sendAll(List<MapEntry<String, Object>> list) async {
      for (final e in list) {
        if (_disposed) return;
        param(e.key).value = e.value;
        _client?.send(OscMessage(e.key, [e.value]));
        done++;
        if (done % 16 == 0) {
          onProgress?.call(done / total);
          if (_client != null) await Future<void>.delayed(const Duration(milliseconds: 12));
        }
      }
    }

    await sendAll(types);
    if (_client != null && types.isNotEmpty) {
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    await sendAll(rest);
    onProgress?.call(1);
  }

  /// Asks the console for the current value of each address. Addresses that
  /// get no answer (lost packets, busy console) are asked again a few times
  /// in the background.
  Future<void> query(List<String> addrs) async {
    final pending = await _askOnce(addrs);
    if (pending != null) unawaited(_retry(pending));
  }

  bool isOn(String addr) {
    final v = param(addr).value;
    return v is num ? v != 0 : true;
  }

  /// Queries every control on the console. Sent in small batches so the
  /// console's UDP buffer is not flooded; unanswered ones are retried.
  Future<void> refreshAll() => query(profile.queryAddresses);

  /// Sends one query per address; returns the set still waiting for replies.
  Future<Set<String>?> _askOnce(List<String> addrs, {void Function(double)? onProgress}) async {
    final client = _client;
    if (client == null || _disposed) return null;
    final pending = addrs.toSet();
    _awaiting.add(pending);
    var i = 0;
    for (final a in addrs) {
      if (_disposed) return null;
      client.send(OscMessage(a));
      if (i % 16 == 15) {
        onProgress?.call(i / addrs.length);
        await Future<void>.delayed(const Duration(milliseconds: 12));
      }
      i++;
    }
    return pending;
  }

  /// Re-asks what is still unanswered, at most [passes] times.
  Future<void> _retry(Set<String> pending, {int passes = 3}) async {
    try {
      for (var pass = 0; pass < passes; pass++) {
        await Future<void>.delayed(Duration(milliseconds: (400 + _rttMs * 2).clamp(400, 3000)));
        final client = _client;
        if (_disposed || client == null || pending.isEmpty) return;
        final again = pending.toList();
        for (var i = 0; i < again.length; i++) {
          if (_disposed) return;
          client.send(OscMessage(again[i]));
          if (i % 16 == 15) await Future<void>.delayed(const Duration(milliseconds: 12));
        }
      }
      await Future<void>.delayed(Duration(milliseconds: (400 + _rttMs * 2).clamp(400, 3000)));
    } finally {
      _awaiting.remove(pending);
    }
  }

  void _onMessage(OscMessage m) {
    _lastRx = DateTime.now();
    if (_state == ConnState.lost) {
      _state = ConnState.connected;
      notifyListeners();
      refreshAll(); // something may have changed while we were away
    }
    if (m.args.isEmpty) return;
    if (m.address.startsWith('/meters/')) {
      final blob = m.args.first;
      if (blob is! Uint8List) return;
      if (m.address == _rtaMeterId && _extraMeters.contains(_rtaMeterId)) {
        rta.update(decodeRtaBlob(blob));
      } else if (m.address == _grMeterId && _extraMeters.contains(_grMeterId) && !_meterStrips.containsKey(m.address)) {
        _onGainReduction(blob);
      } else {
        _onMeters(m.address, blob);
      }
      return;
    }
    if (m.address == '/xinfo') {
      final name = m.args.length >= 2 ? _clip(m.args[1].toString()) : mixerName;
      if (name != mixerName) {
        mixerName = name;
        notifyListeners();
      }
      return;
    }
    for (final w in _awaiting) {
      w.remove(m.address);
    }
    // Don't let incoming values fight a finger that is on the fader.
    if (_touched.contains(m.address)) return;
    // Security: keep state only for addresses this app uses, and cap it, so
    // a flood of made-up addresses can't exhaust memory.
    if (!_params.containsKey(m.address) &&
        (!acceptsAddress(m.address) || _params.length >= maxParams)) {
      return;
    }
    var v = m.args.first;
    if (v is Uint8List) return; // blobs are only meaningful as meters
    if (v is String) v = _clip(v);
    // Every float the consoles send is a 0..1 control position.
    if (v is double) {
      if (!v.isFinite) return;
      v = v.clamp(0.0, 1.0).toDouble();
    }
    final p = param(m.address);
    final old = p.value;
    // A value must keep its kind (number vs text): a malformed packet must
    // not turn a fader into a string the screens can't draw.
    if (old != null && (old is num) != (v is num)) return;
    if (old == null && v is String && _numericAddress(m.address)) return;
    p.value = v;
  }

  static final _numericRe = RegExp(r'/(fader|level|on|pan|gain|trim|mlevel|f|g|q|mix)$');
  static bool _numericAddress(String a) => _numericRe.hasMatch(a);

  /// Upper bound on stored parameters (the largest console needs ~10 000).
  static const maxParams = 30000;

  /// Longest text kept from the mixer (names are 12-32 characters there).
  static const maxText = 64;

  static String _clip(String s) => s.length > maxText ? s.substring(0, maxText) : s;

  /// OSC address families this app reads from X32 / X Air consoles.
  static const _allowedPrefixes = [
    '/ch/', '/bus/', '/mtx/', '/main/', '/lr/', '/dca/', '/auxin/', '/fxrtn/', '/rtn/', //
    '/fxsend/', '/fx/', '/headamp/', '/config/', '/-snap/', '/-show/', '/-stat/',
    '/-prefs/', '/outputs/', '/routing/', '/-urec/', '/-usb/',
  ];

  static bool acceptsAddress(String a) =>
      a.length <= 64 && !a.contains('..') && _allowedPrefixes.any(a.startsWith);

  // ---------------------------------------------------------------- actions

  void set(String addr, Object value) {
    if (_disposed) return;
    param(addr).value = value;
    _client?.send(OscMessage(addr, [value]));
  }

  void setFader(String addr, double v) => set(addr, v.clamp(0.0, 1.0).toDouble());

  void toggleOn(String addr) => set(addr, isOn(addr) ? 0 : 1);

  void rename(Strip s, String name) => set(s.nameAddr, name.length > 12 ? name.substring(0, 12) : name);

  void beginTouch(String addr) => _touched.add(addr);
  void endTouch(String addr) => _touched.remove(addr);

  void _seedDemo() {
    var color = 1;
    for (final s in profile.allStrips) {
      param(s.nameAddr).value = '';
      param(s.colorAddr).value = s.type == StripType.main ? 7 : (color++ % 7) + 1;
      param(s.onAddr).value = 1;
      param(s.faderAddr).value = s.type == StripType.channel ? 0.6 : 0.75;
      if (s.hasSends) {
        for (final t in profile.sendTargets) {
          param(s.sendLevelAddr(t)).value = 0.0;
          param(s.sendOnAddr(t)).value = 1;
        }
      }
      if (s.hasEq) _seedDemoEq(s);
      if (s.hasDetail) _seedDemoDetail(s);
    }
    // X32: FX 1-4 fed from buses 13-16 (a common console layout).
    if (profile.family == MixerFamily.x32) {
      for (var slot = 1; slot <= 4; slot++) {
        param(profile.fxSourceAddr(slot)).value = 12 + slot;
      }
    }
    // FX: reverbs and a delay in the send slots, a GEQ / comps as inserts.
    const demoFx = ['HALL', 'PLAT', 'DLY', 'CRS', 'GEQ2', 'FAC', 'LEC', 'ULC'];
    for (var slot = 1; slot <= profile.fxSlots; slot++) {
      final list = profile.fxTypesForSlot(slot);
      final idx = list.indexOf(demoFx[slot - 1]);
      param(profile.fxTypeAddr(slot)).value = idx < 0 ? 0 : idx;
      for (var p = 1; p <= fxParamsShown; p++) {
        param(profile.fxParAddr(slot, p)).value = 0.5;
      }
    }
    // Matrix sends (X32): Main LR feeds Matrix 1-2 at 0 dB, the rest off.
    for (final src in profile.matrixSources) {
      for (final t in profile.matrixTargets) {
        final feeds = src.type == StripType.main && t.mixIndex <= 2;
        param(src.sendLevelAddr(t)).value = feeds ? 0.75 : 0.0;
        param(src.sendOnAddr(t)).value = 1;
      }
    }
    // Bus send points: X32 post fader, XR pre fader (monitor style); unlinked.
    for (final a in profile.busOptionAddresses) {
      param(a).value = a.startsWith('/config/buslink') ? 0 : (profile.family == MixerFamily.x32 ? 4 : 3);
    }
    // Inserts: nothing inserted yet; X32 insert point post-EQ.
    for (final st in profile.insertStrips) {
      param(profile.insertOnAddr(st)).value = 0;
      param(profile.insertSelAddr(st)).value = 0;
      final pos = profile.insertPosAddr(st);
      if (pos != null) param(pos).value = 1;
    }
    // The console's own library: a few saved shows so the "On mixer" tab
    // has something to show.
    const demoShows = ['Sunday Service', 'Band Rehearsal', 'Acoustic Set', 'Speech Only', 'Wedding'];
    for (final slot in profile.consoleSlots) {
      final i = slot - profile.consoleSlotFirst;
      param(profile.consoleNameAddr(slot)).value = i < demoShows.length ? demoShows[i] : '';
      final hd = profile.consoleHasDataAddr(slot);
      if (hd != null) param(hd).value = i < demoShows.length ? 1 : 0;
    }
    param(profile.consoleCurrentAddr).value = profile.consoleSlotFirst;
    _seedDemoGroups();
    _startDemoMeters();
  }

  /// Demo: vocals in DCA 1, drums in DCA 2 and mute group 1, everything on
  /// Main LR, nothing linked or soloed, monitor level at -10 dB.
  void _seedDemoGroups() {
    final p = profile;
    for (final a in p.groupAddresses) {
      param(a).value = 0;
    }
    for (final s in p.allStrips) {
      final m = p.mainAssignAddr(s);
      if (m != null) param(m).value = s.type == StripType.bus ? 0 : 1;
      final ml = p.monoLevelAddr(s);
      if (ml != null) param(ml).value = 0.0;
      final so = p.soloAddr(s);
      if (so != null) param(so).value = 0;
      if (s.type == StripType.channel && p.hasGroups(s)) {
        if (s.index <= 4) param(p.dcaMaskAddr(s)).value = 1;
        if (s.index >= 5 && s.index <= 10) {
          param(p.dcaMaskAddr(s)).value = 2;
          param(p.muteMaskAddr(s)).value = 1;
        }
      }
    }
    param(MixerProfile.soloAnyAddr).value = 0;
    param(MixerProfile.monitorLevelAddr).value = 0.6;
  }

  /// Flat EQ, plus a gentle shape on the first few channels so the
  /// thumbnails on the strips have something to show.
  void _seedDemoEq(Strip s) {
    final n = s.eqBands;
    param(s.eqOnAddr).value = 1;
    for (var b = 1; b <= n; b++) {
      param(s.eqAddr(b, 'type')).value = eqDefaultType(b, n);
      param(s.eqAddr(b, 'f')).value = freqLaw.toNorm(eqDefaultFreq(b, n));
      param(s.eqAddr(b, 'g')).value = 0.5;
      param(s.eqAddr(b, 'q')).value = qLaw.toNorm(2.0);
    }
    if (s.type == StripType.channel && s.index <= 4) {
      const shapes = [
        [3.0, -2.0, 2.0, 4.0], // vocal: air, a bit of presence
        [5.0, -4.0, 0.0, -2.0], // kick: low end, scoop
        [-3.0, 0.0, 3.0, 2.0], // guitar
        [0.0, 2.0, -3.0, 3.0], // keys
      ];
      for (var b = 1; b <= 4; b++) {
        param(s.eqAddr(b, 'g')).value = eqGainLaw.toNorm(shapes[s.index - 1][b - 1]);
      }
    }
  }

  void _seedDemoDetail(Strip s) {
    param(s.panAddr).value = 0.5;
    param(s.hpOnAddr).value = 0;
    param(s.hpfAddr).value = hpfLaw.toNorm(80);
    param(s.invertAddr).value = 0;
    if (profile.hasTrim) param(s.trimAddr).value = 0.5;
    if (profile.family == MixerFamily.x32) {
      // Default X32 routing: channel N ← In N ← local blocks AN1-8 … AN25-32.
      param(MixerProfile.x32SourceAddr(s.index)).value = s.index;
      for (var b = 0; b < MixerProfile.x32RoutingBlocks.length; b++) {
        param(MixerProfile.x32RoutingBlocks[b]).value = b;
      }
    }
    // Gate and compressor: present but off, with typical vocal-ish settings.
    param(s.gateAddr('on')).value = 0;
    param(s.gateAddr('mode')).value = 3; // GATE
    param(s.gateAddr('thr')).value = gateThrLaw.toNorm(-50);
    param(s.gateAddr('range')).value = gateRangeLaw.toNorm(40);
    param(s.gateAddr('attack')).value = attackLaw.toNorm(1);
    param(s.gateAddr('hold')).value = holdLaw.toNorm(50);
    param(s.gateAddr('release')).value = releaseLaw.toNorm(200);
    param(s.dynAddr('on')).value = 0;
    param(s.dynAddr('mode')).value = 0; // COMP
    param(s.dynAddr('det')).value = 0; // PEAK
    param(s.dynAddr('env')).value = 1; // LOG
    param(s.dynAddr('thr')).value = compThrLaw.toNorm(-20);
    param(s.dynAddr('ratio')).value = 6; // 4:1
    param(s.dynAddr('knee')).value = kneeLaw.toNorm(2);
    param(s.dynAddr('mgain')).value = 0.0;
    param(s.dynAddr('attack')).value = attackLaw.toNorm(10);
    param(s.dynAddr('hold')).value = holdLaw.toNorm(20);
    param(s.dynAddr('release')).value = releaseLaw.toNorm(150);
    param(s.dynAddr('mix')).value = 1.0;
    param(s.dynAddr('auto')).value = 0;
    final ha = headampFor(s);
    if (ha.gainAddr != null) param(ha.gainAddr!).value = headampGainLaw.toNorm(20);
    if (ha.phantomAddr != null) param(ha.phantomAddr!).value = 0;
  }

  /// Plausible moving levels so the demo looks like a live console:
  /// the first 10 inputs carry signal, outputs follow the input faders.
  void _startDemoMeters() {
    final rnd = math.Random();
    final level = <String, double>{};
    _demoMeters = Timer.periodic(const Duration(milliseconds: 60), (_) {
      final update = <String, double>{};
      for (final s in profile.allStrips) {
        if (!s.hasMeter) continue;
        final live = s.type != StripType.channel || s.index <= 10;
        double target;
        if (!live || !isOn(s.onAddr)) {
          target = -90;
        } else {
          final base = s.type == StripType.channel ? -18.0 : -12.0;
          final gain = s.type == StripType.channel ? 0.0 : (faderOf(s.faderAddr) - 0.75) * 30;
          target = base + gain + (rnd.nextDouble() * 14 - 7);
        }
        final prev = level[s.prefix] ?? -90;
        // Fast attack, slower release, like a real meter.
        final next = target > prev ? prev + (target - prev) * 0.7 : prev + (target - prev) * 0.25;
        level[s.prefix] = next;
        update[s.prefix] = next < -80 ? double.negativeInfinity : math.min(next, 0);
      }
      if (_meterRate != MeterRate.off) meters.update(update);
      _demoAnalysis(rnd, level);
    });
  }

  /// Demo: a pink-ish spectrum with a "ringing" peak near 2.5 kHz, and some
  /// compressor reduction on the loud channels.
  void _demoAnalysis(math.Random rnd, Map<String, double> level) {
    if (_rtaStrip != null) {
      rta.update([
        for (var i = 0; i < rtaBins; i++)
          -30 - i * 0.25 + rnd.nextDouble() * 8 + (i >= 66 && i <= 67 ? 18 : 0),
      ]);
    }
    if (_grWatchers > 0) {
      final gr = <String, double>{};
      for (final s in profile.inputs) {
        if (s.type != StripType.channel) continue;
        final l = level[s.prefix] ?? -90;
        gr['${s.prefix}/dyn'] = flagOf(s.dynAddr('on')) || s.index <= 3 ? math.min(0, -(l + 22) * 0.6) : 0;
        gr['${s.prefix}/gate'] = s.index == 5 ? -12 + rnd.nextDouble() * 4 : 0;
      }
      gainReduction.update(gr);
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _keepAlive?.cancel();
    _demoMeters?.cancel();
    _sub?.cancel();
    _client?.close();
    muteLock.dispose();
    rta.dispose();
    gainReduction.dispose();
    super.dispose();
  }
}
