import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../osc/meters.dart';
import '../osc/osc_client.dart';
import '../osc/osc_message.dart';
import '../util/param_law.dart';
import 'mixer_profile.dart';

enum ConnState { connected, lost }

enum HeadampStatus { resolved, pending, none }

/// Which preamp an input channel uses right now.
class HeadampInfo {
  const HeadampInfo(this.status, [this.prefix, this.name]);
  final HeadampStatus status;
  final String? prefix; // e.g. /headamp/004
  final String? name; // e.g. Local 5
  String? get gainAddr => prefix == null ? null : '$prefix/gain';
  String? get phantomAddr => prefix == null ? null : '$prefix/phantom';
}

class MixerConnectException implements Exception {
  MixerConnectException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Holds the live state of one console. Every OSC address has its own
/// ValueNotifier, so a fader move only rebuilds that one fader.
class MixerController extends ChangeNotifier {
  MixerController._(this.profile, this._client, {required this.mixerName, required this.host}) {
    for (final s in profile.allStrips) {
      if (s.hasMeter) (_meterStrips[s.meterId!] ??= []).add(s);
    }
  }

  final MixerProfile profile;
  final OscClient? _client; // null = demo mode
  final String host;
  String mixerName;

  ConnState _state = ConnState.connected;
  ConnState get state => _state;
  bool get isDemo => _client == null;

  final Map<String, ValueNotifier<Object?>> _params = {};
  final Set<String> _touched = {};
  StreamSubscription<OscMessage>? _sub;
  Timer? _keepAlive;
  Timer? _demoMeters;

  /// Live meter levels (dBFS) keyed by strip prefix.
  final MeterLevels meters = MeterLevels();
  final Map<String, List<Strip>> _meterStrips = {};
  DateTime _lastRx = DateTime.now();
  bool _disposed = false;

  // ---------------------------------------------------------------- connect

  /// Connects to [host]. If [family] is null the model is detected via /xinfo,
  /// trying the X32 port first and then the XR port.
  static Future<MixerController> connect(String host, {MixerFamily? family}) async {
    final ports = family == null
        ? const [10023, 10024]
        : [MixerProfile.defaultPort(family)];
    for (final port in ports) {
      final client = await OscClient.open(host, port);
      final info = await client.request('/xinfo');
      if (info != null && info.args.length >= 3) {
        final model = info.args[2].toString();
        final fam = MixerProfile.familyFromModel(model) ??
            family ??
            (port == 10023 ? MixerFamily.x32 : MixerFamily.xr);
        final c = MixerController._(
          MixerProfile.forFamily(fam, model),
          client,
          mixerName: info.args[1].toString(),
          host: host,
        );
        c._start();
        return c;
      }
      client.close();
    }
    throw MixerConnectException('No mixer answered at $host.');
  }

  factory MixerController.demo(MixerFamily family) {
    final c = MixerController._(
      MixerProfile.forFamily(family, family == MixerFamily.x32 ? 'X32' : 'XR18'),
      null,
      mixerName: 'Demo',
      host: '',
    );
    c._seedDemo();
    return c;
  }

  void _start() {
    final client = _client!;
    _sub = client.messages.listen(_onMessage);
    client.send(const OscMessage('/xremote'));
    _subscribeMeters();
    // Consoles drop /xremote and /meters subscriptions after ~10 s, so renew every 8 s.
    _keepAlive = Timer.periodic(const Duration(seconds: 8), (_) {
      client.send(const OscMessage('/xremote'));
      _subscribeMeters();
      client.send(const OscMessage('/xinfo'));
      if (_state == ConnState.connected &&
          DateTime.now().difference(_lastRx) > const Duration(seconds: 20)) {
        _state = ConnState.lost;
        meters.clear(); // don't show frozen levels
        notifyListeners();
      }
    });
    refreshAll();
  }

  void _subscribeMeters() {
    for (final id in profile.meterRequests) {
      _client?.send(OscMessage('/meters', [id]));
    }
  }

  void _onMeters(String id, Uint8List blob) {
    final strips = _meterStrips[id];
    if (strips == null) return;
    final values = decodeMeterBlob(blob, profile.meterFormat);
    final update = <String, double>{};
    for (final s in strips) {
      var db = double.negativeInfinity;
      for (final i in s.meterIdx) {
        if (i < values.length && values[i] > db) db = values[i];
      }
      update[s.prefix] = db;
    }
    meters.update(update);
  }

  // ---------------------------------------------------------------- state

  ValueNotifier<Object?> param(String addr) =>
      _params.putIfAbsent(addr, () => ValueNotifier<Object?>(null));

  double faderOf(String addr) {
    final v = param(addr).value;
    return v is num ? v.toDouble() : 0.0;
  }

  double numOf(String addr, double fallback) {
    final v = param(addr).value;
    return v is num ? v.toDouble() : fallback;
  }

  int intOf(String addr, int fallback) {
    final v = param(addr).value;
    return v is num ? v.toInt() : fallback;
  }

  /// For switches whose "off" is the safe default (phantom, phase, low cut).
  bool flagOf(String addr) {
    final v = param(addr).value;
    return v is num && v != 0;
  }

  void setFlag(String addr, bool on) => set(addr, on ? 1 : 0);

  int? _intOrNull(String addr) {
    final v = param(addr).value;
    return v is num ? v.toInt() : null;
  }

  /// Resolves the preamp for [s]. On X32 this follows source → routing →
  /// user routing, and stays [HeadampStatus.pending] until every value it
  /// needs has arrived, so gain/+48V are never sent to a guessed preamp.
  HeadampInfo headampFor(Strip s) {
    if (s.type != StripType.channel) return const HeadampInfo(HeadampStatus.none);
    if (profile.family == MixerFamily.xr) {
      return HeadampInfo(HeadampStatus.resolved, '/headamp/${two(s.index)}', 'Input ${s.index}');
    }
    final idx = MixerProfile.x32HeadampIndex(s.index, _intOrNull);
    if (idx == null) return const HeadampInfo(HeadampStatus.pending);
    if (idx < 0) return const HeadampInfo(HeadampStatus.none);
    return HeadampInfo(
      HeadampStatus.resolved,
      MixerProfile.x32HeadampPrefix(idx),
      MixerProfile.x32HeadampName(idx),
    );
  }

  /// Asks the console for the current value of each address.
  Future<void> query(List<String> addrs) async {
    final client = _client;
    if (client == null) return;
    for (var i = 0; i < addrs.length; i++) {
      if (_disposed) return;
      client.send(OscMessage(addrs[i]));
      if (i % 16 == 15) await Future<void>.delayed(const Duration(milliseconds: 12));
    }
  }

  bool isOn(String addr) {
    final v = param(addr).value;
    return v is num ? v != 0 : true;
  }

  /// Queries every control on the console. Sent in small batches so the
  /// console's UDP buffer is not flooded.
  Future<void> refreshAll() async {
    final client = _client;
    if (client == null) return;
    final addrs = profile.queryAddresses;
    for (var i = 0; i < addrs.length; i++) {
      if (_disposed) return;
      client.send(OscMessage(addrs[i]));
      if (i % 16 == 15) await Future<void>.delayed(const Duration(milliseconds: 12));
    }
  }

  void _onMessage(OscMessage m) {
    _lastRx = DateTime.now();
    if (_state == ConnState.lost) {
      _state = ConnState.connected;
      notifyListeners();
      refreshAll(); // something may have changed while we were away
    }
    if (m.args.isEmpty) return;
    if (m.address.startsWith('/meters/')) {
      final blob = m.args.first;
      if (blob is Uint8List) _onMeters(m.address, blob);
      return;
    }
    if (m.address == '/xinfo') {
      if (m.args.length >= 2 && m.args[1].toString() != mixerName) {
        mixerName = m.args[1].toString();
        notifyListeners();
      }
      return;
    }
    // Don't let incoming values fight a finger that is on the fader.
    if (_touched.contains(m.address)) return;
    param(m.address).value = m.args.first;
  }

  // ---------------------------------------------------------------- actions

  void set(String addr, Object value) {
    param(addr).value = value;
    _client?.send(OscMessage(addr, [value]));
  }

  void setFader(String addr, double v) => set(addr, v.clamp(0.0, 1.0).toDouble());

  void toggleOn(String addr) => set(addr, isOn(addr) ? 0 : 1);

  void rename(Strip s, String name) => set(s.nameAddr, name.length > 12 ? name.substring(0, 12) : name);

  void beginTouch(String addr) => _touched.add(addr);
  void endTouch(String addr) => _touched.remove(addr);

  void _seedDemo() {
    var color = 1;
    for (final s in profile.allStrips) {
      param(s.nameAddr).value = '';
      param(s.colorAddr).value = s.type == StripType.main ? 7 : (color++ % 7) + 1;
      param(s.onAddr).value = 1;
      param(s.faderAddr).value = s.type == StripType.channel ? 0.6 : 0.75;
      if (s.hasSends) {
        for (final t in profile.sendTargets) {
          param(s.sendLevelAddr(t)).value = 0.0;
          param(s.sendOnAddr(t)).value = 1;
        }
      }
      if (s.hasDetail) _seedDemoDetail(s);
    }
    _startDemoMeters();
  }

  void _seedDemoDetail(Strip s) {
    const types = [1, 2, 2, 4]; // Low Shelf, PEQ, PEQ, High Shelf
    const freqs = [100.0, 400.0, 2500.0, 10000.0];
    param(s.panAddr).value = 0.5;
    param(s.eqOnAddr).value = 1;
    for (var b = 1; b <= profile.channelEqBands; b++) {
      param(s.eqAddr(b, 'type')).value = types[b - 1];
      param(s.eqAddr(b, 'f')).value = freqLaw.toNorm(freqs[b - 1]);
      param(s.eqAddr(b, 'g')).value = 0.5;
      param(s.eqAddr(b, 'q')).value = qLaw.toNorm(2.0);
    }
    param(s.hpOnAddr).value = 0;
    param(s.hpfAddr).value = hpfLaw.toNorm(80);
    param(s.invertAddr).value = 0;
    if (profile.hasTrim) param(s.trimAddr).value = 0.5;
    if (profile.family == MixerFamily.x32) {
      // Default X32 routing: channel N ← In N ← local blocks AN1-8 … AN25-32.
      param(MixerProfile.x32SourceAddr(s.index)).value = s.index;
      for (var b = 0; b < MixerProfile.x32RoutingBlocks.length; b++) {
        param(MixerProfile.x32RoutingBlocks[b]).value = b;
      }
    }
    // Gate and compressor: present but off, with typical vocal-ish settings.
    param(s.gateAddr('on')).value = 0;
    param(s.gateAddr('mode')).value = 3; // GATE
    param(s.gateAddr('thr')).value = gateThrLaw.toNorm(-50);
    param(s.gateAddr('range')).value = gateRangeLaw.toNorm(40);
    param(s.gateAddr('attack')).value = attackLaw.toNorm(1);
    param(s.gateAddr('hold')).value = holdLaw.toNorm(50);
    param(s.gateAddr('release')).value = releaseLaw.toNorm(200);
    param(s.dynAddr('on')).value = 0;
    param(s.dynAddr('mode')).value = 0; // COMP
    param(s.dynAddr('det')).value = 0; // PEAK
    param(s.dynAddr('env')).value = 1; // LOG
    param(s.dynAddr('thr')).value = compThrLaw.toNorm(-20);
    param(s.dynAddr('ratio')).value = 6; // 4:1
    param(s.dynAddr('knee')).value = kneeLaw.toNorm(2);
    param(s.dynAddr('mgain')).value = 0.0;
    param(s.dynAddr('attack')).value = attackLaw.toNorm(10);
    param(s.dynAddr('hold')).value = holdLaw.toNorm(20);
    param(s.dynAddr('release')).value = releaseLaw.toNorm(150);
    param(s.dynAddr('mix')).value = 1.0;
    param(s.dynAddr('auto')).value = 0;
    final ha = headampFor(s);
    if (ha.gainAddr != null) param(ha.gainAddr!).value = headampGainLaw.toNorm(20);
    if (ha.phantomAddr != null) param(ha.phantomAddr!).value = 0;
  }

  /// Plausible moving levels so the demo looks like a live console:
  /// the first 10 inputs carry signal, outputs follow the input faders.
  void _startDemoMeters() {
    final rnd = math.Random();
    final level = <String, double>{};
    _demoMeters = Timer.periodic(const Duration(milliseconds: 60), (_) {
      final update = <String, double>{};
      for (final s in profile.allStrips) {
        if (!s.hasMeter) continue;
        final live = s.type != StripType.channel || s.index <= 10;
        double target;
        if (!live || !isOn(s.onAddr)) {
          target = -90;
        } else {
          final base = s.type == StripType.channel ? -18.0 : -12.0;
          final gain = s.type == StripType.channel ? 0.0 : (faderOf(s.faderAddr) - 0.75) * 30;
          target = base + gain + (rnd.nextDouble() * 14 - 7);
        }
        final prev = level[s.prefix] ?? -90;
        // Fast attack, slower release, like a real meter.
        final next = target > prev ? prev + (target - prev) * 0.7 : prev + (target - prev) * 0.25;
        level[s.prefix] = next;
        update[s.prefix] = next < -80 ? double.negativeInfinity : math.min(next, 0);
      }
      meters.update(update);
    });
  }

  @override
  void dispose() {
    _disposed = true;
    _keepAlive?.cancel();
    _demoMeters?.cancel();
    _sub?.cancel();
    _client?.close();
    super.dispose();
  }
}
