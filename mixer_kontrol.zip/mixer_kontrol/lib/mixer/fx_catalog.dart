/// Effect types of the X32 / M32 and XR / MR effect engines.
///
/// The value written to /fx/N/type is the index into the list for that slot:
/// [fxFullList] for X32 slots 1-4 and all XR slots, [fxInsertList] for X32
/// slots 5-8 (insert-only effects). Order taken from the X32 OSC protocol
/// document; the XR uses the same 61 types (range 0-60).

enum FxCategory { reverb, delay, modulation, combo, eq, dynamics, enhance, amp, pitch }

const fxCategoryLabels = {
  FxCategory.reverb: 'Reverb',
  FxCategory.delay: 'Delay',
  FxCategory.modulation: 'Modulation',
  FxCategory.combo: 'Combination',
  FxCategory.eq: 'EQ',
  FxCategory.dynamics: 'Dynamics',
  FxCategory.enhance: 'Enhance & character',
  FxCategory.amp: 'Amp & drive',
  FxCategory.pitch: 'Pitch',
};

class FxType {
  const FxType(this.code, this.name, this.category);
  final String code;
  final String name;
  final FxCategory category;
}

const fxCatalog = <String, FxType>{
  'HALL': FxType('HALL', 'Hall Reverb', FxCategory.reverb),
  'AMBI': FxType('AMBI', 'Ambience', FxCategory.reverb),
  'RPLT': FxType('RPLT', 'Rich Plate', FxCategory.reverb),
  'ROOM': FxType('ROOM', 'Room Reverb', FxCategory.reverb),
  'CHAM': FxType('CHAM', 'Chamber Reverb', FxCategory.reverb),
  'PLAT': FxType('PLAT', 'Plate Reverb', FxCategory.reverb),
  'VREV': FxType('VREV', 'Vintage Reverb', FxCategory.reverb),
  'VRM': FxType('VRM', 'Vintage Room', FxCategory.reverb),
  'GATE': FxType('GATE', 'Gated Reverb', FxCategory.reverb),
  'RVRS': FxType('RVRS', 'Reverse Reverb', FxCategory.reverb),
  'DLY': FxType('DLY', 'Stereo Delay', FxCategory.delay),
  '3TAP': FxType('3TAP', '3-Tap Delay', FxCategory.delay),
  '4TAP': FxType('4TAP', 'Rhythm Delay', FxCategory.delay),
  'CRS': FxType('CRS', 'Stereo Chorus', FxCategory.modulation),
  'FLNG': FxType('FLNG', 'Stereo Flanger', FxCategory.modulation),
  'PHAS': FxType('PHAS', 'Stereo Phaser', FxCategory.modulation),
  'DIMC': FxType('DIMC', 'Dimensional Chorus', FxCategory.modulation),
  'FILT': FxType('FILT', 'Mood Filter', FxCategory.modulation),
  'ROTA': FxType('ROTA', 'Rotary Speaker', FxCategory.modulation),
  'PAN': FxType('PAN', 'Tremolo / Panner', FxCategory.modulation),
  'SUB': FxType('SUB', 'Sub Octaver', FxCategory.modulation),
  'D/RV': FxType('D/RV', 'Delay + Chamber', FxCategory.combo),
  'CR/R': FxType('CR/R', 'Chorus + Chamber', FxCategory.combo),
  'FL/R': FxType('FL/R', 'Flanger + Chamber', FxCategory.combo),
  'D/CR': FxType('D/CR', 'Delay + Chorus', FxCategory.combo),
  'D/FL': FxType('D/FL', 'Delay + Flanger', FxCategory.combo),
  'MODD': FxType('MODD', 'Modulation Delay', FxCategory.combo),
  'GEQ2': FxType('GEQ2', 'Dual Graphic EQ', FxCategory.eq),
  'GEQ': FxType('GEQ', 'Stereo Graphic EQ', FxCategory.eq),
  'TEQ2': FxType('TEQ2', 'Dual TruEQ', FxCategory.eq),
  'TEQ': FxType('TEQ', 'Stereo TruEQ', FxCategory.eq),
  'DES2': FxType('DES2', 'Dual De-Esser', FxCategory.dynamics),
  'DES': FxType('DES', 'Stereo De-Esser', FxCategory.dynamics),
  'P1A': FxType('P1A', 'Xtec EQ1 (stereo)', FxCategory.eq),
  'P1A2': FxType('P1A2', 'Xtec EQ1 (dual)', FxCategory.eq),
  'PQ5': FxType('PQ5', 'Xtec EQ5 (stereo)', FxCategory.eq),
  'PQ5S': FxType('PQ5S', 'Xtec EQ5 (dual)', FxCategory.eq),
  'WAVD': FxType('WAVD', 'Wave Designer', FxCategory.dynamics),
  'LIM': FxType('LIM', 'Precision Limiter', FxCategory.dynamics),
  'CMB': FxType('CMB', 'Combinator', FxCategory.dynamics),
  'CMB2': FxType('CMB2', 'Combinator (dual)', FxCategory.dynamics),
  'FAC': FxType('FAC', 'Fair Compressor', FxCategory.dynamics),
  'FAC1M': FxType('FAC1M', 'Fair Compressor (M/S)', FxCategory.dynamics),
  'FAC2': FxType('FAC2', 'Fair Compressor (dual)', FxCategory.dynamics),
  'LEC': FxType('LEC', 'Leisure Compressor', FxCategory.dynamics),
  'LEC2': FxType('LEC2', 'Leisure Compressor (dual)', FxCategory.dynamics),
  'ULC': FxType('ULC', 'Ultimo Compressor', FxCategory.dynamics),
  'ULC2': FxType('ULC2', 'Ultimo Compressor (dual)', FxCategory.dynamics),
  'ENH2': FxType('ENH2', 'Enhancer (dual)', FxCategory.enhance),
  'ENH': FxType('ENH', 'Enhancer (stereo)', FxCategory.enhance),
  'EXC2': FxType('EXC2', 'Exciter (dual)', FxCategory.enhance),
  'EXC': FxType('EXC', 'Exciter (stereo)', FxCategory.enhance),
  'IMG': FxType('IMG', 'Stereo Imager', FxCategory.enhance),
  'EDI': FxType('EDI', 'Edison EX1', FxCategory.enhance),
  'SON': FxType('SON', 'Sound Maker', FxCategory.enhance),
  'AMP2': FxType('AMP2', 'Guitar Amp (dual)', FxCategory.amp),
  'AMP': FxType('AMP', 'Guitar Amp (stereo)', FxCategory.amp),
  'DRV2': FxType('DRV2', 'Tube Stage (dual)', FxCategory.amp),
  'DRV': FxType('DRV', 'Tube Stage (stereo)', FxCategory.amp),
  'PIT2': FxType('PIT2', 'Pitch Shifter (dual)', FxCategory.pitch),
  'PIT': FxType('PIT', 'Pitch Shifter (stereo)', FxCategory.pitch),
};

/// /fx/[1…4]/type on X32 and all XR slots: values 0-60.
const fxFullList = [
  'HALL', 'AMBI', 'RPLT', 'ROOM', 'CHAM', 'PLAT', 'VREV', 'VRM', 'GATE', 'RVRS', //
  'DLY', '3TAP', '4TAP', 'CRS', 'FLNG', 'PHAS', 'DIMC', 'FILT', 'ROTA', 'PAN', //
  'SUB', 'D/RV', 'CR/R', 'FL/R', 'D/CR', 'D/FL', 'MODD', 'GEQ2', 'GEQ', 'TEQ2', //
  'TEQ', 'DES2', 'DES', 'P1A', 'P1A2', 'PQ5', 'PQ5S', 'WAVD', 'LIM', 'CMB', //
  'CMB2', 'FAC', 'FAC1M', 'FAC2', 'LEC', 'LEC2', 'ULC', 'ULC2', 'ENH2', 'ENH', //
  'EXC2', 'EXC', 'IMG', 'EDI', 'SON', 'AMP2', 'AMP', 'DRV2', 'DRV', 'PIT2', //
  'PIT',
];

/// /fx/[5…8]/type on X32 (insert-only effects): values 0-33.
const fxInsertList = [
  'GEQ2', 'GEQ', 'TEQ2', 'TEQ', 'DES2', 'DES', 'P1A', 'P1A2', 'PQ5', 'PQ5S', //
  'WAVD', 'LIM', 'FAC', 'FAC1M', 'FAC2', 'LEC', 'LEC2', 'ULC', 'ULC2', 'ENH2', //
  'ENH', 'EXC2', 'EXC', 'IMG', 'EDI', 'SON', 'AMP2', 'AMP', 'DRV2', 'DRV', //
  'PHAS', 'FILT', 'PAN', 'SUB',
];

/// Parameters shown per effect. Effects use up to 64; the first 16 cover
/// the main controls of nearly every type, and the screen can show all.
const fxParamsShown = 16;
const fxParamsMax = 64;
