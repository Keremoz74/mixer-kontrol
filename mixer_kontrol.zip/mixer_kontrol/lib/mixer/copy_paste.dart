import 'mixer_controller.dart';
import 'mixer_profile.dart';

/// Copy a strip's settings and paste them onto other strips of the same kind
/// (channel → channels, bus → buses, …). Preamp gain and +48V are never
/// copied (each input has its own source), nor are inserts (an FX slot side
/// can only serve one channel).

enum CopySection { eq, gate, comp, input, pan, sends, faderMute, nameColor }

const copySectionLabels = {
  CopySection.eq: 'EQ (and low cut)',
  CopySection.gate: 'Gate',
  CopySection.comp: 'Compressor',
  CopySection.input: 'Phase & trim',
  CopySection.pan: 'Pan',
  CopySection.sends: 'Sends',
  CopySection.faderMute: 'Fader & mute',
  CopySection.nameColor: 'Name & colour',
};

/// Pasted by default: the processing. Level, mute and name stay as they are.
const copyDefaultSections = {
  CopySection.eq,
  CopySection.gate,
  CopySection.comp,
  CopySection.input,
  CopySection.pan,
  CopySection.sends,
};

/// Addresses of [section] on [s]; empty if [s] doesn't have it.
List<String> sectionAddresses(MixerProfile p, Strip s, CopySection section) {
  final ch = s.hasDetail;
  switch (section) {
    case CopySection.eq:
      return [...s.eqAddresses, if (ch) ...[s.hpOnAddr, s.hpfAddr]];
    case CopySection.gate:
      return ch ? [for (final f in gateFields) s.gateAddr(f)] : const [];
    case CopySection.comp:
      return ch ? [for (final f in dynFields) s.dynAddr(f)] : const [];
    case CopySection.input:
      return ch ? [s.invertAddr, if (p.hasTrim) s.trimAddr] : const [];
    case CopySection.pan:
      return ch ? [s.panAddr] : const [];
    case CopySection.sends:
      if (s.hasSends) {
        return [for (final t in p.sendTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)]];
      }
      if (s.type == StripType.bus && p.hasMatrix) {
        return [for (final t in p.matrixTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)]];
      }
      return const [];
    case CopySection.faderMute:
      return [s.faderAddr, s.onAddr];
    case CopySection.nameColor:
      return [s.nameAddr, s.colorAddr];
  }
}

List<CopySection> sectionsFor(MixerProfile p, Strip s) =>
    [for (final sec in CopySection.values) if (sectionAddresses(p, s, sec).isNotEmpty) sec];

class StripClipboard {
  StripClipboard(this.family, this.source, this.values);
  final MixerFamily family;
  final Strip source;

  /// Source values by full source address.
  final Map<String, Object> values;
}

/// App-wide clipboard (one copied strip at a time).
StripClipboard? stripClipboard;

/// Strips [clip] can be pasted onto: same kind, same console family.
List<Strip> pasteTargets(MixerProfile p, StripClipboard clip) => [
      for (final s in p.allStrips)
        if (s.type == clip.source.type && p.family == clip.family) s,
    ];

/// Reads the strip's current values from the console, then copies them.
Future<StripClipboard> copyStrip(MixerController c, Strip s) async {
  final p = c.profile;
  final addrs = [for (final sec in sectionsFor(p, s)) ...sectionAddresses(p, s, sec)];
  if (!c.isDemo) {
    await c.query(addrs);
    await Future<void>.delayed(const Duration(milliseconds: 500));
  }
  final values = <String, Object>{};
  for (final a in addrs) {
    final v = c.param(a).value;
    if (v != null) values[a] = v;
  }
  return stripClipboard = StripClipboard(p.family, s, values);
}

/// Pastes [sections] of [clip] onto [targets]. Returns the targets' previous
/// values for undo.
Map<String, Object> pasteStrip(
  MixerController c,
  StripClipboard clip,
  Iterable<Strip> targets,
  Set<CopySection> sections,
) {
  final p = c.profile;
  final before = <String, Object>{};
  final src = clip.source;
  for (final t in targets) {
    if (t.prefix == src.prefix) continue;
    for (final sec in sections) {
      for (final a in sectionAddresses(p, src, sec)) {
        final v = clip.values[a];
        if (v == null) continue;
        final target = t.prefix + a.substring(src.prefix.length);
        final old = c.param(target).value;
        if (old != null) before[target] = old;
        c.set(target, v);
      }
    }
  }
  return before;
}
