import 'mixer_controller.dart';
import 'mixer_profile.dart';

/// Copy a strip's settings and paste them onto other strips of the same kind
/// (channel → channels, bus → buses, …). Preamp gain and +48V are never
/// copied (each input has its own source), nor are inserts (an FX slot side
/// can only serve one channel).

enum CopySection { eq, gate, comp, input, pan, sends, groups, faderMute, nameColor }

const copySectionLabels = {
  CopySection.eq: 'EQ (and low cut)',
  CopySection.gate: 'Gate',
  CopySection.comp: 'Compressor',
  CopySection.input: 'Phase & trim',
  CopySection.pan: 'Pan',
  CopySection.sends: 'Sends',
  CopySection.groups: 'DCA, mute groups & Main LR',
  CopySection.faderMute: 'Fader & mute',
  CopySection.nameColor: 'Name & colour',
};

/// Pasted by default: the processing. Level, mute and name stay as they are.
const copyDefaultSections = {
  CopySection.eq,
  CopySection.gate,
  CopySection.comp,
  CopySection.input,
  CopySection.pan,
  CopySection.sends,
};

/// Addresses of [section] on [s]; empty if [s] doesn't have it.
List<String> sectionAddresses(MixerProfile p, Strip s, CopySection section) {
  final ch = s.hasDetail;
  switch (section) {
    case CopySection.eq:
      return [
        ...s.eqAddresses,
        if (ch) ...[s.hpOnAddr, s.hpfAddr]
      ];
    case CopySection.gate:
      return ch ? [for (final f in gateFields) s.gateAddr(f)] : const [];
    case CopySection.comp:
      return ch ? [for (final f in dynFields) s.dynAddr(f)] : const [];
    case CopySection.input:
      return ch ? [s.invertAddr, if (p.hasTrim) s.trimAddr] : const [];
    case CopySection.pan:
      return ch ? [s.panAddr] : const [];
    case CopySection.sends:
      if (s.hasSends) {
        return {
          for (final t in p.sendTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)],
          for (final t in p.busTargets) p.tapAddr(s, t.mixIndex),
        }.toList();
      }
      if (s.type == StripType.bus && p.hasMatrix) {
        return [
          for (final t in p.matrixTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)]
        ];
      }
      return const [];
    case CopySection.groups:
      return [
        if (p.hasGroups(s)) ...[p.dcaMaskAddr(s), p.muteMaskAddr(s)],
        if (p.mainAssignAddr(s) != null) p.mainAssignAddr(s)!,
        if (p.monoAssignAddr(s) != null) ...[p.monoAssignAddr(s)!, p.monoLevelAddr(s)!],
      ];
    case CopySection.faderMute:
      return [s.faderAddr, s.onAddr];
    case CopySection.nameColor:
      return [s.nameAddr, s.colorAddr];
  }
}

List<CopySection> sectionsFor(MixerProfile p, Strip s) => [
      for (final sec in CopySection.values)
        if (sectionAddresses(p, s, sec).isNotEmpty) sec
    ];

class StripClipboard {
  StripClipboard(this.family, this.sources, this.values) : assert(sources.isNotEmpty);
  final MixerFamily family;

  /// The copied strips, in console order (all of one kind).
  final List<Strip> sources;

  /// The (first) copied strip.
  Strip get source => sources.first;

  /// More than one strip copied: pasted strip by strip onto chosen targets.
  bool get multi => sources.length > 1;

  /// Source values by full source address.
  final Map<String, Object> values;
}

/// App-wide clipboard (one copy, of one or more strips, at a time).
StripClipboard? stripClipboard;

/// Strips [clip] can be pasted onto: same kind, same console family.
List<Strip> pasteTargets(MixerProfile p, StripClipboard clip) => [
      for (final s in p.allStrips)
        if (s.type == clip.source.type && p.family == clip.family) s,
    ];

/// Reads the strip's current values from the console, then copies them.
Future<StripClipboard> copyStrip(MixerController c, Strip s) => copyStrips(c, [s]);

/// Copies several strips of one kind at once (read from the console first).
Future<StripClipboard> copyStrips(MixerController c, List<Strip> strips) async {
  final p = c.profile;
  final order = {for (var i = 0; i < p.allStrips.length; i++) p.allStrips[i].prefix: i};
  final list = [...strips]..sort((a, b) => (order[a.prefix] ?? 0).compareTo(order[b.prefix] ?? 0));
  final addrs = [
    for (final s in list)
      for (final sec in sectionsFor(p, s)) ...sectionAddresses(p, s, sec),
  ];
  if (!c.isDemo) {
    await c.query(addrs);
    await Future<void>.delayed(Duration(milliseconds: 500 + 40 * list.length));
  }
  final values = <String, Object>{};
  for (final a in addrs) {
    final v = c.param(a).value;
    if (v != null) values[a] = v;
  }
  return stripClipboard = StripClipboard(p.family, list, values);
}

/// The default pairing of a multi-strip copy: the copied strips in order,
/// onto consecutive strips starting at [first] (past the last strip: none).
Map<String, Strip?> defaultPasteMap(MixerProfile p, StripClipboard clip, Strip first) {
  final cands = pasteTargets(p, clip);
  final start = cands.indexWhere((t) => t.prefix == first.prefix);
  return {
    for (var i = 0; i < clip.sources.length; i++)
      clip.sources[i].prefix: start >= 0 && start + i < cands.length ? cands[start + i] : null,
  };
}

/// Pastes [sections] of each copied strip onto its target in [map] (copied
/// strip prefix → target; null = skipped). Returns the targets' previous
/// values for undo.
Map<String, Object> pasteMapped(
  MixerController c,
  StripClipboard clip,
  Map<String, Strip?> map,
  Set<CopySection> sections,
) {
  final p = c.profile;
  final before = <String, Object>{};
  for (final src in clip.sources) {
    final t = map[src.prefix];
    if (t == null || t.prefix == src.prefix) continue;
    for (final sec in sections) {
      for (final a in sectionAddresses(p, src, sec)) {
        final v = clip.values[a];
        if (v == null) continue;
        final target = t.prefix + a.substring(src.prefix.length);
        // (a strip pasted onto several: keep the value from before them all)
        final old = c.param(target).value;
        if (old != null) before.putIfAbsent(target, () => old);
        c.set(target, v);
      }
    }
  }
  return before;
}

/// Pastes [sections] of [clip] onto [targets]. Returns the targets' previous
/// values for undo.
Map<String, Object> pasteStrip(
  MixerController c,
  StripClipboard clip,
  Iterable<Strip> targets,
  Set<CopySection> sections,
) {
  final p = c.profile;
  final before = <String, Object>{};
  final src = clip.source;
  for (final t in targets) {
    if (t.prefix == src.prefix) continue;
    for (final sec in sections) {
      for (final a in sectionAddresses(p, src, sec)) {
        final v = clip.values[a];
        if (v == null) continue;
        final target = t.prefix + a.substring(src.prefix.length);
        final old = c.param(target).value;
        if (old != null) before[target] = old;
        c.set(target, v);
      }
    }
  }
  return before;
}
