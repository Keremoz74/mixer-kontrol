import 'package:shared_preferences/shared_preferences.dart';

import 'mixer_controller.dart';
import 'mixer_profile.dart';

/// Copy a strip's settings and paste them onto other strips of the same kind
/// (channel → channels, bus → buses, …). The preamp gain and +48V go to the
/// target's own preamp. Inserts are never copied (an FX slot side can only
/// serve one channel).

enum CopySection { gain, phantom, eq, gate, comp, input, pan, sends, groups, faderMute, nameColor }

const copySectionLabels = {
  CopySection.gain: 'Gain (preamp)',
  CopySection.phantom: '+48V phantom power',
  CopySection.eq: 'EQ (and low cut)',
  CopySection.gate: 'Gate',
  CopySection.comp: 'Compressor',
  CopySection.input: 'Phase & trim',
  CopySection.pan: 'Pan',
  CopySection.sends: 'Sends',
  CopySection.groups: 'DCA, mute groups & Main LR',
  CopySection.faderMute: 'Fader & mute',
  CopySection.nameColor: 'Name & colour',
};

/// Pasted by default: every setting.
const copyDefaultSections = {...CopySection.values};

/// What was ticked the last time something was pasted (kept on the device);
/// the next paste starts with the same choice.
Set<CopySection> pasteSectionsChoice = {...copyDefaultSections};

Future<void> loadPasteSections() async {
  try {
    final p = await SharedPreferences.getInstance();
    final l = p.getStringList('paste_sections_v3');
    if (l != null)
      pasteSectionsChoice = {
        for (final s in CopySection.values)
          if (l.contains(s.name)) s
      };
  } catch (_) {}
}

void rememberPasteSections(Set<CopySection> s) {
  pasteSectionsChoice = {...s};
  SharedPreferences.getInstance()
      .then((p) => p.setStringList('paste_sections_v3', [for (final x in s) x.name]))
      .catchError((_) => false);
}

/// Addresses of [section] on [s]; empty if [s] doesn't have it.
List<String> sectionAddresses(MixerProfile p, Strip s, CopySection section) {
  final ch = s.hasDetail;
  switch (section) {
    case CopySection.gain:
    case CopySection.phantom:
      return const []; // the preamp depends on routing: see gainAddrOf
    case CopySection.eq:
      return [
        ...s.eqAddresses,
        if (ch) ...[s.hpOnAddr, s.hpfAddr]
      ];
    case CopySection.gate:
      return ch ? [for (final f in gateFields) s.gateAddr(f)] : const [];
    case CopySection.comp:
      return ch ? [for (final f in dynFields) s.dynAddr(f)] : const [];
    case CopySection.input:
      return ch ? [s.invertAddr, if (p.hasTrim) s.trimAddr] : const [];
    case CopySection.pan:
      return ch ? [s.panAddr] : const [];
    case CopySection.sends:
      if (s.hasSends) {
        return {
          for (final t in p.sendTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)],
          for (final t in p.busTargets) p.tapAddr(s, t.mixIndex),
        }.toList();
      }
      if (s.type == StripType.bus && p.hasMatrix) {
        return [
          for (final t in p.matrixTargets) ...[s.sendLevelAddr(t), s.sendOnAddr(t)]
        ];
      }
      return const [];
    case CopySection.groups:
      return [
        if (p.hasGroups(s)) ...[p.dcaMaskAddr(s), p.muteMaskAddr(s)],
        if (p.mainAssignAddr(s) != null) p.mainAssignAddr(s)!,
        if (p.monoAssignAddr(s) != null) ...[p.monoAssignAddr(s)!, p.monoLevelAddr(s)!],
      ];
    case CopySection.faderMute:
      return [s.faderAddr, s.onAddr];
    case CopySection.nameColor:
      return [s.nameAddr, s.colorAddr];
  }
}

List<CopySection> sectionsFor(MixerProfile p, Strip s) => [
      for (final sec in CopySection.values)
        if (sectionAddresses(p, s, sec).isNotEmpty) sec
    ];

/// The strip's preamp gain address (where its input comes from), or null.
String? gainAddrOf(MixerController c, Strip s) => s.hasDetail ? c.headampFor(s).gainAddr : null;

/// The strip's +48V address, or null.
String? phantomAddrOf(MixerController c, Strip s) => s.hasDetail ? c.headampFor(s).phantomAddr : null;

/// [sectionsFor] plus the preamp gain and +48V where the strip has them.
List<CopySection> sectionsOn(MixerController c, Strip s) => [
      if (gainAddrOf(c, s) != null) CopySection.gain,
      if (phantomAddrOf(c, s) != null) CopySection.phantom,
      ...sectionsFor(c.profile, s),
    ];

/// Clipboard keys of a copied strip's preamp gain and +48V.
String _gainKey(Strip s) => '${s.prefix}#gain';
String _phantomKey(Strip s) => '${s.prefix}#phantom';

/// Pastes the copied preamp settings of [src] onto [t]'s own preamp.
void _pastePreamp(
  MixerController c,
  StripClipboard clip,
  Strip src,
  Strip t,
  Set<CopySection> sections,
  Map<String, Object> before,
) {
  void put(String key, String? a) {
    final v = clip.values[key];
    if (v == null || a == null) return;
    final old = c.param(a).value;
    if (old != null) before.putIfAbsent(a, () => old);
    c.set(a, v);
  }

  if (sections.contains(CopySection.gain)) put(_gainKey(src), gainAddrOf(c, t));
  if (sections.contains(CopySection.phantom)) put(_phantomKey(src), phantomAddrOf(c, t));
}

class StripClipboard {
  StripClipboard(this.family, this.sources, this.values) : assert(sources.isNotEmpty);
  final MixerFamily family;

  /// The copied strips, in console order (all of one kind).
  final List<Strip> sources;

  /// The (first) copied strip.
  Strip get source => sources.first;

  /// More than one strip copied: pasted strip by strip onto chosen targets.
  bool get multi => sources.length > 1;

  /// Source values by full source address.
  final Map<String, Object> values;
}

/// App-wide clipboard (one copy, of one or more strips, at a time).
StripClipboard? stripClipboard;

/// Strips [clip] can be pasted onto: same kind, same console family.
List<Strip> pasteTargets(MixerProfile p, StripClipboard clip) => [
      for (final s in p.allStrips)
        if (s.type == clip.source.type && p.family == clip.family) s,
    ];

/// Reads the strip's current values from the console, then copies them.
Future<StripClipboard> copyStrip(MixerController c, Strip s) => copyStrips(c, [s]);

/// Copies several strips of one kind at once (read from the console first).
Future<StripClipboard> copyStrips(MixerController c, List<Strip> strips) async {
  final p = c.profile;
  final order = {for (var i = 0; i < p.allStrips.length; i++) p.allStrips[i].prefix: i};
  final list = [...strips]..sort((a, b) => (order[a.prefix] ?? 0).compareTo(order[b.prefix] ?? 0));
  final gains = {for (final s in list) s.prefix: gainAddrOf(c, s)};
  final phantoms = {for (final s in list) s.prefix: phantomAddrOf(c, s)};
  final addrs = [
    for (final s in list) ...[
      for (final sec in sectionsFor(p, s)) ...sectionAddresses(p, s, sec),
      if (gains[s.prefix] != null) gains[s.prefix]!,
      if (phantoms[s.prefix] != null) phantoms[s.prefix]!,
    ],
  ];
  if (!c.isDemo) {
    await c.query(addrs);
    await Future<void>.delayed(Duration(milliseconds: 500 + 40 * list.length));
  }
  final values = <String, Object>{};
  for (final a in addrs) {
    final v = c.param(a).value;
    if (v != null) values[a] = v;
  }
  for (final s in list) {
    final g = gains[s.prefix], ph = phantoms[s.prefix];
    final v = g == null ? null : c.param(g).value;
    if (v != null) values[_gainKey(s)] = v;
    final pv = ph == null ? null : c.param(ph).value;
    if (pv != null) values[_phantomKey(s)] = pv;
  }
  return stripClipboard = StripClipboard(p.family, list, values);
}

/// The default pairing of a multi-strip copy: the copied strips in order,
/// onto consecutive strips starting at [first] (past the last strip: none).
Map<String, Strip?> defaultPasteMap(MixerProfile p, StripClipboard clip, Strip first) {
  final cands = pasteTargets(p, clip);
  final start = cands.indexWhere((t) => t.prefix == first.prefix);
  return {
    for (var i = 0; i < clip.sources.length; i++)
      clip.sources[i].prefix: start >= 0 && start + i < cands.length ? cands[start + i] : null,
  };
}

/// Pastes [sections] of each copied strip onto its target in [map] (copied
/// strip prefix → target; null = skipped). Returns the targets' previous
/// values for undo.
Map<String, Object> pasteMapped(
  MixerController c,
  StripClipboard clip,
  Map<String, Strip?> map,
  Set<CopySection> sections,
) {
  final p = c.profile;
  final before = <String, Object>{};
  for (final src in clip.sources) {
    final t = map[src.prefix];
    if (t == null || t.prefix == src.prefix) continue;
    _pastePreamp(c, clip, src, t, sections, before);
    for (final sec in sections) {
      for (final a in sectionAddresses(p, src, sec)) {
        final v = clip.values[a];
        if (v == null) continue;
        final target = t.prefix + a.substring(src.prefix.length);
        // (a strip pasted onto several: keep the value from before them all)
        final old = c.param(target).value;
        if (old != null) before.putIfAbsent(target, () => old);
        c.set(target, v);
      }
    }
  }
  return before;
}

/// Pastes [sections] of [clip] onto [targets]. Returns the targets' previous
/// values for undo.
Map<String, Object> pasteStrip(
  MixerController c,
  StripClipboard clip,
  Iterable<Strip> targets,
  Set<CopySection> sections,
) {
  final p = c.profile;
  final before = <String, Object>{};
  final src = clip.source;
  for (final t in targets) {
    if (t.prefix == src.prefix) continue;
    _pastePreamp(c, clip, src, t, sections, before);
    for (final sec in sections) {
      for (final a in sectionAddresses(p, src, sec)) {
        final v = clip.values[a];
        if (v == null) continue;
        final target = t.prefix + a.substring(src.prefix.length);
        final old = c.param(target).value;
        if (old != null) before[target] = old;
        c.set(target, v);
      }
    }
  }
  return before;
}
