import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import 'yamaha_map.dart';

/// Connection to a Yamaha console over its remote control protocol (TCP).
/// Speaks the app's own addresses on the outside (see [YamahaMap]).
///
/// The console pushes "NOTIFY set …" lines for changes made elsewhere, so no
/// subscription is needed. If the TCP connection drops, the link reconnects
/// by itself every few seconds.
class YamahaLink implements MixerLink {
  YamahaLink._(this.host, this.port);

  final String host;
  final int port;
  Socket? _socket;
  StreamSubscription<String>? _lines;
  bool _closed = false;
  Timer? _retry;
  final _out = StreamController<OscMessage>.broadcast();

  /// Raw protocol lines (for connect-time questions), before translation.
  final _raw = StreamController<List<String>>.broadcast();

  YamahaMap map = YamahaMap();
  String? productName;

  /// Yamaha parameter → app address it answers (filled as the app asks).
  final Map<String, (String, YamahaKind)> _back = {};

  /// App DCA masks, assembled from one Yamaha switch per DCA.
  final Map<String, int> _masks = {};

  /// Meter paths the console streams → app meter id.
  final Map<String, String> _meterBack = {};

  static const defaultPort = 49280;

  /// Longest line accepted from the console.
  static const maxLine = 8192;

  /// Meter update interval asked from the console.
  static const meterIntervalMs = 100;

  static Future<YamahaLink> connect(String host, {int port = defaultPort, Duration timeout = const Duration(seconds: 3)}) async {
    final l = YamahaLink._(host, port);
    await l._open(timeout);
    return l;
  }

  Future<void> _open(Duration timeout) async {
    final s = await Socket.connect(host, port, timeout: timeout);
    s.setOption(SocketOption.tcpNoDelay, true);
    _socket = s;
    _lines = utf8.decoder
        .bind(s)
        .transform(const LineSplitter())
        .listen(_onLine, onError: (_) => _lost(), onDone: _lost, cancelOnError: true);
  }

  void _lost() {
    _lines?.cancel();
    _lines = null;
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    if (_closed) return;
    // keep trying quietly; the app shows "connection lost" meanwhile
    _retry ??= Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_closed || _socket != null) return;
      try {
        await _open(const Duration(seconds: 2));
        _retry?.cancel();
        _retry = null;
      } catch (_) {}
    });
  }

  void _emit(String addr, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(addr, [v]));
  }

  void _onLine(String line) {
    if (line.length > maxLine) return;
    final t = YamahaMap.tokenize(line.trim());
    if (t.isEmpty) return;
    if (!_raw.isClosed) _raw.add(t);
    if (t.length < 3 || !(t[0] == 'OK' || t[0] == 'OKm' || t[0] == 'NOTIFY')) return;
    switch (t[1]) {
      case 'get':
      case 'set':
        if (t.length >= 6) _onValue(t[2], t[3], t[4], t[5]);
      case 'mtr':
        _onMeter(t);
      case 'sscurrent_ex':
      case 'sscurrentt_ex':
        if (t.length >= 4) {
          final n = double.tryParse(t[3]);
          if (n != null) _emit(MixerProfile.yamahaSceneCurrentAddr, n.round());
        }
      case 'ssinfo_ex':
      case 'ssinfot_ex':
        // OK ssinfo_ex <bank> <n> <text> <name> …
        if (t.length >= 6) {
          final n = double.tryParse(t[3]);
          if (n != null && n >= 0 && n < 1000) _emit(MixerProfile.yamahaSceneNameAddr(n.round()), t[5]);
        }
      case 'devinfo':
        if (t.length >= 4 && t[2] == 'productname') productName = t[3];
    }
  }

  void _onValue(String path, String xs, String ys, String token) {
    final x = int.tryParse(xs), y = int.tryParse(ys);
    if (x == null || y == null) return;
    final hit = _back['$path $x $y'];
    if (hit == null) return;
    final (addr, kind) = hit;
    if (kind == YamahaKind.dcaBit) {
      final on = map.decode(kind, token);
      if (on is! int || y > 30) return;
      final m = _masks[addr] ?? 0;
      final next = on != 0 ? (m | (1 << y)) : (m & ~(1 << y));
      _masks[addr] = next;
      _emit(addr, next);
      return;
    }
    final v = map.decode(kind, token);
    if (v != null) _emit(addr, v);
  }

  void _onMeter(List<String> t) {
    // NOTIFY mtr <path> mtr <hex> <hex> …
    final id = _meterBack[t[2]];
    if (id == null || t.length < 5) return;
    final values = t.sublist(4);
    final n = values.length.clamp(0, 512);
    final bd = ByteData(4 + n * 2);
    bd.setInt32(0, n, Endian.little);
    for (var i = 0; i < n; i++) {
      final raw = int.tryParse(values[i], radix: 16) ?? 0;
      final db = map.meterDb(raw);
      bd.setInt16(4 + i * 2, db.isFinite ? (db * 256).round().clamp(-32767, 32767) : -32768, Endian.little);
    }
    if (!_out.isClosed) _out.add(OscMessage(id, [bd.buffer.asUint8List()]));
  }

  void _write(String line) {
    final s = _socket;
    if (s == null) return;
    try {
      s.write('$line\n');
    } catch (_) {
      _lost();
    }
  }

  @override
  Stream<OscMessage> get messages => _out.stream;

  @override
  void send(OscMessage m) {
    final a = m.address;
    switch (a) {
      case '/xinfo':
        // keep-alive: the answer (the STEREO fader) keeps the connection live
        _write('get ${YamahaMap.root}St/Fader/Level 0 0');
        return;
      case '/meters':
        if (m.args.isNotEmpty && m.args.first is String) _startMeter(m.args.first as String);
        return;
      case '/-snap/load':
        if (m.args.isNotEmpty && m.args.first is num) _write(_scene('ssrecall', (m.args.first as num).toInt()));
        return;
      case '/-snap/save':
        if (m.args.isNotEmpty && m.args.first is num) _write(_scene('ssupdate', (m.args.first as num).toInt()));
        return;
      case MixerProfile.yamahaSceneCurrentAddr:
        if (m.args.isEmpty) _write(_sceneCmd('sscurrent'));
        return;
    }
    final scene = MixerProfile.yamahaSceneFromNameAddr(a);
    if (scene != null) {
      if (m.args.isEmpty) _write(_scene('ssinfo', scene));
      return;
    }
    final dca = map.dcaMaskParams(a);
    if (dca.isNotEmpty) {
      if (m.args.isEmpty) {
        for (final p in dca) {
          _back[p.key] = (a, YamahaKind.dcaBit);
          _write('get ${p.path} ${p.x} ${p.y}');
        }
      } else if (m.args.first is num) {
        final mask = (m.args.first as num).toInt();
        _masks[a] = mask;
        for (final p in dca) {
          _back[p.key] = (a, YamahaKind.dcaBit);
          _write('set ${p.path} ${p.x} ${p.y} ${(mask >> p.y) & 1}');
        }
      }
      return;
    }
    final fixed = YamahaMap.constantFor(a);
    if (fixed != null) {
      if (m.args.isEmpty) _emit(a, fixed);
      return;
    }
    final p = map.toYamaha(a);
    if (p == null) return; // the console has no such control
    _back[p.key] = (a, p.kind);
    if (m.args.isEmpty) {
      _write('get ${p.path} ${p.x} ${p.y}');
      return;
    }
    final v = map.encode(p.kind, m.args.first);
    if (v != null) _write('set ${p.path} ${p.x} ${p.y} $v');
  }

  // ---------------------------------------------------------------- meters & scenes

  /// App meter ids look like /meters/yamaha/InCh.
  void _startMeter(String id) {
    if (!id.startsWith('/meters/yamaha/')) return;
    final cat = id.substring('/meters/yamaha/'.length);
    final pick = cat == 'InCh' || cat == 'StInCh' ? 'PreFader' : 'PostOn';
    final path = '${YamahaMap.root}$cat/$pick';
    _meterBack[path] = id;
    _write('mtrstart $path $meterIntervalMs');
  }

  bool get _textScenes => map.dialect == YamahaDialect.dm7;

  String get _bank => map.dialect == YamahaDialect.clql ? 'MIXER:Lib/Scene' : 'scene_a';

  String _sceneCmd(String verb) => '${verb}${_textScenes ? 't' : ''}_ex $_bank';

  String _scene(String verb, int n) => '${_sceneCmd(verb)} ${_textScenes ? '"$n.00"' : '$n'}';

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------- connect-time questions

  /// Asks the console for its model ("TF5", "DM3"…); null if it won't say.
  Future<String?> askProductName({Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = _raw.stream
        .firstWhere((t) => t.length >= 2 && (t[1] == 'devinfo' || (t[0] == 'ERROR' && t.contains('devinfo'))))
        .timeout(timeout);
    _write('devinfo productname');
    try {
      final t = await reply;
      return t[0] == 'OK' && t.length >= 4 && t[3].trim().isNotEmpty ? t[3].trim() : null;
    } catch (_) {
      return null;
    }
  }

  /// True if [path] x y exists on this console.
  Future<bool> _exists(String path, int x, [int y = 0]) async {
    final reply = _raw.stream
        .firstWhere((t) =>
            (t.length >= 5 && t[0].startsWith('OK') && t[1] == 'get' && t[2] == path && t[3] == '$x' && t[4] == '$y') ||
            t[0] == 'ERROR')
        .timeout(const Duration(milliseconds: 600));
    _write('get $path $x $y');
    try {
      final t = await reply;
      return t[0].startsWith('OK');
    } catch (_) {
      return false;
    }
  }

  /// How many indexes (0..[max]) answer, along x (or y with [alongY]).
  Future<int> _count(String path, int max, {bool alongY = false}) async {
    Future<bool> has(int i) => alongY ? _exists(path, 0, i) : _exists(path, i);
    if (!await has(0)) return 0;
    var lo = 1, hi = max; // lo exists (count >= lo)
    while (lo < hi) {
      final mid = (lo + hi + 1) ~/ 2;
      if (await has(mid - 1)) {
        lo = mid;
      } else {
        hi = mid - 1;
      }
    }
    return lo;
  }

  /// Reads how many channels, buses, DCAs, mute groups… this console has,
  /// and sets up the translation for it.
  Future<YamahaLayout> readLayout(String model) async {
    final dialect = yamahaDialectFor(model);
    const r = YamahaMap.root;
    final inputs = await _count('${r}InCh/Fader/Level', YamahaLayout.maxInputs);
    final stereo = await _count('${r}StInCh/Fader/Level', YamahaLayout.maxStereo);
    final fx = await _count('${r}FxRtnCh/Fader/Level', YamahaLayout.maxFxReturns);
    final mixes = await _count('${r}Mix/Fader/Level', YamahaLayout.maxMixes);
    final mtrx = await _count('${r}Mtrx/Fader/Level', YamahaLayout.maxMatrices);
    final dcas = await _count('${r}DCA/Fader/Level', YamahaLayout.maxDcas);
    final fxSends = inputs == 0 ? 0 : await _count('${r}InCh/ToFx/Level', YamahaLayout.maxFxSends, alongY: true);
    final muteCat = dialect == YamahaDialect.dm3 || dialect == YamahaDialect.dm7 ? 'MuteGrpCtrl' : 'MuteMaster';
    final mutes = await _count('$r$muteCat/On', YamahaLayout.maxMuteGroups);
    final guess = YamahaLayout.forModel(model);
    // Nothing answered at all: fall back to the model's usual layout.
    final layout = inputs == 0 && mixes == 0
        ? guess
        : YamahaLayout(
            inputs: inputs,
            stereoInputs: stereo,
            fxReturns: fx,
            mixes: mixes,
            matrices: mtrx,
            dcas: dcas,
            fxSends: fxSends,
            muteGroups: mutes,
            mixWord: YamahaLayout.mixWordFor(model),
            sceneSlots: guess.sceneSlots,
          );
    map = YamahaMap(dialect: dialect, mixes: layout.mixes, fxSends: layout.fxSends, dcas: layout.dcas);
    return layout;
  }

  /// Registers app addresses up front, so changes made on the console
  /// (NOTIFY) are understood even for controls the app hasn't asked about.
  void learn(Iterable<String> addrs) {
    for (final a in addrs) {
      final dca = map.dcaMaskParams(a);
      if (dca.isNotEmpty) {
        for (final p in dca) {
          _back[p.key] = (a, YamahaKind.dcaBit);
        }
        continue;
      }
      final p = map.toYamaha(a);
      if (p != null) _back.putIfAbsent(p.key, () => (a, p.kind));
    }
  }

  /// Every app address a Yamaha profile can show.
  static Iterable<String> profileAddresses(MixerProfile p) sync* {
    yield* p.queryAddresses;
    yield* p.snapshotAddresses();
    for (final s in p.allStrips) {
      yield* p.detailAddresses(s);
    }
    for (final s in p.inputs) {
      if (s.type == StripType.channel) {
        yield '/headamp/${two(s.index)}/gain';
        yield '/headamp/${two(s.index)}/phantom';
      }
    }
  }

  /// Sets up the translation without asking the console (tests, demo).
  void useLayout(String model, YamahaLayout l) {
    map = YamahaMap(dialect: yamahaDialectFor(model), mixes: l.mixes, fxSends: l.fxSends, dcas: l.dcas);
  }

  @override
  void close() {
    _closed = true;
    _retry?.cancel();
    _lines?.cancel();
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _out.close();
    _raw.close();
  }
}
