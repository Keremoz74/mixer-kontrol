import 'dart:async';
import 'dart:convert';
import 'dart:io';

import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import 'yamaha_map.dart';

/// Connection to a Yamaha console over its remote control protocol (TCP).
/// Speaks the app's own addresses on the outside (see [YamahaMap]).
///
/// The console pushes "NOTIFY set …" lines for changes made elsewhere, so no
/// subscription is needed. Meters are not read yet. If the TCP connection
/// drops, the link reconnects by itself every few seconds.
class YamahaLink implements MixerLink {
  YamahaLink._(this.host, this.port);

  final String host;
  final int port;
  Socket? _socket;
  StreamSubscription<String>? _lines;
  bool _closed = false;
  Timer? _retry;
  final _out = StreamController<OscMessage>.broadcast();

  /// Raw protocol lines (for probing), before translation.
  final _raw = StreamController<List<String>>.broadcast();

  String? productName;

  static const defaultPort = 49280;

  /// Longest line accepted from the console.
  static const maxLine = 8192;

  static Future<YamahaLink> connect(String host, {int port = defaultPort, Duration timeout = const Duration(seconds: 3)}) async {
    final l = YamahaLink._(host, port);
    await l._open(timeout);
    return l;
  }

  Future<void> _open(Duration timeout) async {
    final s = await Socket.connect(host, port, timeout: timeout);
    s.setOption(SocketOption.tcpNoDelay, true);
    _socket = s;
    _lines = utf8.decoder
        .bind(s)
        .transform(const LineSplitter())
        .listen(_onLine, onError: (_) => _lost(), onDone: _lost, cancelOnError: true);
  }

  void _lost() {
    _lines?.cancel();
    _lines = null;
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    if (_closed) return;
    // keep trying quietly; the app shows "connection lost" meanwhile
    _retry ??= Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_closed || _socket != null) return;
      try {
        await _open(const Duration(seconds: 2));
        _retry?.cancel();
        _retry = null;
      } catch (_) {}
    });
  }

  void _onLine(String line) {
    if (line.length > maxLine) return;
    final t = YamahaMap.tokenize(line.trim());
    if (t.isEmpty) return;
    if (!_raw.isClosed) _raw.add(t);
    // OK get <path> x y value · NOTIFY set <path> x y value · OK set …
    if (t.length >= 6 && (t[0] == 'OK' || t[0] == 'OKm' || t[0] == 'NOTIFY') && (t[1] == 'get' || t[1] == 'set')) {
      final x = int.tryParse(t[3]), y = int.tryParse(t[4]);
      if (x == null || y == null) return;
      final addr = YamahaMap.toApp(t[2], x, y);
      if (addr == null) return;
      final kind = YamahaMap.toYamaha(addr)?.kind;
      if (kind == null) return;
      final v = YamahaMap.decode(kind, t[5]);
      if (v != null && !_out.isClosed) _out.add(OscMessage(addr, [v]));
      return;
    }
    if (t.length >= 4 && t[0] == 'OK' && t[1] == 'devinfo' && t[2] == 'productname') {
      productName = t[3];
    }
  }

  void _write(String line) {
    final s = _socket;
    if (s == null) return;
    try {
      s.write('$line\n');
    } catch (_) {
      _lost();
    }
  }

  @override
  Stream<OscMessage> get messages => _out.stream;

  @override
  void send(OscMessage m) {
    final a = m.address;
    if (a == '/xinfo') {
      // keep-alive: the answer (the STEREO fader) keeps the connection live
      _write('get ${YamahaMap.root}St/Fader/Level 0 0');
      return;
    }
    final p = YamahaMap.toYamaha(a);
    if (p == null) return; // not mapped (yet): ignored
    if (m.args.isEmpty) {
      _write('get ${p.path} ${p.x} ${p.y}');
      return;
    }
    final v = YamahaMap.encode(p.kind, m.args.first);
    if (v != null) _write('set ${p.path} ${p.x} ${p.y} $v');
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------- connect-time questions

  /// Asks the console for its model ("TF5", "DM3"…); null if it won't say.
  Future<String?> askProductName({Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = _raw.stream
        .firstWhere((t) => t.length >= 2 && (t[1] == 'devinfo' || (t[0] == 'ERROR' && t.contains('devinfo'))))
        .timeout(timeout);
    _write('devinfo productname');
    try {
      final t = await reply;
      return t[0] == 'OK' && t.length >= 4 && t[3].trim().isNotEmpty ? t[3].trim() : null;
    } catch (_) {
      return null;
    }
  }

  /// True if channel [x] (0-based) of [cat] exists on this console.
  Future<bool> _exists(String cat, int x) async {
    final path = '${YamahaMap.root}$cat/Fader/Level';
    final reply = _raw.stream
        .firstWhere((t) =>
            (t.length >= 5 && t[0].startsWith('OK') && t[1] == 'get' && t[2] == path && t[3] == '$x') ||
            t[0] == 'ERROR')
        .timeout(const Duration(milliseconds: 600));
    _write('get $path $x 0');
    try {
      final t = await reply;
      return t[0].startsWith('OK');
    } catch (_) {
      return false;
    }
  }

  /// How many of [cat] the console has (0..[max]), by asking for the last
  /// one that answers.
  Future<int> _count(String cat, int max) async {
    if (!await _exists(cat, 0)) return 0;
    var lo = 1, hi = max; // lo exists (count >= lo)
    while (lo < hi) {
      final mid = (lo + hi + 1) ~/ 2;
      if (await _exists(cat, mid - 1)) {
        lo = mid;
      } else {
        hi = mid - 1;
      }
    }
    return lo;
  }

  /// Reads how many channels, mixes and DCAs this console has.
  Future<YamahaLayout> readLayout(String model) async {
    final inputs = await _count('InCh', YamahaLayout.maxInputs);
    final stereo = await _count('StInCh', YamahaLayout.maxStereo);
    final fx = await _count('FxRtnCh', YamahaLayout.maxFxReturns);
    final mixes = await _count('Mix', YamahaLayout.maxMixes);
    final dcas = await _count('DCA', YamahaLayout.maxDcas);
    final guess = YamahaLayout.forModel(model);
    // Nothing answered at all: fall back to the model's usual layout.
    if (inputs == 0 && mixes == 0) return guess;
    return YamahaLayout(
      inputs: inputs,
      stereoInputs: stereo,
      fxReturns: fx,
      mixes: mixes,
      dcas: dcas,
      mixWord: YamahaLayout.mixWordFor(model),
    );
  }

  @override
  void close() {
    _closed = true;
    _retry?.cancel();
    _lines?.cancel();
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _out.close();
    _raw.close();
  }
}
