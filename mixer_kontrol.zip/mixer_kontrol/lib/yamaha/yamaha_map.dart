// Translation between the app's own (X32-style) addresses and Yamaha's
// remote control protocol (text lines over TCP 49280), as used by the TF,
// DM3 / DM7, QL and CL series:
//
//   get MIXER:Current/InCh/Fader/Level 0 0
//   set MIXER:Current/InCh/Fader/Level 0 0 -1000
//   OK get MIXER:Current/InCh/Fader/Level 0 0 -1000
//   NOTIFY set MIXER:Current/InCh/Fader/Level 0 0 -1000     (changed elsewhere)
//
// x / y are 0-based (channel, mix / band / DCA). Units, from the consoles'
// own parameter lists: levels dB x 100 (-32768 = -inf, max +10 dB = 1000),
// EQ frequency Hz x 10, EQ gain dB x 100, Q x 1000, dynamics threshold
// dB x 10, range dB x 100, attack ms, hold / release ms x 1000, ratio x 10.

import 'dart:math' as math;

import '../util/fader_math.dart';
import '../util/param_law.dart';

/// Families of Yamaha consoles whose parameter names / units differ a little.
enum YamahaDialect { tf, dm3, dm7, clql }

YamahaDialect yamahaDialectFor(String model) {
  final m = model.toUpperCase();
  if (m.contains('TF')) return YamahaDialect.tf;
  if (m.contains('DM3')) return YamahaDialect.dm3;
  if (m.contains('DM7')) return YamahaDialect.dm7;
  return YamahaDialect.clql;
}

enum YamahaKind {
  level,
  onOff,
  name,
  color,
  pan,
  freq,
  hpf,
  eqGain,
  q,
  eqTypeLow,
  eqTypeHigh,
  haGain,
  gateThr,
  compThr,
  range,
  attack,
  holdMs,
  releaseMs,
  ratio,
  makeup,
  gateMode,

  /// One bit of an app DCA mask (y = DCA).
  dcaBit,
}

class YamahaParam {
  const YamahaParam(this.path, this.x, this.y, this.kind);

  /// Full path, e.g. MIXER:Current/InCh/Fader/Level.
  final String path;
  final int x;
  final int y;
  final YamahaKind kind;

  String get key => '$path $x $y';
}

class YamahaMap {
  YamahaMap({this.dialect = YamahaDialect.clql, this.mixes = 0, this.fxSends = 0, this.dcas = 0});

  final YamahaDialect dialect;

  /// AUX / MIX buses; app sends above this number go to the FX buses.
  final int mixes;
  final int fxSends;
  final int dcas;

  static const root = 'MIXER:Current/';
  static const levelMin = -13800, levelMax = 1000, levelOff = -32768;

  static const _cats = {'ch': 'InCh', 'auxin': 'StInCh', 'fxrtn': 'FxRtnCh', 'bus': 'Mix', 'mtx': 'Mtrx'};
  static final _strip = RegExp(r'^/(ch|auxin|fxrtn|bus|mtx)/(\d{2})(/.+)$');
  static final _main = RegExp(r'^/main/st(/.+)$');
  static final _dca = RegExp(r'^/dca/(\d{1,2})(/.+)$');
  static final _fxsend = RegExp(r'^/fxsend/(\d{1,2})(/.+)$');
  static final _headamp = RegExp(r'^/headamp/(\d{2})/(gain|phantom)$');
  static final _mute = RegExp(r'^/config/mute/(\d{1,2})$');
  static final _send = RegExp(r'^/mix/(\d{2})/(level|on)$');
  static final _eq = RegExp(r'^/eq/(\d)/(f|g|q|type)$');

  bool get _inputsHaveIoGain => dialect == YamahaDialect.tf || dialect == YamahaDialect.dm3;

  /// The Yamaha parameter behind an app address, or null if the console
  /// has no such control (the app then simply doesn't send it).
  YamahaParam? toYamaha(String addr) {
    if (addr == '/config/solo/level') return const YamahaParam('${root}Monitor/Fader/Level', 0, 0, YamahaKind.level);
    var m = _mute.firstMatch(addr);
    if (m != null) {
      final g = int.parse(m[1]!) - 1;
      final cat = dialect == YamahaDialect.dm3 || dialect == YamahaDialect.dm7 ? 'MuteGrpCtrl' : 'MuteMaster';
      return g < 0 ? null : YamahaParam('$root$cat/On', g, 0, YamahaKind.onOff);
    }
    m = _headamp.firstMatch(addr);
    if (m != null) {
      final x = int.parse(m[1]!) - 1;
      if (x < 0) return null;
      if (m[2] == 'phantom') {
        return _inputsHaveIoGain ? YamahaParam('IO:Current/InCh/48VOn', x, 0, YamahaKind.onOff) : null;
      }
      return _inputsHaveIoGain
          ? YamahaParam('IO:Current/InCh/HAGain', x, 0, YamahaKind.haGain)
          : YamahaParam('${root}InCh/Port/HA/Gain', x, 0, YamahaKind.haGain);
    }
    m = _strip.firstMatch(addr);
    if (m != null) {
      final x = int.parse(m[2]!) - 1;
      return x < 0 ? null : _forStrip(_cats[m[1]]!, x, m[3]!);
    }
    m = _main.firstMatch(addr);
    if (m != null) return _forStrip('St', 0, m[1]!);
    m = _dca.firstMatch(addr);
    if (m != null) {
      final x = int.parse(m[1]!) - 1;
      if (x < 0) return null;
      return switch (m[2]) {
        '/fader' => YamahaParam('${root}DCA/Fader/Level', x, 0, YamahaKind.level),
        '/on' => YamahaParam('${root}DCA/Fader/On', x, 0, YamahaKind.onOff),
        '/config/name' => YamahaParam('${root}DCA/Label/Name', x, 0, YamahaKind.name),
        '/config/color' => YamahaParam('${root}DCA/Label/Color', x, 0, YamahaKind.color),
        '/cue' => YamahaParam('${root}Cue/DCA/On', x, 0, YamahaKind.onOff),
        _ => null,
      };
    }
    m = _fxsend.firstMatch(addr);
    if (m != null) {
      final x = int.parse(m[1]!) - 1;
      if (x < 0) return null;
      return switch (m[2]) {
        '/mix/fader' => YamahaParam('${root}Fx/Fader/Level', x, 0, YamahaKind.level),
        '/mix/on' => YamahaParam('${root}Fx/Fader/On', x, 0, YamahaKind.onOff),
        '/config/name' => YamahaParam('${root}Fx/Label/Name', x, 0, YamahaKind.name),
        '/config/color' => YamahaParam('${root}Fx/Label/Color', x, 0, YamahaKind.color),
        '/cue' => YamahaParam('${root}Cue/Fx/On', x, 0, YamahaKind.onOff),
        _ => null,
      };
    }
    return null;
  }

  static final _fixedEqType = RegExp(r'/eq/[23]/type$');

  /// App values that are fixed on Yamaha consoles (answered by the link
  /// itself): EQ bands 2-3 are always bell filters.
  static Object? constantFor(String addr) => _fixedEqType.hasMatch(addr) ? 2 : null;

  /// Addresses a single DCA mask stands for (one per DCA).
  List<YamahaParam> dcaMaskParams(String addr) {
    final m = _strip.firstMatch(addr);
    final cat = m == null ? (addr == '/main/st/grp/dca' ? 'St' : null) : _cats[m[1]];
    if (cat == null || !(m?[3] == '/grp/dca' || addr == '/main/st/grp/dca')) return const [];
    final x = m == null ? 0 : int.parse(m[2]!) - 1;
    return [for (var d = 0; d < dcas; d++) YamahaParam('$root$cat/DCA/Assign', x, d, YamahaKind.dcaBit)];
  }

  YamahaParam? _forStrip(String cat, int x, String rest) {
    final input = cat == 'InCh' || cat == 'StInCh' || cat == 'FxRtnCh';
    final c = '$root$cat';
    switch (rest) {
      case '/mix/fader':
        return YamahaParam('$c/Fader/Level', x, 0, YamahaKind.level);
      case '/mix/on':
        return YamahaParam('$c/Fader/On', x, 0, YamahaKind.onOff);
      case '/config/name':
        return YamahaParam('$c/Label/Name', x, 0, YamahaKind.name);
      case '/config/color':
        return YamahaParam('$c/Label/Color', x, 0, YamahaKind.color);
      case '/mix/pan':
        return cat == 'St' || cat == 'Mtrx' ? null : YamahaParam('$c/ToSt/Pan', x, 0, YamahaKind.pan);
      case '/mix/st':
        return cat == 'St' || cat == 'Mtrx' ? null : YamahaParam('$c/ToSt/On', x, 0, YamahaKind.onOff);
      case '/cue':
        return YamahaParam('${root}Cue/$cat/On', x, 0, YamahaKind.onOff);
      case '/eq/on':
        return YamahaParam('$c/PEQ/On', x, 0, YamahaKind.onOff);
      case '/preamp/hpon':
        return YamahaParam('$c/HPF/On', x, 0, YamahaKind.onOff);
      case '/preamp/hpf':
        return YamahaParam('$c/HPF/Freq', x, 0, YamahaKind.hpf);
    }
    final eq = _eq.firstMatch(rest);
    if (eq != null) {
      final band = int.parse(eq[1]!);
      if (band < 1 || band > 4) return null;
      return switch (eq[2]) {
        'f' => YamahaParam('$c/PEQ/Band/Freq', x, band - 1, YamahaKind.freq),
        'g' => YamahaParam('$c/PEQ/Band/Gain', x, band - 1, YamahaKind.eqGain),
        'q' => YamahaParam('$c/PEQ/Band/Q', x, band - 1, YamahaKind.q),
        _ => band == 1
            ? YamahaParam('$c/PEQ/LowShelving/On', x, 0, YamahaKind.eqTypeLow)
            : band == 4
                ? YamahaParam('$c/PEQ/HighShelving/On', x, 0, YamahaKind.eqTypeHigh)
                : null, // bands 2-3 are always bell (PEQ)
      };
    }
    // Inputs: Dyna1 = gate, Dyna2 = compressor. Buses: Dyna1 = compressor.
    if (rest.startsWith('/gate/') && (cat == 'InCh' || cat == 'StInCh')) {
      final d = '$c/Dyna1';
      return switch (rest.substring(6)) {
        'on' => YamahaParam('$d/On', x, 0, YamahaKind.onOff),
        'mode' => YamahaParam('$d/Type', x, 0, YamahaKind.gateMode),
        'thr' => YamahaParam('$d/Threshold', x, 0, YamahaKind.gateThr),
        'range' => YamahaParam('$d/Range', x, 0, YamahaKind.range),
        'attack' => YamahaParam('$d/Attack', x, 0, YamahaKind.attack),
        'hold' => YamahaParam('$d/Hold', x, 0, YamahaKind.holdMs),
        'release' => YamahaParam('$d/Decay', x, 0, YamahaKind.releaseMs),
        _ => null,
      };
    }
    if (rest.startsWith('/dyn/') && cat != 'FxRtnCh') {
      final d = '$c/${cat == 'InCh' || cat == 'StInCh' ? 'Dyna2' : 'Dyna1'}';
      return switch (rest.substring(5)) {
        'on' => YamahaParam('$d/On', x, 0, YamahaKind.onOff),
        'thr' => YamahaParam('$d/Threshold', x, 0, YamahaKind.compThr),
        'ratio' => YamahaParam('$d/Ratio', x, 0, YamahaKind.ratio),
        'attack' => YamahaParam('$d/Attack', x, 0, YamahaKind.attack),
        'hold' => YamahaParam('$d/Hold', x, 0, YamahaKind.holdMs),
        'release' => YamahaParam('$d/Release', x, 0, YamahaKind.releaseMs),
        'mgain' => YamahaParam('$d/Gain', x, 0, YamahaKind.makeup),
        _ => null,
      };
    }
    final s = _send.firstMatch(rest);
    if (s != null) {
      final n = int.parse(s[1]!);
      if (n < 1) return null;
      final level = s[2] == 'level';
      final kind = level ? YamahaKind.level : YamahaKind.onOff;
      final leaf = level ? 'Level' : 'On';
      if (input) {
        if (n <= mixes) return YamahaParam('$c/ToMix/$leaf', x, n - 1, kind);
        if (n <= mixes + fxSends) return YamahaParam('$c/ToFx/$leaf', x, n - mixes - 1, kind);
        return null;
      }
      // buses and STEREO feed the matrices
      if (cat == 'Mix' || cat == 'St') return YamahaParam('$c/ToMtrx/$leaf', x, n - 1, kind);
      return null;
    }
    if (rest == '/grp/dca') return null; // see dcaMaskParams
    return null;
  }

  // ---------------------------------------------------------------- values

  static double _num(Object v) => v is num ? v.toDouble() : double.nan;
  static int _clampRound(double v, int lo, int hi) => v.round().clamp(lo, hi);

  /// App value → protocol token (null = can't be sent).
  String? encode(YamahaKind kind, Object v, {int band = 0}) {
    if (kind == YamahaKind.name) return quote(v.toString());
    final f = _num(v);
    if (!f.isFinite) return null;
    final n = f.clamp(0.0, 1.0);
    switch (kind) {
      case YamahaKind.level:
        if (n <= 0) return '$levelOff';
        return _clampRound(faderToDb(n) * 100, levelMin, levelMax).toString();
      case YamahaKind.onOff:
      case YamahaKind.dcaBit:
        return f != 0 ? '1' : '0';
      case YamahaKind.color:
        return quote(colorName(f.toInt()));
      case YamahaKind.pan:
        return _clampRound(panLaw.toReal(n) * 0.63, -63, 63).toString();
      case YamahaKind.freq:
        return _clampRound(freqLaw.toReal(n) * 10, 200, 200000).toString();
      case YamahaKind.hpf:
        return _clampRound(hpfLaw.toReal(n) * 10, 200, 20000).toString();
      case YamahaKind.eqGain:
        return _clampRound(eqGainLaw.toReal(n) * 100, -1800, 1800).toString();
      case YamahaKind.q:
        return _clampRound(qLaw.toReal(n) * 1000, 100, 16000).toString();
      case YamahaKind.eqTypeLow:
        return f.toInt() <= 1 ? '1' : '0'; // low cut / low shelf → shelving
      case YamahaKind.eqTypeHigh:
        return f.toInt() >= 4 ? '1' : '0'; // high shelf / high cut → shelving
      case YamahaKind.haGain:
        final db = headampGainLaw.toReal(n);
        return switch (dialect) {
          YamahaDialect.clql => _clampRound(db * 100, -600, 6600).toString(),
          YamahaDialect.dm3 => _clampRound(db, 0, 64).toString(),
          _ => _clampRound(db, -6, 66).toString(),
        };
      case YamahaKind.gateThr:
        return _clampRound(gateThrLaw.toReal(n) * 10, -720, 0).toString();
      case YamahaKind.compThr:
        return _clampRound(compThrLaw.toReal(n) * 10, -540, 0).toString();
      case YamahaKind.range:
        return _clampRound(-gateRangeLaw.toReal(n) * 100, -7200, 0).toString();
      case YamahaKind.attack:
        return _clampRound(attackLaw.toReal(n), 0, 120).toString();
      case YamahaKind.holdMs:
        return _clampRound(holdLaw.toReal(n) * 1000, 20, 1960000).toString();
      case YamahaKind.releaseMs:
        return _clampRound(releaseLaw.toReal(n) * 1000, 3340, 42700000).toString();
      case YamahaKind.ratio:
        final i = f.toInt().clamp(0, compRatios.length - 1);
        return _clampRound(compRatios[i] * 10, 10, 255).toString();
      case YamahaKind.makeup:
        return _clampRound(makeupLaw.toReal(n) * 10, -200, 400).toString();
      case YamahaKind.gateMode:
        final i = f.toInt();
        final t = i == 4 ? 'Ducking' : (i == 3 ? 'Gate' : 'Expander');
        return quote(dialect == YamahaDialect.dm7 ? t.toUpperCase() : t);
      case YamahaKind.name:
        return null;
    }
  }

  /// Protocol token → app value (null = not understood).
  Object? decode(YamahaKind kind, String token) {
    switch (kind) {
      case YamahaKind.name:
        return token;
      case YamahaKind.color:
        return colorIndex(token);
      case YamahaKind.gateMode:
        final t = token.toUpperCase();
        if (t.startsWith('DUCK')) return 4;
        if (t.startsWith('EXP')) return 0;
        return 3;
      default:
        break;
    }
    final i = int.tryParse(token) ?? (token.toUpperCase() == '-INF' ? levelOff : null);
    if (i == null) return null;
    final v = i.toDouble();
    switch (kind) {
      case YamahaKind.level:
        if (i <= levelOff || i < levelMin) return 0.0;
        return dbToFader(i.clamp(levelMin, levelMax) / 100);
      case YamahaKind.onOff:
      case YamahaKind.dcaBit:
        return i != 0 ? 1 : 0;
      case YamahaKind.pan:
        return panLaw.toNorm(v.clamp(-63, 63) / 0.63);
      case YamahaKind.freq:
        return freqLaw.toNorm(v / 10);
      case YamahaKind.hpf:
        return hpfLaw.toNorm(v / 10);
      case YamahaKind.eqGain:
        return eqGainLaw.toNorm(v / 100);
      case YamahaKind.q:
        return qLaw.toNorm(math.max(v, 1) / 1000);
      case YamahaKind.eqTypeLow:
        return i != 0 ? 1 : 2;
      case YamahaKind.eqTypeHigh:
        return i != 0 ? 4 : 2;
      case YamahaKind.haGain:
        return headampGainLaw.toNorm(dialect == YamahaDialect.clql ? v / 100 : v);
      case YamahaKind.gateThr:
        return gateThrLaw.toNorm(v / 10);
      case YamahaKind.compThr:
        return compThrLaw.toNorm(v / 10);
      case YamahaKind.range:
        return gateRangeLaw.toNorm(i <= levelOff ? 60 : -v / 100);
      case YamahaKind.attack:
        return attackLaw.toNorm(v);
      case YamahaKind.holdMs:
        return holdLaw.toNorm(math.max(v, 1) / 1000);
      case YamahaKind.releaseMs:
        return releaseLaw.toNorm(math.max(v, 1) / 1000);
      case YamahaKind.ratio:
        final r = v / 10;
        var best = 0;
        for (var k = 1; k < compRatios.length; k++) {
          if ((compRatios[k] - r).abs() < (compRatios[best] - r).abs()) best = k;
        }
        return best;
      case YamahaKind.makeup:
        return makeupLaw.toNorm(v / 10);
      default:
        return null;
    }
  }

  // App colours (X32 numbering): 0 off, 1 red, 2 green, 3 yellow, 4 blue,
  // 5 magenta, 6 cyan, 7 white.
  static const _colorOut = ['Off', 'Red', 'Green', 'Yellow', 'Blue', 'Purple', 'SkyBlue', 'Off'];
  static const _colorIn = {
    'off': 0, 'red': 1, 'green': 2, 'yellow': 3, 'orange': 3, 'blue': 4, 'purple': 5, 'magenta': 5,
    'pink': 5, 'skyblue': 6, 'cyan': 6, 'white': 7,
  };

  static String colorName(int index) => _colorOut[(index % 8).clamp(0, 7)];
  static int colorIndex(String name) => _colorIn[name.toLowerCase()] ?? 0;

  static String quote(String s) =>
      '"${s.replaceAll('\\', '').replaceAll('"', "'").replaceAll('\n', ' ').replaceAll('\r', ' ')}"';

  /// Splits a protocol line into tokens; "quoted text" is one token.
  static List<String> tokenize(String line) {
    final out = <String>[];
    final b = StringBuffer();
    var inQuote = false, has = false;
    for (var i = 0; i < line.length; i++) {
      final ch = line[i];
      if (inQuote) {
        if (ch == '\\' && i + 1 < line.length) {
          b.write(line[++i]);
        } else if (ch == '"') {
          inQuote = false;
        } else {
          b.write(ch);
        }
      } else if (ch == '"') {
        inQuote = true;
        has = true;
      } else if (ch == ' ' || ch == '\t') {
        if (has || b.isNotEmpty) out.add(b.toString());
        b.clear();
        has = false;
      } else {
        b.write(ch);
        has = true;
      }
    }
    if (has || b.isNotEmpty) out.add(b.toString());
    return out;
  }

  // ---------------------------------------------------------------- meters

  /// Meter value (one hex byte) → dBFS. DM7 uses a lookup table; the other
  /// series send dB + 126.
  double meterDb(int raw) {
    if (dialect == YamahaDialect.dm7) {
      final db = dm7MeterTable[raw.clamp(0, 255)];
      return db <= -126 ? double.negativeInfinity : math.min(db, 20);
    }
    if (raw <= 0) return double.negativeInfinity;
    return (raw - 126).toDouble();
  }

  /// DM7 meter steps (from the Bitfocus Companion Yamaha RCP module, MIT).
  static const dm7MeterTable = <double>[
    -190, -175, -160, -145, -130, -120, -110, -100, -95, -90, -85, -80, -78, -76, -74, -72,
    -70, -68, -66, -64, -62, -60, -59, -58, -57, -56, -55, -54, -53, -52, -51, -50,
    -49, -48, -47, -46, -45, -44.5, -44, -43.5, -43, -42.5, -42, -41.5, -41, -40.5, -40, -39.5,
    -39, -38.5, -38, -37.5, -37, -36.5, -36, -35.5, -35, -34.5, -34, -33.5, -33, -32.5, -32, -31.5,
    -31, -30.5, -30, -29.8, -29.6, -29.4, -29.2, -29, -28.8, -28.6, -28.4, -28.2, -28, -27.8, -27.6, -27.4,
    -27.2, -27, -26.8, -26.6, -26.4, -26.2, -26, -25.8, -25.6, -25.4, -25.2, -25, -24.8, -24.6, -24.4, -24.2,
    -24, -23.8, -23.6, -23.4, -23.2, -23, -22.8, -22.6, -22.4, -22.2, -22, -21.8, -21.6, -21.4, -21.2, -21,
    -20.8, -20.6, -20.4, -20.2, -20, -19.8, -19.6, -19.4, -19.2, -19, -18.8, -18.6, -18.4, -18.2, -18, -17.8,
    -17.6, -17.4, -17.2, -17, -16.8, -16.6, -16.4, -16.2, -16, -15.8, -15.6, -15.4, -15.2, -15, -14.8, -14.6,
    -14.4, -14.2, -14, -13.8, -13.6, -13.4, -13.2, -13, -12.8, -12.6, -12.4, -12.2, -12, -11.8, -11.6, -11.4,
    -11.2, -11, -10.8, -10.6, -10.4, -10.2, -10, -9.8, -9.6, -9.4, -9.2, -9, -8.8, -8.6, -8.4, -8.2,
    -8, -7.8, -7.6, -7.4, -7.2, -7, -6.8, -6.6, -6.4, -6.2, -6, -5.8, -5.6, -5.4, -5.2, -5,
    -4.8, -4.6, -4.4, -4.2, -4, -3.8, -3.6, -3.4, -3.2, -3, -2.8, -2.6, -2.4, -2.2, -2, -1.8,
    -1.6, -1.4, -1.2, -1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1, 1.2, 1.4,
    1.6, 1.8, 2, 2.2, 2.4, 2.6, 2.8, 3, 3.5, 4, 4.5, 5, 5.5, 6, 7, 8,
    9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 1000,
  ];
}
