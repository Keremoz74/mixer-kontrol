// Translation between the app's own (X32-style) addresses and Yamaha's
// remote control protocol (text lines over TCP 49280), as used by the TF,
// DM3 / DM7, QL and CL series:
//
//   get MIXER:Current/InCh/Fader/Level 0 0
//   set MIXER:Current/InCh/Fader/Level 0 0 -1000
//   OK get MIXER:Current/InCh/Fader/Level 0 0 -1000
//   NOTIFY set MIXER:Current/InCh/Fader/Level 0 0 -1000     (changed elsewhere)
//
// x / y are 0-based (channel, mix). Levels are dB x 100 (-32768 = -inf,
// max +10.00 dB = 1000), on/off 0/1, names and colours quoted text.
//
// Experimental: written from public documentation, not yet confirmed on
// every model.

import '../util/fader_math.dart';

enum YamahaKind { level, onOff, name, color }

class YamahaParam {
  const YamahaParam(this.path, this.x, this.y, this.kind);

  /// Full path, e.g. MIXER:Current/InCh/Fader/Level.
  final String path;
  final int x;
  final int y;
  final YamahaKind kind;

  String get key => '$path $x $y';
}

class YamahaMap {
  static const root = 'MIXER:Current/';
  static const levelMin = -13800, levelMax = 1000, levelOff = -32768;

  /// App strip prefix → Yamaha channel kind.
  static const _cats = {'ch': 'InCh', 'auxin': 'StInCh', 'fxrtn': 'FxRtnCh', 'bus': 'Mix'};
  static final _catsBack = {for (final e in _cats.entries) e.value: e.key};

  static final _stripFader = RegExp(r'^/(ch|auxin|fxrtn|bus)/(\d{2})/mix/(fader|on)$');
  static final _stripLabel = RegExp(r'^/(ch|auxin|fxrtn|bus)/(\d{2})/config/(name|color)$');
  static final _send = RegExp(r'^/(ch|auxin|fxrtn)/(\d{2})/mix/(\d{2})/(level|on)$');
  static final _main = RegExp(r'^/main/st/(mix/fader|mix/on|config/name|config/color)$');
  static final _dca = RegExp(r'^/dca/(\d{1,2})/(fader|on|config/name|config/color)$');

  static String _two(int n) => n.toString().padLeft(2, '0');

  /// The Yamaha parameter behind an app address, or null if not mapped.
  static YamahaParam? toYamaha(String addr) {
    var m = _stripFader.firstMatch(addr);
    if (m != null) {
      final level = m[3] == 'fader';
      return YamahaParam('$root${_cats[m[1]]}/Fader/${level ? 'Level' : 'On'}', int.parse(m[2]!) - 1, 0,
          level ? YamahaKind.level : YamahaKind.onOff);
    }
    m = _stripLabel.firstMatch(addr);
    if (m != null) {
      final name = m[3] == 'name';
      return YamahaParam('$root${_cats[m[1]]}/Label/${name ? 'Name' : 'Color'}', int.parse(m[2]!) - 1, 0,
          name ? YamahaKind.name : YamahaKind.color);
    }
    m = _send.firstMatch(addr);
    if (m != null) {
      final level = m[4] == 'level';
      return YamahaParam('$root${_cats[m[1]]}/ToMix/${level ? 'Level' : 'On'}', int.parse(m[2]!) - 1,
          int.parse(m[3]!) - 1, level ? YamahaKind.level : YamahaKind.onOff);
    }
    m = _main.firstMatch(addr);
    if (m != null) {
      return switch (m[1]) {
        'mix/fader' => const YamahaParam('${root}St/Fader/Level', 0, 0, YamahaKind.level),
        'mix/on' => const YamahaParam('${root}St/Fader/On', 0, 0, YamahaKind.onOff),
        'config/name' => const YamahaParam('${root}St/Label/Name', 0, 0, YamahaKind.name),
        _ => const YamahaParam('${root}St/Label/Color', 0, 0, YamahaKind.color),
      };
    }
    m = _dca.firstMatch(addr);
    if (m != null) {
      final x = int.parse(m[1]!) - 1;
      return switch (m[2]) {
        'fader' => YamahaParam('${root}DCA/Fader/Level', x, 0, YamahaKind.level),
        'on' => YamahaParam('${root}DCA/Fader/On', x, 0, YamahaKind.onOff),
        'config/name' => YamahaParam('${root}DCA/Label/Name', x, 0, YamahaKind.name),
        _ => YamahaParam('${root}DCA/Label/Color', x, 0, YamahaKind.color),
      };
    }
    return null;
  }

  /// The app address for a Yamaha parameter, or null if the app doesn't use it.
  static String? toApp(String path, int x, int y) {
    if (!path.startsWith(root) || x < 0 || y < 0 || x > 255 || y > 255) return null;
    final parts = path.substring(root.length).split('/');
    if (parts.length != 3) return null;
    final (cat, group, leaf) = (parts[0], parts[1], parts[2]);
    if (cat == 'St') {
      if (x != 0) return null;
      return switch ('$group/$leaf') {
        'Fader/Level' => '/main/st/mix/fader',
        'Fader/On' => '/main/st/mix/on',
        'Label/Name' => '/main/st/config/name',
        'Label/Color' => '/main/st/config/color',
        _ => null,
      };
    }
    if (cat == 'DCA') {
      final d = '/dca/${x + 1}';
      return switch ('$group/$leaf') {
        'Fader/Level' => '$d/fader',
        'Fader/On' => '$d/on',
        'Label/Name' => '$d/config/name',
        'Label/Color' => '$d/config/color',
        _ => null,
      };
    }
    final app = _catsBack[cat];
    if (app == null) return null;
    final p = '/$app/${_two(x + 1)}';
    switch ('$group/$leaf') {
      case 'Fader/Level':
        return '$p/mix/fader';
      case 'Fader/On':
        return '$p/mix/on';
      case 'Label/Name':
        return '$p/config/name';
      case 'Label/Color':
        return '$p/config/color';
      case 'ToMix/Level':
        return app == 'bus' ? null : '$p/mix/${_two(y + 1)}/level';
      case 'ToMix/On':
        return app == 'bus' ? null : '$p/mix/${_two(y + 1)}/on';
    }
    return null;
  }

  // ---------------------------------------------------------------- values

  /// App value → protocol token (null = can't be sent).
  static String? encode(YamahaKind kind, Object v) {
    switch (kind) {
      case YamahaKind.level:
        if (v is! num) return null;
        final f = v.toDouble();
        if (!f.isFinite) return null;
        if (f <= 0) return '$levelOff';
        return (faderToDb(f.clamp(0.0, 1.0)) * 100).round().clamp(levelMin, levelMax).toString();
      case YamahaKind.onOff:
        if (v is! num) return null;
        return v != 0 ? '1' : '0';
      case YamahaKind.name:
        return quote(v.toString());
      case YamahaKind.color:
        if (v is! num) return null;
        return quote(colorName(v.toInt()));
    }
  }

  /// Protocol token → app value (null = not understood).
  static Object? decode(YamahaKind kind, String token) {
    switch (kind) {
      case YamahaKind.level:
        final n = int.tryParse(token);
        if (n == null) return null;
        if (n <= levelOff || n < levelMin) return 0.0;
        return dbToFader(n.clamp(levelMin, levelMax) / 100);
      case YamahaKind.onOff:
        final n = int.tryParse(token);
        return n == null ? null : (n != 0 ? 1 : 0);
      case YamahaKind.name:
        return token;
      case YamahaKind.color:
        return colorIndex(token);
    }
  }

  // App colours (X32 numbering): 0 off, 1 red, 2 green, 3 yellow, 4 blue,
  // 5 magenta, 6 cyan, 7 white.
  static const _colorOut = ['Off', 'Red', 'Green', 'Yellow', 'Blue', 'Purple', 'SkyBlue', 'Off'];
  static const _colorIn = {
    'off': 0, 'red': 1, 'green': 2, 'yellow': 3, 'orange': 3, 'blue': 4, 'purple': 5, 'magenta': 5,
    'pink': 5, 'skyblue': 6, 'cyan': 6, 'white': 7,
  };

  static String colorName(int index) => _colorOut[(index % 8).clamp(0, 7)];
  static int colorIndex(String name) => _colorIn[name.toLowerCase()] ?? 0;

  static String quote(String s) =>
      '"${s.replaceAll('\\', '').replaceAll('"', "'").replaceAll('\n', ' ').replaceAll('\r', ' ')}"';

  /// Splits a protocol line into tokens; "quoted text" is one token.
  static List<String> tokenize(String line) {
    final out = <String>[];
    final b = StringBuffer();
    var inQuote = false, has = false;
    for (var i = 0; i < line.length; i++) {
      final ch = line[i];
      if (inQuote) {
        if (ch == '\\' && i + 1 < line.length) {
          b.write(line[++i]);
        } else if (ch == '"') {
          inQuote = false;
        } else {
          b.write(ch);
        }
      } else if (ch == '"') {
        inQuote = true;
        has = true;
      } else if (ch == ' ' || ch == '\t') {
        if (has || b.isNotEmpty) out.add(b.toString());
        b.clear();
        has = false;
      } else {
        b.write(ch);
        has = true;
      }
    }
    if (has || b.isNotEmpty) out.add(b.toString());
    return out;
  }
}
