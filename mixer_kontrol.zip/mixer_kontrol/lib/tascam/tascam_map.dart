// Translation between the app's own (X32-style) addresses and the TASCAM
// Sonicview 16 / 24 Ember+ tree, from TEAC's "Sonicview Ember+ Tree
// Structure Specification" rev 1.1.0. Parameters are named by their
// identifier path (sonicview/channels/channel_1/fader); the link resolves
// those to Ember+ numbers by browsing the tree.
//
// App → Sonicview: /ch/NN → channel_N (1-40), /auxin/NN → channel_stin_N
// (1-2), /fxrtn/NN → channel_fxrtn_N (1-4), /bus/NN → channel_mix_N (1-22),
// /main/st → channel_main_lr, /dca/N → channel_dca_N (1-8),
// /fxsend/N → fx/fx_N (1-4), /config/mute/N → channel_mutegroup_N (1-8).

import 'dart:math' as math;

import '../util/fader_math.dart';
import '../util/param_law.dart';
import 'tascam_tables.dart';

enum TascamKind {
  fader,
  muteInv,
  onOff,
  name,
  pan,
  eqFreq,
  eqGain,
  eqQ,
  eqTypeLow,
  eqTypeHigh,
  hpf,
  trim,
  haGain,
  gateMode,
  gateThr,
  gateRange,
  attackMs,
  gateHold,
  gateDecay,
  compMode,
  compThr,
  compRatio,
  compAttack,
  compRelease,
  compGain,

  /// One bit of an app DCA / mute group mask (bit = [TascamParam.bit]).
  maskBit,
  sceneName,
  sceneEmpty,
}

class TascamParam {
  const TascamParam(this.path, this.kind, {this.bit = 0});

  /// Identifier path below the root, e.g. sonicview/channels/channel_1/fader.
  final String path;
  final TascamKind kind;
  final int bit;
}

class TascamLayout {
  const TascamLayout({this.analogInputs = 24});
  static const channels = 40, stereoIns = 2, fxReturns = 4, mixes = 22, fxSends = 4, dcas = 8, muteGroups = 8;
  static const snapshots = 128;
  final int analogInputs;

  static const models = ['Sonicview 16', 'Sonicview 24'];

  factory TascamLayout.forModel(String model) =>
      TascamLayout(analogInputs: model.contains('16') ? 16 : 24);
}

class TascamMap {
  const TascamMap({this.layout = const TascamLayout()});
  final TascamLayout layout;

  static const root = 'sonicview';
  static const ch = '$root/channels';

  static final _strip = RegExp(r'^/(ch|auxin|fxrtn|bus)/(\d{2})(/.+)$');
  static final _main = RegExp(r'^/main/st(/.+)$');
  static final _dca = RegExp(r'^/dca/(\d{1,2})(/.+)$');
  static final _fxsend = RegExp(r'^/fxsend/(\d)(/.+)$');
  static final _headamp = RegExp(r'^/headamp/(\d{2})/(gain|phantom)$');
  static final _mute = RegExp(r'^/config/mute/(\d{1,2})$');
  static final _send = RegExp(r'^/mix/(\d{2})/(level|on)$');
  static final _eq = RegExp(r'^/eq/(\d)/(f|g|q|type)$');
  static final _scene = RegExp(r'^/-snap/(\d{3})/name$');

  /// Module node and the name it has in send parameter identifiers.
  static (String, String)? _module(String cat, int n) => switch (cat) {
        'ch' when n >= 1 && n <= TascamLayout.channels => ('channel_$n', 'channel_$n'),
        'auxin' when n >= 1 && n <= TascamLayout.stereoIns => ('channel_stin_$n', 'channel_stin_$n'),
        'fxrtn' when n >= 1 && n <= TascamLayout.fxReturns => ('channel_fxrtn_$n', 'bus_fx_$n'),
        'bus' when n >= 1 && n <= TascamLayout.mixes => ('channel_mix_$n', 'bus_mix_$n'),
        _ => null,
      };

  /// The Sonicview parameter(s) behind an app address. Several = one per bit
  /// of a mask (DCA / mute group membership) or name + "empty" of a scene.
  List<TascamParam> toTascam(String addr) {
    var m = _scene.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > TascamLayout.snapshots) return const [];
      return [
        TascamParam('$root/snapshots/snapshot_$n/name', TascamKind.sceneName),
        TascamParam('$root/snapshots/snapshot_$n/empty', TascamKind.sceneEmpty),
      ];
    }
    final one = _single(addr);
    if (one != null) return [one];
    m = _strip.firstMatch(addr);
    if (m != null && (m[3] == '/grp/dca' || m[3] == '/grp/mute')) {
      final mod = _module(m[1]!, int.parse(m[2]!));
      if (mod == null || m[1] == 'bus') return const [];
      final dca = m[3] == '/grp/dca';
      final count = dca ? TascamLayout.dcas : TascamLayout.muteGroups;
      return [
        for (var i = 1; i <= count; i++)
          TascamParam('$ch/${mod.$1}/${dca ? 'dca${i}_assgin' : 'mutegroup${i}_assign'}', TascamKind.maskBit, bit: i - 1),
      ];
    }
    return const [];
  }

  TascamParam? _single(String addr) {
    var m = _mute.firstMatch(addr);
    if (m != null) {
      final g = int.parse(m[1]!);
      return g < 1 || g > TascamLayout.muteGroups ? null : TascamParam('$ch/channel_mutegroup_$g/mute', TascamKind.onOff);
    }
    m = _headamp.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > layout.analogInputs) return null;
      return m[2] == 'gain'
          ? TascamParam('$root/sources/analog_$n/analog_gain', TascamKind.haGain)
          : TascamParam('$root/sources/analog_$n/phantom', TascamKind.onOff);
    }
    m = _dca.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > TascamLayout.dcas) return null;
      final d = '$ch/channel_dca_$n';
      return switch (m[2]) {
        '/fader' => TascamParam('$d/fader', TascamKind.fader),
        '/on' => TascamParam('$d/mute', TascamKind.muteInv),
        '/config/name' => TascamParam('$d/user_module_label', TascamKind.name),
        '/cue' => TascamParam('$d/solo', TascamKind.onOff),
        _ => null,
      };
    }
    m = _fxsend.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > TascamLayout.fxSends) return null;
      final f = '$root/fx/fx_$n';
      return switch (m[2]) {
        '/mix/fader' => TascamParam('$f/fx_input_level', TascamKind.fader),
        '/mix/on' => TascamParam('$f/fx_send_mute', TascamKind.muteInv),
        _ => null,
      };
    }
    m = _main.firstMatch(addr);
    if (m != null) return _forStrip('main', 'channel_main_lr', 'channel_main_lr', m[1]!);
    m = _strip.firstMatch(addr);
    if (m != null) {
      final mod = _module(m[1]!, int.parse(m[2]!));
      if (mod == null) return null;
      return _forStrip(m[1]!, mod.$1, mod.$2, m[3]!);
    }
    return null;
  }

  TascamParam? _forStrip(String cat, String node, String sendName, String rest) {
    final p = '$ch/$node';
    final input = cat == 'ch' || cat == 'auxin' || cat == 'fxrtn';
    switch (rest) {
      case '/mix/fader':
        return TascamParam('$p/fader', TascamKind.fader);
      case '/mix/on':
        return TascamParam('$p/mute', TascamKind.muteInv);
      case '/config/name':
        return TascamParam('$p/user_module_label', TascamKind.name);
      case '/mix/pan':
        return cat == 'main' ? null : TascamParam('$p/pan_bal', TascamKind.pan);
      case '/cue':
        return TascamParam('$p/solo', TascamKind.onOff);
      case '/mix/st':
        return cat == 'main' ? null : TascamParam('$root/send/bus_main_lr/send_sw/send_sw_$sendName', TascamKind.onOff);
      case '/eq/on':
        return TascamParam('$p/eq/eq_sw', TascamKind.onOff);
      case '/preamp/hpon':
        return cat == 'ch' || cat == 'auxin' ? TascamParam('$p/eq/hpf/hpf_sw', TascamKind.onOff) : null;
      case '/preamp/hpf':
        return cat == 'ch' || cat == 'auxin' ? TascamParam('$p/eq/hpf/hpf_freq', TascamKind.hpf) : null;
      case '/preamp/invert':
        return cat == 'ch' ? TascamParam('$p/phase', TascamKind.onOff) : null;
      case '/preamp/trim':
        return cat == 'ch' ? TascamParam('$p/d.trim', TascamKind.trim) : null;
    }
    final eq = _eq.firstMatch(rest);
    if (eq != null) {
      final band = int.parse(eq[1]!);
      if (band < 1 || band > 4) return null;
      final b = '$p/eq/${const ['lo_band', 'lm_band', 'hm_band', 'hi_band'][band - 1]}';
      return switch (eq[2]) {
        'f' => TascamParam('$b/eq_band_freq', TascamKind.eqFreq),
        'g' => TascamParam('$b/eq_band_gain', TascamKind.eqGain),
        'q' => TascamParam('$b/eq_band_q', TascamKind.eqQ),
        _ => band == 1
            ? TascamParam('$b/eq_lo_band_type', TascamKind.eqTypeLow)
            : band == 4
                ? TascamParam('$b/eq_hi_band_type', TascamKind.eqTypeHigh)
                : null,
      };
    }
    if (rest.startsWith('/gate/')) {
      if (cat != 'ch') return null;
      final d = '$p/dynamics_1';
      return switch (rest.substring(6)) {
        'on' => TascamParam('$d/dyn1_sw', TascamKind.onOff),
        'mode' => TascamParam('$d/dyn1_type', TascamKind.gateMode),
        'thr' => TascamParam('$d/gate/dyn1_gate_threshold', TascamKind.gateThr),
        'range' => TascamParam('$d/gate/dyn1_gate_range', TascamKind.gateRange),
        'attack' => TascamParam('$d/gate/dyn1_gate_attack', TascamKind.attackMs),
        'hold' => TascamParam('$d/gate/dyn1_gate_hold', TascamKind.gateHold),
        'release' => TascamParam('$d/gate/dyn1_gate_decay', TascamKind.gateDecay),
        _ => null,
      };
    }
    if (rest.startsWith('/dyn/')) {
      if (cat == 'auxin' || cat == 'fxrtn') return null;
      final d = '$p/dynamics_2';
      return switch (rest.substring(5)) {
        'on' => TascamParam('$d/dyn2_sw', TascamKind.onOff),
        'mode' => TascamParam('$d/dyn2_type', TascamKind.compMode),
        'thr' => TascamParam('$d/comp/dyn2_comp_threshold', TascamKind.compThr),
        'ratio' => TascamParam('$d/comp/dyn2_comp_ratio', TascamKind.compRatio),
        'attack' => TascamParam('$d/comp/dyn2_comp_attack', TascamKind.compAttack),
        'release' => TascamParam('$d/comp/dyn2_comp_release', TascamKind.compRelease),
        'mgain' => TascamParam('$d/comp/dyn2_comp_gain', TascamKind.compGain),
        'auto' => TascamParam('$d/comp/dyn2_comp_automake', TascamKind.onOff),
        _ => null,
      };
    }
    final s = _send.firstMatch(rest);
    if (s != null && input) {
      final k = int.parse(s[1]!);
      final level = s[2] == 'level';
      final kind = level ? TascamKind.fader : TascamKind.onOff;
      final leaf = level ? 'send_lvl' : 'send_sw';
      if (k >= 1 && k <= TascamLayout.mixes) {
        return TascamParam('$root/send/bus_mix_$k/$leaf/${leaf}_mix${k}_$sendName', kind);
      }
      final f = k - TascamLayout.mixes;
      if (f >= 1 && f <= TascamLayout.fxSends) {
        return TascamParam('$root/send/bus_fx_$f/$leaf/${leaf}_fx${f}_$sendName', kind);
      }
    }
    return null;
  }

  static final _fixedEqType = RegExp(r'/eq/[23]/type$');
  static final _color = RegExp(r'/config/color$');
  static final _fxName = RegExp(r'^/fxsend/\d/config/name$');
  static final _fxCue = RegExp(r'^/fxsend/\d/cue$');

  /// App values the console doesn't have (answered by the link itself):
  /// mid EQ bands are always bells, strips have no colour over Ember+, the
  /// FX buses have no name or solo there.
  static Object? constantFor(String addr) {
    if (_fixedEqType.hasMatch(addr)) return 2;
    if (_color.hasMatch(addr)) return 0;
    if (_fxName.hasMatch(addr)) return '';
    if (_fxCue.hasMatch(addr)) return 0;
    return null;
  }

  // ---------------------------------------------------------------- values

  static int _nearest(List<double> table, double v) {
    var best = 0;
    for (var i = 1; i < table.length; i++) {
      if ((table[i] - v).abs() < (table[best] - v).abs()) best = i;
    }
    return best;
  }

  static int _nearestLog(List<double> table, double v) {
    if (v <= 0) return 0;
    var best = 0;
    for (var i = 1; i < table.length; i++) {
      if ((_ln(table[i]) - _ln(v)).abs() < (_ln(table[best]) - _ln(v)).abs()) best = i;
    }
    return best;
  }

  static double _ln(double x) => x <= 0 ? -1e9 : math.log(x);

  /// Fader index (0-1023) for an app fader position.
  static int faderIndex(double norm) {
    if (norm <= 0) return 0;
    final db = faderToDb(norm);
    final t = TascamTables.faderDb;
    var best = 11; // first finite step
    for (var i = 11; i < t.length; i++) {
      if ((t[i] - db).abs() < (t[best] - db).abs()) best = i;
    }
    // several indexes share a value near 0 dB: prefer the documented 0 dB = 816
    if (t[best] == 0 && db.abs() < 0.025) return 816;
    return best;
  }

  static double faderNorm(int index) {
    final t = TascamTables.faderDb;
    final db = t[index.clamp(0, t.length - 1)];
    if (db <= -999) return 0.0;
    return dbToFader(db.clamp(-90, 10).toDouble());
  }

  static const _lowTypes = ['bell', 'lo_shelf'];
  static const _highTypes = ['bell', 'hi_shelf', 'lpf'];

  /// App value → Ember+ value (int / bool / String); null = can't be sent.
  /// [enumeration] = the parameter's enum names, when the console gave them.
  Object? encode(TascamKind kind, Object v, {List<String>? enumeration}) {
    if (kind == TascamKind.name) return v.toString().replaceAll(RegExp(r'[\x00-\x1f]'), ' ');
    if (v is! num || !v.isFinite) return null;
    final f = v.toDouble();
    final n = f.clamp(0.0, 1.0);
    int pick(List<String> fallback, String name) {
      final names = enumeration ?? fallback;
      final i = names.indexWhere((e) => e.trim().toLowerCase() == name);
      return i < 0 ? 0 : i;
    }

    switch (kind) {
      case TascamKind.fader:
        return faderIndex(n);
      case TascamKind.muteInv:
        return f == 0;
      case TascamKind.onOff:
      case TascamKind.maskBit:
        return f != 0;
      case TascamKind.pan:
        return (panLaw.toReal(n) + 100).round().clamp(0, 200);
      case TascamKind.eqFreq:
        return _nearestLog(TascamTables.eqFreq, freqLaw.toReal(n));
      case TascamKind.eqGain:
        return (eqGainLaw.toReal(n) * 10).round().clamp(-180, 180);
      case TascamKind.eqQ:
        return _nearestLog(TascamTables.eqQ, qLaw.toReal(n));
      case TascamKind.eqTypeLow:
        return pick(_lowTypes, f.toInt() <= 1 ? 'lo_shelf' : 'bell');
      case TascamKind.eqTypeHigh:
        return pick(_highTypes, f.toInt() >= 5 ? 'lpf' : (f.toInt() == 4 ? 'hi_shelf' : 'bell'));
      case TascamKind.hpf:
        return _nearestLog(TascamTables.hpfFreq, hpfLaw.toReal(n));
      case TascamKind.trim:
        return _nearest(TascamTables.trimDb, trimLaw.toReal(n));
      case TascamKind.haGain:
        return headampGainLaw.toReal(n).round().clamp(12, 66);
      case TascamKind.gateMode:
        return pick(const ['gate', 'exp', 'de-esser'], f.toInt() <= 2 ? 'exp' : 'gate');
      case TascamKind.gateThr:
        return (gateThrLaw.toReal(n) + 80).round().clamp(0, 80);
      case TascamKind.gateRange:
        return (60 - gateRangeLaw.toReal(n)).round().clamp(0, 60);
      case TascamKind.attackMs:
        return attackLaw.toReal(n).round().clamp(0, 125);
      case TascamKind.gateHold:
        return (holdLaw.toReal(n) / 10).round().clamp(0, 99);
      case TascamKind.gateDecay:
        return _nearestLog(TascamTables.gateDecayMs, releaseLaw.toReal(n));
      case TascamKind.compMode:
        return pick(const ['comp', 'ducker'], 'comp');
      case TascamKind.compThr:
        return (compThrLaw.toReal(n) + 49).round().clamp(0, 49);
      case TascamKind.compRatio:
        return _nearestLog(TascamTables.compRatio, compRatios[f.toInt().clamp(0, compRatios.length - 1)]);
      case TascamKind.compAttack:
        return _nearestLog(TascamTables.compAttackMs, attackLaw.toReal(n).clamp(0.02, 125).toDouble());
      case TascamKind.compRelease:
        return _nearestLog(TascamTables.compReleaseMs, releaseLaw.toReal(n));
      case TascamKind.compGain:
        return makeupLaw.toReal(n).round().clamp(0, 20);
      case TascamKind.name:
      case TascamKind.sceneName:
      case TascamKind.sceneEmpty:
        return null;
    }
  }

  /// Ember+ value → app value (null = not understood).
  Object? decode(TascamKind kind, Object? v, {List<String>? enumeration}) {
    if (v == null) return null;
    if (kind == TascamKind.name || kind == TascamKind.sceneName) return v is String ? v : null;
    final b = v is bool ? v : (v is num ? v != 0 : null);
    final i = v is int ? v : (v is double ? v.round() : (v is bool ? (v ? 1 : 0) : null));
    String? named() {
      if (v is String) return v.toLowerCase();
      final names = enumeration;
      if (names == null || i == null || i < 0 || i >= names.length) return null;
      return names[i].trim().toLowerCase();
    }

    switch (kind) {
      case TascamKind.muteInv:
        return b == null ? null : (b ? 0 : 1);
      case TascamKind.onOff:
      case TascamKind.maskBit:
      case TascamKind.sceneEmpty:
        return b == null ? null : (b ? 1 : 0);
      case TascamKind.eqTypeLow:
        final s = named() ?? (i == 1 ? 'lo_shelf' : 'bell');
        return s.contains('shelf') ? 1 : 2;
      case TascamKind.eqTypeHigh:
        final s = named() ?? (i == 1 ? 'hi_shelf' : (i == 2 ? 'lpf' : 'bell'));
        return s.contains('lpf') ? 5 : (s.contains('shelf') ? 4 : 2);
      case TascamKind.gateMode:
        final s = named() ?? (i == 1 ? 'exp' : 'gate');
        return s.startsWith('exp') ? 0 : 3;
      case TascamKind.compMode:
        return 0;
      default:
        break;
    }
    if (i == null) return null;
    switch (kind) {
      case TascamKind.fader:
        return faderNorm(i);
      case TascamKind.pan:
        return panLaw.toNorm(i.clamp(0, 200) - 100.0);
      case TascamKind.eqFreq:
        return freqLaw.toNorm(TascamTables.eqFreq[i.clamp(0, TascamTables.eqFreq.length - 1)]);
      case TascamKind.eqGain:
        return eqGainLaw.toNorm(i.clamp(-180, 180) / 10);
      case TascamKind.eqQ:
        return qLaw.toNorm(TascamTables.eqQ[i.clamp(0, TascamTables.eqQ.length - 1)].clamp(0.3, 10).toDouble());
      case TascamKind.hpf:
        return hpfLaw.toNorm(TascamTables.hpfFreq[i.clamp(0, TascamTables.hpfFreq.length - 1)].clamp(20, 400).toDouble());
      case TascamKind.trim:
        return trimLaw.toNorm(TascamTables.trimDb[i.clamp(0, TascamTables.trimDb.length - 1)].clamp(-18, 18).toDouble());
      case TascamKind.haGain:
        return headampGainLaw.toNorm(i.clamp(12, 66).toDouble());
      case TascamKind.gateThr:
        return gateThrLaw.toNorm(i.clamp(0, 80) - 80.0);
      case TascamKind.gateRange:
        return gateRangeLaw.toNorm((60 - i.clamp(0, 60)).clamp(3, 60).toDouble());
      case TascamKind.attackMs:
        return attackLaw.toNorm(i.clamp(0, 125).toDouble());
      case TascamKind.gateHold:
        return holdLaw.toNorm((i.clamp(0, 99) * 10).clamp(0.02, 2000).toDouble());
      case TascamKind.gateDecay:
        return releaseLaw.toNorm(TascamTables.gateDecayMs[i.clamp(0, 99)].clamp(5, 4000).toDouble());
      case TascamKind.compThr:
        return compThrLaw.toNorm(i.clamp(0, 49) - 49.0);
      case TascamKind.compRatio:
        final r = TascamTables.compRatio[i.clamp(0, TascamTables.compRatio.length - 1)];
        var best = 0;
        for (var k = 1; k < compRatios.length; k++) {
          if ((_ln(compRatios[k]) - _ln(r)).abs() < (_ln(compRatios[best]) - _ln(r)).abs()) best = k;
        }
        return best;
      case TascamKind.compAttack:
        return attackLaw.toNorm(TascamTables.compAttackMs[i.clamp(0, TascamTables.compAttackMs.length - 1)]);
      case TascamKind.compRelease:
        return releaseLaw.toNorm(TascamTables.compReleaseMs[i.clamp(0, 99)].clamp(5, 4000).toDouble());
      case TascamKind.compGain:
        return makeupLaw.toNorm(i.clamp(0, 20).toDouble());
      default:
        return null;
    }
  }

  // ---------------------------------------------------------------- meters
  //
  // UDP meter pages (TEAC "Meter data protocol" v1.00): header "SV_METER",
  // then tag / size / payload blocks of 16-bit little-endian values,
  // 0..0x7fff = 20·log10(v / 0x7fff) dB.

  /// App meter blob: ch 1-40 [0-39], ST IN 1-2 L/R [40-43], FX RTN 1-4 L/R
  /// [44-51], MIX 1-22 [52-73], Main L/R [74, 75].
  static const meterCount = 76;

  /// Meter tags used and where their values go in the app blob.
  static const meterTags = {
    0x0001: (0, 40), // CH INPUT
    0x0007: (40, 4), // ST-IN INPUT
    0x000C: (44, 8), // FX POST FX
    0x0014: (52, 22), // MIX OUTPUT
    0x001A: (74, 2), // Main OUTPUT
  };

  static int crc16Xmodem(List<int> data) {
    var crc = 0;
    for (final b in data) {
      crc ^= b << 8;
      for (var k = 0; k < 8; k++) {
        crc = crc & 0x8000 != 0 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
      }
    }
    return crc;
  }

  static const headerSize = 32;

  /// Reads one meter packet into [into] (raw 0..0x7fff values). False if
  /// the packet isn't a valid Sonicview meter page.
  static bool readMeterPacket(List<int> p, List<int> into) {
    if (p.length < headerSize) return false;
    if (String.fromCharCodes(p.sublist(0, 8)) != 'SV_METER') return false;
    if (String.fromCharCodes(p.sublist(10, 14)) != 'DATA') return false;
    int u16(int i) => p[i] | (p[i + 1] << 8);
    final crc = u16(28), size = u16(30);
    if (headerSize + size > p.length) return false;
    final data = p.sublist(headerSize, headerSize + size);
    if (crc16Xmodem(data) != crc) return false;
    var i = 0;
    while (i + 4 <= data.length) {
      final tag = data[i] | (data[i + 1] << 8);
      var len = data[i + 2] | (data[i + 3] << 8);
      final slot = meterTags[tag];
      // the size is in bytes; a few tables in the spec give a word count
      if (slot != null && len == slot.$2) len = slot.$2 * 2;
      i += 4;
      if (i + len > data.length) break;
      if (slot != null) {
        final (at, count) = slot;
        for (var k = 0; k < count && k * 2 + 1 < len; k++) {
          into[at + k] = data[i + k * 2] | (data[i + k * 2 + 1] << 8);
        }
      }
      i += len;
    }
    return true;
  }

  /// Raw meter value → 1/256 dB (int16), -32768 = silence.
  static int meterWord(int raw) {
    if (raw <= 0) return -32768;
    final db = 20 * math.log(raw.clamp(1, 0x7fff) / 0x7fff) / math.ln10;
    return (db * 256).round().clamp(-32767, 32767);
  }
}
