import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import '../ember/ember.dart';
import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import 'tascam_map.dart';

/// Connection to a TASCAM Sonicview 16 / 24 over Ember+ (TCP, S101 framing).
///
/// Ember+ addresses parameters by number; the numbers are learned by
/// browsing the tree (GetDirectory) down to each parameter the app uses,
/// and only those branches are browsed. The console then reports every
/// change under the branches seen. Meters come as UDP pages after the app
/// writes its own IP address to the console's meter application.
class TascamLink implements MixerLink {
  TascamLink._(this.host, this.port);

  final String host;
  final int port;
  Socket? _socket;
  StreamSubscription<List<int>>? _sub;
  final _decoder = S101Decoder();
  bool _closed = false;
  Timer? _retry;
  Timer? _pump;
  final _out = StreamController<OscMessage>.broadcast();

  TascamMap map = const TascamMap();

  static const defaultPort = 9000;
  static const meterId = '/meters/tascam';
  static const aliveAddr = '/-stat/tascam/alive';

  // ---- tree
  final Map<String, List<int>> _pathOf = {};
  final Map<String, String> _nameOf = {};
  final Map<String, Object?> _value = {};
  final Map<String, List<String>> _enum = {};
  final Set<String> _expanded = {};
  final Map<String, DateTime> _requested = {};
  final Map<String, int> _tries = {};
  final Map<String, List<void Function()>> _waiting = {};
  final List<String> _queue = [];
  static const _maxOutstanding = 12;

  // ---- app side
  final Map<String, Map<String, TascamParam>> _back = {};
  final Map<String, int> _masks = {};
  final Map<int, (String?, bool?)> _scenes = {};

  static Future<TascamLink> connect(String host, {int port = defaultPort, Duration timeout = const Duration(seconds: 3)}) async {
    final l = TascamLink._(host, port);
    await l._open(timeout);
    return l;
  }

  Future<void> _open(Duration timeout) async {
    final s = await Socket.connect(host, port, timeout: timeout);
    s.setOption(SocketOption.tcpNoDelay, true);
    _socket = s;
    _sub = s.listen(_onBytes, onError: (_) => _lost(), onDone: _lost, cancelOnError: true);
    _pump ??= Timer.periodic(const Duration(milliseconds: 500), (_) => _checkRequests());
    _requested[''] = DateTime.now();
    _write(Glow.getRootDirectory());
  }

  void _lost() {
    _sub?.cancel();
    _sub = null;
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _expanded.clear();
    _requested.clear();
    _queue.clear();
    if (_closed) return;
    _retry ??= Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_closed || _socket != null) return;
      try {
        await _open(const Duration(seconds: 2));
        _retry?.cancel();
        _retry = null;
        // browse again to everything the app uses: values arrive with it
        for (final name in _back.keys.toList()) {
          _resolve(name, (_) {});
        }
      } catch (_) {}
    });
  }

  void _write(List<int> glow) {
    final s = _socket;
    if (s == null) return;
    try {
      s.add(S101.ember(glow));
    } catch (_) {
      _lost();
    }
  }

  void _emit(String addr, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(addr, [v]));
  }

  // ---------------------------------------------------------------- incoming

  void _onBytes(List<int> data) {
    for (final f in _decoder.add(data)) {
      if (f.command == S101.cmdKeepAliveRequest) {
        try {
          _socket?.add(S101.keepAliveResponse());
        } catch (_) {}
        continue;
      }
      if (f.command == S101.cmdKeepAliveResponse) {
        _emit(aliveAddr, 1);
        continue;
      }
      if (f.command != S101.cmdEmber) continue;
      List<EmberElement> els;
      try {
        els = parseGlow(f.payload);
      } catch (_) {
        continue; // malformed message
      }
      _onElements(els);
    }
  }

  void _onElements(List<EmberElement> els) {
    final touched = <String>{};
    for (final e in els) {
      final key = e.path.join('.');
      var name = _nameOf[key];
      if (e.identifier != null && e.identifier!.isNotEmpty && !e.identifier!.contains('/')) {
        final parentKey = e.path.length <= 1 ? '' : e.path.sublist(0, e.path.length - 1).join('.');
        final parent = parentKey.isEmpty ? '' : _nameOf[parentKey];
        if (parent != null) {
          name = parent.isEmpty ? e.identifier! : '$parent/${e.identifier}';
          _nameOf[key] = name;
          _pathOf[name] = e.path;
          if (_requested.containsKey(parent)) touched.add(parent);
        }
      }
      if (name == null) continue;
      if (e.enumeration != null) _enum[name] = e.enumeration!;
      if (e.hasValue) {
        _value[name] = e.value;
        _dispatch(name);
      }
    }
    for (final p in touched) {
      _expanded.add(p);
      _requested.remove(p);
      _tries.remove(p);
      final w = _waiting.remove(p);
      if (w != null) {
        for (final f in w) {
          f();
        }
      }
    }
    _sendQueued();
  }

  void _dispatch(String name) {
    final hits = _back[name];
    if (hits == null) return;
    final v = _value[name];
    hits.forEach((addr, p) {
      switch (p.kind) {
        case TascamKind.maskBit:
          final on = map.decode(p.kind, v);
          if (on is! int) return;
          final m = _masks[addr] ?? 0;
          final next = on != 0 ? (m | (1 << p.bit)) : (m & ~(1 << p.bit));
          _masks[addr] = next;
          _emit(addr, next);
        case TascamKind.sceneName:
        case TascamKind.sceneEmpty:
          final n = _sceneOf(addr);
          if (n == null) return;
          final (nm, empty) = _scenes[n] ?? (null, null);
          final next = p.kind == TascamKind.sceneName ? (v is String ? v : nm, empty) : (nm, v is bool ? v : empty);
          _scenes[n] = next;
          if (next.$2 == true) {
            _emit(addr, '');
          } else if (next.$1 != null && next.$2 == false) {
            _emit(addr, next.$1!.trim().isEmpty ? 'Snapshot $n' : next.$1!);
          }
        default:
          final out = map.decode(p.kind, v, enumeration: _enum[name]);
          if (out != null) _emit(addr, out);
      }
    });
  }

  static int? _sceneOf(String addr) => MixerProfile.yamahaSceneFromNameAddr(addr);

  // ---------------------------------------------------------------- browsing

  /// Calls [then] with the Ember+ number path of [name] once it is known
  /// (browsing the tree down to it). Dropped if the console has no such
  /// parameter.
  void _resolve(String name, void Function(List<int>) then) {
    final known = _pathOf[name];
    if (known != null) {
      then(known);
      return;
    }
    final segs = name.split('/');
    var parent = '';
    for (var i = 0; i < segs.length; i++) {
      final here = i == 0 ? segs[0] : '$parent/${segs[i]}';
      if (!_pathOf.containsKey(here)) {
        if (_expanded.contains(parent)) return; // no such element
        (_waiting[parent] ??= []).add(() => _resolve(name, then));
        _browse(parent);
        return;
      }
      parent = here;
    }
  }

  void _browse(String node) {
    if (_expanded.contains(node) || _requested.containsKey(node) || _queue.contains(node)) return;
    _queue.add(node);
    _sendQueued();
  }

  void _sendQueued() {
    while (_queue.isNotEmpty && _requested.length < _maxOutstanding && _socket != null) {
      final node = _queue.removeAt(0);
      if (_expanded.contains(node)) continue;
      if (node.isEmpty) {
        _requested[node] = DateTime.now();
        _write(Glow.getRootDirectory());
        continue;
      }
      final path = _pathOf[node];
      if (path == null) continue;
      _requested[node] = DateTime.now();
      _write(Glow.getDirectory(path));
    }
  }

  /// Requests without an answer are tried again, then given up.
  void _checkRequests() {
    final now = DateTime.now();
    for (final e in _requested.entries.toList()) {
      if (now.difference(e.value) < const Duration(seconds: 3)) continue;
      _requested.remove(e.key);
      final t = (_tries[e.key] ?? 0) + 1;
      _tries[e.key] = t;
      if (t <= 3) {
        _queue.insert(0, e.key);
      } else {
        // an empty node, or one the console won't open: stop waiting on it
        _expanded.add(e.key);
        _waiting.remove(e.key);
      }
    }
    _sendQueued();
    _renewMeters();
  }

  /// True once the root and the "sonicview" node are known.
  Future<bool> ready({Duration timeout = const Duration(seconds: 3)}) async {
    final sw = Stopwatch()..start();
    while (sw.elapsed < timeout) {
      if (_pathOf.containsKey(TascamMap.root)) return true;
      await Future<void>.delayed(const Duration(milliseconds: 20));
    }
    return false;
  }

  /// The product name ("Sonicview 24"); null if the console won't say.
  Future<String?> askProduct({Duration timeout = const Duration(seconds: 3)}) async {
    const name = '${TascamMap.root}/identity/product';
    final done = Completer<String?>();
    _resolve(name, (_) {
      final v = _value[name];
      if (!done.isCompleted) done.complete(v is String ? v : null);
    });
    try {
      return await done.future.timeout(timeout);
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------- outgoing

  @override
  Stream<OscMessage> get messages => _out.stream;

  void _register(String addr, TascamParam p) => (_back[p.path] ??= {})[addr] = p;

  @override
  void send(OscMessage m) {
    final a = m.address;
    switch (a) {
      case '/xremote':
        return;
      case '/xinfo':
        try {
          _socket?.add(S101.keepAliveRequest());
        } catch (_) {}
        return;
      case '/meters':
        if (m.args.isNotEmpty && m.args.first == meterId) _wantMeters();
        return;
      case '/-snap/load':
        final n = m.args.isEmpty ? null : m.args.first;
        if (n is num && n >= 1 && n <= TascamLayout.snapshots) {
          _set('${TascamMap.root}/snapshots/snapshot_${n.toInt()}/recall', true);
        }
        return;
    }
    final fixed = TascamMap.constantFor(a);
    if (fixed != null) {
      if (m.args.isEmpty) _emit(a, fixed);
      return;
    }
    final params = map.toTascam(a);
    if (params.isEmpty) return; // the console has no such control
    for (final p in params) {
      _register(a, p);
    }
    if (m.args.isEmpty) {
      for (final p in params) {
        _resolve(p.path, (_) {
          if (_value.containsKey(p.path)) _dispatch(p.path);
        });
      }
      return;
    }
    final v = m.args.first;
    if (params.first.kind == TascamKind.maskBit) {
      if (v is! num) return;
      final mask = v.toInt();
      _masks[a] = mask;
      for (final p in params) {
        _set(p.path, (mask >> p.bit) & 1 == 1);
      }
      return;
    }
    final p = params.first;
    final out = map.encode(p.kind, v, enumeration: _enum[p.path]);
    if (out != null) _set(p.path, out);
  }

  void _set(String name, Object value) {
    _value[name] = value;
    _resolve(name, (path) => _write(Glow.setValue(path, value)));
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  /// Registers app addresses up front, so changes made on the console are
  /// understood even for controls the app hasn't asked about.
  void learn(Iterable<String> addrs) {
    for (final a in addrs) {
      for (final p in map.toTascam(a)) {
        _register(a, p);
      }
    }
  }

  void useModel(String model) => map = TascamMap(layout: TascamLayout.forModel(model));

  /// Every app address a Sonicview profile can show.
  static Iterable<String> profileAddresses(MixerProfile p) sync* {
    yield* p.queryAddresses;
    yield* p.snapshotAddresses();
    yield* p.consoleLibraryAddresses;
    for (final s in p.allStrips) {
      yield* p.detailAddresses(s);
    }
    for (final s in p.inputs) {
      if (s.type == StripType.channel) {
        yield '/headamp/${two(s.index)}/gain';
        yield '/headamp/${two(s.index)}/phantom';
      }
    }
  }

  // ---------------------------------------------------------------- meters

  RawDatagramSocket? _meterSock;
  DateTime _meterWanted = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _meterAsked = DateTime.fromMillisecondsSinceEpoch(0);
  bool _opening = false;
  final List<int> _raw = List<int>.filled(TascamMap.meterCount, 0);

  static const _meterSetting = '${TascamMap.root}/meter_application/setting';
  static const meterPort = 41624;

  void _wantMeters() {
    _meterWanted = DateTime.now();
    if (_meterSock != null || _opening || _closed) return;
    _openMeters();
  }

  Future<void> _openMeters() async {
    _opening = true;
    try {
      RawDatagramSocket u;
      try {
        u = await RawDatagramSocket.bind(InternetAddress.anyIPv4, meterPort);
      } catch (_) {
        // another app on this device has the console's meter port: use our
        // own and tell the console
        u = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
        _set('$_meterSetting/sv_meter_udp_port', u.port);
      }
      if (_closed) {
        u.close();
        return;
      }
      final hostAddr = InternetAddress.tryParse(host);
      u.listen((e) {
        if (e != RawSocketEvent.read) return;
        final dg = u.receive();
        if (dg == null || dg.data.length > 4096) return;
        if (hostAddr != null && dg.address != hostAddr) return;
        if (TascamMap.readMeterPacket(dg.data, _raw)) _emitMeters();
      });
      _meterSock = u;
      _askMeters();
    } catch (_) {
      _meterSock = null;
    } finally {
      _opening = false;
    }
  }

  void _askMeters() {
    final ip = _socket?.address.address;
    if (ip == null) return;
    _meterAsked = DateTime.now();
    // meters off on the console: ask for 100 ms
    const interval = '$_meterSetting/sv_meter_interval';
    _resolve(interval, (_) {
      final v = _value[interval];
      if (v == 0 || (v is String && v.toUpperCase() == 'OFF')) _set(interval, 2);
    });
    _set('$_meterSetting/sv_meter_ip_connect', ip);
  }

  /// The console stops sending after ~10 min; ask again every 4 min while
  /// meters are shown, and stop when the app stops asking.
  void _renewMeters() {
    if (_meterSock == null) return;
    final now = DateTime.now();
    if (now.difference(_meterWanted) > const Duration(seconds: 9)) {
      final ip = _socket?.address.address;
      if (ip != null) _set('$_meterSetting/sv_meter_ip_disconnect', ip);
      _meterSock?.close();
      _meterSock = null;
      return;
    }
    if (now.difference(_meterAsked) > const Duration(minutes: 4)) _askMeters();
  }

  void _emitMeters() {
    final bd = ByteData(4 + _raw.length * 2);
    bd.setInt32(0, _raw.length, Endian.little);
    for (var i = 0; i < _raw.length; i++) {
      bd.setInt16(4 + i * 2, TascamMap.meterWord(_raw[i]), Endian.little);
    }
    if (!_out.isClosed) _out.add(OscMessage(meterId, [bd.buffer.asUint8List()]));
  }

  @override
  void close() {
    if (_meterSock != null) {
      final ip = _socket?.address.address;
      if (ip != null) _set('$_meterSetting/sv_meter_ip_disconnect', ip);
    }
    _closed = true;
    _retry?.cancel();
    _pump?.cancel();
    _meterSock?.close();
    _sub?.cancel();
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _out.close();
  }
}
