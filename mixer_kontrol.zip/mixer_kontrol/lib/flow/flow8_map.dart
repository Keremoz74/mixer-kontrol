// Behringer FLOW 8: the app's own (X32-style) addresses ↔ the mixer's MIDI
// control messages, from the MIDI implementation in the FLOW 8 user manual.
//
// MIDI channels (1-based): inputs Ch 1, 2, 3, 4, 5/6, 7/8, USB/BT = 1…7,
// MAIN = 8, MON 1 = 9, MON 2 = 10, FX 1 = 11, FX 2 = 12, FX slot 1 = 13,
// FX slot 2 = 14, global = 16.
//
// App → FLOW 8:
//   /ch/NN/mix/fader      CC 7   level (0 = off, 1…127 = -70…+10 dB)
//   /ch/NN/mix/pan        CC 10  balance (64 = centre)
//   /ch/NN/mix/on         CC 5   mute (inverted: on = not muted)
//   /ch/NN/cue            CC 6   solo
//   /ch/NN/eq/1…4/g       CC 1…4 low, low mid, high mid, high (-15…+15 dB)
//   /headamp/NN/gain      CC 8   gain -20…+60 dB (Ch 1 … 7/8)
//   /headamp/NN/phantom   CC 12  48 V (Ch 1 and 2)
//   /ch/NN/preamp/hpf     CC 9   low cut 20…600 Hz (hpon off = 20 Hz)
//   /ch/NN/mix/01…04/level CC 14…17 send to MON 1, MON 2, FX 1, FX 2
//   /main/st/mix/fader    ch 8  CC 7;  /main/st/mix/pan ch 8 CC 10
//   /bus/01, /bus/02      ch 9, 10 CC 7 (MON 1, MON 2 level)
//   /fxsend/1, /fxsend/2  ch 11, 12 CC 7 (FX 1, FX 2 level)
// Buses have no mute in the MIDI table: the link mutes one by sending its
// level as "off" and restores the level on unmute.

import 'dart:math' as math;

import '../util/fader_math.dart';
import '../util/param_law.dart';

/// One MIDI Control Change.
class FlowCc {
  const FlowCc(this.channel, this.cc, this.value);

  /// 1-based MIDI channel.
  final int channel;
  final int cc;
  final int value;

  List<int> get bytes => [0xB0 | ((channel - 1) & 0x0F), cc & 0x7F, value.clamp(0, 127)];

  @override
  bool operator ==(Object other) =>
      other is FlowCc && other.channel == channel && other.cc == cc && other.value == value;
  @override
  int get hashCode => Object.hash(channel, cc, value);
  @override
  String toString() => 'ch$channel CC$cc=$value';
}

/// What a parameter is, for converting values.
enum FlowKind { level, balance, muteInv, onOff, eqGain, gain, lowCut }

class FlowParam {
  const FlowParam(this.channel, this.cc, this.kind);
  final int channel;
  final int cc;
  final FlowKind kind;
}

class Flow8Map {
  const Flow8Map();

  /// Input strips (Ch 1, 2, 3, 4, 5/6, 7/8, USB/BT).
  static const inputs = 7;
  static const labels = ['CH 1', 'CH 2', 'CH 3', 'CH 4', 'CH 5/6', 'CH 7/8', 'USB/BT'];
  static const stereo = {5, 6, 7};

  /// Send targets: MON 1, MON 2, FX 1, FX 2 (app mix index 1…4).
  static const sendLabels = ['MON 1', 'MON 2', 'FX 1', 'FX 2'];

  static const mainChannel = 8;

  /// MIDI channel of a bus prefix (/bus/01 → 9 …), or null.
  static int? busChannel(String prefix) => switch (prefix) {
        '/main/st' => mainChannel,
        '/bus/01' => 9,
        '/bus/02' => 10,
        '/fxsend/1' => 11,
        '/fxsend/2' => 12,
        _ => null,
      };

  static final _ch = RegExp(r'^/ch/(\d{2})(/.+)$');
  static final _head = RegExp(r'^/headamp/(\d{2})/(gain|phantom)$');
  static final _bus = RegExp(r'^(/main/st|/bus/0[12]|/fxsend/[12])(/.+)$');
  static final _send = RegExp(r'^/mix/(\d{2})/level$');
  static final _eq = RegExp(r'^/eq/([1-4])/g$');

  /// The FLOW 8 control behind an app address, or null (not on the FLOW 8).
  FlowParam? toFlow(String addr) {
    var m = _head.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (m[2] == 'gain') return n >= 1 && n <= 6 ? FlowParam(n, 8, FlowKind.gain) : null;
      return n == 1 || n == 2 ? FlowParam(n, 12, FlowKind.onOff) : null;
    }
    m = _bus.firstMatch(addr);
    if (m != null) {
      final ch = busChannel(m[1]!)!;
      return switch (m[2]) {
        '/mix/fader' => FlowParam(ch, 7, FlowKind.level),
        '/mix/pan' when ch == mainChannel => const FlowParam(mainChannel, 10, FlowKind.balance),
        _ => null,
      };
    }
    m = _ch.firstMatch(addr);
    if (m == null) return null;
    final n = int.parse(m[1]!);
    if (n < 1 || n > inputs) return null;
    final rest = m[2]!;
    switch (rest) {
      case '/mix/fader':
        return FlowParam(n, 7, FlowKind.level);
      case '/mix/pan':
        return FlowParam(n, 10, FlowKind.balance);
      case '/mix/on':
        return FlowParam(n, 5, FlowKind.muteInv);
      case '/cue':
        return FlowParam(n, 6, FlowKind.onOff);
      case '/preamp/hpf':
        return n <= 6 ? FlowParam(n, 9, FlowKind.lowCut) : null;
    }
    final eq = _eq.firstMatch(rest);
    if (eq != null) return FlowParam(n, int.parse(eq[1]!), FlowKind.eqGain);
    final s = _send.firstMatch(rest);
    if (s != null) {
      final k = int.parse(s[1]!);
      return k >= 1 && k <= 4 ? FlowParam(n, 13 + k, FlowKind.level) : null;
    }
    return null;
  }

  /// The app address for a received CC, or null.
  String? toApp(int channel, int cc) {
    String? bus(int ch) => switch (ch) {
          8 => '/main/st',
          9 => '/bus/01',
          10 => '/bus/02',
          11 => '/fxsend/1',
          12 => '/fxsend/2',
          _ => null,
        };
    if (channel >= 8) {
      final b = bus(channel);
      if (b == null) return null;
      if (cc == 7) return '$b/mix/fader';
      if (cc == 10 && channel == mainChannel) return '$b/mix/pan';
      return null;
    }
    if (channel < 1 || channel > inputs) return null;
    final p = '/ch/${channel.toString().padLeft(2, '0')}';
    return switch (cc) {
      7 => '$p/mix/fader',
      10 => '$p/mix/pan',
      5 => '$p/mix/on',
      6 => '$p/cue',
      >= 1 && <= 4 => '$p/eq/$cc/g',
      8 when channel <= 6 => '/headamp/${channel.toString().padLeft(2, '0')}/gain',
      12 when channel <= 2 => '/headamp/${channel.toString().padLeft(2, '0')}/phantom',
      9 when channel <= 6 => '$p/preamp/hpf',
      >= 14 && <= 17 => '$p/mix/${(cc - 13).toString().padLeft(2, '0')}/level',
      _ => null,
    };
  }

  // ---------------------------------------------------------------- values

  /// App fader (X32 law) → FLOW 8 level: 0 = off, 1…127 = -70…+10 dB.
  static int levelCc(double fader) {
    final db = faderToDb(fader);
    if (db.isInfinite || db < -70) return 0;
    return (1 + (db + 70) / 80 * 126).round().clamp(1, 127);
  }

  static double levelFromCc(int v) => v <= 0 ? 0 : dbToFader(-70 + (v - 1) / 126 * 80);

  /// App 0…1 pan → balance 0…127 (0.5 → 64).
  static int balanceCc(double pan) => pan.clamp(0.0, 1.0) >= 0.5
      ? (64 + (pan - 0.5) * 2 * 63).round().clamp(64, 127)
      : (pan * 2 * 64).round().clamp(0, 64);
  static double balanceFromCc(int v) => v >= 64 ? 0.5 + (v - 64) / 63 / 2 : v / 64 / 2;

  /// EQ gain (app law -15…+15 dB) ↔ 0…127, 64 = 0 dB.
  static int eqCc(double norm) {
    final db = eqGainLaw.toReal(norm);
    return db >= 0 ? (64 + db / 15 * 63).round().clamp(64, 127) : (64 + db / 15 * 64).round().clamp(0, 64);
  }

  static double eqFromCc(int v) => eqGainLaw.toNorm(v >= 64 ? (v - 64) / 63 * 15 : (v - 64) / 64 * 15);

  /// Preamp gain: app law (headampGainLaw, -12…+60 dB) ↔ FLOW -20…+60 dB.
  static int gainCc(double norm) => ((headampGainLaw.toReal(norm) + 20) / 80 * 127).round().clamp(0, 127);
  static double gainFromCc(int v) => headampGainLaw.toNorm(-20 + v / 127 * 80);

  /// Low cut: app law (hpfLaw, 20…400 Hz) ↔ FLOW 20…600 Hz (log).
  static int lowCutCc(double norm) {
    final hz = hpfLaw.toReal(norm);
    return (math.log(hz / 20) / math.log(30) * 127).round().clamp(0, 127);
  }

  static double lowCutFromCc(int v) => hpfLaw.toNorm(20 * math.pow(30, v / 127).toDouble());

  /// The CC for [value] (as the app stores it) of [p].
  static int encode(FlowParam p, Object value) {
    final v = value is num ? value.toDouble() : 0.0;
    return switch (p.kind) {
      FlowKind.level => levelCc(v),
      FlowKind.balance => balanceCc(v),
      FlowKind.muteInv => v >= 0.5 ? 0 : 127,
      FlowKind.onOff => v >= 0.5 ? 127 : 0,
      FlowKind.eqGain => eqCc(v),
      FlowKind.gain => gainCc(v),
      FlowKind.lowCut => lowCutCc(v),
    };
  }

  /// The app value for a received CC of [p].
  static Object decode(FlowParam p, int cc) => switch (p.kind) {
        FlowKind.level => levelFromCc(cc),
        FlowKind.balance => balanceFromCc(cc),
        FlowKind.muteInv => cc > 0 ? 0 : 1,
        FlowKind.onOff => cc > 0 ? 1 : 0,
        FlowKind.eqGain => eqFromCc(cc),
        FlowKind.gain => gainFromCc(cc),
        FlowKind.lowCut => lowCutFromCc(cc),
      };
}
