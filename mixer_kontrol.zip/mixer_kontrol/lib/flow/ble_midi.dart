// Bluetooth LE MIDI framing (MMA "MIDI over Bluetooth LE"): each packet is a
// header byte, then per message a timestamp byte and the MIDI bytes.

/// Standard BLE MIDI service and its data characteristic.
const bleMidiService = '03b80e5a-ede8-4b33-a751-6ce34ec4c700';
const bleMidiCharacteristic = '7772e5db-3868-4112-a1a9-f2669d106bf3';

/// One BLE MIDI packet carrying [midi] (complete messages), timestamp 0.
List<int> bleMidiPacket(List<int> midi) => [0x80, 0x80, ...midi];

/// The MIDI bytes in a BLE MIDI packet (header and timestamps removed).
List<int> bleMidiDecode(List<int> p) {
  if (p.length < 3 || p[0] & 0x80 == 0) return const [];
  final out = <int>[];
  var i = 1;
  while (i < p.length) {
    final b = p[i];
    // a timestamp byte comes before every status byte
    if (b & 0x80 != 0 && i + 1 < p.length && p[i + 1] & 0x80 != 0) {
      i++;
      continue;
    }
    out.add(b);
    i++;
  }
  return out;
}

String hex(List<int> b) => b.map((x) => x.toRadixString(16).padLeft(2, '0')).join(' ');

/// Bytes from a hex string ("b0 05 7f", "B0057F"); null if not hex.
List<int>? parseHex(String s) {
  final t = s.replaceAll(RegExp(r'[\s,:-]'), '');
  if (t.isEmpty || t.length.isOdd || !RegExp(r'^[0-9a-fA-F]+$').hasMatch(t)) return null;
  return [for (var i = 0; i < t.length; i += 2) int.parse(t.substring(i, i + 2), radix: 16)];
}
