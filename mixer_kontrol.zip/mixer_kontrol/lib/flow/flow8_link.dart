// Behringer FLOW 8 over MIDI (USB, or Bluetooth MIDI where the mixer offers
// it). The FLOW 8 only takes control messages; it can't be asked for its
// state. The link therefore keeps the last values the app set (saved on the
// device, per mixer) and answers the app's queries from them, and takes
// what the mixer sends back, if anything, as changes.

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:shared_preferences/shared_preferences.dart';

import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import '../util/fader_math.dart';
import '../util/param_law.dart';
import 'flow8_map.dart';

class Flow8Link implements MixerLink {
  Flow8Link({
    required void Function(Uint8List bytes) sendBytes,
    Stream<Uint8List>? incoming,
    this.deviceName = 'FLOW 8',
    this.prefsKey = 'flow8_state',
    void Function()? onClose,
  })  : _sendBytes = sendBytes,
        _onClose = onClose {
    _in = incoming?.listen(_onMidi);
  }

  final void Function(Uint8List bytes) _sendBytes;
  final void Function()? _onClose;
  final String deviceName;
  final String prefsKey;
  final _map = const Flow8Map();
  final _out = StreamController<OscMessage>.broadcast();
  StreamSubscription<Uint8List>? _in;
  Timer? _saveTimer;
  bool _closed = false;

  /// Last known value per app address.
  final Map<String, Object> _state = {};

  /// Bytes sent, newest last (for the diagnostics page and tests).
  final List<String> log = [];

  @override
  Stream<OscMessage> get messages => _out.stream;

  /// Loads the values saved last time (they stand in for the mixer's own,
  /// which can't be read).
  Future<void> restore() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(prefsKey);
      if (raw == null || raw.length > 200000) return;
      final m = jsonDecode(raw);
      if (m is! Map) return;
      m.forEach((k, v) {
        if (k is String && k.length < 64 && (v is num || v is String) && _accepts(k)) _state[k] = v as Object;
      });
    } catch (_) {}
  }

  bool _accepts(String addr) => _map.toFlow(addr) != null || addr.endsWith('/mix/on') || addr.endsWith('/hpon');

  void _save() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(seconds: 1), () async {
      try {
        final p = await SharedPreferences.getInstance();
        await p.setString(
            prefsKey,
            jsonEncode({
              for (final e in _state.entries)
                if (_accepts(e.key)) e.key: e.value
            }));
      } catch (_) {}
    });
  }

  /// Fixed values of the FLOW 8 (EQ frequencies and types, EQ always on).
  static Object? fixed(String addr) {
    final eq = RegExp(r'^/ch/\d{2}/eq/([1-4])/(type|f|q)$').firstMatch(addr);
    if (eq != null) {
      final b = int.parse(eq[1]!);
      return switch (eq[2]) {
        'type' => b == 1 ? 1 : (b == 4 ? 4 : 2), // shelf, peak, peak, shelf
        'f' => freqLaw.toNorm(const [80.0, 300.0, 1500.0, 12000.0][b - 1]),
        _ => qLaw.toNorm(1.0),
      };
    }
    if (RegExp(r'^/ch/\d{2}/eq/on$').hasMatch(addr)) return 1;
    return null;
  }

  /// What the app shows before anything is known.
  static Object? defaultFor(String addr) {
    final f = fixed(addr);
    if (f != null) return f;
    if (addr.endsWith('/mix/fader')) return dbToFader(0);
    if (addr.endsWith('/mix/pan')) return 0.5;
    if (addr.endsWith('/mix/on')) return 1;
    if (addr.endsWith('/cue') || addr.endsWith('/phantom') || addr.endsWith('/preamp/hpon')) return 0;
    if (RegExp(r'/eq/[1-4]/g$').hasMatch(addr)) return 0.5;
    if (RegExp(r'/mix/\d{2}/level$').hasMatch(addr)) return 0.0;
    if (addr.endsWith('/preamp/hpf')) return 0.0;
    if (addr.startsWith('/headamp/') && addr.endsWith('/gain')) return headampGainLaw.toNorm(20);
    return null;
  }

  @override
  void send(OscMessage m) {
    if (_closed) return;
    final a = m.address;
    if (m.args.isEmpty) {
      _answer(a);
      return;
    }
    final v = m.args.first;
    // EQ frequency / type / Q are fixed on the FLOW 8: put them back.
    final fx = fixed(a);
    if (fx != null) {
      Timer.run(() => _emit(a, fx));
      return;
    }
    _state[a] = v;
    _save();
    // Low cut on/off: off = 20 Hz.
    if (a.endsWith('/preamp/hpon')) {
      final hpf = a.replaceFirst('/hpon', '/hpf');
      final p = _map.toFlow(hpf);
      if (p != null) _cc(p.channel, p.cc, (v is num && v != 0) ? Flow8Map.encode(p, _state[hpf] ?? 0.0) : 0);
      return;
    }
    if (a.endsWith('/preamp/hpf') && !_on(a.replaceFirst('/preamp/hpf', '/preamp/hpon'), 0)) return;
    // Bus mute: the FLOW 8 has none; mute = level off, unmute = level back.
    final bus = RegExp(r'^(/main/st|/bus/0[12]|/fxsend/[12])/mix/on$').firstMatch(a);
    if (bus != null) {
      final fader = '${bus[1]}/mix/fader';
      final p = _map.toFlow(fader)!;
      _cc(p.channel, p.cc, (v is num && v != 0) ? Flow8Map.encode(p, _state[fader] ?? defaultFor(fader)!) : 0);
      return;
    }
    final p = _map.toFlow(a);
    if (p == null) return;
    // A muted bus stays silent while its fader moves.
    final busFader = RegExp(r'^(/main/st|/bus/0[12]|/fxsend/[12])/mix/fader$').firstMatch(a);
    if (busFader != null && !_on('${busFader[1]}/mix/on', 1)) return;
    _cc(p.channel, p.cc, Flow8Map.encode(p, v));
  }

  bool _on(String addr, int dflt) {
    final v = _state[addr] ?? dflt;
    return v is num && v != 0;
  }

  void _cc(int channel, int cc, int value) {
    final c = FlowCc(channel, cc, value);
    log.add(c.toString());
    if (log.length > 500) log.removeRange(0, log.length - 500);
    try {
      _sendBytes(Uint8List.fromList(c.bytes));
    } catch (_) {}
  }

  void _answer(String a) {
    if (a == '/xinfo') {
      Timer.run(() => _out.isClosed ? null : _out.add(OscMessage('/xinfo', ['midi', deviceName, 'FLOW 8', '1.0'])));
      return;
    }
    final v = _state[a] ?? defaultFor(a);
    if (v != null) Timer.run(() => _emit(a, v));
  }

  void _emit(String a, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(a, [v]));
  }

  /// MIDI from the mixer (if it sends any): Control Changes become changes.
  void _onMidi(Uint8List data) {
    var i = 0;
    while (i < data.length) {
      final s = data[i];
      if (s & 0xF0 == 0xB0 && i + 2 < data.length) {
        final ch = (s & 0x0F) + 1, cc = data[i + 1] & 0x7F, val = data[i + 2] & 0x7F;
        final addr = _map.toApp(ch, cc);
        final p = addr == null ? null : _map.toFlow(addr);
        if (addr != null && p != null) {
          final v = Flow8Map.decode(p, val);
          _state[addr] = v;
          _save();
          _emit(addr, v);
        }
        i += 3;
      } else {
        i++;
      }
    }
  }

  /// Sends every known value to the mixer (after a reconnect, or to make the
  /// mixer match what the app shows).
  void pushAll() {
    for (final e in _state.entries.toList()) {
      if (e.key.endsWith('/hpon') || (e.key.endsWith('/mix/on') && !e.key.startsWith('/ch/'))) continue;
      send(OscMessage(e.key, [e.value]));
    }
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    if (address == '/xinfo') return OscMessage('/xinfo', ['midi', deviceName, 'FLOW 8', '1.0']);
    final v = _state[address] ?? defaultFor(address);
    return v == null ? null : OscMessage(address, [v]);
  }

  @override
  void close() {
    _closed = true;
    _saveTimer?.cancel();
    _in?.cancel();
    _out.close();
    _onClose?.call();
  }
}
