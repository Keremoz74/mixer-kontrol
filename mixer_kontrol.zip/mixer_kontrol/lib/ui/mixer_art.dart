import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'mixer_catalog.dart';

/// Original, brand-free illustration of a mixer. Drawn from an [ArtSpec]
/// (form, number of faders and screens, size), so models can be told apart
/// without copying any real product.
class MixerArt extends StatelessWidget {
  const MixerArt({super.key, this.family, this.spec, this.accent, this.width = 120, this.height = 72});

  /// Shorthand when only the family is known.
  final MixerFamily? family;
  final ArtSpec? spec;

  /// Brand colour for the rim light and lit buttons.
  final Color? accent;
  final double width;
  final double height;

  static ArtSpec defaultFor(MixerFamily? f) => switch (f) {
        MixerFamily.xr => const ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0),
        MixerFamily.yamaha || MixerFamily.tascam || MixerFamily.wing =>
          const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.26),
        MixerFamily.allenHeath => const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.24),
        _ => const ArtSpec(ArtKind.desk, faders: 16, masters: 9, screen: 0.14),
      };

  @override
  Widget build(BuildContext context) {
    final s = spec ?? defaultFor(family);
    final a = accent ?? MixerCatalog.accentOfFamily(family);
    return SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: switch (s.kind) {
          ArtKind.desk || ArtKind.touchDesk => _DeskPainter(s, a),
          ArtKind.rack => _RackPainter(s, a),
          ArtKind.stagebox => _StageBoxPainter(s, a),
        },
      ),
    );
  }
}

const _bodyTop = Color(0xFF2C3446);
const _bodyBottom = Color(0xFF151A24);
const _metal = Color(0xFF8E96A3);
const _hole = Color(0xFF0A0D12);
const _stripColors = [
  Color(0xFFE5484D), Color(0xFF46A758), Color(0xFFF5D90A), Color(0xFF3E8EF7), //
  Color(0xFFD864D8), Color(0xFF29C5D6), Color(0xFFEDEDED), Color(0xFFF08A24),
];

void _shadow(Canvas c, Rect r) => c.drawOval(
      r,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

void _outline(Canvas c, Path p) => c.drawPath(
      p,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.18),
    );

Paint _bodyPaint(Rect r) => Paint()
  ..shader = const LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [_bodyTop, _bodyBottom],
  ).createShader(r);

/// A glowing screen; touch screens show a few tiles.
void _screen(Canvas c, Rect r, {bool touch = false}) {
  final rr = RRect.fromRectAndRadius(r, const Radius.circular(2));
  c.drawRRect(
    rr.inflate(1.5),
    Paint()
      ..color = AppStyle.glowBlue.withValues(alpha: 0.45)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
  );
  c.drawRRect(
    rr,
    Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF2D6FD6), Color(0xFF173A78)],
      ).createShader(r),
  );
  if (!touch || r.width < 14) return;
  // a strip view: little meters and tiles
  final n = math.max(4, (r.width / 6).floor());
  final bw = r.width / n;
  for (var i = 0; i < n; i++) {
    final hgt = r.height * (0.25 + 0.5 * ((i * 37) % 10) / 10);
    c.drawRect(
      Rect.fromLTWH(r.left + i * bw + bw * 0.25, r.bottom - hgt - r.height * 0.08, bw * 0.5, hgt),
      Paint()..color = const Color(0xFF7FE3C4).withValues(alpha: 0.75),
    );
  }
  c.drawRect(
    Rect.fromLTWH(r.left, r.top, r.width, r.height * 0.16),
    Paint()..color = Colors.white.withValues(alpha: 0.18),
  );
}

/// Desk console in a three-quarter view: a sloped work surface with depth,
/// a raised screen section at the back, and a rim light in the brand colour.
class _DeskPainter extends CustomPainter {
  _DeskPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final k = 0.72 + 0.28 * s.size.clamp(0.0, 1.0);
    // normalised drawing space -> pixels (smaller desks drawn smaller)
    Offset p(double x, double y) => Offset(w * (0.5 + (x - 0.5) * k), h * (0.5 + (y - 0.5) * (0.80 + 0.20 * k)));

    // the work surface, seen from the front-left and above
    final bl = p(0.15, 0.08), br = p(0.86, 0.05), fl = p(0.02, 0.77), fr = p(0.93, 0.83);
    Offset at(double u, double v) {
      final back = Offset.lerp(bl, br, u)!, front = Offset.lerp(fl, fr, u)!;
      return Offset.lerp(back, front, v)!;
    }

    // local scale (pixels per unit of u) at depth v: things shrink towards the back
    double span(double v) => (at(1, v) - at(0, v)).distance;
    Path quad(double u0, double v0, double u1, double v1) => Path()
      ..moveTo(at(u0, v0).dx, at(u0, v0).dy)
      ..lineTo(at(u1, v0).dx, at(u1, v0).dy)
      ..lineTo(at(u1, v1).dx, at(u1, v1).dy)
      ..lineTo(at(u0, v1).dx, at(u0, v1).dy)
      ..close();

    final down = Offset(0, h * 0.10 * k);
    _shadow(canvas, Rect.fromPoints(fl + Offset(w * 0.02, down.dy * 0.6), fr + Offset(w * 0.02, down.dy * 1.6)));

    // right side (a wedge: taller at the back) and the front edge
    final side = Path()
      ..moveTo(br.dx, br.dy)
      ..lineTo(fr.dx, fr.dy)
      ..lineTo(fr.dx, fr.dy + down.dy)
      ..lineTo(br.dx + w * 0.012, br.dy + down.dy * 2.0)
      ..close();
    canvas.drawPath(
      side,
      Paint()
        ..shader = LinearGradient(colors: [const Color(0xFF1B2130), Color.lerp(const Color(0xFF0D1018), accent, 0.10)!])
            .createShader(side.getBounds()),
    );
    final front = Path()
      ..moveTo(fl.dx, fl.dy)
      ..lineTo(fr.dx, fr.dy)
      ..lineTo(fr.dx, fr.dy + down.dy)
      ..lineTo(fl.dx, fl.dy + down.dy)
      ..close();
    canvas.drawPath(front, Paint()..color = const Color(0xFF0B0E15));

    // surface: lighter at the back
    final top = quad(0, 0, 1, 1);
    canvas.drawPath(
      top,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF353F55), Color(0xFF1A2030), Color(0xFF121722)],
          stops: [0, 0.5, 1],
        ).createShader(top.getBounds()),
    );

    final touch = s.kind == ArtKind.touchDesk;
    final noFaders = s.faders == 0 && s.masters == 0;
    final split = noFaders ? 0.80 : (touch ? 0.42 : 0.36);

    // raised screen section at the back
    final bridge = quad(0.02, 0.02, 0.98, split);
    canvas.drawPath(bridge, Paint()..color = Colors.white.withValues(alpha: 0.05));
    canvas.drawLine(at(0.02, split), at(0.98, split), Paint()
      ..color = Colors.black.withValues(alpha: 0.55)
      ..strokeWidth = math.max(0.8, h * 0.012));

    // screens
    var spanL = 0.5, spanR = 0.5;
    if (s.screens > 0 && s.screen > 0) {
      final scale = touch || noFaders ? 1.15 : 1.0;
      final sw = (s.screen * scale).clamp(0.08, 0.80);
      final total = sw * s.screens + 0.03 * (s.screens - 1);
      var left = (!touch && s.screens == 1) ? 0.52 : 0.5 - total / 2;
      spanL = left;
      spanR = left + total;
      final v0 = split * 0.14, v1 = split * (touch || noFaders ? 0.86 : 0.62);
      for (var i = 0; i < s.screens; i++) {
        _quadScreen(canvas, at(left, v0), at(left + sw, v0), at(left + sw, v1), at(left, v1), touch || noFaders, accent);
        left += sw + 0.03;
      }
    }

    // knob fields either side of the screens
    final knobPaint = Paint()..color = const Color(0xFF9AA3B0);
    final ledPaint = Paint()..color = accent;
    void knobs(double u0, double u1) {
      if (u1 - u0 < 0.06) return;
      final cols = math.max(2, ((u1 - u0) / 0.045).floor());
      for (var row = 0; row < 3; row++) {
        final v = split * (0.22 + row * 0.26);
        final r = math.max(0.6, span(v) * 0.0085);
        for (var i = 0; i < cols; i++) {
          final u = u0 + (u1 - u0) * (i + 0.5) / cols;
          canvas.drawCircle(at(u, v), r, (row == 2 && i % 3 == 1) ? ledPaint : knobPaint);
        }
      }
    }

    knobs(0.06, spanL - 0.03);
    knobs(spanR + 0.03, 0.94);

    if (noFaders) {
      _rim(canvas, fl, fr, br, accent, h);
      return;
    }

    // faders: channel bays (gap every 8) and masters at the right
    final channels = s.faders, masters = s.masters;
    final masterW = masters == 0 ? 0.0 : (masters == 1 ? 0.08 : math.min(0.30, 0.032 * masters + 0.03));
    const left = 0.06;
    final right = 0.95 - masterW;
    final bays = math.max(1, (channels / 8).ceil());
    const gap = 0.012;
    final usable = (right - left) - gap * (bays - 1);
    final step = channels == 0 ? 0.0 : usable / channels;
    final vStrip = split + 0.07, vBtn = split + 0.15, vTop = split + 0.22, vBot = 0.95;

    void fader(double u, double pos, Color cap, double slot) {
      final a = at(u, vTop), b = at(u, vBot);
      canvas.drawLine(a, b, Paint()
        ..color = Colors.black
        ..strokeWidth = math.max(0.8, span(0.8) * slot * 0.18));
      final v = vBot - (vBot - vTop) * pos;
      final cw = math.max(1.6, math.min(span(v) * slot * 0.70, w * 0.04));
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: at(u, v), width: cw, height: math.max(1.2, cw * 0.55)),
            const Radius.circular(1)),
        Paint()..color = cap,
      );
    }

    for (var i = 0; i < channels; i++) {
      final u = left + step * (i + 0.5) + gap * (i ~/ 8);
      // scribble-strip colours, then a row of lit select buttons
      final sw = math.max(1.2, span(vStrip) * step * 0.72);
      canvas.drawRect(
        Rect.fromCenter(center: at(u, vStrip), width: sw, height: math.max(1.0, h * 0.030)),
        Paint()..color = _stripColors[i % _stripColors.length],
      );
      canvas.drawCircle(at(u, vBtn), math.max(0.6, span(vBtn) * step * 0.20),
          Paint()..color = i % 4 == 0 ? accent : Colors.white.withValues(alpha: 0.35));
      fader(u, 0.3 + ((i * 7) % 5) * 0.12, const Color(0xFFD5DAE2), step);
    }
    final slot = masters <= 1 ? 0.06 : (masterW - 0.03) / masters;
    for (var m = 0; m < masters; m++) {
      final u = masters == 1 ? 0.915 : right + 0.02 + slot * (m + 0.5);
      final last = m == masters - 1;
      fader(u, last ? 0.75 : 0.40 + (m % 3) * 0.12, last ? accent : const Color(0xFFB0B7C3), math.min(slot, step == 0 ? slot : step));
    }

    _rim(canvas, fl, fr, br, accent, h);
  }

  @override
  bool shouldRepaint(covariant _DeskPainter old) => old.s != s || old.accent != accent;
}

/// Rim light in the brand colour along the front and right edges.
void _rim(Canvas canvas, Offset fl, Offset fr, Offset br, Color accent, double h) {
  final edge = Path()
    ..moveTo(fl.dx, fl.dy)
    ..lineTo(fr.dx, fr.dy)
    ..lineTo(br.dx, br.dy);
  canvas.drawPath(edge, Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = math.max(1.5, h * 0.035)
    ..color = accent.withValues(alpha: 0.55)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, math.max(1.5, h * 0.03)));
  canvas.drawPath(edge, Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = math.max(0.6, h * 0.008)
    ..color = Color.lerp(accent, Colors.white, 0.45)!.withValues(alpha: 0.9));
}

/// A glowing screen on a sloped surface (corners top-left, top-right,
/// bottom-right, bottom-left), with meters when it is a touch screen.
void _quadScreen(Canvas c, Offset tl, Offset tr, Offset brc, Offset blc, bool touch, Color accent) {
  final path = Path()
    ..moveTo(tl.dx, tl.dy)
    ..lineTo(tr.dx, tr.dy)
    ..lineTo(brc.dx, brc.dy)
    ..lineTo(blc.dx, blc.dy)
    ..close();
  final b = path.getBounds();
  c.drawPath(path, Paint()
    ..color = AppStyle.glowBlue.withValues(alpha: 0.55)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, math.max(2, b.height * 0.25)));
  c.drawPath(path, Paint()
    ..shader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF3A86F0), Color(0xFF16397A)],
    ).createShader(b));
  if (b.width < 10) return;
  Offset at(double u, double v) => Offset.lerp(Offset.lerp(tl, tr, u)!, Offset.lerp(blc, brc, u)!, v)!;
  // title bar and a row of meters
  final bar = Path()
    ..moveTo(tl.dx, tl.dy)
    ..lineTo(tr.dx, tr.dy)
    ..lineTo(at(1, 0.16).dx, at(1, 0.16).dy)
    ..lineTo(at(0, 0.16).dx, at(0, 0.16).dy)
    ..close();
  c.drawPath(bar, Paint()..color = Colors.white.withValues(alpha: 0.22));
  if (!touch) return;
  final n = math.max(4, (b.width / 4.5).floor());
  final meter = Paint()
    ..color = const Color(0xFF7FE3C4).withValues(alpha: 0.85)
    ..strokeWidth = math.max(0.8, b.width / n * 0.45);
  for (var i = 0; i < n; i++) {
    final u = (i + 0.5) / n;
    final hgt = 0.25 + 0.5 * ((i * 37) % 10) / 10;
    c.drawLine(at(u, 0.92), at(u, 0.92 - hgt * 0.7), meter);
  }
}

/// Rack unit: front panel with rack ears, optional screen, knobs and inputs.
class _RackPainter extends CustomPainter {
  _RackPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final ph = h * (0.30 + 0.12 * s.units.clamp(1, 4));
    final r = Rect.fromLTWH(w * 0.08, (h - ph) / 2, w * 0.84, ph);
    _shadow(canvas, Rect.fromLTWH(w * 0.10, r.bottom - h * 0.04, w * 0.80, h * 0.10));
    // ears
    final ear = Paint()..color = const Color(0xFF3A4356);
    for (final x in [r.left - w * 0.05, r.right]) {
      final e = Rect.fromLTWH(x, r.top, w * 0.05, r.height);
      canvas.drawRect(e, ear);
      for (var u = 0; u < s.units; u++) {
        canvas.drawCircle(Offset(e.center.dx, r.top + r.height * (u + 0.5) / s.units), w * 0.008, Paint()..color = _hole);
      }
    }
    // top of the unit, seen from above
    final lid = Path()
      ..moveTo(r.left + w * 0.04, r.top - h * 0.10)
      ..lineTo(r.right - w * 0.02, r.top - h * 0.10)
      ..lineTo(r.right, r.top)
      ..lineTo(r.left, r.top)
      ..close();
    canvas.drawPath(lid, Paint()..color = const Color(0xFF353F55));
    final face = Path()..addRRect(RRect.fromRectAndRadius(r, const Radius.circular(2)));
    canvas.drawPath(face, _bodyPaint(r));
    _outline(canvas, face);
    _rim(canvas, r.bottomLeft, r.bottomRight, Offset(r.right, r.top), accent, h * 0.6);
    // unit lines
    for (var u = 1; u < s.units; u++) {
      final y = r.top + r.height * u / s.units;
      canvas.drawLine(Offset(r.left, y), Offset(r.right, y), Paint()..color = Colors.black.withValues(alpha: 0.35));
    }
    var x = r.left + r.width * 0.05;
    if (s.screens > 0 && s.screen > 0) {
      final sw = r.width * s.screen;
      _screen(canvas, Rect.fromLTWH(x, r.top + r.height * 0.14, sw, r.height * 0.62), touch: s.screen > 0.25);
      x += sw + r.width * 0.05;
    }
    // knobs block
    final kr = math.max(1.2, w * 0.012);
    for (var row = 0; row < 2; row++) {
      for (var i = 0; i < 4; i++) {
        canvas.drawCircle(
          Offset(x + i * kr * 3.2, r.top + r.height * (0.32 + row * 0.36)),
          kr,
          Paint()..color = _metal,
        );
      }
    }
    x += kr * 3.2 * 4 + r.width * 0.04;
    // inputs (two rows) up to the right edge
    if (s.jacks > 0) {
      final cols = (s.jacks / 2).ceil();
      final avail = r.right - r.width * 0.04 - x;
      final step = avail / cols;
      final jr = math.min(step * 0.34, r.height * 0.16);
      for (var row = 0; row < 2; row++) {
        for (var i = 0; i < cols; i++) {
          final c = Offset(x + step * (i + 0.5), r.top + r.height * (0.32 + row * 0.36));
          canvas.drawCircle(c, jr, Paint()..color = _hole);
          canvas.drawCircle(c, jr, Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1
            ..color = const Color(0xFF9AA3B0));
        }
      }
    } else {
      // remote-only rack: status lights
      for (var i = 0; i < 3; i++) {
        canvas.drawCircle(Offset(r.right - r.width * (0.08 + i * 0.06), r.center.dy), w * 0.012,
            Paint()..color = i == 0 ? accent : const Color(0xFF3A4356));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RackPainter old) => old.s != s || old.accent != accent;
}

/// Stage box: rugged box with combo inputs, knobs, status light, handles.
class _StageBoxPainter extends CustomPainter {
  _StageBoxPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final bwf = 0.56 + 0.20 * s.size.clamp(0.0, 1.0);
    final bx = Rect.fromLTWH(w * (1 - bwf) / 2, h * 0.24, w * bwf, h * 0.60);
    _shadow(canvas, Rect.fromLTWH(bx.left, h * 0.82, bx.width, h * 0.12));
    final topFace = Path()
      ..moveTo(bx.left + w * 0.04, bx.top - h * 0.12)
      ..lineTo(bx.right - w * 0.04, bx.top - h * 0.12)
      ..lineTo(bx.right, bx.top)
      ..lineTo(bx.left, bx.top)
      ..close();
    canvas.drawPath(topFace, Paint()..color = const Color(0xFF3A4356));
    final front = Path()..addRRect(RRect.fromRectAndRadius(bx, const Radius.circular(4)));
    canvas.drawPath(front, _bodyPaint(bx));
    _outline(canvas, front);
    _rim(canvas, bx.bottomLeft, bx.bottomRight, Offset(bx.right, bx.top), accent, h * 0.6);
    final handle = Paint()
      ..color = _metal
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.02
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(bx.left - w * 0.03, bx.top + h * 0.08), Offset(bx.left - w * 0.03, bx.bottom - h * 0.08), handle);
    canvas.drawLine(Offset(bx.right + w * 0.03, bx.top + h * 0.08), Offset(bx.right + w * 0.03, bx.bottom - h * 0.08), handle);
    final cols = math.max(3, (s.jacks / 2).ceil());
    final stepX = bx.width / cols;
    for (var r = 0; r < 2; r++) {
      for (var i = 0; i < cols; i++) {
        final c = Offset(bx.left + stepX * (i + 0.5), bx.top + bx.height * (0.28 + r * 0.30));
        final jr = math.min(stepX * 0.32, bx.height * 0.12);
        canvas.drawCircle(c, jr, Paint()..color = _hole);
        canvas.drawCircle(c, jr, Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.1
          ..color = const Color(0xFF9AA3B0));
        canvas.drawCircle(c, jr * 0.3, Paint()..color = const Color(0xFF5A6272));
      }
    }
    for (var i = 0; i < 3; i++) {
      canvas.drawCircle(Offset(bx.left + bx.width * (0.16 + i * 0.12), bx.top + bx.height * 0.85), w * 0.016,
          Paint()..color = _metal);
    }
    final led = Offset(bx.right - bx.width * 0.12, bx.top + bx.height * 0.85);
    canvas.drawCircle(led, w * 0.02, Paint()
      ..color = accent
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    canvas.drawCircle(led, w * 0.011, Paint()..color = const Color(0xFFB5FFF4));
  }

  @override
  bool shouldRepaint(covariant _StageBoxPainter old) => old.s != s || old.accent != accent;
}
