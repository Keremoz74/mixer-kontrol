import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_profile.dart';
import 'mixer_catalog.dart';

/// Original, brand-free illustration of a mixer, drawn straight from above
/// like a product shot (desks) or from the front (racks, stage boxes). The
/// layout comes from an [ArtSpec]: fader banks, where the screens and knob
/// blocks are, the inputs on a front panel. No logos, no copied artwork.
class MixerArt extends StatelessWidget {
  const MixerArt({super.key, this.family, this.spec, this.accent, this.width = 120, this.height = 72});

  /// Shorthand when only the family is known.
  final MixerFamily? family;
  final ArtSpec? spec;

  /// Brand colour for lit rings and keys.
  final Color? accent;
  final double width;
  final double height;

  static ArtSpec defaultFor(MixerFamily? f) => switch (f) {
        MixerFamily.xr => const ArtSpec(ArtKind.stagebox, screens: 0, rows: [8, 8], outs: 8, antenna: true,
            tone: ArtTone.black),
        MixerFamily.yamaha || MixerFamily.tascam || MixerFamily.wing =>
          const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.26, tone: ArtTone.black),
        MixerFamily.allenHeath => const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.2, screenAt: 0.66,
            block: ArtBlock.left, tone: ArtTone.black),
        _ => const ArtSpec(ArtKind.desk, faders: 24, bays: [8, 8, 8], screen: 0.14, screenAt: 0.72,
            block: ArtBlock.left, meters: true, tone: ArtTone.graphite),
      };

  @override
  Widget build(BuildContext context) {
    final s = spec ?? defaultFor(family);
    final a = accent ?? MixerCatalog.accentOfFamily(family);
    return SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: switch (s.kind) {
          ArtKind.desk || ArtKind.touchDesk => _DeskPainter(s, a),
          ArtKind.rack => _RackPainter(s, a),
          ArtKind.stagebox => _FrontPanelPainter(s, a),
        },
      ),
    );
  }
}

// ----------------------------------------------------------------- palette

const _hole = Color(0xFF050608);
const _lcd = [
  Color(0xFF3E8EF7), Color(0xFFE5484D), Color(0xFF46A758), Color(0xFFF5D90A), //
  Color(0xFFD864D8), Color(0xFF29C5D6), Color(0xFFEDEDED), Color(0xFFF08A24),
];

/// Panel colours of a finish: top-to-bottom gradient, frame, arm rest.
({Color hi, Color lo, Color frame, Color arm, Color print}) _finish(ArtTone t) => switch (t) {
      ArtTone.silver => (
          hi: const Color(0xFF8C94A3),
          lo: const Color(0xFF6A7282),
          frame: const Color(0xFF3B414C),
          arm: const Color(0xFF23272E),
          print: const Color(0xFF1E2229),
        ),
      ArtTone.graphite => (
          hi: const Color(0xFF4B5059),
          lo: const Color(0xFF3A3E46),
          frame: const Color(0xFF1E2025),
          arm: const Color(0xFF15171A),
          print: const Color(0xFFB9BEC7),
        ),
      ArtTone.black => (
          hi: const Color(0xFF2A2C31),
          lo: const Color(0xFF1C1E22),
          frame: const Color(0xFF0E0F11),
          arm: const Color(0xFF0B0C0E),
          print: const Color(0xFFA8ADB5),
        ),
      ArtTone.navy => (
          hi: const Color(0xFF2F3E58),
          lo: const Color(0xFF223047),
          frame: const Color(0xFF121A28),
          arm: const Color(0xFF0D121C),
          print: const Color(0xFFB4C2D9),
        ),
      ArtTone.charcoal => (
          hi: const Color(0xFF383C44),
          lo: const Color(0xFF2B2E35),
          frame: const Color(0xFF15171B),
          arm: const Color(0xFF101114),
          print: const Color(0xFFB0B5BD),
        ),
    };

// ----------------------------------------------------------------- parts

/// Fit a body of [aspect] (width / height) into [size], with room for the
/// shadow, and return its rectangle.
Rect _fit(Size size, double aspect, {double pad = 0.05}) {
  final w = size.width * (1 - 2 * pad), h = size.height * (1 - 2 * pad);
  final bw = math.min(w, h * aspect), bh = bw / aspect;
  return Rect.fromCenter(center: size.center(Offset.zero), width: bw, height: bh);
}

void _body(Canvas c, RRect r, ({Color hi, Color lo, Color frame, Color arm, Color print}) f, Color accent) {
  // shadow under the unit and a faint glow in the brand colour
  c.drawRRect(r.shift(Offset(0, r.height * 0.03)), Paint()
    ..color = Colors.black.withValues(alpha: 0.7)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, math.max(2, r.height * 0.04)));
  c.drawRRect(r.inflate(1), Paint()
    ..color = accent.withValues(alpha: 0.18)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, math.max(2, r.height * 0.05)));
  c.drawRRect(r, Paint()..color = f.frame);
  final inner = r.deflate(math.max(1, r.width * 0.008));
  c.drawRRect(
    inner,
    Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [f.hi, f.lo],
      ).createShader(inner.outerRect),
  );
  // light from above: a bright top edge
  c.drawLine(Offset(inner.left + inner.tlRadiusX, inner.top + 0.5), Offset(inner.right - inner.trRadiusX, inner.top + 0.5),
      Paint()
        ..color = Colors.white.withValues(alpha: 0.25)
        ..strokeWidth = 1);
}

/// A knob from above: shadow, lit top-left, pointer, optional coloured ring.
void _knob(Canvas c, Offset o, double r, {Color? ring, double turn = 0.3, Color cap = const Color(0xFF3A3F48)}) {
  if (r < 0.5) return;
  if (ring != null && r >= 1) {
    final rr = Rect.fromCircle(center: o, radius: r * 1.5);
    c.drawArc(rr, math.pi * 0.75, math.pi * 1.5 * (0.25 + turn * 0.75), false, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(0.5, r * 0.35)
      ..color = ring);
  }
  if (r >= 1.5) {
    c.drawCircle(o + Offset(r * 0.15, r * 0.3), r * 1.05, Paint()
      ..color = Colors.black.withValues(alpha: 0.6)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * 0.35));
  }
  c.drawCircle(o, r, Paint()
    ..shader = RadialGradient(
      center: const Alignment(-0.4, -0.5),
      colors: [Color.lerp(cap, Colors.white, 0.45)!, cap, Color.lerp(cap, Colors.black, 0.6)!],
      stops: const [0, 0.6, 1],
    ).createShader(Rect.fromCircle(center: o, radius: r)));
  if (r >= 1.8) {
    final a = math.pi * 0.75 + turn * math.pi * 1.5;
    c.drawLine(o + Offset(math.cos(a), math.sin(a)) * r * 0.3, o + Offset(math.cos(a), math.sin(a)) * r * 0.9, Paint()
      ..color = Colors.white
      ..strokeWidth = math.max(0.5, r * 0.18)
      ..strokeCap = StrokeCap.round);
  }
}

/// A rubber key; lit keys glow.
void _key(Canvas c, Rect r, Color? lit) {
  if (r.width < 0.6) return;
  final rr = RRect.fromRectAndRadius(r, Radius.circular(math.max(0.4, r.shortestSide * 0.22)));
  if (lit != null && r.width >= 3) {
    c.drawRRect(rr.inflate(r.width * 0.15), Paint()
      ..color = lit.withValues(alpha: 0.5)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, r.width * 0.3));
  }
  c.drawRRect(
    rr,
    Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: lit != null
            ? [Color.lerp(lit, Colors.white, 0.4)!, lit]
            : const [Color(0xFF6A707B), Color(0xFF3D424B)],
      ).createShader(r),
  );
}

/// A row of [n] keys centred on [cy] between [x0] and [x1].
void _keyRow(Canvas c, double x0, double x1, double cy, int n, double kh, Color? Function(int i) lit, {double fill = 0.7}) {
  final step = (x1 - x0) / n;
  for (var i = 0; i < n; i++) {
    final cx = x0 + step * (i + 0.5);
    _key(c, Rect.fromCenter(center: Offset(cx, cy), width: step * fill, height: kh), lit(i));
  }
}

/// A backlit scribble-strip LCD.
void _scribble(Canvas c, Rect r, Color color) {
  c.drawRect(r.inflate(math.max(0.3, r.width * 0.05)), Paint()..color = _hole);
  c.drawRect(r, Paint()..color = Color.lerp(color, Colors.black, 0.1)!);
  if (r.width >= 7) {
    final p = Paint()
      ..color = Colors.black.withValues(alpha: 0.7)
      ..strokeWidth = math.max(0.4, r.height * 0.14);
    c.drawLine(Offset(r.left + r.width * 0.15, r.top + r.height * 0.35), Offset(r.right - r.width * 0.2, r.top + r.height * 0.35), p);
    c.drawLine(Offset(r.left + r.width * 0.15, r.top + r.height * 0.68), Offset(r.right - r.width * 0.45, r.top + r.height * 0.68), p);
  }
}

/// A fader: slot, scale marks, and the cap at [pos] (0 bottom .. 1 top).
void _fader(Canvas c, double x, double top, double bottom, double slot, double pos, Color cap, Color print) {
  final gw = math.max(0.7, slot * 0.10);
  c.drawLine(Offset(x, top), Offset(x, bottom), Paint()
    ..color = _hole
    ..strokeCap = StrokeCap.round
    ..strokeWidth = gw);
  if (slot >= 8) {
    final tick = Paint()
      ..color = print.withValues(alpha: 0.5)
      ..strokeWidth = 0.5;
    for (var t = 0; t <= 6; t++) {
      final y = top + (bottom - top) * t / 6;
      c.drawLine(Offset(x - slot * 0.32, y), Offset(x - slot * 0.18, y), tick);
    }
  }
  final cw = math.max(1.4, slot * 0.56), ch = math.max(1.4, cw * 0.9);
  final cy = bottom - (bottom - top) * pos;
  final r = Rect.fromCenter(center: Offset(x, cy), width: cw, height: ch);
  if (cw >= 3) {
    c.drawRRect(RRect.fromRectAndRadius(r.shift(Offset(0, ch * 0.35)), Radius.circular(cw * 0.15)), Paint()
      ..color = Colors.black.withValues(alpha: 0.65)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, cw * 0.2));
  }
  c.drawRRect(
    RRect.fromRectAndRadius(r, Radius.circular(math.max(0.4, cw * 0.14))),
    Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color.lerp(cap, Colors.white, 0.35)!, cap, Color.lerp(cap, Colors.black, 0.5)!],
        stops: const [0, 0.5, 1],
      ).createShader(r),
  );
  c.drawLine(Offset(r.left + cw * 0.1, cy), Offset(r.right - cw * 0.1, cy), Paint()
    ..color = Colors.white.withValues(alpha: 0.95)
    ..strokeWidth = math.max(0.4, ch * 0.12));
}

/// A small LED level meter (vertical), green with amber/red at the top.
void _meter(Canvas c, Rect r, double level) {
  c.drawRect(r, Paint()..color = _hole);
  final n = math.max(3, (r.height / 2.2).floor());
  final lit = (n * level).round();
  final seg = r.height / n;
  for (var i = 0; i < n; i++) {
    final on = i < lit;
    final col = i >= n - 1 ? const Color(0xFFE5484D) : (i >= n * 0.7 ? const Color(0xFFF5B83D) : const Color(0xFF4ADE80));
    c.drawRect(
      Rect.fromLTWH(r.left + r.width * 0.15, r.bottom - seg * (i + 1) + seg * 0.15, r.width * 0.7, seg * 0.7),
      Paint()..color = on ? col : col.withValues(alpha: 0.12),
    );
  }
}

/// A screen: bezel, dark UI with tabs, channel view (touch) or text, glass.
void _screen(Canvas c, Rect r, Color accent, {bool touch = true}) {
  c.drawRRect(RRect.fromRectAndRadius(r.inflate(r.shortestSide * 0.04), Radius.circular(r.shortestSide * 0.06)),
      Paint()..color = const Color(0xFF030405));
  final g = r.deflate(r.shortestSide * 0.05);
  c.drawRect(g, Paint()
    ..shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF16305C), Color(0xFF0A1630)],
    ).createShader(g));
  if (g.width < 8) return;
  // tab bar
  final tabs = math.max(3, (g.width / 12).floor());
  final tw = g.width / tabs, th = g.height * 0.11;
  for (var i = 0; i < tabs; i++) {
    c.drawRect(Rect.fromLTWH(g.left + tw * i + tw * 0.06, g.top + th * 0.3, tw * 0.88, th),
        Paint()..color = i == 1 ? accent : Colors.white.withValues(alpha: 0.16));
  }
  final body = Rect.fromLTRB(g.left, g.top + th * 1.6, g.right, g.bottom);
  if (touch) {
    final n = math.max(4, (g.width / 6).floor());
    final cw = body.width / n;
    for (var i = 0; i < n; i++) {
      final x = body.left + cw * (i + 0.5);
      final lvl = 0.25 + 0.65 * ((i * 37) % 10) / 10;
      final mh = body.height * 0.85;
      c.drawLine(Offset(x - cw * 0.18, body.bottom - body.height * 0.06),
          Offset(x - cw * 0.18, body.bottom - body.height * 0.06 - mh * lvl), Paint()
            ..color = lvl > 0.8 ? const Color(0xFFF5B83D) : const Color(0xFF4ADE80)
            ..strokeWidth = math.max(0.5, cw * 0.22));
      if (cw >= 4) {
        c.drawLine(Offset(x + cw * 0.18, body.top + body.height * 0.1), Offset(x + cw * 0.18, body.bottom - body.height * 0.06),
            Paint()
              ..color = Colors.white.withValues(alpha: 0.22)
              ..strokeWidth = math.max(0.4, cw * 0.06));
        final fy = body.top + body.height * (0.25 + 0.5 * (((i * 13) % 10) / 10));
        c.drawLine(Offset(x + cw * 0.02, fy), Offset(x + cw * 0.34, fy), Paint()
          ..color = Colors.white
          ..strokeWidth = math.max(0.5, cw * 0.12));
      }
    }
  } else {
    for (var i = 0; i < 4; i++) {
      final y = body.top + body.height * (0.15 + i * 0.22);
      c.drawLine(Offset(body.left + body.width * 0.06, y), Offset(body.left + body.width * (0.7 - i * 0.1), y), Paint()
        ..color = Colors.white.withValues(alpha: 0.55)
        ..strokeWidth = math.max(0.5, body.height * 0.07));
    }
    _meter(c, Rect.fromLTWH(body.right - body.width * 0.14, body.top + body.height * 0.08, body.width * 0.07, body.height * 0.84), 0.7);
  }
  // glass reflection
  c.drawPath(
    Path()
      ..moveTo(g.left, g.top)
      ..lineTo(g.left + g.width * 0.42, g.top)
      ..lineTo(g.left + g.width * 0.18, g.bottom)
      ..lineTo(g.left, g.bottom)
      ..close(),
    Paint()..color = Colors.white.withValues(alpha: 0.06),
  );
}

/// A block of channel-strip knobs in little framed sections, with a few
/// keys, like the processing area of a console.
void _knobBlock(Canvas c, Rect r, Color accent, Color print, {int seed = 0}) {
  if (r.width < 4 || r.height < 4) return;
  final sections = math.max(1, (r.width / (r.height * 0.9)).round());
  final sw = r.width / sections;
  for (var s = 0; s < sections; s++) {
    final box = Rect.fromLTWH(r.left + sw * s, r.top, sw, r.height).deflate(math.min(sw, r.height) * 0.04);
    c.drawRRect(RRect.fromRectAndRadius(box, Radius.circular(box.shortestSide * 0.05)), Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6
      ..color = print.withValues(alpha: 0.35));
    final cols = 3, rows = 2;
    final kr = math.min(box.width / cols, box.height / (rows + 0.8)) * 0.24;
    for (var row = 0; row < rows; row++) {
      for (var col = 0; col < cols; col++) {
        final o = Offset(box.left + box.width * (col + 0.5) / cols, box.top + box.height * (0.22 + row * 0.38));
        _knob(c, o, kr, ring: (row + col + s + seed) % 2 == 0 ? accent : null, turn: ((row * 5 + col * 3 + s) % 10) / 10);
      }
    }
    _keyRow(c, box.left + box.width * 0.08, box.right - box.width * 0.08, box.bottom - box.height * 0.1, 4, box.height * 0.07,
        (i) => (i + s + seed) % 3 == 0 ? accent : null);
  }
}

/// A grid of keys (scene / view / assign areas).
void _keyGrid(Canvas c, Rect r, int cols, int rows, Color? Function(int col, int row) lit) {
  if (r.width < 3 || r.height < 3) return;
  final cw = r.width / cols, rh = r.height / rows;
  for (var y = 0; y < rows; y++) {
    for (var x = 0; x < cols; x++) {
      _key(c, Rect.fromCenter(center: Offset(r.left + cw * (x + 0.5), r.top + rh * (y + 0.5)), width: cw * 0.7, height: rh * 0.55),
          lit(x, y));
    }
  }
}

// ----------------------------------------------------------------- desks

/// A desk console straight from above.
class _DeskPainter extends CustomPainter {
  _DeskPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final f = _finish(s.tone);
    final groups = s.groups;
    final noFaders = groups.isEmpty && s.masters == 0;
    final channels = groups.fold<int>(0, (a, b) => a + b) + s.tail;
    final slots = channels + s.masters * 1.6 + (s.rightCol ? 2.5 : 0);
    final aspect = s.aspect ?? (noFaders ? 1.45 : (0.95 + slots * 0.034).clamp(1.0, 2.3));
    final box = _fit(size, aspect, pad: s.bridge ? 0.04 : 0.05);
    final rr = RRect.fromRectAndRadius(box, Radius.circular(box.shortestSide * 0.05));

    if (noFaders) {
      _touchOnly(canvas, box, rr, f);
      return;
    }
    if (s.look != null && _looks.containsKey(s.look)) {
      var body = box;
      if (s.bridge && s.look == 'cl') {
        // free-standing meter bridge above the middle of the desk
        final bh = box.height * 0.17;
        body = Rect.fromLTRB(box.left, box.top + bh, box.right, box.bottom);
        _meterBridge(canvas, Rect.fromLTWH(box.left + box.width * 0.25, box.top, box.width * 0.48, bh * 0.92));
      }
      final brr = RRect.fromRectAndRadius(body, Radius.circular(body.shortestSide * 0.05));
      _body(canvas, brr, f, accent);
      _looks[s.look]!(canvas, body, f, accent, s);
      _armRest(canvas, body, brr, f);
      return;
    }

    _body(canvas, rr, f, accent);
    final W = box.width, H = box.height;
    double X(double u) => box.left + W * u;
    double Y(double v) => box.top + H * v;

    // meter bridge across the top
    var top = 0.04;
    if (s.bridge) {
      final br = Rect.fromLTRB(X(0.02), Y(0.02), X(0.98), Y(0.10));
      canvas.drawRect(br, Paint()..color = _hole);
      final n = math.max(8, channels);
      final mw = br.width / n;
      for (var i = 0; i < n; i++) {
        _meter(canvas, Rect.fromLTWH(br.left + mw * i + mw * 0.2, br.top + br.height * 0.1, mw * 0.6, br.height * 0.8),
            0.3 + 0.6 * ((i * 37) % 10) / 10);
      }
      top = 0.13;
    }

    // ---- fader layout across the body
    final right = s.rightCol ? 0.88 : 0.975;
    final gaps = (groups.length - 1) * 0.5 + (s.masters > 0 ? 0.7 : 0) + (s.tail > 0 ? 0.7 : 0);
    final units = channels + s.masters * 1.4 + gaps;
    final step = (right - 0.025) / units;
    final chU = <double>[];
    final bays = <(double, double)>[];
    var u = 0.025;
    for (var g = 0; g < groups.length; g++) {
      final a = u;
      for (var i = 0; i < groups[g]; i++) {
        chU.add(u + step / 2);
        u += step;
      }
      bays.add((a, u));
      if (g < groups.length - 1) u += step * 0.5;
    }
    final masterU = <double>[];
    if (s.masters > 0) {
      u += step * 0.7;
      for (var m = 0; m < s.masters; m++) {
        masterU.add(u + step * 0.7);
        u += step * 1.4;
      }
    }
    if (s.tail > 0) {
      u += step * 0.7;
      final a = u;
      for (var i = 0; i < s.tail; i++) {
        chU.add(u + step / 2);
        u += step;
      }
      bays.add((a, u));
    }

    // ---- vertical zones
    final touch = s.kind == ArtKind.touchDesk;
    final deep = s.block == ArtBlock.left || s.block == ArtBlock.both;
    final split = top + (deep ? 0.36 : (touch ? 0.30 : 0.28));
    final vKnob = split + 0.04;
    final vSel = split + (s.chKnobs ? 0.085 : 0.035);
    final vLcd = vSel + 0.045;
    final vMute = vLcd + 0.05;
    final vF0 = vMute + 0.045, vF1 = 0.88;

    // seam between the top section and the channel strips
    canvas.drawLine(Offset(X(0.015), Y(split)), Offset(X(0.985), Y(split)), Paint()
      ..color = Colors.black.withValues(alpha: 0.6)
      ..strokeWidth = math.max(0.6, H * 0.006));
    canvas.drawLine(Offset(X(0.015), Y(split) + 1), Offset(X(0.985), Y(split) + 1), Paint()
      ..color = Colors.white.withValues(alpha: 0.10)
      ..strokeWidth = 0.6);

    // ---- screens
    final screens = <Rect>[];
    if (s.screens > 0 && s.screen > 0) {
      final sh = (split - top) * (touch ? 0.86 : 0.62);
      final sy = Y(top + (split - top) * 0.07);
      if (s.screenBays != null && bays.isNotEmpty) {
        for (final b in s.screenBays!) {
          final (a, z) = bays[b.clamp(0, bays.length - 1)];
          final c = (a + z) / 2, sw = math.min(s.screen, (z - a) * 0.95);
          screens.add(Rect.fromLTWH(X(c - sw / 2), sy, W * sw, H * sh));
        }
      } else {
        final total = s.screen * s.screens + 0.02 * (s.screens - 1);
        var left = (s.screenAt - total / 2).clamp(0.02, 0.98 - total);
        for (var i = 0; i < s.screens; i++) {
          screens.add(Rect.fromLTWH(X(left), sy, W * s.screen, H * sh));
          left += s.screen + 0.02;
        }
      }
    }
    final sl = screens.isEmpty ? box.center.dx : screens.map((r) => r.left).reduce(math.min);
    final sr = screens.isEmpty ? box.center.dx : screens.map((r) => r.right).reduce(math.max);

    // ---- top section: knob blocks and key areas either side of the screens
    final zoneTop = Y(top + 0.01), zoneBot = Y(split - 0.015);
    final leftZone = Rect.fromLTRB(X(0.02), zoneTop, sl - W * 0.015, zoneBot);
    final rightZone = Rect.fromLTRB(sr + W * 0.015, zoneTop, X(0.98), zoneBot);
    void keys(Rect r) => _keyGrid(canvas, r, math.max(2, (r.width / (H * 0.05)).floor()), 3,
        (x, y) => (x + y * 2) % 5 == 0 ? _lcd[(x + y) % _lcd.length] : null);
    void knobsRow(Rect r) {
      // a looser area: two rows of knobs and a row of keys
      final n = math.max(2, (r.width / (H * 0.06)).floor());
      final kr = math.min(r.width / n, r.height / 3) * 0.26;
      for (var row = 0; row < 2; row++) {
        for (var i = 0; i < n; i++) {
          _knob(canvas, Offset(r.left + r.width * (i + 0.5) / n, r.top + r.height * (0.2 + row * 0.34)), kr,
              turn: ((i * 3 + row) % 10) / 10);
        }
      }
      _keyRow(canvas, r.left, r.right, r.top + r.height * 0.85, n, r.height * 0.1, (i) => i % 4 == 1 ? accent : null);
    }

    switch (s.block) {
      case ArtBlock.left:
        _knobBlock(canvas, leftZone, accent, f.print);
        keys(rightZone);
      case ArtBlock.right:
        keys(leftZone);
        _knobBlock(canvas, rightZone, accent, f.print, seed: 1);
      case ArtBlock.both:
        _knobBlock(canvas, leftZone, accent, f.print);
        _knobBlock(canvas, rightZone, accent, f.print, seed: 1);
      case ArtBlock.none:
        knobsRow(leftZone);
        knobsRow(rightZone);
    }
    for (final r in screens) {
      if (s.raised) {
        // a swivel screen: deep shadow beneath, thick housing
        canvas.drawRRect(RRect.fromRectAndRadius(r.shift(Offset(0, r.height * 0.12)).inflate(r.width * 0.02), Radius.circular(4)),
            Paint()
              ..color = Colors.black.withValues(alpha: 0.7)
              ..maskFilter = MaskFilter.blur(BlurStyle.normal, r.height * 0.08));
        canvas.drawRRect(RRect.fromRectAndRadius(r.inflate(r.width * 0.03), Radius.circular(r.width * 0.03)),
            Paint()..color = const Color(0xFF15171B));
      }
      _screen(canvas, r, accent, touch: touch);
    }
    // non-touch desks: data knobs under the small screen
    if (!touch && screens.length == 1) {
      final r = screens.first;
      final ky = r.bottom + (Y(split) - r.bottom) * 0.45;
      for (var i = 0; i < 6; i++) {
        _knob(canvas, Offset(r.left + r.width * (i + 0.5) / 6, ky), r.width / 6 * 0.28, turn: i / 6);
      }
    }

    // ---- channel strips
    for (var i = 0; i < chU.length; i++) {
      final x = X(chU[i]);
      final sw = W * step;
      final color = _lcd[(i ~/ 8 + (i % 8 < 4 ? 0 : 3)) % _lcd.length];
      if (s.chKnobs) _knob(canvas, Offset(x, Y(vKnob)), sw * 0.3, ring: accent, turn: ((i * 3) % 10) / 10);
      _key(canvas, Rect.fromCenter(center: Offset(x, Y(vSel)), width: sw * 0.62, height: H * 0.026),
          i % 8 == 2 ? accent : null);
      final lcd = Rect.fromCenter(
          center: Offset(s.meters ? x - sw * 0.1 : x, Y(vLcd)), width: sw * (s.meters ? 0.6 : 0.8), height: H * 0.036);
      _scribble(canvas, lcd, color);
      if (s.meters) {
        _meter(canvas, Rect.fromLTWH(lcd.right + sw * 0.06, lcd.top - H * 0.008, sw * 0.16, lcd.height + H * 0.016),
            0.3 + 0.6 * ((i * 29) % 10) / 10);
      }
      _key(canvas, Rect.fromCenter(center: Offset(x - sw * 0.2, Y(vMute)), width: sw * 0.34, height: H * 0.022),
          i % 5 == 1 ? const Color(0xFFF5D90A) : null);
      _key(canvas, Rect.fromCenter(center: Offset(x + sw * 0.2, Y(vMute)), width: sw * 0.34, height: H * 0.022),
          i % 7 == 3 ? const Color(0xFFE5484D) : null);
      _fader(canvas, x, Y(vF0), Y(vF1), sw, 0.25 + ((i * 7) % 5) * 0.13, const Color(0xFF9EA4AE), f.print);
    }
    for (var m = 0; m < masterU.length; m++) {
      final last = m == masterU.length - 1;
      final x = X(masterU[m]);
      _key(canvas, Rect.fromCenter(center: Offset(x, Y(vSel)), width: W * step * 0.8, height: H * 0.026), null);
      _meter(canvas, Rect.fromCenter(center: Offset(x, Y(vLcd + 0.01)), width: W * step * 0.3, height: H * 0.08), 0.75);
      _fader(canvas, x, Y(vF0), Y(vF1), W * step * 1.3, last ? 0.72 : 0.5,
          last ? const Color(0xFFD9363E) : const Color(0xFF9EA4AE), f.print);
    }

    // ---- right column of keys (scenes / assign / mute groups)
    if (s.rightCol) {
      final col = Rect.fromLTRB(X(0.895), Y(split + 0.02), X(0.98), Y(vF1));
      canvas.drawRRect(RRect.fromRectAndRadius(col, const Radius.circular(2)), Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.6
        ..color = f.print.withValues(alpha: 0.3));
      _keyGrid(canvas, col.deflate(col.width * 0.08), 2, 9, (x, y) => (y == 2 || y == 5) ? const Color(0xFF46C27A) : null);
    }

    _armRest(canvas, box, rr, f);
  }

  /// Fader-less touch mixer (CQ): wings with handles, a big screen,
  /// encoders and keys underneath.
  void _touchOnly(Canvas canvas, Rect box, RRect rr, ({Color hi, Color lo, Color frame, Color arm, Color print}) f) {
    final W = box.width, H = box.height;
    // handles on the wings
    final handle = Paint()
      ..color = const Color(0xFF3B414C)
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.2, W * 0.025);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTRB(box.left - W * 0.02, box.top + H * 0.15, box.left + W * 0.05, box.bottom - H * 0.15),
        Radius.circular(W * 0.03)), handle);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTRB(box.right - W * 0.05, box.top + H * 0.15, box.right + W * 0.02, box.bottom - H * 0.15),
        Radius.circular(W * 0.03)), handle);
    final body = RRect.fromRectAndRadius(box.deflate(W * 0.04), Radius.circular(H * 0.06));
    _body(canvas, body, f, accent);
    final inner = body.outerRect;
    final sw = inner.width * s.screen.clamp(0.4, 0.75);
    final scr = Rect.fromLTWH(inner.center.dx - sw / 2, inner.top + inner.height * 0.08, sw, inner.height * 0.6);
    _screen(canvas, scr, accent);
    final ky = inner.top + inner.height * 0.84;
    final n = math.max(3, s.encoders);
    for (var i = 0; i < n; i++) {
      _knob(canvas, Offset(scr.left + sw * 0.3 + sw * 0.7 * (i + 0.5) / n, ky), inner.height * 0.07, ring: accent, turn: i / n);
    }
    _keyRow(canvas, scr.left, scr.left + sw * 0.28, ky, 5, inner.height * 0.05, (i) => i == 4 ? accent : null);
    if (s.antenna) {
      final base = Offset(inner.right - inner.width * 0.06, inner.top + inner.height * 0.1);
      canvas.drawCircle(base, inner.height * 0.04, Paint()..color = const Color(0xFF15171B));
      canvas.drawLine(base, base + Offset(inner.width * 0.12, -inner.height * 0.03), Paint()
        ..color = const Color(0xFF2A2E35)
        ..strokeWidth = math.max(1.2, inner.height * 0.035)
        ..strokeCap = StrokeCap.round);
    }
  }

  @override
  bool shouldRepaint(covariant _DeskPainter old) => old.s != s || old.accent != accent;
}

/// Padded arm rest along the front of a desk.
void _armRest(Canvas canvas, Rect box, RRect rr, ({Color hi, Color lo, Color frame, Color arm, Color print}) f) {
  final y = box.top + box.height * 0.905;
  final arm = RRect.fromLTRBAndCorners(box.left, y, box.right, box.bottom, bottomLeft: rr.blRadius, bottomRight: rr.brRadius);
  canvas.drawRRect(
    arm,
    Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color.lerp(f.arm, Colors.white, 0.14)!, f.arm, Colors.black],
        stops: const [0, 0.4, 1],
      ).createShader(arm.outerRect),
  );
  canvas.drawLine(Offset(box.left + 2, y), Offset(box.right - 2, y), Paint()
    ..color = Colors.white.withValues(alpha: 0.18)
    ..strokeWidth = 0.8);
}

// ----------------------------------------------------------------- photo-based panels

typedef _Fin = ({Color hi, Color lo, Color frame, Color arm, Color print});
typedef _Look = void Function(Canvas c, Rect box, _Fin f, Color accent, ArtSpec s);

/// Panels drawn after a reference photo of the model (layout only).
final Map<String, _Look> _looks = {
  'dm3': _dm3,
  'dm7': _dm7,
  'dm7c': _dm7c,
  'tf': _tf,
  'ql': _ql,
  'cl': _cl,
};

const _orange = Color(0xFFF59E2B);
const _white = Color(0xFFE8EBEF);

/// Yamaha DM3: big touch screen top left, USB / phones top right; eight
/// strips and the master (three rows of keys, the bottom one orange ON
/// keys); Touch and Turn knob, fader-bank keys and a framed block of four
/// orange user keys on the right.
void _dm3(Canvas c, Rect b, _Fin f, Color accent, ArtSpec s) {
  final W = b.width, H = b.height;
  Offset P(double u, double v) => Offset(b.left + W * u, b.top + H * v);
  Rect R(double u0, double v0, double u1, double v1) => Rect.fromPoints(P(u0, v0), P(u1, v1));

  _screen(c, R(0.06, 0.05, 0.74, 0.43), accent);
  // USB, phones and level
  c.drawRRect(RRect.fromRectAndRadius(R(0.85, 0.07, 0.91, 0.11), const Radius.circular(1)), Paint()..color = _hole);
  c.drawRRect(RRect.fromRectAndRadius(R(0.80, 0.14, 0.94, 0.30), Radius.circular(W * 0.01)), Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 0.7
    ..color = f.print.withValues(alpha: 0.4));
  _knob(c, P(0.87, 0.19), W * 0.022, turn: 0.55);
  c.drawCircle(P(0.87, 0.26), W * 0.016, Paint()..color = _hole);

  // eight channel strips and the master
  const cols = 9;
  final x0 = 0.07, x1 = 0.66;
  final step = (x1 - x0) / cols;
  for (var i = 0; i < cols; i++) {
    final u = x0 + step * (i + 0.5);
    final kw = W * step * 0.62, kh = H * 0.028;
    if (i == 0) _key(c, Rect.fromCenter(center: P(u, 0.475), width: kw, height: kh), const Color(0xFF46C27A));
    _key(c, Rect.fromCenter(center: P(u, 0.52), width: kw, height: kh), i == cols - 1 ? null : _white);
    _key(c, Rect.fromCenter(center: P(u, 0.565), width: kw, height: kh), null);
    _key(c, Rect.fromCenter(center: P(u, 0.61), width: kw, height: kh), _orange);
    final master = i == cols - 1;
    _fader(c, P(u, 0).dx, P(0, 0.665).dy, P(0, 0.875).dy, W * step * (master ? 1.05 : 0.9),
        master ? 0.78 : 0.62 + 0.04 * (i % 3), master ? const Color(0xFFD9363E) : const Color(0xFFA5ABB4), f.print);
  }

  // Touch and Turn: label strip and the knob
  c.drawRect(R(0.69, 0.47, 0.79, 0.52), Paint()..color = const Color(0xFFDADDE2));
  _knob(c, P(0.86, 0.50), W * 0.035, turn: 0.4, cap: const Color(0xFF50555E));
  // fader bank keys
  for (var r = 0; r < 2; r++) {
    for (var k = 0; k < 2; k++) {
      _key(c, Rect.fromCenter(center: P(0.74 + k * 0.13, 0.575 + r * 0.05), width: W * 0.08, height: H * 0.03),
          r == 0 && k == 0 ? _white : null);
    }
  }
  // user defined keys
  final box = R(0.70, 0.69, 0.94, 0.87);
  c.drawRRect(RRect.fromRectAndRadius(box, Radius.circular(W * 0.01)), Paint()..color = const Color(0xFF15171B));
  c.drawRect(Rect.fromLTWH(box.left, box.top, box.width, box.height * 0.16), Paint()..color = accent.withValues(alpha: 0.85));
  for (var r = 0; r < 2; r++) {
    for (var k = 0; k < 2; k++) {
      _key(c, Rect.fromCenter(center: Offset(box.left + box.width * (0.3 + k * 0.4), box.top + box.height * (0.42 + r * 0.32)),
          width: box.width * 0.24, height: box.height * 0.18), _orange);
    }
  }
}

/// A round push key (TF style) with an optional lit colour and a dark rim.
void _roundKey(Canvas c, Offset o, double r, Color? lit, {Color rim = const Color(0xFF15171B)}) {
  if (r < 0.5) return;
  c.drawCircle(o, r * 1.18, Paint()..color = rim);
  if (lit != null && r >= 2) {
    c.drawCircle(o, r * 1.3, Paint()
      ..color = lit.withValues(alpha: 0.35)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * 0.5));
  }
  c.drawCircle(o, r, Paint()
    ..shader = RadialGradient(
      center: const Alignment(-0.3, -0.4),
      colors: lit != null
          ? [Color.lerp(lit, Colors.white, 0.5)!, lit]
          : const [Color(0xFF8D939C), Color(0xFF4C515A)],
    ).createShader(Rect.fromCircle(center: o, radius: r)));
}

/// A knob with a ring of amber LEDs around it (TF gain / FX knobs).
void _ledKnob(Canvas c, Offset o, double r) {
  final n = 13;
  for (var i = 0; i < n; i++) {
    final a = math.pi * 0.75 + math.pi * 1.5 * i / (n - 1);
    c.drawCircle(o + Offset(math.cos(a), math.sin(a)) * r * 1.5, math.max(0.4, r * 0.13),
        Paint()..color = i < 9 ? const Color(0xFFF5B83D) : const Color(0xFF3A3020));
  }
  _knob(c, o, r, turn: 0.6, cap: const Color(0xFF2A2D33));
}

/// Fader with a black cap and a white line (TF / DM style), on a light or dark lane.
void _darkFader(Canvas c, double x, double top, double bottom, double slot, double pos, Color cap, Color print) =>
    _fader(c, x, top, bottom, slot, pos, cap, print);

/// One DM7-style channel strip: knob with an LED ring colour under it,
/// SEL / CUE / ON keys, and a silver-capped fader.
void _dmStrip(Canvas c, double x, double sw, double Function(double v) Y, Color led, bool first, Color print) {
  _knob(c, Offset(x, Y(0.515)), sw * 0.28, turn: 0.5, cap: const Color(0xFF22252A));
  c.drawLine(Offset(x - sw * 0.2, Y(0.548)), Offset(x + sw * 0.2, Y(0.548)), Paint()
    ..color = led
    ..strokeWidth = math.max(0.6, sw * 0.08));
  final kw = sw * 0.66, kh = (Y(0.02) - Y(0)) * 1.1;
  _key(c, Rect.fromCenter(center: Offset(x, Y(0.575)), width: kw, height: kh), first ? const Color(0xFF46C27A) : null);
  _key(c, Rect.fromCenter(center: Offset(x, Y(0.605)), width: kw * 0.8, height: kh * 0.85), null);
  _key(c, Rect.fromCenter(center: Offset(x, Y(0.635)), width: kw, height: kh), const Color(0xFFF07A3A));
  _fader(c, x, Y(0.68), Y(0.87), sw, 0.72, const Color(0xFFD4D8DE), print);
}

/// A small key with an LCD label above it (user defined keys).
void _lcdKey(Canvas c, Rect r, Color accent) {
  final lcd = Rect.fromLTWH(r.left, r.top, r.width, r.height * 0.55);
  c.drawRect(lcd, Paint()..color = const Color(0xFFDCE6F5));
  c.drawRect(Rect.fromLTWH(lcd.left, lcd.top, lcd.width, lcd.height * 0.25), Paint()..color = accent.withValues(alpha: 0.8));
  _key(c, Rect.fromLTWH(r.left + r.width * 0.15, r.top + r.height * 0.68, r.width * 0.3, r.height * 0.28), null);
  _key(c, Rect.fromLTWH(r.left + r.width * 0.55, r.top + r.height * 0.68, r.width * 0.3, r.height * 0.28), null);
}

/// DM7: two 12" screens over the two banks of 12, key columns beside them,
/// a small touch screen and the user-key / knob panel on the right; banks
/// of 12 + 12 + 4 with Touch-and-Turn sections between, and the E/F strips,
/// scene memory and jog wheel at the right.
void _dm7(Canvas c, Rect b, _Fin f, Color accent, ArtSpec s) {
  final W = b.width, H = b.height;
  double X(double u) => b.left + W * u;
  double Y(double v) => b.top + H * v;
  Rect R(double u0, double v0, double u1, double v1) => Rect.fromLTRB(X(u0), Y(v0), X(u1), Y(v1));
  // raised screen section
  c.drawRect(R(0.02, 0.03, 0.98, 0.475), Paint()..color = const Color(0xFF1B1D21));
  c.drawLine(Offset(X(0.745), Y(0.03)), Offset(X(0.745), Y(0.97)), Paint()
    ..color = Colors.black
    ..strokeWidth = math.max(0.8, W * 0.003));
  _screen(c, R(0.06, 0.10, 0.345, 0.44), accent);
  _screen(c, R(0.385, 0.10, 0.615, 0.44), accent);
  _screen(c, R(0.655, 0.13, 0.725, 0.44), accent, touch: false);
  for (final u in [0.362, 0.633]) {
    for (var i = 0; i < 6; i++) {
      _key(c, Rect.fromCenter(center: Offset(X(u), Y(0.13 + i * 0.055)), width: W * 0.012, height: H * 0.022), i == 1 ? const Color(0xFF46C27A) : null);
    }
  }
  for (final u in [0.672, 0.71]) {
    c.drawRect(Rect.fromCenter(center: Offset(X(u), Y(0.06)), width: W * 0.014, height: H * 0.016), Paint()..color = _hole);
  }
  // user defined keys and knobs
  _keyRow(c, X(0.76), X(0.89), Y(0.11), 4, H * 0.02, (i) => i == 3 ? const Color(0xFF29C5D6) : null);
  for (var r = 0; r < 3; r++) {
    for (var k = 0; k < 2; k++) {
      _lcdKey(c, R(0.76 + k * 0.066, 0.16 + r * 0.1, 0.815 + k * 0.066, 0.245 + r * 0.1), accent);
    }
  }
  for (var r = 0; r < 2; r++) {
    for (var k = 0; k < 2; k++) {
      _knob(c, Offset(X(0.912 + k * 0.035), Y(0.20 + r * 0.1)), W * 0.009, turn: 0.4);
    }
  }
  _knob(c, Offset(X(0.912), Y(0.40)), W * 0.009, ring: accent);
  _knob(c, Offset(X(0.947), Y(0.40)), W * 0.009, ring: accent);
  // strips
  const leds = [Color(0xFFE5484D), Color(0xFFE5484D), Color(0xFFF5D90A), Color(0xFF46C27A)];
  void bank(double u0, double u1, int n, bool firstGreen) {
    final sw = W * (u1 - u0) / n;
    for (var i = 0; i < n; i++) {
      _dmStrip(c, X(u0) + sw * (i + 0.5), sw, Y, leds[(i * 4 ~/ n) % 4], firstGreen && i == 0, f.print);
    }
  }

  bank(0.06, 0.345, 12, true);
  bank(0.385, 0.615, 12, true);
  bank(0.655, 0.735, 4, false);
  bank(0.755, 0.80, 2, false);
  // touch and turn + user keys between the banks
  for (final u in [0.365, 0.635]) {
    _knob(c, Offset(X(u), Y(0.52)), W * 0.008, cap: const Color(0xFFB8BEC7));
    for (var i = 0; i < 3; i++) {
      _lcdKey(c, Rect.fromCenter(center: Offset(X(u), Y(0.63 + i * 0.09)), width: W * 0.03, height: H * 0.07), accent);
    }
  }
  // panner, scene memory, jog
  for (var i = 0; i < 2; i++) {
    _knob(c, Offset(X(0.83 + i * 0.1), Y(0.54)), W * 0.008);
  }
  _keyRow(c, X(0.82), X(0.96), Y(0.58), 4, H * 0.02, (i) => null);
  c.drawRect(R(0.86, 0.62, 0.92, 0.665), Paint()..color = const Color(0xFFDCE6F5));
  _keyRow(c, X(0.82), X(0.96), Y(0.70), 4, H * 0.022, (i) => i == 3 ? _white : null);
  final jog = Offset(X(0.92), Y(0.77));
  c.drawCircle(jog, W * 0.032, Paint()..color = const Color(0xFF111316));
  c.drawCircle(jog, W * 0.027, Paint()
    ..shader = const RadialGradient(center: Alignment(-0.3, -0.4), colors: [Color(0xFFE6E9EE), Color(0xFF7D838D)])
        .createShader(Rect.fromCircle(center: jog, radius: W * 0.027)));
  for (var i = 0; i < 3; i++) {
    _key(c, Rect.fromCenter(center: Offset(X(0.835), Y(0.73 + i * 0.04)), width: W * 0.014, height: H * 0.02), null);
  }
  _keyRow(c, X(0.82), X(0.96), Y(0.865), 4, H * 0.02, (i) => i == 0 ? _orange : null);
}

/// DM7 Compact: one big screen, a key column and a small screen; a bank of
/// 12, the Touch-and-Turn / user-key column, and a bank of 4.
void _dm7c(Canvas c, Rect b, _Fin f, Color accent, ArtSpec s) {
  final W = b.width, H = b.height;
  double X(double u) => b.left + W * u;
  double Y(double v) => b.top + H * v;
  Rect R(double u0, double v0, double u1, double v1) => Rect.fromLTRB(X(u0), Y(v0), X(u1), Y(v1));
  c.drawRect(R(0.03, 0.03, 0.97, 0.475), Paint()..color = const Color(0xFF1B1D21));
  _screen(c, R(0.08, 0.12, 0.62, 0.45), accent);
  _screen(c, R(0.70, 0.17, 0.93, 0.45), accent, touch: false);
  for (var i = 0; i < 6; i++) {
    _key(c, Rect.fromCenter(center: Offset(X(0.665), Y(0.15 + i * 0.05)), width: W * 0.035, height: H * 0.022), i == 1 ? const Color(0xFF46C27A) : null);
  }
  for (final u in [0.74, 0.83]) {
    c.drawRect(Rect.fromCenter(center: Offset(X(u), Y(0.08)), width: W * 0.03, height: H * 0.016), Paint()..color = _hole);
  }
  const leds = [Color(0xFFE5484D), Color(0xFFF5D90A), Color(0xFF46C27A)];
  final sw = W * 0.54 / 12;
  for (var i = 0; i < 12; i++) {
    _dmStrip(c, X(0.08) + sw * (i + 0.5), sw, Y, leds[i * 3 ~/ 12], i == 0, f.print);
  }
  final sw2 = W * 0.22 / 4;
  for (var i = 0; i < 4; i++) {
    _dmStrip(c, X(0.71) + sw2 * (i + 0.5), sw2, Y, const [_white, Color(0xFF3E8EF7), Color(0xFF46C27A), _white][i], false, f.print);
  }
  _knob(c, Offset(X(0.665), Y(0.515)), W * 0.014, cap: const Color(0xFFB8BEC7));
  for (var i = 0; i < 3; i++) {
    _lcdKey(c, Rect.fromCenter(center: Offset(X(0.665), Y(0.63 + i * 0.09)), width: W * 0.07, height: H * 0.07), accent);
  }
}

/// Yamaha TF: black top panel with the control cluster on the right (ST IN
/// strips, screen with four user knobs, Touch and Turn, user keys A-F, FX
/// strips, master meter) and a dotted grille filling the rest; silver
/// channel area with banks of 8 on striped lanes (round SEL / CUE / ON
/// keys, peak LEDs, a black name display with colour bars, black fader
/// caps), the stereo strip and the column of AUX keys.
void _tf(Canvas c, Rect b, _Fin f, Color accent, ArtSpec s) {
  final W = b.width, H = b.height;
  double Y(double v) => b.top + H * v;
  final banks = s.groups.length;
  // black top panel
  final topH = H * 0.335;
  c.drawRRect(
      RRect.fromRectAndCorners(Rect.fromLTWH(b.left, b.top, W, topH),
          topLeft: Radius.circular(b.shortestSide * 0.05), topRight: Radius.circular(b.shortestSide * 0.05)),
      Paint()..color = const Color(0xFF111214));
  // cluster: sized by the height, aligned right
  final u = H * 0.0097; // one "percent" of the TF1 width
  final cx0 = b.right - u * 93;
  double CX(double p) => cx0 + u * p;
  // dotted grille where the cluster leaves room
  if (cx0 - b.left > u * 12) {
    final dot = Paint()..color = const Color(0xFF2B2E33);
    for (var y = Y(0.06); y < b.top + topH - u * 3; y += u * 2.2) {
      for (var x = b.left + u * 4; x < cx0 - u * 3; x += u * 2.2) {
        c.drawCircle(Offset(x, y), math.max(0.3, u * 0.35), dot);
      }
    }
  }
  // ST IN
  c.drawRect(Rect.fromLTRB(CX(7), Y(0.10), CX(24), Y(0.31)), Paint()..color = const Color(0xFF1E2024));
  for (var i = 0; i < 2; i++) {
    final x = CX(11 + i * 8.5);
    _roundKey(c, Offset(x, Y(0.155)), u * 1.7, null);
    _roundKey(c, Offset(x, Y(0.19)), u * 1.1, null);
    _roundKey(c, Offset(x, Y(0.24)), u * 1.3, const Color(0xFFF2B35A));
    _ledKnob(c, Offset(x, Y(0.285)), u * 1.4);
  }
  // screen + user knobs + touch and turn
  _screen(c, Rect.fromLTRB(CX(28), Y(0.11), CX(57), Y(0.28)), accent);
  for (var i = 0; i < 4; i++) {
    _knob(c, Offset(CX(34 + i * 5.7), Y(0.325)), u * 1.5, turn: 0.4);
  }
  c.drawCircle(Offset(CX(61), Y(0.31)), u * 4.2, Paint()..color = const Color(0xFF1C1E22));
  _knob(c, Offset(CX(61), Y(0.305)), u * 1.6, cap: const Color(0xFFD9DCE1));
  // user keys A-F, mute, FX strips, fader bank
  c.drawRect(Rect.fromLTRB(CX(61), Y(0.105), CX(74), Y(0.18)), Paint()..color = const Color(0xFF1E2024));
  for (var r = 0; r < 2; r++) {
    for (var k = 0; k < 3; k++) {
      _roundKey(c, Offset(CX(64 + k * 3.6), Y(0.13 + r * 0.03)), u * 1.0, null, rim: _orange);
    }
  }
  c.drawRect(Rect.fromLTRB(CX(75), Y(0.105), CX(80), Y(0.18)), Paint()..color = const Color(0xFF1E2024));
  _roundKey(c, Offset(CX(77.5), Y(0.13)), u * 1.0, null);
  _roundKey(c, Offset(CX(77.5), Y(0.16)), u * 1.0, null);
  for (var r = 0; r < 2; r++) {
    final y = Y(0.205 + r * 0.04);
    c.drawRect(Rect.fromLTRB(CX(61), y - u * 2, CX(80), y + u * 2), Paint()..color = const Color(0xFF1E2024));
    _roundKey(c, Offset(CX(64), y), u * 1.0, null);
    _roundKey(c, Offset(CX(67.5), y), u * 0.9, null);
    _roundKey(c, Offset(CX(73), y), u * 0.9, const Color(0xFFF2B35A));
    _ledKnob(c, Offset(CX(77.5), y), u * 1.2);
  }
  c.drawRect(Rect.fromLTRB(CX(67), Y(0.305), CX(79), Y(0.33)), Paint()..color = const Color(0xFF9AA0A9));
  for (var i = 0; i < 3; i++) {
    _roundKey(c, Offset(CX(69 + i * 3.8), Y(0.317)), u * 0.95, i == 0 ? const Color(0xFF46C27A) : null);
  }
  _meter(c, Rect.fromLTRB(CX(81.5), Y(0.11), CX(83.5), Y(0.24)), 0.75);
  _meter(c, Rect.fromLTRB(CX(83.8), Y(0.11), CX(85.8), Y(0.24)), 0.7);
  c.drawCircle(Offset(CX(84), Y(0.27)), u * 0.8, Paint()..color = _hole);
  _knob(c, Offset(CX(84), Y(0.31)), u * 1.0, turn: 0.7, cap: const Color(0xFFD9DCE1));

  // ---- silver channel area
  final top = Y(0.40), bot = Y(0.935);
  final auxW = u * 4;
  final x0 = b.left + u * 7, x1 = b.right - u * 7 - auxW;
  final strips = banks * 8 + 1;
  final sw = (x1 - x0 - u * 1.5 * banks) / strips;
  var x = x0;
  final colors = [for (var i = 0; i < 8; i++) HSVColor.fromAHSV(1, (230 + i * 40) % 360, 0.75, 0.9).toColor()];
  void strip(double cx, int i, bool stereo) {
    final lane = Rect.fromLTRB(cx - sw / 2, top, cx + sw / 2, bot);
    c.drawRect(lane, Paint()..color = i.isEven ? const Color(0xFFD5D8DD) : const Color(0xFFAEB3BA));
    _roundKey(c, Offset(cx, Y(0.445)), sw * 0.32, (i == 0 && !stereo) ? const Color(0xFF46C27A) : null);
    _roundKey(c, Offset(cx, Y(0.48)), sw * 0.2, null);
    for (var l = 0; l < 3; l++) {
      c.drawCircle(Offset(cx - sw * 0.2, Y(0.5 + l * 0.008)), math.max(0.3, sw * 0.04),
          Paint()..color = l == 0 ? const Color(0xFFE5484D) : const Color(0xFF6A6F77));
    }
    _roundKey(c, Offset(cx, Y(0.535)), sw * 0.27, const Color(0xFFF2B35A));
    _fader(c, cx, Y(0.66), Y(0.90), sw, 0.62, stereo ? const Color(0xFFD9363E) : const Color(0xFF1E2024), const Color(0xFF3A3F48));
  }

  for (var g = 0; g < banks; g++) {
    final bx0 = x;
    for (var i = 0; i < 8; i++) {
      strip(x + sw / 2, i, false);
      x += sw;
    }
    // name display with colour bars
    final disp = Rect.fromLTRB(bx0, Y(0.565), x, Y(0.615));
    c.drawRect(disp, Paint()..color = const Color(0xFF0B0C0E));
    for (var i = 0; i < 8; i++) {
      final cx = bx0 + sw * (i + 0.5);
      if (sw > 6) {
        c.drawLine(Offset(cx - sw * 0.25, disp.top + disp.height * 0.4), Offset(cx + sw * 0.2, disp.top + disp.height * 0.4), Paint()
          ..color = Colors.white.withValues(alpha: 0.8)
          ..strokeWidth = math.max(0.4, disp.height * 0.12));
      }
      c.drawLine(Offset(cx - sw * 0.42, disp.bottom - disp.height * 0.15), Offset(cx + sw * 0.42, disp.bottom - disp.height * 0.15),
          Paint()
            ..color = colors[(g * 2 + i ~/ 4) % 8]
            ..strokeWidth = math.max(0.6, disp.height * 0.14));
    }
    x += u * 1.5;
  }
  strip(x + sw / 2, 1, true);
  c.drawRect(Rect.fromLTRB(x, Y(0.565), x + sw, Y(0.615)), Paint()..color = const Color(0xFF0B0C0E));
  // AUX keys
  final ax = b.right - u * 6 - auxW / 2;
  c.drawRect(Rect.fromLTRB(ax - auxW / 2, top, ax + auxW / 2, Y(0.86)), Paint()..color = const Color(0xFFBFC3C9));
  for (var i = 0; i < 16; i++) {
    _roundKey(c, Offset(ax, Y(0.42 + i * 0.027 + (i >= 8 ? 0.02 : 0))), auxW * 0.3, null);
  }
  _roundKey(c, Offset(ax, Y(0.895)), auxW * 0.33, null, rim: _orange);
}

/// A free-standing LED meter bridge (rows of red over amber over green).
void _meterBridge(Canvas c, Rect r) {
  c.drawRRect(RRect.fromRectAndRadius(r.shift(Offset(0, r.height * 0.06)), Radius.circular(r.height * 0.1)), Paint()
    ..color = Colors.black.withValues(alpha: 0.6)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, r.height * 0.08));
  c.drawRRect(RRect.fromRectAndRadius(r, Radius.circular(r.height * 0.1)), Paint()..color = const Color(0xFF2B2E33));
  final inner = r.deflate(r.height * 0.1);
  c.drawRect(inner, Paint()..color = const Color(0xFF07080A));
  final n = math.max(10, (inner.width / 2.4).floor());
  final cw = inner.width / n;
  for (var i = 0; i < n; i++) {
    if (i % 9 == 8) continue; // gaps between groups
    final lvl = 0.45 + 0.5 * ((i * 37) % 10) / 10;
    final x = inner.left + cw * (i + 0.5);
    final h = inner.height * lvl;
    c.drawLine(Offset(x, inner.bottom), Offset(x, inner.bottom - h * 0.45), Paint()
      ..color = const Color(0xFFB7D12F)
      ..strokeWidth = cw * 0.6);
    c.drawLine(Offset(x, inner.bottom - h * 0.45), Offset(x, inner.bottom - h), Paint()
      ..color = const Color(0xFFE5482F)
      ..strokeWidth = cw * 0.6);
  }
}

/// A Yamaha QL/CL-style strip: keys, a small LED meter column, ON key,
/// a pale name display and a silver fader. [y] maps 0..1 within the strip zone.
void _qlStrip(Canvas c, double x, double sw, double Function(double v) y, {bool knob = false, Color lcd = const Color(0xFFBFD8F2)}) {
  if (knob) _knob(c, Offset(x, y(0.03)), sw * 0.3, turn: 0.5, cap: const Color(0xFF1E2024));
  final k0 = knob ? 0.10 : 0.02;
  _key(c, Rect.fromCenter(center: Offset(x, y(k0)), width: sw * 0.6, height: sw * 0.3), null);
  _meter(c, Rect.fromCenter(center: Offset(x, y(k0 + 0.09)), width: sw * 0.22, height: y(0.1) - y(0)), 0.4 + 0.4 * ((x * 7).floor() % 3) / 3);
  _key(c, Rect.fromCenter(center: Offset(x, y(k0 + 0.18)), width: sw * 0.6, height: sw * 0.3), const Color(0xFFF07A3A));
  c.drawRect(Rect.fromCenter(center: Offset(x, y(k0 + 0.25)), width: sw * 0.84, height: y(0.05) - y(0)), Paint()..color = lcd);
  _fader(c, x, y(0.42), y(0.97), sw, 0.72, const Color(0xFFD9DDE3), const Color(0xFFA8ADB5));
}

/// Dotted speaker-style grille.
void _grille(Canvas c, Rect r, double pitch) {
  c.drawRect(r, Paint()..color = const Color(0xFF16181B));
  final dot = Paint()..color = const Color(0xFF2C2F35);
  for (var y = r.top + pitch; y < r.bottom - pitch / 2; y += pitch) {
    for (var x = r.left + pitch; x < r.right - pitch / 2; x += pitch) {
      c.drawCircle(Offset(x, y), math.max(0.3, pitch * 0.18), dot);
    }
  }
}

/// Coloured Selected-Channel knobs (two columns of coloured caps, then a grid).
void _selectedChannel(Canvas c, Rect r) {
  c.drawRect(r, Paint()..color = const Color(0xFF34373D));
  const caps = [Color(0xFFC0324A), Color(0xFFC0324A), Color(0xFF3557C8), Color(0xFF3557C8), Color(0xFF2CA6C0), Color(0xFF2CA6C0), Color(0xFF7A4BC8)];
  final kr = math.min(r.width * 0.07, r.height / 16);
  for (var i = 0; i < 7; i++) {
    for (var k = 0; k < 2; k++) {
      _knob(c, Offset(r.left + r.width * (0.12 + k * 0.18), r.top + r.height * (0.12 + i * 0.125)), kr, cap: caps[i], turn: 0.4);
    }
  }
  for (var i = 0; i < 6; i++) {
    for (var k = 0; k < 3; k++) {
      _knob(c, Offset(r.left + r.width * (0.55 + k * 0.17), r.top + r.height * (0.14 + i * 0.145)), kr * 0.9,
          cap: i < 2 ? const Color(0xFF8A9099) : const Color(0xFF2E8F7E), turn: 0.5);
    }
  }
}

/// Yamaha QL: speaker grille on the left (QL5), key columns either side of
/// the screen, the coloured Selected Channel knobs; banks of 8 and 2 masters.
void _ql(Canvas c, Rect b, _Fin f, Color accent, ArtSpec s) {
  final W = b.width, H = b.height;
  final banks = s.groups.length;
  final u = H * 0.01;
  final cx0 = b.right - u * 95;
  double CX(double p) => cx0 + u * p;
  double Y(double v) => b.top + H * v;
  if (cx0 - b.left > u * 10) _grille(c, Rect.fromLTRB(b.left + u * 4, Y(0.05), cx0, Y(0.36)), u * 2);
  for (final p in [6.0, 11.0]) {
    for (var i = 0; i < 7; i++) {
      _key(c, Rect.fromCenter(center: Offset(CX(p), Y(0.08 + i * 0.038)), width: u * 3.2, height: u * 1.6), i == 0 ? const Color(0xFF46C27A) : null);
    }
  }
  _screen(c, Rect.fromLTRB(CX(15), Y(0.05), CX(62), Y(0.36)), accent);
  _selectedChannel(c, Rect.fromLTRB(CX(64), Y(0.05), CX(84), Y(0.30)));
  for (var i = 0; i < 7; i++) {
    _key(c, Rect.fromCenter(center: Offset(CX(89), Y(0.08 + i * 0.038)), width: u * 3.2, height: u * 1.6), null);
  }
  _knob(c, Offset(CX(68), Y(0.335)), u * 1.4, cap: const Color(0xFFD9DCE1));
  _keyRow(c, CX(74), CX(92), Y(0.34), 4, u * 1.4, (i) => i == 0 ? const Color(0xFF46C27A) : null);
  // strips
  final x0 = b.left + W * 0.03, x1 = b.right - W * 0.03;
  final units = banks * 8 + 2 + banks * 0.5 + 0.5;
  final sw = (x1 - x0) / units;
  double y(double v) => Y(0.41 + v * 0.47);
  var x = x0;
  const lcds = [Color(0xFFBFD8F2), Color(0xFFE8B8C8), Color(0xFFBFE8CF), Color(0xFFE9E1B4)];
  for (var g = 0; g < banks; g++) {
    for (var i = 0; i < 8; i++) {
      _qlStrip(c, x + sw / 2, sw, y, lcd: lcds[(g + i ~/ 4) % 4]);
      x += sw;
    }
    x += sw * 0.5;
  }
  x += sw * 0.5;
  for (var i = 0; i < 2; i++) {
    _qlStrip(c, x + sw / 2, sw, y, lcd: Color.lerp(const Color(0xFFE5484D), Colors.white, 0.5)!);
    x += sw;
  }
}

/// Yamaha CL: grille and tablet bar on the left, Selected Channel knobs,
/// the screen above the Centralogic bank, user knobs; input banks, a key
/// column, the Centralogic bank of 8, scene memory with orange user keys,
/// (CL5: another bank of 8) and two masters.
void _cl(Canvas c, Rect b, _Fin f, Color accent, ArtSpec s) {
  final W = b.width, H = b.height;
  double Y(double v) => b.top + H * v;
  final inputs = s.groups.length - 1; // the last group is the Centralogic bank
  final rightBank = s.tail > 0;
  final units = 8.0 * (inputs + 1 + (rightBank ? 1 : 0)) + 0.6 * inputs + 2.0 + 5.0 + 2.6 + (rightBank ? 0.6 : 0);
  final x0 = b.left + W * 0.025;
  final sw = (W * 0.95) / units;
  double y(double v) => Y(0.55 + v * 0.33);
  var x = x0;
  final bankX = <double>[];
  for (var g = 0; g < inputs; g++) {
    bankX.add(x);
    for (var i = 0; i < 8; i++) {
      _qlStrip(c, x + sw / 2, sw, y, knob: true);
      x += sw;
    }
    x += sw * 0.6;
  }
  // key column
  _keyGrid(c, Rect.fromLTWH(x, y(0.15), sw * 1.6, y(0.95) - y(0.15)), 1, 8, (cc, r) => r == 0 ? const Color(0xFF46C27A) : null);
  x += sw * 2.0;
  // Centralogic bank (with lane lines reaching up to the screen)
  final clX = x;
  for (var i = 0; i < 8; i++) {
    c.drawLine(Offset(x + sw / 2, Y(0.40)), Offset(x + sw / 2, y(0)), Paint()
      ..color = Colors.white.withValues(alpha: 0.12)
      ..strokeWidth = 0.6);
    _qlStrip(c, x + sw / 2, sw, y, knob: true);
    x += sw;
  }
  final clEnd = x;
  // scene memory and user keys
  final sm = Rect.fromLTWH(x + sw * 0.3, y(0.02), sw * 4.4, y(0.95) - y(0.02));
  _keyRow(c, sm.left, sm.left + sm.width * 0.55, sm.top + sm.height * 0.05, 3, sw * 0.3, (i) => null);
  _knob(c, Offset(sm.right - sm.width * 0.15, sm.top + sm.height * 0.08), sw * 0.35, cap: const Color(0xFF1E2024));
  _keyGrid(c, Rect.fromLTWH(sm.left, sm.top + sm.height * 0.2, sm.width * 0.45, sm.height * 0.75), 1, 8, (cc, r) => r == 2 ? const Color(0xFF46C27A) : null);
  _keyGrid(c, Rect.fromLTWH(sm.left + sm.width * 0.55, sm.top + sm.height * 0.25, sm.width * 0.42, sm.height * 0.65), 2, 8,
      (cc, r) => const Color(0xFFF07A3A));
  x += sw * 5.0;
  if (rightBank) {
    for (var i = 0; i < 8; i++) {
      _qlStrip(c, x + sw / 2, sw, y, knob: true);
      x += sw;
    }
    x += sw * 0.6;
  }
  x += sw * 0.6;
  for (var i = 0; i < 2; i++) {
    _qlStrip(c, x + sw / 2, sw, y, knob: true, lcd: const Color(0xFFF5C46B));
    x += sw;
  }

  // ---- top panel
  final scr = Rect.fromLTRB(clX - sw * 0.2, Y(0.05), clEnd + sw * 1.2, Y(0.40));
  final selW = sw * 6.5;
  final sel = Rect.fromLTRB(scr.left - selW - sw * 0.3, Y(0.05), scr.left - sw * 0.3, Y(0.42));
  c.drawRect(Rect.fromLTRB(sel.left - sw * 0.2, Y(0.03), scr.right + sw * 0.3, Y(0.43)), Paint()..color = const Color(0xFF3A3D43));
  if (sel.left - b.left > W * 0.06) {
    _grille(c, Rect.fromLTRB(b.left + W * 0.02, Y(0.05), sel.left - sw * 0.6, Y(0.42)), math.max(1.5, H * 0.018));
    // tablet bar
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTRB(b.left + W * 0.04, Y(0.455), b.left + W * 0.04 + sw * 6, Y(0.475)), const Radius.circular(2)),
        Paint()..color = const Color(0xFFB5BAC2));
  }
  _selectedChannel(c, sel);
  _screen(c, scr, accent);
  for (var i = 0; i < 4; i++) {
    _knob(c, Offset(scr.right + sw * 1.5, Y(0.10 + i * 0.075)), sw * 0.35, cap: const Color(0xFF1E2024));
  }
  final rightFree = Rect.fromLTRB(scr.right + sw * 3, Y(0.05), b.right - W * 0.02, Y(0.30));
  if (s.screens > 0 && !s.bridge && rightFree.width > sw * 4) {
    // CL5: meters built into the top panel
    _meterBridge(c, Rect.fromLTWH(rightFree.left, rightFree.top, rightFree.width * 0.9, rightFree.height * 0.6));
  }
  c.drawRect(Rect.fromCenter(center: Offset(b.right - W * 0.06, Y(0.33)), width: sw * 0.9, height: sw * 0.5), Paint()..color = _hole);
}

/// TF-RACK front: screen on the left, fader-bank keys and Touch and Turn,
/// USB ports, a row of orange-ringed user keys, four user knobs, mute keys,
/// phones and level; chrome handles on the ears.
void _tfRack(Canvas c, Rect box, Rect face, Color accent) {
  final W = face.width, H = face.height;
  double X(double u) => face.left + W * u;
  double Y(double v) => face.top + H * v;
  for (final ex in [box.left, box.right - box.width * 0.045]) {
    final bar = RRect.fromRectAndRadius(
        Rect.fromLTWH(ex + box.width * 0.008, face.top + H * 0.18, box.width * 0.028, H * 0.64), Radius.circular(box.width * 0.012));
    c.drawRRect(bar, Paint()
      ..shader = const LinearGradient(colors: [Color(0xFF6E7580), Color(0xFFE0E4EA), Color(0xFF6E7580)]).createShader(bar.outerRect));
  }
  _screen(c, Rect.fromLTRB(X(0.03), Y(0.18), X(0.35), Y(0.86)), accent);
  for (var i = 0; i < 4; i++) {
    _roundKey(c, Offset(X(0.39), Y(0.20 + i * 0.12)), H * 0.045, i == 0 ? const Color(0xFF46C27A) : null);
  }
  c.drawCircle(Offset(X(0.40), Y(0.80)), H * 0.11, Paint()..color = const Color(0xFF1C1E22));
  _knob(c, Offset(X(0.40), Y(0.78)), H * 0.055, cap: const Color(0xFFD9DCE1));
  for (var i = 0; i < 2; i++) {
    c.drawRect(Rect.fromCenter(center: Offset(X(0.47), Y(0.24 + i * 0.16)), width: W * 0.025, height: H * 0.05), Paint()..color = _hole);
  }
  c.drawRect(Rect.fromLTRB(X(0.53), Y(0.12), X(0.68), Y(0.28)), Paint()..color = const Color(0xFF0B0C0E));
  c.drawRect(Rect.fromLTRB(X(0.51), Y(0.44), X(0.86), Y(0.62)), Paint()..color = const Color(0xFF1E2024));
  for (var i = 0; i < 6; i++) {
    _roundKey(c, Offset(X(0.54 + i * 0.058), Y(0.53)), H * 0.04, null, rim: _orange);
  }
  for (var i = 0; i < 4; i++) {
    _knob(c, Offset(X(0.56 + i * 0.085), Y(0.80)), H * 0.06, turn: 0.4);
  }
  c.drawRect(Rect.fromLTRB(X(0.74), Y(0.10), X(0.86), Y(0.36)), Paint()..color = const Color(0xFF1E2024));
  _roundKey(c, Offset(X(0.775), Y(0.17)), H * 0.035, null);
  _roundKey(c, Offset(X(0.775), Y(0.29)), H * 0.035, null);
  _roundKey(c, Offset(X(0.83), Y(0.20)), H * 0.04, null, rim: _orange);
  c.drawCircle(Offset(X(0.92), Y(0.56)), H * 0.035, Paint()..color = _hole);
  _knob(c, Offset(X(0.92), Y(0.78)), H * 0.05, turn: 0.7, cap: const Color(0xFFD9DCE1));
}

// ----------------------------------------------------------------- sockets

/// XLR/jack combo input: black housing, grey ring, three pins and the jack.
void _combo(Canvas c, Offset o, double r) {
  c.drawCircle(o, r, Paint()..color = const Color(0xFF17191D));
  c.drawCircle(o, r * 0.86, Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = math.max(0.5, r * 0.14)
    ..shader = const SweepGradient(colors: [Color(0xFFB8BFC9), Color(0xFF5C636E), Color(0xFFB8BFC9)])
        .createShader(Rect.fromCircle(center: o, radius: r)));
  c.drawCircle(o, r * 0.28, Paint()..color = _hole);
  if (r >= 3) {
    for (final a in [-2.4, -0.74, 1.57]) {
      c.drawCircle(o + Offset(math.cos(a), math.sin(a)) * r * 0.55, r * 0.1, Paint()..color = _hole);
    }
  }
}

/// XLR output: metal face with three pin holes and a latch.
void _xlr(Canvas c, Offset o, double r) {
  c.drawCircle(o, r, Paint()
    ..shader = RadialGradient(colors: const [Color(0xFF9AA2AD), Color(0xFF4A505A)])
        .createShader(Rect.fromCircle(center: o, radius: r)));
  c.drawCircle(o, r * 0.72, Paint()..color = const Color(0xFF1B1E23));
  for (final a in [-2.6, -0.54, 1.57]) {
    c.drawCircle(o + Offset(math.cos(a), math.sin(a)) * r * 0.4, math.max(0.4, r * 0.12), Paint()..color = const Color(0xFF8C939D));
  }
}

/// 1/4" jack: ring and hole.
void _jack(Canvas c, Offset o, double r) {
  c.drawCircle(o, r, Paint()..color = const Color(0xFF8C939D));
  c.drawCircle(o, r * 0.62, Paint()..color = const Color(0xFF2A2E35));
  c.drawCircle(o, r * 0.36, Paint()..color = _hole);
}

void _rj45(Canvas c, Offset o, double s) {
  c.drawRect(Rect.fromCenter(center: o, width: s * 1.3, height: s), Paint()..color = const Color(0xFF8C939D));
  c.drawRect(Rect.fromCenter(center: o, width: s * 1.05, height: s * 0.78), Paint()..color = _hole);
}

// ----------------------------------------------------------------- racks

/// Rack unit from the front: ears with slotted holes, screen, keys, knobs, inputs.
class _RackPainter extends CustomPainter {
  _RackPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final f = _finish(s.tone);
    final aspect = 19 / (1.75 * s.units.clamp(1, 4)) * 0.92;
    final box = _fit(size, aspect, pad: 0.04);
    final ear = box.width * 0.045;
    final face = Rect.fromLTRB(box.left + ear, box.top, box.right - ear, box.bottom);
    // ears
    for (final ex in [box.left, box.right - ear]) {
      final e = Rect.fromLTWH(ex, box.top, ear, box.height);
      canvas.drawRect(e, Paint()..color = Color.lerp(f.frame, Colors.white, 0.12)!);
      for (var u = 0; u < s.units; u++) {
        final cy = box.top + box.height * (u + 0.5) / s.units;
        canvas.drawRRect(
            RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(e.center.dx, cy), width: ear * 0.6, height: ear * 0.32),
                Radius.circular(ear * 0.16)),
            Paint()..color = _hole);
      }
    }
    _body(canvas, RRect.fromRectAndRadius(face, const Radius.circular(2)), f, accent);
    if (s.look == 'tfrack') {
      _tfRack(canvas, box, face, accent);
      return;
    }
    final W = face.width, H = face.height;
    var x = face.left + W * 0.03;
    if (s.screens > 0 && s.screen > 0) {
      final sw = W * s.screen * 0.9;
      _screen(canvas, Rect.fromLTWH(x, face.top + H * 0.12, sw, H * 0.76), accent, touch: s.screen > 0.25);
      x += sw + W * 0.03;
    }
    // keys and data knobs
    final kcols = s.units == 1 ? 6 : 4;
    _keyGrid(canvas, Rect.fromLTWH(x, face.top + H * 0.12, W * 0.12, H * (s.units == 1 ? 0.7 : 0.4)), kcols ~/ 2, s.units == 1 ? 2 : 3,
        (c, r) => (c + r) % 3 == 0 ? accent : null);
    if (s.units > 1) {
      for (var i = 0; i < 3; i++) {
        _knob(canvas, Offset(x + W * 0.02 + W * 0.04 * i, face.top + H * 0.72), H * 0.07, turn: i / 3);
      }
    }
    x += W * 0.15;
    // inputs: combos in two rows (or status LEDs on remote-only units)
    if (s.jacks > 0) {
      final cols = (s.jacks / 2).ceil();
      final avail = face.right - W * 0.03 - x;
      final step = avail / cols;
      final r = math.min(step * 0.40, H * 0.17);
      for (var row = 0; row < 2; row++) {
        for (var i = 0; i < cols; i++) {
          _combo(canvas, Offset(x + step * (i + 0.5), face.top + H * (0.3 + row * 0.4)), r);
        }
      }
    } else {
      for (var i = 0; i < 4; i++) {
        canvas.drawCircle(Offset(face.right - W * (0.05 + i * 0.035), face.center.dy), H * 0.06,
            Paint()..color = i == 0 ? accent : const Color(0xFF3A3F48));
      }
      _rj45(canvas, Offset(face.right - W * 0.25, face.center.dy), H * 0.3);
    }
  }

  @override
  bool shouldRepaint(covariant _RackPainter old) => old.s != s || old.accent != accent;
}

// ----------------------------------------------------------------- front panels

/// Front panel of a stage-box mixer (X Air / MR / Qu-SB / CQ-20B): tubular
/// handles at the sides, a connector strip on top (network, MIDI, USB),
/// rows of combo inputs (or line jacks), the XLR outputs, phones and level,
/// and the Wi-Fi antenna.
class _FrontPanelPainter extends CustomPainter {
  _FrontPanelPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final f = _finish(s.tone);
    final rows = s.rows ?? const [8, 8];
    final maxCols = rows.fold<int>(0, math.max);
    final lines = rows.length + (s.outs > 0 ? 1 : 0) + 0.8;
    final aspect = (maxCols * 0.26 + 0.55) / (lines * 0.25 + 0.1);
    final box = _fit(size, aspect, pad: 0.06);
    final hw = box.width * 0.045;
    final face = Rect.fromLTRB(box.left + hw, box.top + (s.antenna ? box.height * 0.10 : 0), box.right - hw, box.bottom);
    // antenna (behind the top edge)
    if (s.antenna) {
      final base = Offset(face.right - face.width * 0.16, face.top + face.height * 0.12);
      canvas.drawLine(base, Offset(base.dx, box.top - box.height * 0.04), Paint()
        ..color = const Color(0xFF1F2227)
        ..strokeWidth = math.max(1.4, face.width * 0.022)
        ..strokeCap = StrokeCap.round);
    }
    _body(canvas, RRect.fromRectAndRadius(face, Radius.circular(face.height * 0.05)), f, accent);
    // tubular handles
    for (final hx in [box.left, face.right]) {
      final bar = RRect.fromRectAndRadius(Rect.fromLTWH(hx + hw * 0.15, face.top - face.height * 0.02, hw * 0.7, face.height * 1.04),
          Radius.circular(hw * 0.35));
      canvas.drawRRect(bar, Paint()..color = const Color(0xFF16181C));
      canvas.drawRRect(bar.deflate(hw * 0.12), Paint()
        ..shader = const LinearGradient(colors: [Color(0xFF6E7580), Color(0xFFE0E4EA), Color(0xFF6E7580)])
            .createShader(bar.outerRect));
    }
    final W = face.width, H = face.height;
    final lineH = H / lines;
    final step = W * 0.88 / maxCols;
    final x0 = face.left + W * 0.06;
    // connector strip
    final cy = face.top + lineH * 0.45;
    final cs = math.max(1.2, lineH * 0.32);
    _rj45(canvas, Offset(x0 + cs, cy), cs);
    _combo(canvas, Offset(x0 + cs * 3.4, cy), cs * 0.65);
    _combo(canvas, Offset(x0 + cs * 5.0, cy), cs * 0.65);
    canvas.drawRect(Rect.fromCenter(center: Offset(x0 + cs * 7, cy), width: cs * 0.8, height: cs * 0.6), Paint()..color = const Color(0xFF8C939D));
    _rj45(canvas, Offset(x0 + cs * 9, cy), cs);
    canvas.drawCircle(Offset(x0 + cs * 11, cy), cs * 0.25, Paint()
      ..color = accent
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5));
    if (s.antenna) {
      canvas.drawCircle(Offset(face.right - W * 0.16, face.top + H * 0.12), cs * 0.6, Paint()..color = const Color(0xFF15171B));
    }
    // inputs
    for (var r = 0; r < rows.length; r++) {
      final y = face.top + lineH * (r + 1.3);
      final line = s.lineRow && r == 1;
      for (var i = 0; i < rows[r]; i++) {
        final o = Offset(x0 + step * (i + 0.5), y);
        if (line) {
          _jack(canvas, o, math.min(step, lineH) * 0.26);
        } else {
          _combo(canvas, o, math.min(step, lineH) * 0.40);
        }
      }
    }
    // outputs, phones and level
    if (s.outs > 0) {
      final y = face.top + lineH * (rows.length + 1.3);
      for (var i = 0; i < s.outs; i++) {
        _xlr(canvas, Offset(x0 + step * (i + 0.5), y), math.min(step, lineH) * 0.34);
      }
      _jack(canvas, Offset(face.right - W * 0.12, y), math.min(step, lineH) * 0.22);
      _knob(canvas, Offset(face.right - W * 0.06, y), math.min(step, lineH) * 0.2, turn: 0.6);
    }
  }

  @override
  bool shouldRepaint(covariant _FrontPanelPainter old) => old.s != s || old.accent != accent;
}
