import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'mixer_catalog.dart';

/// Original, brand-free illustration of a mixer. Drawn from an [ArtSpec]
/// (form, number of faders and screens, size), so models can be told apart
/// without copying any real product.
class MixerArt extends StatelessWidget {
  const MixerArt({super.key, this.family, this.spec, this.width = 120, this.height = 72});

  /// Shorthand when only the family is known.
  final MixerFamily? family;
  final ArtSpec? spec;
  final double width;
  final double height;

  static ArtSpec defaultFor(MixerFamily? f) => switch (f) {
        MixerFamily.xr => const ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0),
        MixerFamily.yamaha || MixerFamily.tascam || MixerFamily.wing =>
          const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.26),
        MixerFamily.allenHeath => const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.24),
        _ => const ArtSpec(ArtKind.desk, faders: 16, masters: 9, screen: 0.14),
      };

  @override
  Widget build(BuildContext context) {
    final s = spec ?? defaultFor(family);
    return SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: switch (s.kind) {
          ArtKind.desk || ArtKind.touchDesk => _DeskPainter(s),
          ArtKind.rack => _RackPainter(s),
          ArtKind.stagebox => _StageBoxPainter(s),
        },
      ),
    );
  }
}

const _bodyTop = Color(0xFF2C3446);
const _bodyBottom = Color(0xFF151A24);
const _metal = Color(0xFF8E96A3);
const _hole = Color(0xFF0A0D12);
const _stripColors = [
  Color(0xFFE5484D), Color(0xFF46A758), Color(0xFFF5D90A), Color(0xFF3E8EF7), //
  Color(0xFFD864D8), Color(0xFF29C5D6), Color(0xFFEDEDED), Color(0xFFF08A24),
];

void _shadow(Canvas c, Rect r) => c.drawOval(
      r,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

void _outline(Canvas c, Path p) => c.drawPath(
      p,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.18),
    );

Paint _bodyPaint(Rect r) => Paint()
  ..shader = const LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [_bodyTop, _bodyBottom],
  ).createShader(r);

/// A glowing screen; touch screens show a few tiles.
void _screen(Canvas c, Rect r, {bool touch = false}) {
  final rr = RRect.fromRectAndRadius(r, const Radius.circular(2));
  c.drawRRect(
    rr.inflate(1.5),
    Paint()
      ..color = AppStyle.glowBlue.withValues(alpha: 0.45)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
  );
  c.drawRRect(
    rr,
    Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF2D6FD6), Color(0xFF173A78)],
      ).createShader(r),
  );
  if (!touch || r.width < 14) return;
  // a strip view: little meters and tiles
  final n = math.max(4, (r.width / 6).floor());
  final bw = r.width / n;
  for (var i = 0; i < n; i++) {
    final hgt = r.height * (0.25 + 0.5 * ((i * 37) % 10) / 10);
    c.drawRect(
      Rect.fromLTWH(r.left + i * bw + bw * 0.25, r.bottom - hgt - r.height * 0.08, bw * 0.5, hgt),
      Paint()..color = const Color(0xFF7FE3C4).withValues(alpha: 0.75),
    );
  }
  c.drawRect(
    Rect.fromLTWH(r.left, r.top, r.width, r.height * 0.16),
    Paint()..color = Colors.white.withValues(alpha: 0.18),
  );
}

void _fader(Canvas c, double x, double top, double bottom, double pos, Color cap, double capW) {
  c.drawLine(
    Offset(x, top),
    Offset(x, bottom),
    Paint()
      ..color = Colors.black
      ..strokeWidth = math.max(1, capW * 0.22),
  );
  final y = bottom - (bottom - top) * pos;
  c.drawRRect(
    RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(x, y), width: capW, height: capW * 0.62),
      const Radius.circular(1.2),
    ),
    Paint()..color = cap,
  );
}

/// Desk console (with or without a large touch screen).
class _DeskPainter extends CustomPainter {
  _DeskPainter(this.s);
  final ArtSpec s;

  @override
  void paint(Canvas canvas, Size size) {
    final fullW = size.width, h = size.height;
    final bw = fullW * (0.62 + 0.38 * s.size.clamp(0.0, 1.0));
    final x0 = (fullW - bw) / 2;
    double px(double f) => x0 + bw * f;

    _shadow(canvas, Rect.fromLTWH(px(0.04), h * 0.86, bw * 0.92, h * 0.12));
    final body = Path()
      ..moveTo(px(0.08), h * 0.08)
      ..lineTo(px(0.92), h * 0.08)
      ..lineTo(px(0.99), h * 0.90)
      ..lineTo(px(0.01), h * 0.90)
      ..close();
    canvas.drawPath(body, _bodyPaint(Offset.zero & size));
    _outline(canvas, body);
    canvas.drawRect(Rect.fromLTWH(px(0.01), h * 0.90, bw * 0.98, h * 0.05), Paint()..color = const Color(0xFF0B0E14));

    final touch = s.kind == ArtKind.touchDesk;
    final noFaders = s.faders == 0 && s.masters == 0;

    // screens
    if (s.screens > 0 && s.screen > 0) {
      final sh = noFaders ? h * 0.58 : (touch ? h * 0.26 : h * 0.15);
      final total = s.screen * s.screens + 0.03 * (s.screens - 1);
      var left = 0.5 - total / 2;
      // non-touch desks keep their small screen right of centre
      if (!touch && s.screens == 1) left = 0.50;
      for (var i = 0; i < s.screens; i++) {
        _screen(canvas, Rect.fromLTWH(px(left), h * 0.13, bw * s.screen, sh), touch: touch);
        left += s.screen + 0.03;
      }
    }

    // knobs: a row each side of the screen area
    final knob = Paint()..color = _metal;
    final kr = math.max(1.2, bw * 0.011);
    if (!noFaders) {
      for (var i = 0; i < 4; i++) {
        canvas.drawCircle(Offset(px(0.12 + i * 0.045), h * 0.19), kr, knob);
        canvas.drawCircle(Offset(px(0.75 + i * 0.045), h * 0.19), kr, knob);
      }
    } else {
      for (var i = 0; i < 6; i++) {
        canvas.drawCircle(Offset(px(0.20 + i * 0.12), h * 0.80), kr * 1.4, knob);
      }
      return;
    }

    // faders: channel bays (gap every 8) and masters at the right
    final channels = s.faders, masters = s.masters;
    final top = touch ? h * 0.48 : h * 0.44, bottom = h * 0.85;
    final masterW = masters == 0 ? 0.0 : (masters == 1 ? 0.09 : math.min(0.34, 0.035 * masters + 0.03));
    final left = 0.07, right = 0.95 - masterW;
    final bays = math.max(1, (channels / 8).ceil());
    final gap = 0.012;
    final usable = (right - left) - gap * (bays - 1);
    final step = channels == 0 ? 0.0 : usable / channels;
    final capW = math.max(2.0, math.min(bw * step * 0.72, bw * 0.045));
    for (var i = 0; i < channels; i++) {
      final f = left + step * (i + 0.5) + gap * (i ~/ 8);
      final x = px(f);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(x, top - h * 0.05), width: math.max(2, bw * step * 0.78), height: h * 0.05),
          const Radius.circular(1),
        ),
        Paint()..color = _stripColors[i % _stripColors.length],
      );
      _fader(canvas, x, top, bottom, 0.3 + ((i * 7) % 5) * 0.12, const Color(0xFFD5DAE2), capW);
    }
    for (var m = 0; m < masters; m++) {
      final f = masters == 1 ? 0.92 : right + 0.02 + (masterW - 0.03) * (m + 0.5) / masters;
      final last = m == masters - 1;
      _fader(canvas, px(f), top, bottom, last ? 0.75 : 0.55, last ? AppStyle.mainTeal : const Color(0xFFB0B7C3),
          math.max(2.0, math.min(capW, bw * 0.04)));
    }
  }

  @override
  bool shouldRepaint(covariant _DeskPainter old) => old.s != s;
}

/// Rack unit: front panel with rack ears, optional screen, knobs and inputs.
class _RackPainter extends CustomPainter {
  _RackPainter(this.s);
  final ArtSpec s;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final ph = h * (0.30 + 0.12 * s.units.clamp(1, 4));
    final r = Rect.fromLTWH(w * 0.08, (h - ph) / 2, w * 0.84, ph);
    _shadow(canvas, Rect.fromLTWH(w * 0.10, r.bottom - h * 0.04, w * 0.80, h * 0.10));
    // ears
    final ear = Paint()..color = const Color(0xFF3A4356);
    for (final x in [r.left - w * 0.05, r.right]) {
      final e = Rect.fromLTWH(x, r.top, w * 0.05, r.height);
      canvas.drawRect(e, ear);
      for (var u = 0; u < s.units; u++) {
        canvas.drawCircle(Offset(e.center.dx, r.top + r.height * (u + 0.5) / s.units), w * 0.008, Paint()..color = _hole);
      }
    }
    final face = Path()..addRRect(RRect.fromRectAndRadius(r, const Radius.circular(2)));
    canvas.drawPath(face, _bodyPaint(r));
    _outline(canvas, face);
    // unit lines
    for (var u = 1; u < s.units; u++) {
      final y = r.top + r.height * u / s.units;
      canvas.drawLine(Offset(r.left, y), Offset(r.right, y), Paint()..color = Colors.black.withValues(alpha: 0.35));
    }
    var x = r.left + r.width * 0.05;
    if (s.screens > 0 && s.screen > 0) {
      final sw = r.width * s.screen;
      _screen(canvas, Rect.fromLTWH(x, r.top + r.height * 0.14, sw, r.height * 0.62), touch: s.screen > 0.25);
      x += sw + r.width * 0.05;
    }
    // knobs block
    final kr = math.max(1.2, w * 0.012);
    for (var row = 0; row < 2; row++) {
      for (var i = 0; i < 4; i++) {
        canvas.drawCircle(
          Offset(x + i * kr * 3.2, r.top + r.height * (0.32 + row * 0.36)),
          kr,
          Paint()..color = _metal,
        );
      }
    }
    x += kr * 3.2 * 4 + r.width * 0.04;
    // inputs (two rows) up to the right edge
    if (s.jacks > 0) {
      final cols = (s.jacks / 2).ceil();
      final avail = r.right - r.width * 0.04 - x;
      final step = avail / cols;
      final jr = math.min(step * 0.34, r.height * 0.16);
      for (var row = 0; row < 2; row++) {
        for (var i = 0; i < cols; i++) {
          final c = Offset(x + step * (i + 0.5), r.top + r.height * (0.32 + row * 0.36));
          canvas.drawCircle(c, jr, Paint()..color = _hole);
          canvas.drawCircle(c, jr, Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1
            ..color = const Color(0xFF9AA3B0));
        }
      }
    } else {
      // remote-only rack: status lights
      for (var i = 0; i < 3; i++) {
        canvas.drawCircle(Offset(r.right - r.width * (0.08 + i * 0.06), r.center.dy), w * 0.012,
            Paint()..color = i == 0 ? AppStyle.mainTeal : const Color(0xFF3A4356));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RackPainter old) => old.s != s;
}

/// Stage box: rugged box with combo inputs, knobs, status light, handles.
class _StageBoxPainter extends CustomPainter {
  _StageBoxPainter(this.s);
  final ArtSpec s;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final bwf = 0.56 + 0.20 * s.size.clamp(0.0, 1.0);
    final bx = Rect.fromLTWH(w * (1 - bwf) / 2, h * 0.24, w * bwf, h * 0.60);
    _shadow(canvas, Rect.fromLTWH(bx.left, h * 0.82, bx.width, h * 0.12));
    final topFace = Path()
      ..moveTo(bx.left + w * 0.04, bx.top - h * 0.12)
      ..lineTo(bx.right - w * 0.04, bx.top - h * 0.12)
      ..lineTo(bx.right, bx.top)
      ..lineTo(bx.left, bx.top)
      ..close();
    canvas.drawPath(topFace, Paint()..color = const Color(0xFF3A4356));
    final front = Path()..addRRect(RRect.fromRectAndRadius(bx, const Radius.circular(4)));
    canvas.drawPath(front, _bodyPaint(bx));
    _outline(canvas, front);
    final handle = Paint()
      ..color = _metal
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.02
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(bx.left - w * 0.03, bx.top + h * 0.08), Offset(bx.left - w * 0.03, bx.bottom - h * 0.08), handle);
    canvas.drawLine(Offset(bx.right + w * 0.03, bx.top + h * 0.08), Offset(bx.right + w * 0.03, bx.bottom - h * 0.08), handle);
    final cols = math.max(3, (s.jacks / 2).ceil());
    final stepX = bx.width / cols;
    for (var r = 0; r < 2; r++) {
      for (var i = 0; i < cols; i++) {
        final c = Offset(bx.left + stepX * (i + 0.5), bx.top + bx.height * (0.28 + r * 0.30));
        final jr = math.min(stepX * 0.32, bx.height * 0.12);
        canvas.drawCircle(c, jr, Paint()..color = _hole);
        canvas.drawCircle(c, jr, Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.1
          ..color = const Color(0xFF9AA3B0));
        canvas.drawCircle(c, jr * 0.3, Paint()..color = const Color(0xFF5A6272));
      }
    }
    for (var i = 0; i < 3; i++) {
      canvas.drawCircle(Offset(bx.left + bx.width * (0.16 + i * 0.12), bx.top + bx.height * 0.85), w * 0.016,
          Paint()..color = _metal);
    }
    final led = Offset(bx.right - bx.width * 0.12, bx.top + bx.height * 0.85);
    canvas.drawCircle(led, w * 0.02, Paint()
      ..color = AppStyle.mainTeal
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    canvas.drawCircle(led, w * 0.011, Paint()..color = const Color(0xFFB5FFF4));
  }

  @override
  bool shouldRepaint(covariant _StageBoxPainter old) => old.s != s;
}
