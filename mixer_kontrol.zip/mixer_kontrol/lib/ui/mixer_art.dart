import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'mixer_catalog.dart';

/// Original, brand-free illustration of a mixer. Drawn from an [ArtSpec]
/// (form, number of faders and screens, size), so models can be told apart
/// without copying any real product.
class MixerArt extends StatelessWidget {
  const MixerArt({super.key, this.family, this.spec, this.accent, this.width = 120, this.height = 72});

  /// Shorthand when only the family is known.
  final MixerFamily? family;
  final ArtSpec? spec;

  /// Brand colour for the rim light and lit buttons.
  final Color? accent;
  final double width;
  final double height;

  static ArtSpec defaultFor(MixerFamily? f) => switch (f) {
        MixerFamily.xr => const ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0),
        MixerFamily.yamaha || MixerFamily.tascam || MixerFamily.wing =>
          const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.26),
        MixerFamily.allenHeath => const ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.24),
        _ => const ArtSpec(ArtKind.desk, faders: 16, masters: 9, screen: 0.14),
      };

  @override
  Widget build(BuildContext context) {
    final s = spec ?? defaultFor(family);
    final a = accent ?? MixerCatalog.accentOfFamily(family);
    return SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: switch (s.kind) {
          ArtKind.desk || ArtKind.touchDesk => _DeskPainter(s, a),
          ArtKind.rack => _RackPainter(s, a),
          ArtKind.stagebox => _StageBoxPainter(s, a),
        },
      ),
    );
  }
}

const _metal = Color(0xFF8E96A3);
const _hole = Color(0xFF0A0D12);
const _stripColors = [
  Color(0xFFE5484D), Color(0xFF46A758), Color(0xFFF5D90A), Color(0xFF3E8EF7), //
  Color(0xFFD864D8), Color(0xFF29C5D6), Color(0xFFEDEDED), Color(0xFFF08A24),
];

/// Surface (back, middle, front), side and front-edge colours of a finish.
({List<Color> top, Color side, Color edge, Color bridge}) _finish(ArtTone t) => switch (t) {
      ArtTone.silver => (
          top: const [Color(0xFF7A8396), Color(0xFF555E70), Color(0xFF3C4352)],
          side: const Color(0xFF3A404C),
          edge: const Color(0xFF262B34),
          bridge: const Color(0xFF8A93A6),
        ),
      ArtTone.graphite => (
          top: const [Color(0xFF4A505C), Color(0xFF2E323B), Color(0xFF1E2128)],
          side: const Color(0xFF22252C),
          edge: const Color(0xFF121418),
          bridge: const Color(0xFF555B68),
        ),
      ArtTone.black => (
          top: const [Color(0xFF26292F), Color(0xFF17191E), Color(0xFF0E0F12)],
          side: const Color(0xFF15171B),
          edge: const Color(0xFF07080A),
          bridge: const Color(0xFF30343C),
        ),
      ArtTone.navy => (
          top: const [Color(0xFF34507E), Color(0xFF203556), Color(0xFF142238)],
          side: const Color(0xFF172742),
          edge: const Color(0xFF0B1424),
          bridge: const Color(0xFF3E5C8C),
        ),
      ArtTone.charcoal => (
          top: const [Color(0xFF353F55), Color(0xFF1A2030), Color(0xFF121722)],
          side: const Color(0xFF1B2130),
          edge: const Color(0xFF0B0E15),
          bridge: const Color(0xFF414B63),
        ),
    };

void _shadow(Canvas c, Rect r) => c.drawOval(
      r,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

void _outline(Canvas c, Path p) => c.drawPath(
      p,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.18),
    );

/// A glowing screen; touch screens show a few tiles.
void _screen(Canvas c, Rect r, {bool touch = false}) {
  final rr = RRect.fromRectAndRadius(r, const Radius.circular(2));
  c.drawRRect(
    rr.inflate(1.5),
    Paint()
      ..color = AppStyle.glowBlue.withValues(alpha: 0.45)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
  );
  c.drawRRect(
    rr,
    Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF2D6FD6), Color(0xFF173A78)],
      ).createShader(r),
  );
  if (!touch || r.width < 14) return;
  // a strip view: little meters and tiles
  final n = math.max(4, (r.width / 6).floor());
  final bw = r.width / n;
  for (var i = 0; i < n; i++) {
    final hgt = r.height * (0.25 + 0.5 * ((i * 37) % 10) / 10);
    c.drawRect(
      Rect.fromLTWH(r.left + i * bw + bw * 0.25, r.bottom - hgt - r.height * 0.08, bw * 0.5, hgt),
      Paint()..color = const Color(0xFF7FE3C4).withValues(alpha: 0.75),
    );
  }
  c.drawRect(
    Rect.fromLTWH(r.left, r.top, r.width, r.height * 0.16),
    Paint()..color = Colors.white.withValues(alpha: 0.18),
  );
}

/// Desk console in a three-quarter view: a sloped work surface with depth,
/// a raised screen section at the back, and a rim light in the brand colour.
/// The layout (fader groups, screens, knob blocks) comes from the [ArtSpec].
class _DeskPainter extends CustomPainter {
  _DeskPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final noFaders = s.groups.isEmpty && s.masters == 0;
    final fin = _finish(s.tone);
    // Width follows the number of faders (an 8-fader desk is nearly square,
    // a 32-fader one long and flat); depth changes much less.
    final slots = s.groups.fold<int>(0, (a, b) => a + b) + s.tail + s.masters * 1.5;
    final wide = noFaders ? s.size.clamp(0.3, 1.0) : ((slots - 6) / 30).clamp(0.0, 1.0);
    final kx = 0.46 + 0.54 * wide, ky = 0.80 + 0.12 * wide;
    final k = kx;
    final lift = s.bridge ? 0.06 : 0.0;
    Offset p(double x, double y) => Offset(w * (0.5 + (x - 0.5) * kx), h * (0.5 + lift + (y - 0.5) * ky));

    // the work surface, seen from the front-left and above
    final bl = p(0.15, 0.10), br = p(0.86, 0.07), fl = p(0.02, 0.77), fr = p(0.93, 0.83);
    Offset at(double u, double v) {
      final back = Offset.lerp(bl, br, u)!, front = Offset.lerp(fl, fr, u)!;
      return Offset.lerp(back, front, v)!;
    }

    // local scale (pixels per unit of u) at depth v: things shrink towards the back
    double span(double v) => (at(1, v) - at(0, v)).distance;
    Path quad(double u0, double v0, double u1, double v1) => Path()
      ..moveTo(at(u0, v0).dx, at(u0, v0).dy)
      ..lineTo(at(u1, v0).dx, at(u1, v0).dy)
      ..lineTo(at(u1, v1).dx, at(u1, v1).dy)
      ..lineTo(at(u0, v1).dx, at(u0, v1).dy)
      ..close();

    final down = Offset(0, h * 0.10 * k);
    _shadow(canvas, Rect.fromPoints(fl + Offset(w * 0.02, down.dy * 0.6), fr + Offset(w * 0.02, down.dy * 1.6)));

    // side handles of the fader-less touch mixers
    if (noFaders) {
      final handle = Paint()
        ..color = const Color(0xFF5A6476)
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = math.max(1.5, w * 0.022);
      canvas.drawLine(at(0, 0.15) - Offset(w * 0.03, 0), at(0, 0.85) - Offset(w * 0.03, 0), handle);
      canvas.drawLine(at(1, 0.15) + Offset(w * 0.03, 0), at(1, 0.85) + Offset(w * 0.03, 0), handle);
    }

    // right side (a wedge: taller at the back) and the front edge
    final side = Path()
      ..moveTo(br.dx, br.dy)
      ..lineTo(fr.dx, fr.dy)
      ..lineTo(fr.dx, fr.dy + down.dy)
      ..lineTo(br.dx + w * 0.012, br.dy + down.dy * 2.0)
      ..close();
    canvas.drawPath(
      side,
      Paint()
        ..shader = LinearGradient(colors: [fin.side, Color.lerp(fin.edge, accent, 0.10)!])
            .createShader(side.getBounds()),
    );
    final front = Path()
      ..moveTo(fl.dx, fl.dy)
      ..lineTo(fr.dx, fr.dy)
      ..lineTo(fr.dx, fr.dy + down.dy)
      ..lineTo(fl.dx, fl.dy + down.dy)
      ..close();
    canvas.drawPath(front, Paint()..color = fin.edge);

    // surface: lighter at the back
    final top = quad(0, 0, 1, 1);
    canvas.drawPath(
      top,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: fin.top,
          stops: const [0, 0.5, 1],
        ).createShader(top.getBounds()),
    );

    // light from the top left: a soft sheen across the panel
    canvas.drawPath(top, Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Colors.white.withValues(alpha: 0.10), Colors.white.withValues(alpha: 0.0), Colors.black.withValues(alpha: 0.18)],
        stops: const [0, 0.45, 1],
      ).createShader(top.getBounds()));
    // end cheeks: darker side pieces framing the panel
    for (final (a, z) in [(0.0, 0.022), (0.978, 1.0)]) {
      canvas.drawPath(quad(a, 0, z, 1), Paint()..color = Color.lerp(fin.edge, Colors.white, 0.06)!);
    }
    // bevelled back edge
    canvas.drawLine(bl, br, Paint()
      ..color = Colors.white.withValues(alpha: 0.30)
      ..strokeWidth = math.max(0.5, h * 0.006));

    final touch = s.kind == ArtKind.touchDesk;
    // a deep channel-strip section where there is a big knob block
    final split = noFaders
        ? 0.72
        : (s.block == ArtBlock.left || s.block == ArtBlock.both)
            ? (s.chKnobs ? 0.40 : 0.44)
            : (touch ? 0.38 : 0.36);

    // meter bridge standing along the back edge: a row of LED meters
    if (s.bridge) {
      final up = Offset(0, -h * 0.12 * ky);
      final a0 = at(0.03, 0), a1 = at(0.97, 0);
      final panel = Path()
        ..moveTo(a0.dx, a0.dy)
        ..lineTo(a1.dx, a1.dy)
        ..lineTo((a1 + up).dx, (a1 + up).dy)
        ..lineTo((a0 + up).dx, (a0 + up).dy)
        ..close();
      canvas.drawPath(panel, Paint()..color = fin.bridge);
      canvas.drawPath(panel, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8
        ..color = Colors.black.withValues(alpha: 0.5));
      final n = math.max(8, (span(0) / 4).floor());
      for (var i = 0; i < n; i++) {
        final base = Offset.lerp(a0, a1, (i + 0.5) / n)! + up * 0.15;
        final lit = 0.3 + 0.55 * ((i * 37) % 10) / 10;
        canvas.drawLine(base, base + up * 0.7 * lit, Paint()
          ..color = lit > 0.75 ? const Color(0xFFF5B83D) : const Color(0xFF4ADE80)
          ..strokeWidth = math.max(0.7, span(0) / n * 0.45));
      }
    }

    // raised screen section at the back
    final bridge = quad(0.02, 0.02, 0.98, split);
    canvas.drawPath(bridge, Paint()..color = Colors.white.withValues(alpha: 0.05));
    canvas.drawLine(at(0.02, split), at(0.98, split), Paint()
      ..color = Colors.black.withValues(alpha: 0.55)
      ..strokeWidth = math.max(0.8, h * 0.012));
    canvas.drawLine(at(0.02, split) + Offset(0, h * 0.008), at(0.98, split) + Offset(0, h * 0.008), Paint()
      ..color = Colors.white.withValues(alpha: 0.10)
      ..strokeWidth = math.max(0.5, h * 0.005));

    // ---- fader layout across the body: groups, the masters, the tail bank
    final groups = s.groups;
    final channels = groups.fold<int>(0, (a, b) => a + b) + s.tail;
    final masters = s.masters;
    final gaps = (groups.isEmpty ? 0 : groups.length - 1) * 0.6 + (masters > 0 ? 0.8 : 0) + (s.tail > 0 ? 0.8 : 0);
    final units = channels + masters * 1.5 + gaps;
    final step = units == 0 ? 0.0 : 0.88 / units;
    final chU = <double>[]; // centre of every channel fader
    final bayRange = <(double, double)>[];
    var u = 0.06;
    for (var g = 0; g < groups.length; g++) {
      final start = u;
      for (var i = 0; i < groups[g]; i++) {
        chU.add(u + step / 2);
        u += step;
      }
      bayRange.add((start, u));
      if (g < groups.length - 1) u += step * 0.6;
    }
    final masterU = <double>[];
    if (masters > 0) {
      u += step * 0.8;
      for (var m = 0; m < masters; m++) {
        masterU.add(u + step * 0.75);
        u += step * 1.5;
      }
    }
    if (s.tail > 0) {
      u += step * 0.8;
      final start = u;
      for (var i = 0; i < s.tail; i++) {
        chU.add(u + step / 2);
        u += step;
      }
      bayRange.add((start, u));
    }

    // ---- screens
    final screens = <(double, double)>[];
    if (s.screens > 0 && s.screen > 0) {
      if (s.screenBays != null && bayRange.isNotEmpty) {
        for (final b in s.screenBays!) {
          final (a, z) = bayRange[b.clamp(0, bayRange.length - 1)];
          final c = (a + z) / 2, sw = math.min(s.screen, (z - a) * 0.92);
          screens.add((c - sw / 2, c + sw / 2));
        }
      } else {
        final total = s.screen * s.screens + 0.03 * (s.screens - 1);
        var left = (s.screenAt - total / 2).clamp(0.04, 0.96 - total);
        for (var i = 0; i < s.screens; i++) {
          screens.add((left, left + s.screen));
          left += s.screen + 0.03;
        }
      }
    }
    final spanL = screens.isEmpty ? 0.5 : screens.map((e) => e.$1).reduce(math.min);
    final spanR = screens.isEmpty ? 0.5 : screens.map((e) => e.$2).reduce(math.max);

    // ---- knob blocks in the back section
    // fine print and seams only when the picture is big enough to show them
    final detail = span(0.5) > 180;
    final legend = Paint()
      ..color = Colors.white.withValues(alpha: 0.28)
      ..strokeWidth = 0.6;
    void knobs(double u0, double u1, {required bool dense}) {
      if (u1 - u0 < 0.05) return;
      final rows = dense ? 4 : 3;
      final cols = math.max(2, ((u1 - u0) / (dense ? 0.034 : 0.045)).floor());
      for (var row = 0; row < rows; row++) {
        final v = split * (0.16 + row * (0.70 / (rows - 1)));
        final r = math.max(0.6, span(v) * (dense ? 0.0095 : 0.0080));
        for (var i = 0; i < cols; i++) {
          final uu = u0 + (u1 - u0) * (i + 0.5) / cols;
          final c = at(uu, v);
          if (!dense && row == 2 && i % 3 == 1) {
            _key(canvas, c, r * 2.2, accent);
          } else {
            _knob(canvas, c, r * 1.15, ring: dense && (row + i) % 3 == 0 ? accent : null, turn: ((row * 7 + i * 3) % 10) / 10);
          }
          if (detail && row < rows - 1) {
            // printed legend under the knob
            canvas.drawLine(c + Offset(-r, r * 2.0), c + Offset(r, r * 2.0), legend);
          }
        }
      }
    }

    void keys(double u0, double u1) {
      if (u1 - u0 < 0.04) return;
      final cols = math.max(2, ((u1 - u0) / 0.03).floor());
      for (var row = 0; row < 3; row++) {
        final v = split * (0.22 + row * 0.28);
        final kw = math.max(1.0, span(v) * 0.016);
        for (var i = 0; i < cols; i++) {
          final c = at(u0 + (u1 - u0) * (i + 0.5) / cols, v);
          _key(canvas, c, kw, (row + i) % 4 == 0 ? _stripColors[(i + row) % _stripColors.length] : null);
        }
      }
    }

    final leftArea = (0.05, spanL - 0.03), rightArea = (spanR + 0.03, 0.95);
    switch (s.block) {
      case ArtBlock.none:
        knobs(leftArea.$1, leftArea.$2, dense: false);
        knobs(rightArea.$1, rightArea.$2, dense: false);
      case ArtBlock.left:
        knobs(leftArea.$1, leftArea.$2, dense: true);
        keys(rightArea.$1, rightArea.$2);
      case ArtBlock.right:
        keys(leftArea.$1, leftArea.$2);
        knobs(rightArea.$1, rightArea.$2, dense: true);
      case ArtBlock.both:
        knobs(leftArea.$1, leftArea.$2, dense: true);
        knobs(rightArea.$1, rightArea.$2, dense: true);
    }

    // ---- screens, drawn over the back section (or standing up on a housing)
    final v0 = split * 0.12, v1 = split * (touch || noFaders ? 0.88 : 0.62);
    for (final (a, z) in screens) {
      var tl = at(a, v0), tr = at(z, v0), brc = at(z, v1), blc = at(a, v1);
      if (s.raised) {
        final lift = Offset(0, -h * 0.13 * k);
        final housing = Path()
          ..moveTo(blc.dx, blc.dy)
          ..lineTo(brc.dx, brc.dy)
          ..lineTo((brc + lift * 0.4).dx, (brc + lift * 0.4).dy)
          ..lineTo((blc + lift * 0.4).dx, (blc + lift * 0.4).dy)
          ..close();
        canvas.drawPath(housing, Paint()..color = const Color(0xFF0E121B));
        tl += lift;
        tr += lift;
        brc += lift * 0.5;
        blc += lift * 0.5;
        final bezel = Path()
          ..moveTo(tl.dx - 1.5, tl.dy - 1.5)
          ..lineTo(tr.dx + 1.5, tr.dy - 1.5)
          ..lineTo(brc.dx + 1.5, brc.dy + 1.5)
          ..lineTo(blc.dx - 1.5, blc.dy + 1.5)
          ..close();
        canvas.drawPath(bezel, Paint()..color = const Color(0xFF0A0D13));
      }
      _quadScreen(canvas, tl, tr, brc, blc, touch || noFaders, accent);
    }

    // ---- fader-less touch mixers: encoders and keys under the screen
    if (noFaders) {
      final n = math.max(3, s.encoders);
      for (var i = 0; i < n; i++) {
        final c = at(0.30 + 0.40 * (i + 0.5) / n, 0.86);
        final r = math.max(1.2, span(0.86) * 0.025);
        _knob(canvas, c, r, ring: accent, turn: i * 0.2);
      }
      for (var i = 0; i < 5; i++) {
        _key(canvas, at(0.08 + i * 0.035, 0.86), math.max(1.2, span(0.86) * 0.024), i == 4 ? accent : null);
      }
      if (s.antenna) _antenna(canvas, at(0.92, 0.05), h * 0.30, w);
      _rim(canvas, fl, fr, br, accent, h);
      return;
    }

    // ---- channel strips: knob, meter, scribble strip, select key, fader
    final vKnob = split + 0.05;
    final vStrip = split + (s.chKnobs ? 0.12 : 0.07);
    final vBtn = vStrip + 0.07;
    final vTop = vBtn + 0.06, vBot = 0.86;

    void fader(double uu, double pos, Color cap, Color line, double slot) {
      // the slot: a dark groove cut into the panel, lit on its lower lip
      final a = at(uu, vTop), b = at(uu, vBot);
      final gw = math.max(0.8, span(0.7) * slot * 0.16);
      canvas.drawLine(a, b, Paint()
        ..color = Colors.black
        ..strokeCap = StrokeCap.round
        ..strokeWidth = gw);
      if (gw >= 1.2) {
        canvas.drawLine(a + Offset(gw * 0.6, 0), b + Offset(gw * 0.6, 0), Paint()
          ..color = Colors.white.withValues(alpha: 0.10)
          ..strokeWidth = math.max(0.4, gw * 0.35));
      }
      final v = vBot - (vBot - vTop) * pos;
      final cw = math.max(1.6, math.min(span(v) * slot * 0.74, w * 0.045));
      _cap(canvas, at(uu, v), cw, cap, line);
    }

    for (var i = 0; i < chU.length; i++) {
      final uu = chU[i];
      final color = _stripColors[i % _stripColors.length];
      if (s.chKnobs) {
        _knob(canvas, at(uu, vKnob), math.max(0.7, span(vKnob) * step * 0.26),
            ring: accent.withValues(alpha: 0.7), turn: ((i * 3) % 10) / 10);
      }
      final sw = math.max(1.2, span(vStrip) * step * (s.meters ? 0.58 : 0.76));
      final strip = at(uu, vStrip);
      _scribble(canvas, s.meters ? strip - Offset(sw * 0.2, 0) : strip, sw, math.max(1.0, h * 0.034), color);
      if (s.meters) {
        // a small LED meter beside each strip: green, then amber at the top
        final mx = strip.dx + sw * 0.6, mh = math.max(1.5, h * 0.05), lit = 0.3 + ((i * 5) % 7) / 10;
        canvas.drawLine(Offset(mx, strip.dy + mh / 2), Offset(mx, strip.dy + mh / 2 - mh * lit), Paint()
          ..color = lit > 0.8 ? const Color(0xFFF5B83D) : const Color(0xFF4ADE80)
          ..strokeWidth = math.max(0.6, sw * 0.22));
      }
      // select / mute keys
      final kw = math.max(1.0, span(vBtn) * step * 0.52);
      _key(canvas, at(uu, vBtn) - Offset(0, kw * 0.45), kw, i % 4 == 0 ? accent : null);
      _key(canvas, at(uu, vBtn) + Offset(0, kw * 0.45), kw, i % 7 == 3 ? const Color(0xFFE5484D) : null);
      fader(uu, 0.3 + ((i * 7) % 5) * 0.12, const Color(0xFFC9CED6), Colors.white, step);
    }
    for (var m = 0; m < masterU.length; m++) {
      final last = m == masterU.length - 1;
      fader(masterU[m], last ? 0.75 : 0.5, last ? const Color(0xFFE23B3B) : const Color(0xFF9097A3),
          Colors.white, step * 1.2);
    }

    // padded arm rest along the front
    final arm = quad(0.0, 0.90, 1.0, 1.0);
    canvas.drawPath(arm, Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color.lerp(fin.edge, Colors.white, 0.18)!, fin.edge, Colors.black],
        stops: const [0, 0.35, 1],
      ).createShader(arm.getBounds()));
    canvas.drawLine(at(0.0, 0.90), at(1.0, 0.90), Paint()
      ..color = Colors.white.withValues(alpha: 0.22)
      ..strokeWidth = math.max(0.5, h * 0.006));

    _rim(canvas, fl, fr, br, accent, h);
  }

  @override
  bool shouldRepaint(covariant _DeskPainter old) => old.s != s || old.accent != accent;
}

/// A knob seen from above: soft shadow, a lit top-left, a pointer line.
void _knob(Canvas c, Offset o, double r, {Color? ring, double turn = 0.3}) {
  if (r >= 1.6) {
    c.drawCircle(o + Offset(r * 0.25, r * 0.35), r * 1.05, Paint()
      ..color = Colors.black.withValues(alpha: 0.55)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * 0.4));
  }
  if (ring != null) {
    c.drawCircle(o, r * 1.55, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(0.5, r * 0.35)
      ..color = ring.withValues(alpha: 0.85));
  }
  c.drawCircle(o, r, Paint()
    ..shader = const RadialGradient(
      center: Alignment(-0.45, -0.5),
      radius: 1.0,
      colors: [Color(0xFFCDD3DC), Color(0xFF6E7684), Color(0xFF2A2F38)],
      stops: [0, 0.55, 1],
    ).createShader(Rect.fromCircle(center: o, radius: r)));
  if (r >= 2.2) {
    final a = -math.pi * 0.75 + turn * math.pi * 1.5;
    c.drawLine(o, o + Offset(math.cos(a), math.sin(a)) * r * 0.85, Paint()
      ..color = Colors.white.withValues(alpha: 0.9)
      ..strokeWidth = math.max(0.5, r * 0.18)
      ..strokeCap = StrokeCap.round);
  }
}

/// A rubber key; lit keys glow in their colour.
void _key(Canvas c, Offset o, double kw, Color? lit) {
  final r = Rect.fromCenter(center: o, width: kw, height: kw * 0.68);
  if (lit != null && kw >= 2.5) {
    c.drawRRect(RRect.fromRectAndRadius(r.inflate(kw * 0.25), Radius.circular(kw * 0.3)), Paint()
      ..color = lit.withValues(alpha: 0.45)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, kw * 0.35));
  }
  c.drawRRect(
    RRect.fromRectAndRadius(r, Radius.circular(math.max(0.5, kw * 0.18))),
    Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: lit != null
            ? [Color.lerp(lit, Colors.white, 0.35)!, lit]
            : const [Color(0xFF5E6676), Color(0xFF353B46)],
      ).createShader(r),
  );
}

/// A fader cap: drop shadow, lit top face, a centre line.
void _cap(Canvas c, Offset o, double cw, Color color, Color line) {
  final ch = math.max(1.2, cw * 0.62);
  final r = Rect.fromCenter(center: o, width: cw, height: ch);
  if (cw >= 3) {
    c.drawRRect(RRect.fromRectAndRadius(r.shift(Offset(cw * 0.12, ch * 0.45)), Radius.circular(cw * 0.15)), Paint()
      ..color = Colors.black.withValues(alpha: 0.6)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, cw * 0.18));
  }
  c.drawRRect(
    RRect.fromRectAndRadius(r, Radius.circular(math.max(0.5, cw * 0.15))),
    Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color.lerp(color, Colors.white, 0.45)!, color, Color.lerp(color, Colors.black, 0.45)!],
        stops: const [0, 0.45, 1],
      ).createShader(r),
  );
  if (cw >= 3) {
    c.drawLine(Offset(r.left + cw * 0.12, o.dy), Offset(r.right - cw * 0.12, o.dy), Paint()
      ..color = line
      ..strokeWidth = math.max(0.5, ch * 0.16));
  }
}

/// A backlit scribble-strip LCD with a name on it.
void _scribble(Canvas c, Offset o, double sw, double sh, Color color) {
  final r = Rect.fromCenter(center: o, width: sw, height: sh);
  c.drawRect(r.inflate(math.max(0.3, sw * 0.06)), Paint()..color = const Color(0xFF07090C));
  c.drawRect(r, Paint()..color = Color.lerp(color, Colors.black, 0.15)!);
  if (sw >= 6) {
    c.drawLine(Offset(r.left + sw * 0.18, r.top + sh * 0.38), Offset(r.right - sw * 0.25, r.top + sh * 0.38), Paint()
      ..color = Colors.black.withValues(alpha: 0.75)
      ..strokeWidth = math.max(0.4, sh * 0.16));
    c.drawLine(Offset(r.left + sw * 0.18, r.top + sh * 0.68), Offset(r.right - sw * 0.45, r.top + sh * 0.68), Paint()
      ..color = Colors.black.withValues(alpha: 0.6)
      ..strokeWidth = math.max(0.4, sh * 0.12));
  }
}

/// A Wi-Fi antenna standing up from [base].
void _antenna(Canvas canvas, Offset base, double len, double w) {
  canvas.drawLine(base, base - Offset(0, len), Paint()
    ..color = const Color(0xFF2A303C)
    ..strokeCap = StrokeCap.round
    ..strokeWidth = math.max(1.5, w * 0.022));
  canvas.drawCircle(base, math.max(1.5, w * 0.018), Paint()..color = const Color(0xFF1A1F29));
}

/// Rim light in the brand colour along the front and right edges.
void _rim(Canvas canvas, Offset fl, Offset fr, Offset br, Color accent, double h) {
  final edge = Path()
    ..moveTo(fl.dx, fl.dy)
    ..lineTo(fr.dx, fr.dy)
    ..lineTo(br.dx, br.dy);
  canvas.drawPath(edge, Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = math.max(1.5, h * 0.035)
    ..color = accent.withValues(alpha: 0.55)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, math.max(1.5, h * 0.03)));
  canvas.drawPath(edge, Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = math.max(0.6, h * 0.008)
    ..color = Color.lerp(accent, Colors.white, 0.45)!.withValues(alpha: 0.9));
}

/// A screen on a sloped surface (corners top-left, top-right, bottom-right,
/// bottom-left): black bezel, a dark UI with a tab bar, channel strips with
/// faders and meters (touch screens), and a glass reflection.
void _quadScreen(Canvas c, Offset tl, Offset tr, Offset brc, Offset blc, bool touch, Color accent) {
  Path poly(List<Offset> pts) {
    final p = Path()..moveTo(pts[0].dx, pts[0].dy);
    for (final q in pts.skip(1)) {
      p.lineTo(q.dx, q.dy);
    }
    return p..close();
  }

  final outer = poly([tl, tr, brc, blc]);
  final b = outer.getBounds();
  c.drawPath(outer, Paint()
    ..color = AppStyle.glowBlue.withValues(alpha: 0.40)
    ..maskFilter = MaskFilter.blur(BlurStyle.normal, math.max(2, b.height * 0.22)));
  // bezel
  c.drawPath(outer, Paint()..color = const Color(0xFF05070A));
  Offset at(double u, double v) => Offset.lerp(Offset.lerp(tl, tr, u)!, Offset.lerp(blc, brc, u)!, v)!;
  final m = b.width < 14 ? 0.0 : 0.05;
  Offset gl(double u, double v) => at(m + (1 - 2 * m) * u, m * 1.3 + (1 - 2.6 * m) * v);
  final glass = poly([gl(0, 0), gl(1, 0), gl(1, 1), gl(0, 1)]);
  c.drawPath(glass, Paint()
    ..shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF1C3F7A), Color(0xFF0D1E3E)],
    ).createShader(b));
  if (b.width < 10) return;
  // tab bar
  final tabs = math.max(3, (b.width / 14).floor());
  for (var i = 0; i < tabs; i++) {
    final u0 = (i + 0.08) / tabs, u1 = (i + 0.92) / tabs;
    c.drawPath(
      poly([gl(u0, 0.03), gl(u1, 0.03), gl(u1, 0.14), gl(u0, 0.14)]),
      Paint()..color = i == 1 ? accent.withValues(alpha: 0.9) : Colors.white.withValues(alpha: 0.18),
    );
  }
  if (touch) {
    // channel strips: a meter and a little fader each
    final n = math.max(4, (b.width / 5.5).floor());
    final cw = b.width / n;
    for (var i = 0; i < n; i++) {
      final u = (i + 0.5) / n;
      final lvl = 0.25 + 0.6 * ((i * 37) % 10) / 10;
      c.drawLine(gl(u - 0.18 / n, 0.92), gl(u - 0.18 / n, 0.92 - 0.6 * lvl), Paint()
        ..color = lvl > 0.75 ? const Color(0xFFF5B83D) : const Color(0xFF4ADE80)
        ..strokeWidth = math.max(0.6, cw * 0.22));
      if (cw >= 4) {
        c.drawLine(gl(u + 0.2 / n, 0.30), gl(u + 0.2 / n, 0.92), Paint()
          ..color = Colors.white.withValues(alpha: 0.25)
          ..strokeWidth = math.max(0.4, cw * 0.08));
        final fy = 0.85 - 0.5 * (((i * 13) % 10) / 10);
        c.drawLine(gl(u + 0.02 / n, fy), gl(u + 0.38 / n, fy), Paint()
          ..color = Colors.white.withValues(alpha: 0.85)
          ..strokeWidth = math.max(0.6, cw * 0.14));
      }
    }
  } else {
    // a small status display: a few lines of text and a meter
    for (var i = 0; i < 3; i++) {
      c.drawLine(gl(0.08, 0.32 + i * 0.2), gl(0.6 - i * 0.12, 0.32 + i * 0.2), Paint()
        ..color = Colors.white.withValues(alpha: 0.5)
        ..strokeWidth = math.max(0.5, b.height * 0.06));
    }
    c.drawLine(gl(0.85, 0.9), gl(0.85, 0.3), Paint()
      ..color = const Color(0xFF4ADE80)
      ..strokeWidth = math.max(0.6, b.width * 0.05));
  }
  // glass reflection: a soft diagonal band
  c.drawPath(
    poly([gl(0.0, 0.0), gl(0.38, 0.0), gl(0.12, 1.0), gl(0.0, 1.0)]),
    Paint()..color = Colors.white.withValues(alpha: 0.07),
  );
}

/// Rack unit: front panel with rack ears, optional screen, knobs and inputs.
class _RackPainter extends CustomPainter {
  _RackPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final ph = h * (0.30 + 0.12 * s.units.clamp(1, 4));
    final r = Rect.fromLTWH(w * 0.08, (h - ph) / 2, w * 0.84, ph);
    _shadow(canvas, Rect.fromLTWH(w * 0.10, r.bottom - h * 0.04, w * 0.80, h * 0.10));
    // ears
    final ear = Paint()..color = const Color(0xFF3A4356);
    for (final x in [r.left - w * 0.05, r.right]) {
      final e = Rect.fromLTWH(x, r.top, w * 0.05, r.height);
      canvas.drawRect(e, ear);
      for (var u = 0; u < s.units; u++) {
        canvas.drawCircle(Offset(e.center.dx, r.top + r.height * (u + 0.5) / s.units), w * 0.008, Paint()..color = _hole);
      }
    }
    // top of the unit, seen from above
    final lid = Path()
      ..moveTo(r.left + w * 0.04, r.top - h * 0.10)
      ..lineTo(r.right - w * 0.02, r.top - h * 0.10)
      ..lineTo(r.right, r.top)
      ..lineTo(r.left, r.top)
      ..close();
    canvas.drawPath(lid, Paint()..color = const Color(0xFF353F55));
    final fin = _finish(s.tone);
    final face = Path()..addRRect(RRect.fromRectAndRadius(r, const Radius.circular(2)));
    canvas.drawPath(
        face,
        Paint()
          ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [fin.top[0], fin.top[2]])
              .createShader(r));
    _outline(canvas, face);
    _rim(canvas, r.bottomLeft, r.bottomRight, Offset(r.right, r.top), accent, h * 0.6);
    // unit lines
    for (var u = 1; u < s.units; u++) {
      final y = r.top + r.height * u / s.units;
      canvas.drawLine(Offset(r.left, y), Offset(r.right, y), Paint()..color = Colors.black.withValues(alpha: 0.35));
    }
    var x = r.left + r.width * 0.05;
    if (s.screens > 0 && s.screen > 0) {
      final sw = r.width * s.screen;
      _screen(canvas, Rect.fromLTWH(x, r.top + r.height * 0.14, sw, r.height * 0.62), touch: s.screen > 0.25);
      x += sw + r.width * 0.05;
    }
    // knobs block
    final kr = math.max(1.2, w * 0.012);
    for (var row = 0; row < 2; row++) {
      for (var i = 0; i < 4; i++) {
        canvas.drawCircle(
          Offset(x + i * kr * 3.2, r.top + r.height * (0.32 + row * 0.36)),
          kr,
          Paint()..color = _metal,
        );
      }
    }
    x += kr * 3.2 * 4 + r.width * 0.04;
    // inputs (two rows) up to the right edge
    if (s.jacks > 0) {
      final cols = (s.jacks / 2).ceil();
      final avail = r.right - r.width * 0.04 - x;
      final step = avail / cols;
      final jr = math.min(step * 0.34, r.height * 0.16);
      for (var row = 0; row < 2; row++) {
        for (var i = 0; i < cols; i++) {
          final c = Offset(x + step * (i + 0.5), r.top + r.height * (0.32 + row * 0.36));
          canvas.drawCircle(c, jr, Paint()..color = _hole);
          canvas.drawCircle(c, jr, Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1
            ..color = const Color(0xFF9AA3B0));
        }
      }
    } else {
      // remote-only rack: status lights
      for (var i = 0; i < 3; i++) {
        canvas.drawCircle(Offset(r.right - r.width * (0.08 + i * 0.06), r.center.dy), w * 0.012,
            Paint()..color = i == 0 ? accent : const Color(0xFF3A4356));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RackPainter old) => old.s != s || old.accent != accent;
}

/// Stage box / front panel (X Air, MR, Qu-SB, CQ-20B): a wide box with
/// side handles, rows of combo inputs, a row of XLR outputs, connectors on
/// top and (when it has Wi-Fi) an antenna.
class _StageBoxPainter extends CustomPainter {
  _StageBoxPainter(this.s, this.accent);
  final ArtSpec s;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final rows = s.rows ?? [math.max(3, (s.jacks / 2).ceil()), math.max(3, (s.jacks / 2).ceil())];
    final lines = rows.length + (s.outs > 0 ? 1 : 0) + 1; // + the connector strip
    final bwf = 0.62 + 0.24 * s.size.clamp(0.0, 1.0);
    final bh = math.min(h * 0.68, h * (0.20 + 0.14 * lines));
    final bx = Rect.fromLTWH(w * (1 - bwf) / 2, h * 0.92 - bh, w * bwf, bh);
    _shadow(canvas, Rect.fromLTWH(bx.left, bx.bottom - h * 0.04, bx.width, h * 0.10));
    if (s.antenna) {
      // stays inside the picture
      final base = Offset(bx.right - bx.width * 0.14, bx.top + bx.height * 0.14);
      _antenna(canvas, base, math.min(h * 0.42, base.dy - h * 0.03), w);
    }
    final topFace = Path()
      ..moveTo(bx.left + w * 0.03, bx.top - h * 0.08)
      ..lineTo(bx.right - w * 0.015, bx.top - h * 0.08)
      ..lineTo(bx.right, bx.top)
      ..lineTo(bx.left, bx.top)
      ..close();
    canvas.drawPath(topFace, Paint()..color = const Color(0xFF353F55));
    final fin = _finish(s.tone);
    final front = Path()..addRRect(RRect.fromRectAndRadius(bx, const Radius.circular(3)));
    canvas.drawPath(
        front,
        Paint()
          ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [fin.top[0], fin.top[2]])
              .createShader(bx));
    _outline(canvas, front);
    // side handles (rack-ear style bars)
    final handle = Paint()
      ..color = const Color(0xFF1C222D)
      ..style = PaintingStyle.fill;
    for (final x in [bx.left - w * 0.035, bx.right + w * 0.005]) {
      final hr = RRect.fromRectAndRadius(Rect.fromLTWH(x, bx.top - h * 0.02, w * 0.03, bx.height + h * 0.04), const Radius.circular(3));
      canvas.drawRRect(hr, handle);
      canvas.drawLine(Offset(x + w * 0.015, bx.top + bx.height * 0.12), Offset(x + w * 0.015, bx.bottom - bx.height * 0.12),
          Paint()
            ..color = const Color(0xFFB8C0CC)
            ..strokeWidth = math.max(0.8, w * 0.006));
    }
    final lineH = bx.height / lines;
    // connector strip: network, MIDI, USB
    final cy = bx.top + lineH * 0.5;
    final cs = math.max(1.5, lineH * 0.30);
    canvas.drawRect(Rect.fromCenter(center: Offset(bx.left + bx.width * 0.08, cy), width: cs * 1.3, height: cs), Paint()..color = _hole);
    for (var i = 0; i < 2; i++) {
      canvas.drawCircle(Offset(bx.left + bx.width * (0.20 + i * 0.07), cy), cs * 0.55, Paint()..color = _hole);
    }
    canvas.drawRect(Rect.fromCenter(center: Offset(bx.left + bx.width * 0.36, cy), width: cs, height: cs * 0.7), Paint()..color = _hole);
    final led = Offset(bx.left + bx.width * 0.46, cy);
    canvas.drawCircle(led, math.max(1.2, w * 0.012), Paint()
      ..color = accent
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2));
    // input rows (combo sockets)
    final maxCols = rows.fold<int>(0, math.max);
    final stepX = bx.width * 0.86 / maxCols;
    for (var r = 0; r < rows.length; r++) {
      final y = bx.top + lineH * (r + 1.5);
      final jr = math.min(stepX * 0.36, lineH * 0.36);
      for (var i = 0; i < rows[r]; i++) {
        final c = Offset(bx.left + bx.width * 0.07 + stepX * (i + 0.5), y);
        canvas.drawCircle(c, jr, Paint()..color = _hole);
        canvas.drawCircle(c, jr, Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(0.6, jr * 0.16)
          ..color = const Color(0xFF9AA3B0));
        canvas.drawCircle(c, jr * 0.32, Paint()..color = const Color(0xFF5A6272));
      }
    }
    // XLR outputs: smaller sockets with three pins
    if (s.outs > 0) {
      final y = bx.top + lineH * (rows.length + 1.5);
      final jr = math.min(stepX * 0.30, lineH * 0.32);
      for (var i = 0; i < s.outs; i++) {
        final c = Offset(bx.left + bx.width * 0.07 + stepX * (i + 0.5), y);
        canvas.drawCircle(c, jr, Paint()..color = const Color(0xFF3A4252));
        for (var pin = 0; pin < 3; pin++) {
          final a = -math.pi / 2 + pin * 2 * math.pi / 3;
          canvas.drawCircle(c + Offset(math.cos(a), math.sin(a)) * jr * 0.45, math.max(0.4, jr * 0.13), Paint()..color = _hole);
        }
      }
      // phones / level knob at the end of the row
      final kc = Offset(bx.right - bx.width * 0.08, y);
      canvas.drawCircle(kc, jr * 0.8, Paint()..color = _metal);
    }
    _rim(canvas, bx.bottomLeft, bx.bottomRight, Offset(bx.right, bx.top), accent, h * 0.6);
  }

  @override
  bool shouldRepaint(covariant _StageBoxPainter old) => old.s != s || old.accent != accent;
}
