import 'package:flutter/material.dart';

import '../mixer/mixer_profile.dart';
import 'app_style.dart';

/// Original, brand-free illustrations of the two mixer families:
/// a desk console (X32 / M32 family) and a compact stage box (XR / MR family).
class MixerArt extends StatelessWidget {
  const MixerArt({super.key, required this.family, this.width = 120, this.height = 72});
  final MixerFamily family;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: family == MixerFamily.x32 ? _ConsolePainter() : _StageBoxPainter(),
      ),
    );
  }
}

/// Desk console: sloped body, screen, colour strips, a bank of faders and a
/// teal master fader.
class _ConsolePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;

    // Shadow under the desk
    canvas.drawOval(
      Rect.fromLTWH(w * 0.06, h * 0.86, w * 0.88, h * 0.12),
      Paint()
        ..color = Colors.black.withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // Body: a trapezoid seen slightly from above
    final body = Path()
      ..moveTo(w * 0.10, h * 0.08)
      ..lineTo(w * 0.90, h * 0.08)
      ..lineTo(w * 0.98, h * 0.90)
      ..lineTo(w * 0.02, h * 0.90)
      ..close();
    canvas.drawPath(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF2C3446), Color(0xFF151A24)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawPath(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.18),
    );
    // Front lip
    canvas.drawRect(
      Rect.fromLTWH(w * 0.02, h * 0.90, w * 0.96, h * 0.05),
      Paint()..color = const Color(0xFF0B0E14),
    );

    // Screen with a blue glow
    final screen = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.40, h * 0.14, w * 0.22, h * 0.16),
      const Radius.circular(2),
    );
    canvas.drawRRect(
      screen.inflate(2),
      Paint()
        ..color = AppStyle.glowBlue.withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
    canvas.drawRRect(screen, Paint()..color = const Color(0xFF2D6FD6));

    // Knob rows either side of the screen
    final knob = Paint()..color = const Color(0xFF8E96A3);
    for (var i = 0; i < 4; i++) {
      canvas.drawCircle(Offset(w * (0.18 + i * 0.05), h * 0.20), w * 0.012, knob);
      canvas.drawCircle(Offset(w * (0.67 + i * 0.05), h * 0.20), w * 0.012, knob);
    }

    // Scribble strips
    const colors = [
      Color(0xFFE5484D), Color(0xFF46A758), Color(0xFFF5D90A), Color(0xFF3E8EF7), //
      Color(0xFFD864D8), Color(0xFF29C5D6), Color(0xFFEDEDED), Color(0xFF3E8EF7),
    ];
    const faders = 8;
    final left = w * 0.10, right = w * 0.80;
    final step = (right - left) / faders;
    for (var i = 0; i < faders; i++) {
      final x = left + step * (i + 0.5);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(x, h * 0.40), width: step * 0.7, height: h * 0.06),
          const Radius.circular(1.5),
        ),
        Paint()..color = colors[i],
      );
      _fader(canvas, x, h * 0.50, h * 0.84, 0.35 + (i % 3) * 0.18, const Color(0xFFD5DAE2), w);
    }
    // Master fader
    _fader(canvas, w * 0.89, h * 0.36, h * 0.84, 0.75, AppStyle.mainTeal, w);
  }

  void _fader(Canvas canvas, double x, double top, double bottom, double pos, Color cap, double w) {
    canvas.drawLine(
      Offset(x, top),
      Offset(x, bottom),
      Paint()
        ..color = Colors.black
        ..strokeWidth = w * 0.012,
    );
    final y = bottom - (bottom - top) * pos;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(x, y), width: w * 0.045, height: w * 0.03),
        const Radius.circular(1.5),
      ),
      Paint()..color = cap,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Compact stage box: a rugged box with a row of combo inputs, a few knobs,
/// a status light and side handles.
class _StageBoxPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final bx = Rect.fromLTWH(w * 0.12, h * 0.22, w * 0.76, h * 0.62);

    canvas.drawOval(
      Rect.fromLTWH(w * 0.12, h * 0.82, w * 0.76, h * 0.12),
      Paint()
        ..color = Colors.black.withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // Top face (a little perspective)
    final top = Path()
      ..moveTo(bx.left + w * 0.04, bx.top - h * 0.12)
      ..lineTo(bx.right - w * 0.04, bx.top - h * 0.12)
      ..lineTo(bx.right, bx.top)
      ..lineTo(bx.left, bx.top)
      ..close();
    canvas.drawPath(top, Paint()..color = const Color(0xFF3A4356));

    // Front panel
    final front = RRect.fromRectAndRadius(bx, const Radius.circular(4));
    canvas.drawRRect(
      front,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF2A3142), Color(0xFF141922)],
        ).createShader(bx),
    );
    canvas.drawRRect(
      front,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.18),
    );

    // Side handles
    final handle = Paint()
      ..color = const Color(0xFF8E96A3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.02
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(bx.left - w * 0.03, bx.top + h * 0.08), Offset(bx.left - w * 0.03, bx.bottom - h * 0.08), handle);
    canvas.drawLine(Offset(bx.right + w * 0.03, bx.top + h * 0.08), Offset(bx.right + w * 0.03, bx.bottom - h * 0.08), handle);

    // Two rows of combo inputs
    const cols = 6;
    final stepX = bx.width / cols;
    for (var r = 0; r < 2; r++) {
      for (var i = 0; i < cols; i++) {
        final c = Offset(bx.left + stepX * (i + 0.5), bx.top + bx.height * (0.30 + r * 0.30));
        canvas.drawCircle(c, stepX * 0.30, Paint()..color = const Color(0xFF0A0D12));
        canvas.drawCircle(
          c,
          stepX * 0.30,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.2
            ..color = const Color(0xFF9AA3B0),
        );
        canvas.drawCircle(c, stepX * 0.09, Paint()..color = const Color(0xFF5A6272));
      }
    }

    // Knobs and status light along the bottom
    for (var i = 0; i < 3; i++) {
      canvas.drawCircle(
        Offset(bx.left + bx.width * (0.18 + i * 0.12), bx.top + bx.height * 0.85),
        w * 0.018,
        Paint()..color = const Color(0xFF8E96A3),
      );
    }
    final led = Offset(bx.right - bx.width * 0.12, bx.top + bx.height * 0.85);
    canvas.drawCircle(
      led,
      w * 0.02,
      Paint()
        ..color = AppStyle.mainTeal
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
    canvas.drawCircle(led, w * 0.012, Paint()..color = const Color(0xFFB5FFF4));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
