// Bluetooth test for the FLOW 8: finds the mixer, lists what it offers over
// Bluetooth LE, listens to everything it sends and logs it, and, where the
// mixer speaks standard Bluetooth MIDI, opens it as a mixer. The log can be
// shared so the mixer's own protocol can be worked out from it.

import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:share_plus/share_plus.dart';

import '../flow/ble_midi.dart';
import '../flow/flow8_link.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'mixer_screen.dart';

class BleProbeScreen extends StatefulWidget {
  const BleProbeScreen({super.key});

  @override
  State<BleProbeScreen> createState() => _BleProbeScreenState();
}

class _BleProbeScreenState extends State<BleProbeScreen> {
  final List<ScanResult> _found = [];
  final List<String> _log = [];
  final List<StreamSubscription<dynamic>> _subs = [];
  final Stopwatch _clock = Stopwatch()..start();
  StreamSubscription<List<ScanResult>>? _scanSub;
  BluetoothDevice? _device;
  List<BluetoothService> _services = [];
  BluetoothCharacteristic? _midi;
  bool _scanning = false;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _scan();
  }

  @override
  void dispose() {
    _scanSub?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    FlutterBluePlus.stopScan();
    _device?.disconnect();
    super.dispose();
  }

  void _add(String line) {
    final t = (_clock.elapsedMilliseconds / 1000).toStringAsFixed(2).padLeft(7);
    setState(() {
      _log.add('$t  $line');
      if (_log.length > 3000) _log.removeRange(0, _log.length - 3000);
    });
  }

  Future<void> _scan() async {
    setState(() {
      _error = null;
      _found.clear();
      _scanning = true;
    });
    try {
      if (await FlutterBluePlus.isSupported == false) {
        setState(() => _error = 'This device has no Bluetooth LE.');
        return;
      }
      _scanSub?.cancel();
      _scanSub = FlutterBluePlus.scanResults.listen((r) {
        if (!mounted) return;
        setState(() {
          _found
            ..clear()
            ..addAll(r)
            ..sort((a, b) {
              int score(ScanResult x) => _name(x).toUpperCase().contains('FLOW') ? 0 : (_name(x).isEmpty ? 2 : 1);
              final s = score(a).compareTo(score(b));
              return s != 0 ? s : b.rssi.compareTo(a.rssi);
            });
        });
      });
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 12));
      await FlutterBluePlus.isScanning.where((s) => !s).first;
    } catch (e) {
      if (mounted) setState(() => _error = 'Scan failed: $e');
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

  static String _name(ScanResult r) =>
      r.device.platformName.isNotEmpty ? r.device.platformName : r.advertisementData.advName;

  Future<void> _connect(ScanResult r) async {
    await FlutterBluePlus.stopScan();
    setState(() {
      _busy = true;
      _error = null;
    });
    final d = r.device;
    _add('connect ${_name(r)} ${d.remoteId.str} rssi ${r.rssi}');
    _add('adv services ${r.advertisementData.serviceUuids.map((g) => g.str).join(', ')}');
    if (r.advertisementData.manufacturerData.isNotEmpty) {
      r.advertisementData.manufacturerData
          .forEach((k, v) => _add('adv manufacturer 0x${k.toRadixString(16)}: ${hex(v)}'));
    }
    try {
      await d.connect(license: License.nonprofit, timeout: const Duration(seconds: 20));
      _device = d;
      _subs.add(d.connectionState.listen((s) {
        if (s == BluetoothConnectionState.disconnected) _add('disconnected');
      }));
      final services = await d.discoverServices();
      _services = services;
      for (final s in services) {
        _add('service ${s.uuid.str128}');
        for (final c in s.characteristics) {
          _add('  char ${c.uuid.str128} [${_props(c)}]');
          if (s.uuid.str128.toLowerCase() == bleMidiService && c.uuid.str128.toLowerCase() == bleMidiCharacteristic) {
            _midi = c;
          }
        }
      }
      if (_midi != null) _add('*** standard Bluetooth MIDI service found ***');
      // read what can be read, listen to everything that can be listened to
      for (final s in services) {
        for (final c in s.characteristics) {
          if (c.properties.read) {
            try {
              final v = await c.read();
              _add('read ${_short(c)}: ${hex(v)}  ${_ascii(v)}');
            } catch (e) {
              _add('read ${_short(c)} failed: $e');
            }
          }
          if (c.properties.notify || c.properties.indicate) {
            _subs.add(c.onValueReceived.listen((v) {
              final midi = c == _midi ? '  midi: ${hex(bleMidiDecode(v))}' : '';
              _add('<< ${_short(c)}: ${hex(v)}$midi');
            }));
            try {
              await c.setNotifyValue(true);
              _add('listening ${_short(c)}');
            } catch (e) {
              _add('listen ${_short(c)} failed: $e');
            }
          }
        }
      }
    } catch (e) {
      _add('connect failed: $e');
      if (mounted) setState(() => _error = 'Could not connect: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  static String _props(BluetoothCharacteristic c) => [
        if (c.properties.read) 'read',
        if (c.properties.write) 'write',
        if (c.properties.writeWithoutResponse) 'write-no-resp',
        if (c.properties.notify) 'notify',
        if (c.properties.indicate) 'indicate',
      ].join(' ');

  static String _short(BluetoothCharacteristic c) => c.uuid.str;

  static String _ascii(List<int> v) =>
      String.fromCharCodes(v.map((b) => b >= 32 && b < 127 ? b : 46)); // '.' for the rest

  Future<void> _write(BluetoothCharacteristic c, List<int> bytes) async {
    try {
      await c.write(bytes, withoutResponse: c.properties.writeWithoutResponse && !c.properties.write);
      _add('>> ${_short(c)}: ${hex(bytes)}');
    } catch (e) {
      _add('write ${_short(c)} failed: $e');
    }
  }

  /// CH 1 mute on / off over Bluetooth MIDI (the FLOW 8's own MIDI table).
  Future<void> _testMute(bool on) => _write(_midi!, bleMidiPacket([0xB0, 5, on ? 127 : 0]));

  void _openMixer() {
    final c = _midi!;
    final d = _device!;
    final link = Flow8Link(
      sendBytes: (b) =>
          c.write(bleMidiPacket(b), withoutResponse: c.properties.writeWithoutResponse).catchError((_) {}),
      incoming: c.onValueReceived.map((v) => Uint8List.fromList(bleMidiDecode(v))),
      deviceName: d.platformName.isEmpty ? 'FLOW 8' : d.platformName,
      onClose: () => d.disconnect().catchError((_) {}),
    );
    link.restore().then((_) {
      if (!mounted) return;
      final mc =
          MixerController.overLink(MixerProfile.flow8('FLOW 8'), link, mixerName: link.deviceName, host: 'Bluetooth');
      // the mixer screen owns the controller now; keep the BLE link open
      _device = null;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MixerScreen(controller: mc)));
    });
  }

  Future<void> _writeDialog(BluetoothCharacteristic c) async {
    final t = TextEditingController();
    final bytes = await showDialog<List<int>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Write to ${_short(c)}'),
        content: TextField(
          controller: t,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'hex, e.g. b0 05 7f'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, parseHex(t.text)), child: const Text('Send')),
        ],
      ),
    );
    if (bytes != null) await _write(c, bytes);
  }

  Future<void> _share() async {
    final text = _log.join('\n');
    await Clipboard.setData(ClipboardData(text: text));
    try {
      await SharePlus.instance.share(ShareParams(text: text, subject: 'FLOW 8 Bluetooth log'));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final connected = _device != null;
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('FLOW 8 · Bluetooth test'),
          actions: [
            IconButton(
              tooltip: 'Share / copy the log',
              onPressed: _log.isEmpty ? null : _share,
              icon: const Icon(Icons.ios_share),
            ),
          ],
        ),
        body: SafeArea(
          top: false,
          child: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              const Text(
                'Close the FLOW Mix app first: the mixer takes one Bluetooth connection at a time. '
                'Once connected, move a few controls on the FLOW 8 (a fader, a mute) and share the log.',
                style: TextStyle(color: Colors.white70),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!, style: const TextStyle(color: Color(0xFFFF6B6B))),
                ),
              const SizedBox(height: 10),
              if (!connected) ...[
                Row(
                  children: [
                    Text(_scanning ? 'Searching…' : 'Devices', style: const TextStyle(fontWeight: FontWeight.w700)),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: _scanning || _busy ? null : _scan,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Search again'),
                    ),
                  ],
                ),
                for (final r in _found.take(30))
                  ListTile(
                    dense: true,
                    leading: Icon(
                      Icons.bluetooth,
                      color: _name(r).toUpperCase().contains('FLOW') ? AppStyle.glowBlue : Colors.white38,
                    ),
                    title: Text(_name(r).isEmpty ? '(no name)' : _name(r)),
                    subtitle: Text('${r.device.remoteId.str} · ${r.rssi} dBm'),
                    trailing: _busy ? null : const Icon(Icons.chevron_right),
                    onTap: _busy ? null : () => _connect(r),
                  ),
              ],
              if (connected && _midi != null)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Bluetooth MIDI found', style: TextStyle(fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        const Text('Test: CH 1 should mute and unmute.', style: TextStyle(color: Colors.white70)),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            OutlinedButton(onPressed: () => _testMute(true), child: const Text('CH 1 mute')),
                            OutlinedButton(onPressed: () => _testMute(false), child: const Text('CH 1 unmute')),
                            FilledButton.icon(
                              onPressed: _openMixer,
                              icon: const Icon(Icons.tune),
                              label: const Text('Open as mixer'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              if (connected)
                for (final s in _services)
                  for (final c in s.characteristics)
                    if (c.properties.write || c.properties.writeWithoutResponse)
                      ListTile(
                        dense: true,
                        title: Text('Write ${_short(c)}'),
                        subtitle: Text(s.uuid.str),
                        trailing: const Icon(Icons.edit),
                        onTap: () => _writeDialog(c),
                      ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Text('Log (${_log.length})', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const Spacer(),
                  TextButton(onPressed: () => setState(_log.clear), child: const Text('Clear')),
                ],
              ),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.4),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SelectableText(
                  _log.isEmpty ? '—' : _log.reversed.take(300).join('\n'),
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
