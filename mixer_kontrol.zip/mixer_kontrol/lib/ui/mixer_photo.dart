import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'mixer_art.dart';
import 'mixer_catalog.dart';

/// The person's own photos of their mixers, one per catalog model, kept on
/// this device only (in the app's documents folder).
class MixerPhotos {
  MixerPhotos._();

  static String _key(String id) => 'mixer_photo_$id';

  /// Bumped whenever a photo changes, so pictures redraw.
  static final changes = ValueNotifier<int>(0);

  static final Map<String, String?> _cache = {};

  static Future<File?> fileFor(String id) async {
    String? path;
    if (_cache.containsKey(id)) {
      path = _cache[id];
    } else {
      try {
        path = (await SharedPreferences.getInstance()).getString(_key(id));
      } catch (_) {}
      _cache[id] = path;
    }
    if (path == null) return null;
    final f = File(path);
    return await f.exists() ? f : null;
  }

  /// Picks a photo from the camera or gallery and keeps a copy. False if the
  /// person cancelled or it couldn't be saved.
  static Future<bool> pick(String id, ImageSource source) async {
    try {
      final x = await ImagePicker().pickImage(source: source, maxWidth: 1600, maxHeight: 1600, imageQuality: 85);
      if (x == null) return false;
      final dir = Directory('${(await getApplicationDocumentsDirectory()).path}/mixer_photos');
      await dir.create(recursive: true);
      // a new name each time, so the picture cache never shows the old one
      final dest = File('${dir.path}/${id}_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await File(x.path).copy(dest.path);
      final old = await fileFor(id);
      (await SharedPreferences.getInstance()).setString(_key(id), dest.path);
      _cache[id] = dest.path;
      if (old != null) {
        try {
          await old.delete();
        } catch (_) {}
      }
      changes.value++;
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> remove(String id) async {
    final old = await fileFor(id);
    try {
      (await SharedPreferences.getInstance()).remove(_key(id));
      await old?.delete();
    } catch (_) {}
    _cache[id] = null;
    changes.value++;
  }

  @visibleForTesting
  static void clearCache() => _cache.clear();
}

/// The person's photo of [model] if they added one, else its illustration.
class MixerPicture extends StatelessWidget {
  const MixerPicture({super.key, required this.model, this.width = 160, this.height = 96, this.radius = 10});
  final MixerModel model;
  final double width;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: MixerPhotos.changes,
      builder: (context, _, __) => FutureBuilder<File?>(
        future: MixerPhotos.fileFor(model.id),
        builder: (context, snap) {
          final f = snap.data;
          if (f == null) return MixerArt(spec: model.art, width: width, height: height);
          return ClipRRect(
            borderRadius: BorderRadius.circular(radius),
            child: Image.file(
              f,
              width: width,
              height: height,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => MixerArt(spec: model.art, width: width, height: height),
            ),
          );
        },
      ),
    );
  }
}
