import 'package:flutter/material.dart';

import '../util/fader_math.dart';

/// Vertical fader with relative dragging (the fader never jumps to the finger),
/// double-tap to 0 dB.
class VerticalFader extends StatefulWidget {
  const VerticalFader({
    super.key,
    required this.value,
    required this.onChanged,
    this.onStart,
    this.onEnd,
    this.accent,
    this.thumbHeight = 44,
    this.showScale = false,
  });

  final double value;
  final ValueChanged<double> onChanged;
  final VoidCallback? onStart;
  final VoidCallback? onEnd;
  final Color? accent;
  final double thumbHeight;

  /// Draw dB numbers next to the ticks (only when there is room).
  final bool showScale;

  @override
  State<VerticalFader> createState() => _VerticalFaderState();
}

class _VerticalFaderState extends State<VerticalFader> {
  double _drag = 0;
  bool _active = false;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final thumbH = widget.thumbHeight;
    return LayoutBuilder(builder: (context, c) {
      final travel = (c.maxHeight - thumbH).clamp(1.0, double.infinity);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onVerticalDragStart: (_) {
          _drag = widget.value;
          setState(() => _active = true);
          widget.onStart?.call();
        },
        onVerticalDragUpdate: (d) {
          _drag = (_drag - d.delta.dy / travel).clamp(0.0, 1.0);
          widget.onChanged(_drag);
        },
        onVerticalDragEnd: (_) => _end(),
        onVerticalDragCancel: _end,
        onDoubleTap: () {
          widget.onStart?.call();
          widget.onChanged(unityFader);
          widget.onEnd?.call();
        },
        child: CustomPaint(
          size: Size(c.maxWidth, c.maxHeight),
          painter: _FaderPainter(
            value: widget.value,
            thumbH: thumbH,
            accent: widget.accent ?? scheme.primary,
            tick: Colors.white.withValues(alpha: 0.28),
            label: Colors.white.withValues(alpha: 0.45),
            active: _active,
            showScale: widget.showScale,
          ),
        ),
      );
    });
  }

  void _end() {
    if (_active) setState(() => _active = false);
    widget.onEnd?.call();
  }
}

class _FaderPainter extends CustomPainter {
  _FaderPainter({
    required this.value,
    required this.thumbH,
    required this.accent,
    required this.tick,
    required this.label,
    required this.active,
    required this.showScale,
  });

  final double value;
  final double thumbH;
  final Color accent, tick, label;
  final bool active, showScale;

  static const _ticks = [10.0, 5.0, 0.0, -5.0, -10.0, -20.0, -30.0, -40.0, -60.0];
  // A const Set of doubles is not allowed in Dart (no primitive equality), so a list.
  static const _labelled = [10.0, 0.0, -10.0, -20.0, -40.0];

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final top = thumbH / 2;
    final travel = size.height - thumbH;
    final bottom = top + travel;
    double yFor(double f) => top + (1 - f) * travel;

    // Scale ticks
    final tickPaint = Paint()
      ..color = tick
      ..strokeWidth = 1;
    for (final db in _ticks) {
      final y = yFor(dbToFader(db));
      final w = db == 0 ? size.width * 0.40 : size.width * 0.26;
      canvas.drawLine(Offset(cx - w, y), Offset(cx - 7, y), tickPaint);
      canvas.drawLine(Offset(cx + 7, y), Offset(cx + w, y), tickPaint);
      if (showScale && _labelled.contains(db)) {
        final tp = TextPainter(
          text: TextSpan(
            text: db > 0 ? '+${db.round()}' : '${db.round()}',
            style: TextStyle(color: label, fontSize: 9),
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(size.width - tp.width - 1, y - tp.height / 2));
      }
    }

    // Recessed slot
    final slot = RRect.fromLTRBR(cx - 3.5, top, cx + 3.5, bottom, const Radius.circular(4));
    canvas.drawRRect(slot, Paint()..color = const Color(0xFF030406));
    canvas.drawRRect(
      slot,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.08),
    );

    // Level fill with a soft glow
    final y = yFor(value);
    if (bottom - y > 1) {
      final fill = RRect.fromLTRBR(cx - 2, y, cx + 2, bottom, const Radius.circular(2));
      canvas.drawRRect(
        fill.inflate(2),
        Paint()
          ..color = accent.withValues(alpha: 0.45)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
      );
      canvas.drawRRect(fill, Paint()..color = accent);
    }

    // Fader cap: brushed-metal gradient, grip ridges, accent index line.
    // (never wider than the strip: slim strips sit side by side)
    final tw = (size.width * 0.66).clamp(26.0, 58.0).clamp(0.0, size.width + 2);
    final rect = Rect.fromCenter(center: Offset(cx, y), width: tw, height: thumbH);
    final cap = RRect.fromRectAndRadius(rect, const Radius.circular(7));
    canvas.drawRRect(
      cap.shift(const Offset(0, 3)),
      Paint()
        ..color = Colors.black.withValues(alpha: 0.55)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
    canvas.drawRRect(
      cap,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: active
              ? const [Color(0xFFF4F6FA), Color(0xFFC9CFD8), Color(0xFFAEB5C0)]
              : const [Color(0xFFE2E6EC), Color(0xFFB4BBC6), Color(0xFF8E96A3)],
          stops: const [0, 0.5, 1],
        ).createShader(rect),
    );
    canvas.drawRRect(
      cap,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.6),
    );
    final ridge = Paint()
      ..color = Colors.black.withValues(alpha: 0.18)
      ..strokeWidth = 1;
    final step = thumbH / 8;
    for (var i = 1; i < 8; i++) {
      if (i == 4) continue;
      final ry = rect.top + i * step;
      canvas.drawLine(Offset(rect.left + 5, ry), Offset(rect.right - 5, ry), ridge);
    }
    canvas.drawLine(
      Offset(rect.left + 3, y),
      Offset(rect.right - 3, y),
      Paint()
        ..color = accent
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(_FaderPainter old) =>
      old.value != value ||
      old.accent != accent ||
      old.active != active ||
      old.thumbH != thumbH ||
      old.showScale != showScale;
}
