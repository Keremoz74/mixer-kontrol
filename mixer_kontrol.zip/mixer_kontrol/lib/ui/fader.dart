import 'package:flutter/material.dart';

import '../util/fader_math.dart';

/// Vertical fader with relative dragging (the fader never jumps to the finger),
/// double-tap to 0 dB.
class VerticalFader extends StatefulWidget {
  const VerticalFader({
    super.key,
    required this.value,
    required this.onChanged,
    this.onStart,
    this.onEnd,
    this.accent,
  });

  final double value;
  final ValueChanged<double> onChanged;
  final VoidCallback? onStart;
  final VoidCallback? onEnd;
  final Color? accent;

  @override
  State<VerticalFader> createState() => _VerticalFaderState();
}

class _VerticalFaderState extends State<VerticalFader> {
  static const double _thumbH = 44;
  double _drag = 0;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return LayoutBuilder(builder: (context, c) {
      final travel = (c.maxHeight - _thumbH).clamp(1.0, double.infinity);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onVerticalDragStart: (_) {
          _drag = widget.value;
          widget.onStart?.call();
        },
        onVerticalDragUpdate: (d) {
          _drag = (_drag - d.delta.dy / travel).clamp(0.0, 1.0);
          widget.onChanged(_drag);
        },
        onVerticalDragEnd: (_) => widget.onEnd?.call(),
        onVerticalDragCancel: () => widget.onEnd?.call(),
        onDoubleTap: () {
          widget.onStart?.call();
          widget.onChanged(unityFader);
          widget.onEnd?.call();
        },
        child: CustomPaint(
          size: Size(c.maxWidth, c.maxHeight),
          painter: _FaderPainter(
            value: widget.value,
            thumbH: _thumbH,
            accent: widget.accent ?? scheme.primary,
            track: scheme.surfaceContainerHighest,
            tick: scheme.onSurfaceVariant.withValues(alpha: 0.5),
            thumb: scheme.onSurface,
          ),
        ),
      );
    });
  }
}

class _FaderPainter extends CustomPainter {
  _FaderPainter({
    required this.value,
    required this.thumbH,
    required this.accent,
    required this.track,
    required this.tick,
    required this.thumb,
  });

  final double value;
  final double thumbH;
  final Color accent, track, tick, thumb;

  static const _ticks = [10.0, 5.0, 0.0, -5.0, -10.0, -20.0, -30.0, -40.0, -60.0];

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final top = thumbH / 2;
    final travel = size.height - thumbH;
    double yFor(double f) => top + (1 - f) * travel;

    // Scale ticks
    final tickPaint = Paint()
      ..color = tick
      ..strokeWidth = 1;
    for (final db in _ticks) {
      final y = yFor(dbToFader(db));
      final w = db == 0 ? size.width * 0.38 : size.width * 0.22;
      canvas.drawLine(Offset(cx - w, y), Offset(cx - 6, y), tickPaint);
      canvas.drawLine(Offset(cx + 6, y), Offset(cx + w, y), tickPaint);
    }

    // Track + level fill
    final trackRect = RRect.fromLTRBR(cx - 3, top, cx + 3, top + travel, const Radius.circular(3));
    canvas.drawRRect(trackRect, Paint()..color = track);
    final y = yFor(value);
    canvas.drawRRect(
      RRect.fromLTRBR(cx - 3, y, cx + 3, top + travel, const Radius.circular(3)),
      Paint()..color = accent,
    );

    // Thumb
    final tw = (size.width * 0.62).clamp(28.0, 56.0);
    final thumbRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(cx, y), width: tw, height: thumbH),
      const Radius.circular(6),
    );
    canvas.drawRRect(thumbRect.shift(const Offset(0, 2)), Paint()..color = Colors.black38);
    canvas.drawRRect(thumbRect, Paint()..color = thumb);
    canvas.drawLine(
      Offset(cx - tw / 2 + 4, y),
      Offset(cx + tw / 2 - 4, y),
      Paint()
        ..color = accent
        ..strokeWidth = 3,
    );
  }

  @override
  bool shouldRepaint(_FaderPainter old) =>
      old.value != value || old.accent != accent || old.thumb != thumb;
}
