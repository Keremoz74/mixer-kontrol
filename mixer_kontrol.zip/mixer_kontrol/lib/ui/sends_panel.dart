import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';
import 'channel_strip.dart' show sendsAccent, stripColor;
import 'param_controls.dart';

/// Every bus / FX send of one channel on a single page — the reverse of
/// "sends on fader" (which shows one bus across all channels).
class SendsPanel extends StatelessWidget {
  const SendsPanel({super.key, required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final targets = controller.profile.sendTargets;
    return LayoutBuilder(builder: (context, cons) {
      // Two columns when there is room (tablet, phone in landscape).
      final cols = cons.maxWidth >= 640 ? 2 : 1;
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: cols,
          mainAxisExtent: 122,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: targets.length,
        itemBuilder: (context, i) => _SendRow(controller: controller, strip: strip, target: targets[i]),
      );
    });
  }
}

class _SendRow extends StatelessWidget {
  const _SendRow({required this.controller, required this.strip, required this.target});
  final MixerController controller;
  final Strip strip;
  final SendTarget target;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final onAddr = strip.sendOnAddr(target);
    final nameN = c.param(target.master.nameAddr);
    final colorN = c.param(target.master.colorAddr);
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 0),
      decoration: AppStyle.panel(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              ListenableBuilder(
                listenable: colorN,
                builder: (context, _) => Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(color: stripColor(colorN.value), shape: BoxShape.circle),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ListenableBuilder(
                  listenable: nameN,
                  builder: (context, _) {
                    final n = nameN.value;
                    final custom = n is String && n.trim().isNotEmpty;
                    return Text(
                      custom ? '$n  ·  ${target.label}' : target.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    );
                  },
                ),
              ),
              ValueListenableBuilder<Object?>(
                valueListenable: c.param(onAddr),
                builder: (context, v, _) => Switch(
                  value: c.isOn(onAddr),
                  activeTrackColor: sendsAccent,
                  onChanged: (on) => c.setFlag(onAddr, on),
                ),
              ),
            ],
          ),
          ParamSlider(
            controller: c,
            addr: strip.sendLevelAddr(target),
            label: 'Seviye',
            color: sendsAccent,
            fallback: 0,
            resetNorm: unityFader,
            format: formatDb,
          ),
        ],
      ),
    );
  }
}
