import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';
import 'param_controls.dart';

const assignAccent = Color(0xFF9D7BFF);
const soloYellow = Color(0xFFFFD60A);

String stripTitle(MixerController c, Strip s) {
  final n = c.param(s.nameAddr).value;
  return n is String && n.trim().isNotEmpty ? '${n.trim()} (${s.defaultLabel})' : s.defaultLabel;
}

/// True if [s] has anything to show in the assign sheet.
bool hasAssignOptions(MixerProfile p, Strip s) =>
    p.hasGroups(s) || p.mainAssignAddr(s) != null || p.linkAddr(s) != null;

/// DCA / mute group membership, Main LR (and X32 mono) assignment and the
/// stereo link of one strip.
Future<void> showAssignSheet(BuildContext context, MixerController c, Strip s) {
  final p = c.profile;
  final addrs = <String>[
    if (p.hasGroups(s)) ...[p.dcaMaskAddr(s), p.muteMaskAddr(s)],
    if (p.mainAssignAddr(s) != null) p.mainAssignAddr(s)!,
    if (p.monoAssignAddr(s) != null) ...[p.monoAssignAddr(s)!, p.monoLevelAddr(s)!],
    if (p.linkAddr(s) != null) p.linkAddr(s)!,
  ];
  c.query(addrs);
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    builder: (context) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.85),
        child: ListenableBuilder(
          listenable: Listenable.merge([for (final a in addrs) c.param(a)]),
          builder: (context, _) => ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              Text(stripTitle(c, s), style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              if (p.mainAssignAddr(s) != null)
                _panel(SwitchListTile(
                  activeTrackColor: AppStyle.mainTeal,
                  secondary: const Icon(Icons.speaker_group_outlined),
                  title: const Text('Send to Main LR'),
                  subtitle: const Text('Off = this strip only feeds buses / matrices', style: TextStyle(fontSize: 12)),
                  value: c.flagOf(p.mainAssignAddr(s)!),
                  onChanged: (v) => c.setFlag(p.mainAssignAddr(s)!, v),
                )),
              if (p.monoAssignAddr(s) != null)
                _panel(Column(
                  children: [
                    SwitchListTile(
                      activeTrackColor: AppStyle.mainTeal,
                      secondary: const Icon(Icons.center_focus_strong_outlined),
                      title: const Text('Send to M/C (mono / centre)'),
                      value: c.flagOf(p.monoAssignAddr(s)!),
                      onChanged: (v) => c.setFlag(p.monoAssignAddr(s)!, v),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
                      child: ParamSlider(
                        controller: c,
                        addr: p.monoLevelAddr(s)!,
                        label: 'M/C level',
                        format: formatDb,
                        fallback: 0,
                        resetNorm: unityFader,
                        enabled: c.flagOf(p.monoAssignAddr(s)!),
                        color: AppStyle.mainTeal,
                      ),
                    ),
                  ],
                )),
              if (p.linkAddr(s) != null) ...[
                Builder(builder: (context) {
                  final partner = p.linkPartner(s);
                  final a = s.index.isOdd ? s : partner;
                  final b = s.index.isOdd ? partner : s;
                  final pair = a != null && b != null ? '${a.defaultLabel} + ${b.defaultLabel}' : s.defaultLabel;
                  return _panel(SwitchListTile(
                    activeTrackColor: assignAccent,
                    secondary: const Icon(Icons.link),
                    title: Text('Stereo link: $pair'),
                    subtitle: const Text(
                      'The console mirrors settings between the two; pan becomes balance.',
                      style: TextStyle(fontSize: 12),
                    ),
                    value: c.flagOf(p.linkAddr(s)!),
                    onChanged: (v) => c.setFlag(p.linkAddr(s)!, v),
                  ));
                }),
              ],
              if (p.hasGroups(s)) ...[
                const SizedBox(height: 6),
                const Text('DCA', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final d in p.dcas)
                      FilterChip(
                        label: Text(_dcaName(c, d)),
                        selected: c.inDca(s, d.index),
                        selectedColor: AppStyle.glowBlue.withValues(alpha: 0.4),
                        onSelected: (v) => c.setInDca(s, d.index, v),
                      ),
                  ],
                ),
                const SizedBox(height: 14),
                const Text('Mute groups', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (var g = 1; g <= p.muteGroupCount; g++)
                      FilterChip(
                        label: Text('Mute $g'),
                        selected: c.inMuteGroup(s, g),
                        selectedColor: AppStyle.muteRed.withValues(alpha: 0.45),
                        onSelected: (v) => c.setInMuteGroup(s, g, v),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    ),
  );
}

String _dcaName(MixerController c, Strip d) {
  final n = c.param(d.nameAddr).value;
  return n is String && n.trim().isNotEmpty ? n.trim() : d.defaultLabel;
}

Widget _panel(Widget child) => Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: AppStyle.panel(),
      child: child,
    );

// ---------------------------------------------------------------- monitor / solo

/// Monitor (phones) level, what is soloed, and clear solo.
Future<void> showMonitorSheet(BuildContext context, MixerController c) {
  final p = c.profile;
  c.query(p.soloAddresses);
  final soloAddrs = [for (final s in p.allStrips) if (p.soloAddr(s) != null) p.soloAddr(s)!];
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    builder: (context) => SafeArea(
      child: ListenableBuilder(
        listenable: Listenable.merge([
          c.param(MixerProfile.soloAnyAddr),
          for (final a in soloAddrs) c.param(a),
        ]),
        builder: (context, _) {
          final soloed = [for (final s in p.allStrips) if (c.soloOn(s)) s];
          return ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              Text('Monitor & solo', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              if (c.profile.hasMonitorLevel)
              Container(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                decoration: AppStyle.panel(),
                child: ParamSlider(
                  controller: c,
                  addr: MixerProfile.monitorLevelAddr,
                  label: 'Monitor / phones level',
                  format: formatDb,
                  fallback: 0.5,
                  color: soloYellow,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      soloed.isEmpty ? 'Nothing soloed' : 'Soloed: ${soloed.map((s) => s.defaultLabel).join(', ')}',
                      style: TextStyle(color: soloed.isEmpty ? Colors.white54 : soloYellow),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: soloYellow, foregroundColor: Colors.black),
                    onPressed: c.anySolo ? c.clearSolo : null,
                    icon: const Icon(Icons.clear_all),
                    label: const Text('Clear solo'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'Tap S on a strip to listen to it in the phones / monitor output without changing the main mix.',
                style: TextStyle(fontSize: 12, color: Colors.white54),
              ),
            ],
          );
        },
      ),
    ),
  );
}

// ---------------------------------------------------------------- M/C bus (X32)

/// Mode of the X32 mono / centre bus.
Future<void> showMonoOptions(BuildContext context, MixerController c) {
  c.query(const [MixerProfile.monoModeAddr, MixerProfile.monoLinkAddr]);
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    builder: (context) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('M/C bus', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            const Text('Mode', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            ParamChoice(
              controller: c,
              addr: MixerProfile.monoModeAddr,
              labels: const ['LR + Mono', 'LCR'],
              color: AppStyle.mainTeal,
            ),
            const SizedBox(height: 6),
            const Text(
              'LR + Mono: a separate mono mix (e.g. a sub or a fill). LCR: the M/C bus becomes the centre speaker and pan spreads across L, C and R.',
              style: TextStyle(fontSize: 12, color: Colors.white54),
            ),
            const SizedBox(height: 10),
            Container(
              decoration: AppStyle.panel(),
              child: ValueListenableBuilder<Object?>(
                valueListenable: c.param(MixerProfile.monoLinkAddr),
                builder: (context, _, __) => SwitchListTile(
                  activeTrackColor: AppStyle.mainTeal,
                  title: const Text('M/C follows the Main LR fader'),
                  value: c.flagOf(MixerProfile.monoLinkAddr),
                  onChanged: (v) => c.setFlag(MixerProfile.monoLinkAddr, v),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
