import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../mixer/rta.dart';
import '../util/param_law.dart';
import 'app_style.dart';
import 'rta_view.dart';

/// Ring-out helper: watches the RTA of an output, points at sustained narrow
/// peaks (likely feedback) and cuts them with a narrow band of that output's
/// parametric EQ.
class FeedbackScreen extends StatefulWidget {
  const FeedbackScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _Cut {
  _Cut(this.strip, this.band, this.before);
  final Strip strip;
  final int band;
  final Map<String, Object?> before;
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  MixerController get c => widget.controller;
  late Strip _out = c.profile.main;
  List<FeedbackPeak> _peaks = const [];
  final Map<int, int> _seen = {}; // freq bucket -> consecutive hits
  final List<_Cut> _cuts = [];
  Timer? _scan;
  double _sensitivity = 12;

  List<Strip> get _outputs => [
        c.profile.main,
        if (c.profile.mono != null) c.profile.mono!,
        ...c.profile.mixBuses,
      ];

  @override
  void initState() {
    super.initState();
    c.watchRta(_out);
    c.query(_out.eqAddresses);
    _scan = Timer.periodic(const Duration(milliseconds: 250), (_) => _detect());
  }

  @override
  void dispose() {
    _scan?.cancel();
    c.unwatchRta();
    super.dispose();
  }

  void _select(Strip s) {
    setState(() {
      _out = s;
      _peaks = const [];
      _seen.clear();
    });
    c.rta.clear();
    c.watchRta(s);
    c.query(s.eqAddresses);
  }

  /// A peak counts once it has stood out for about a second.
  void _detect() {
    final found = findFeedbackPeaks(c.rta.db, minAbove: _sensitivity);
    final buckets = <int>{};
    for (final f in found) {
      final b = (math.log(f.hz) / math.ln2 * 6).round(); // 1/6-octave buckets
      buckets.add(b);
      _seen[b] = (_seen[b] ?? 0) + 1;
    }
    _seen.removeWhere((k, _) => !buckets.contains(k));
    final steady = [
      for (final f in found)
        if ((_seen[(math.log(f.hz) / math.ln2 * 6).round()] ?? 0) >= 4) f,
    ];
    if (!mounted) return;
    setState(() => _peaks = steady);
  }

  int? _bandFor(double hz) {
    final s = _out;
    final n = s.eqBands;
    // Reuse a band already cutting close to this frequency.
    for (var b = 1; b <= n; b++) {
      final type = c.intOf(s.eqAddr(b, 'type'), -1);
      final f = freqLaw.toReal(c.numOf(s.eqAddr(b, 'f'), 0.5));
      final g = eqGainLaw.toReal(c.numOf(s.eqAddr(b, 'g'), 0.5));
      if (type == 2 && g < -0.5 && (math.log(f / hz) / math.ln2).abs() < 1 / 6) return b;
    }
    // Otherwise a flat band, middle bands first (keep the shelves).
    final order = [for (var b = 2; b < n; b++) b, 1, n];
    for (final b in order) {
      final g = eqGainLaw.toReal(c.numOf(s.eqAddr(b, 'g'), 0.5));
      if (g.abs() < 0.5) return b;
    }
    return null;
  }

  void _cut(FeedbackPeak pk) {
    final s = _out;
    final b = _bandFor(pk.hz);
    if (b == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No free EQ band left on this output. Insert a graphic EQ (FX Rack) for more cuts.'),
      ));
      return;
    }
    final addrs = [s.eqOnAddr, s.eqAddr(b, 'type'), s.eqAddr(b, 'f'), s.eqAddr(b, 'g'), s.eqAddr(b, 'q')];
    final before = {for (final a in addrs) a: c.param(a).value};
    final g0 = eqGainLaw.toReal(c.numOf(s.eqAddr(b, 'g'), 0.5));
    final double newG = math.max(-15.0, (g0 < -0.5 ? g0 : 0.0) - 3.0);
    c.set(s.eqOnAddr, 1);
    c.set(s.eqAddr(b, 'type'), 2); // PEQ
    c.set(s.eqAddr(b, 'f'), freqLaw.toNorm(pk.hz));
    c.set(s.eqAddr(b, 'q'), qLaw.toNorm(8));
    c.set(s.eqAddr(b, 'g'), eqGainLaw.toNorm(newG));
    setState(() => _cuts.add(_Cut(s, b, before)));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('${formatHz(pk.hz)}: band $b at ${newG.toStringAsFixed(0)} dB, Q 8'),
      duration: const Duration(seconds: 2),
    ));
  }

  void _undo(_Cut cut) {
    cut.before.forEach((a, v) {
      if (v != null) c.set(a, v);
    });
    setState(() => _cuts.remove(cut));
  }

  String _name(Strip s) {
    final n = c.param(s.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? '${n.trim()} (${s.defaultLabel})' : s.defaultLabel;
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('Feedback finder')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
          children: [
            const Text(
              'Ring out a system: with the mics in place, raise the output slowly until it starts to ring. '
              'The ringing frequency shows up below; tap Cut to notch it on this output\'s EQ, then raise again.',
              style: TextStyle(fontSize: 13, color: Colors.white70),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _out.prefix,
              decoration: const InputDecoration(labelText: 'Output', border: OutlineInputBorder()),
              items: [for (final s in _outputs) DropdownMenuItem(value: s.prefix, child: Text(_name(s)))],
              onChanged: (v) => _select(_outputs.firstWhere((s) => s.prefix == v)),
            ),
            const SizedBox(height: 10),
            Container(
              height: 200,
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.35),
                borderRadius: BorderRadius.circular(12),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: CustomPaint(
                  painter: RtaPainter(c.rta, marks: [for (final p in _peaks) p.hz]),
                  child: const SizedBox.expand(),
                ),
              ),
            ),
            Row(
              children: [
                const Text('Sensitivity', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 6,
                    max: 20,
                    divisions: 14,
                    value: 26 - _sensitivity,
                    label: '${_sensitivity.round()} dB above surroundings',
                    onChanged: (v) => setState(() => _sensitivity = 26 - v),
                  ),
                ),
              ],
            ),
            const Text('Ringing now', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            if (_peaks.isEmpty)
              Text(
                c.rta.hasData || c.isDemo ? 'Nothing ringing.' : 'Waiting for analyser data from the mixer…',
                style: const TextStyle(color: Colors.white54),
              ),
            for (final pk in _peaks)
              Container(
                margin: const EdgeInsets.only(bottom: 6),
                decoration: AppStyle.panel(),
                child: ListTile(
                  leading: const Icon(Icons.warning_amber, color: Color(0xFFE5484D)),
                  title: Text(formatHz(pk.hz), style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${pk.above.toStringAsFixed(0)} dB above the surrounding spectrum'),
                  trailing: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE5484D)),
                    onPressed: () => _cut(pk),
                    child: const Text('Cut'),
                  ),
                ),
              ),
            if (_cuts.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text('Cuts made', style: TextStyle(fontWeight: FontWeight.w700)),
              for (final cut in _cuts.reversed)
                ListTile(
                  dense: true,
                  title: Text('${cut.strip.defaultLabel} · EQ band ${cut.band}'),
                  subtitle: Text(formatHz(freqLaw.toReal(c.numOf(cut.strip.eqAddr(cut.band, 'f'), 0.5)))),
                  trailing: TextButton(onPressed: () => _undo(cut), child: const Text('Undo')),
                ),
            ],
            const SizedBox(height: 12),
            const Text(
              'Keep levels moderate while ringing out and protect your ears. Cuts are narrow (Q 8), 3 dB per tap.',
              style: TextStyle(fontSize: 12, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }
}
