import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_strip.dart';
import 'fx_screen.dart' show fxAccent;

/// FX page for consoles whose effects can't be edited remotely (Yamaha):
/// the FX bus masters and FX returns side by side, and every input's send
/// to the chosen FX bus as faders.
class FxBusScreen extends StatefulWidget {
  const FxBusScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<FxBusScreen> createState() => _FxBusScreenState();
}

class _FxBusScreenState extends State<FxBusScreen> {
  MixerController get c => widget.controller;
  int _fx = 0;

  List<SendTarget> get _targets => [
        for (final t in c.profile.sendTargets)
          if (t.master.type == StripType.fxSend) t,
      ];

  List<Strip> get _returns => [for (final s in c.profile.inputs) if (s.type == StripType.fxReturn) s];

  @override
  void initState() {
    super.initState();
    final t = _targets;
    c.query([
      for (final s in [..._returns, for (final x in t) x.master]) ...[s.nameAddr, s.colorAddr, s.faderAddr, s.onAddr],
      for (final x in t)
        for (final s in c.profile.inputs)
          if (s.hasSends) ...[s.sendLevelAddr(x), s.sendOnAddr(x)],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500;
    final stripW = size.shortestSide >= 600 ? 82.0 : 64.0;
    final targets = _targets;
    final returns = _returns;
    final target = targets.isEmpty ? null : targets[_fx.clamp(0, targets.length - 1)];
    final senders = [for (final s in c.profile.inputs) if (s.hasSends && s.type != StripType.fxReturn) s];

    Widget row(List<Widget> children) => ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 6),
          children: [
            for (final w in children) Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: w),
          ],
        );

    return AppBackground(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('FX'),
          toolbarHeight: compact ? 44 : null,
        ),
        body: SafeArea(
          top: false,
          child: LayoutBuilder(builder: (context, box) {
            final tall = box.maxHeight > 620;
            final masters = SizedBox(
              height: tall ? box.maxHeight * 0.42 : box.maxHeight * 0.5,
              child: row([
                for (final t in targets)
                  ChannelStrip(
                    controller: c,
                    strip: t.master,
                    width: stripW + 6,
                    isMaster: true,
                    compact: true,
                    highlight: fxAccent,
                  ),
                for (final r in returns) ChannelStrip(controller: c, strip: r, width: stripW, compact: true),
              ]),
            );
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 6),
                  child: Text(
                    targets.isEmpty
                        ? 'FX returns. Effect types and settings are chosen on the console.'
                        : 'FX buses and returns. Effect types and settings are chosen on the console.',
                    style: const TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                ),
                masters,
                if (target != null) ...[
                  const Divider(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        const Text('Sends to', style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Wrap(
                              spacing: 6,
                              children: [
                                for (var i = 0; i < targets.length; i++)
                                  ChoiceChip(
                                    label: Text(targets[i].label),
                                    selected: i == _fx,
                                    selectedColor: fxAccent.withValues(alpha: 0.35),
                                    onSelected: (_) => setState(() => _fx = i),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Expanded(
                    child: row([
                      for (final s in senders)
                        ChannelStrip(
                          key: ValueKey('${s.prefix}-${target.mixIndex}'),
                          controller: c,
                          strip: s,
                          sendTarget: target,
                          width: stripW,
                          compact: true,
                          personal: true,
                        ),
                    ]),
                  ),
                ] else
                  const Spacer(),
              ],
            );
          }),
        ),
      ),
    );
  }
}
