import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_strip.dart';
import 'fx_screen.dart' show fxAccent;

/// FX page for consoles whose effects can't be edited remotely (Yamaha):
/// the FX bus masters and FX returns side by side, and every input's send
/// to the chosen FX bus as faders.
///
/// TF / DM3 have dedicated FX buses and returns. CL / QL / DM7 feed their
/// effect racks from MIX buses and bring them back on ST IN / input
/// channels, so there the person picks which ones are the effects (kept on
/// this device; names like "Reverb" or "FX" are picked automatically).
class FxBusScreen extends StatefulWidget {
  const FxBusScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<FxBusScreen> createState() => _FxBusScreenState();
}

class _FxBusScreenState extends State<FxBusScreen> {
  MixerController get c => widget.controller;
  int _fx = 0;

  /// FX buses / returns the console has as such (XR, TF, DM3, A&H…).
  bool get _fixedSends => c.profile.sendTargets.any((t) => t.master.type == StripType.fxSend);
  bool get _fixedReturns => c.profile.inputs.any((s) => s.type == StripType.fxReturn);

  /// Something has to be picked by the person (X32 FX sends are MIX buses;
  /// CL / QL / DM7 sends and returns are ordinary buses and channels).
  bool get _dedicated => _fixedSends && _fixedReturns;

  /// CL / QL / DM7: strips the person marked as effects (prefixes).
  Set<String>? _picked;

  String get _prefKey => 'fx_page_${c.profile.family.name}_${c.profile.model}';

  static final _fxName = RegExp(r'\b(fx|efx|rev|reverb|verb|dly|delay|echo|plate|hall|room|chorus)\b', caseSensitive: false);

  List<SendTarget> get _targets => _fixedSends
      ? [for (final t in c.profile.sendTargets) if (t.master.type == StripType.fxSend) t]
      : [for (final t in c.profile.busTargets) if (_picked?.contains(t.master.prefix) ?? false) t];

  List<Strip> get _returns => _fixedReturns
      ? [for (final s in c.profile.inputs) if (s.type == StripType.fxReturn) s]
      : [for (final s in c.profile.inputs) if (_picked?.contains(s.prefix) ?? false) s];

  String _name(Strip s) {
    final n = c.param(s.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n.trim() : s.defaultLabel;
  }

  @override
  void initState() {
    super.initState();
    _query();
    if (c.profile.family == MixerFamily.x32) {
      c.query([for (var slot = 1; slot <= 4; slot++) c.profile.fxSourceAddr(slot)]);
    }
    if (!_dedicated) _load();
  }

  void _query() {
    final t = _targets;
    c.query([
      for (final s in [..._returns, for (final x in t) x.master]) ...[s.nameAddr, s.colorAddr, s.faderAddr, s.onAddr],
      for (final x in t)
        for (final s in c.profile.inputs)
          if (s.hasSends) ...[s.sendLevelAddr(x), s.sendOnAddr(x)],
    ]);
  }

  Future<void> _load() async {
    List<String>? saved;
    try {
      saved = (await SharedPreferences.getInstance()).getStringList(_prefKey);
    } catch (_) {}
    if (saved == null && c.profile.family == MixerFamily.x32) {
      // let the FX source answers arrive first
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    final x32Sources = {
      if (c.profile.family == MixerFamily.x32)
        for (var slot = 1; slot <= 4; slot++) c.intOf(c.profile.fxSourceAddr(slot), 0),
    };
    final picked = saved?.toSet() ??
        {
          // first time: what feeds the FX (X32), else buses / inputs named like effects
          for (final t in c.profile.busTargets)
            if (x32Sources.contains(t.mixIndex) || _fxName.hasMatch(_name(t.master))) t.master.prefix,
          if (!_fixedReturns)
            for (final s in c.profile.inputs)
              if (_fxName.hasMatch(_name(s))) s.prefix,
        };
    if (!mounted) return;
    setState(() => _picked = picked);
    _query();
  }

  Future<void> _save() async {
    try {
      await (await SharedPreferences.getInstance()).setStringList(_prefKey, _picked!.toList());
    } catch (_) {}
  }

  /// CL / QL / DM7: choose which MIX buses feed effects and which inputs
  /// bring them back.
  Future<void> _choose() async {
    final picked = {...?_picked};
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) {
          Widget chip(Strip s) => FilterChip(
                label: Text(_name(s)),
                selected: picked.contains(s.prefix),
                selectedColor: fxAccent.withValues(alpha: 0.35),
                onSelected: (v) => setLocal(() => v ? picked.add(s.prefix) : picked.remove(s.prefix)),
              );
          return SafeArea(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.85),
              child: ListView(
                shrinkWrap: true,
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  const Text('Effects on this console', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  const Text(
                    'Pick the buses that feed your effects and the channels they come back on. '
                    'Your choice is remembered on this device for this console model.',
                    style: TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                  const SizedBox(height: 12),
                  if (!_fixedSends) ...[
                  const Text('FX sends (buses)', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Wrap(spacing: 6, runSpacing: 6, children: [for (final t in c.profile.busTargets) chip(t.master)]),
                  const SizedBox(height: 14),
                  ],
                  if (!_fixedReturns) ...[
                  const Text('FX returns (input channels)', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Wrap(spacing: 6, runSpacing: 6, children: [
                    for (final s in c.profile.inputs.where((s) => s.type == StripType.auxIn)) chip(s),
                    for (final s in c.profile.inputs.where((s) => s.type == StripType.channel)) chip(s),
                  ]),
                  ],
                  const SizedBox(height: 12),
                  FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Done')),
                ],
              ),
            ),
          );
        },
      ),
    );
    if (!mounted) return;
    setState(() {
      _picked = picked;
      _fx = 0;
    });
    await _save();
    _query();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500;
    final stripW = size.shortestSide >= 600 ? 82.0 : 64.0;
    final targets = _targets;
    final returns = _returns;
    final target = targets.isEmpty ? null : targets[_fx.clamp(0, targets.length - 1)];
    final senders = [
      for (final s in c.profile.inputs)
        if (s.hasSends && s.type != StripType.fxReturn && !(_picked?.contains(s.prefix) ?? false)) s,
    ];

    Widget row(List<Widget> children) => ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 6),
          children: [
            for (final w in children) Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: w),
          ],
        );

    return AppBackground(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('FX'),
          toolbarHeight: compact ? 44 : null,
          actions: [
            if (!_dedicated)
              IconButton(tooltip: 'Choose effect buses', icon: const Icon(Icons.tune), onPressed: _choose),
          ],
        ),
        body: SafeArea(
          top: false,
          child: LayoutBuilder(builder: (context, box) {
            final tall = box.maxHeight > 620;
            // Short screens (phone in landscape): both rows keep a usable
            // strip height and the page scrolls instead.
            final mastersH = math.max(tall ? box.maxHeight * 0.42 : box.maxHeight * 0.5, 230.0);
            final sendersH = math.max(box.maxHeight - mastersH - 120, 250.0);
            final scroll = mastersH + sendersH + 120 > box.maxHeight;
            final masters = SizedBox(
              height: mastersH,
              child: row([
                for (final t in targets)
                  ChannelStrip(
                    controller: c,
                    strip: t.master,
                    width: stripW + 6,
                    isMaster: true,
                    compact: true,
                    highlight: fxAccent,
                  ),
                for (final r in returns) ChannelStrip(controller: c, strip: r, width: stripW, compact: true),
              ]),
            );
            final page = Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 6),
                  child: Text(
                    !_dedicated && targets.isEmpty && returns.isEmpty
                        ? 'Tap the ⚙ button to pick the MIX buses that feed your effects and the channels they return on.'
                        : 'FX buses and returns. Effect types and settings are chosen on the console.',
                    style: const TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                ),
                masters,
                if (target != null) ...[
                  const Divider(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        const Text('Sends to', style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Wrap(
                              spacing: 6,
                              children: [
                                for (var i = 0; i < targets.length; i++)
                                  ChoiceChip(
                                    label: Text(targets[i].label),
                                    selected: i == _fx,
                                    selectedColor: fxAccent.withValues(alpha: 0.35),
                                    onSelected: (_) => setState(() => _fx = i),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    height: sendersH,
                    child: row([
                      for (final s in senders)
                        ChannelStrip(
                          key: ValueKey('${s.prefix}-${target.mixIndex}'),
                          controller: c,
                          strip: s,
                          sendTarget: target,
                          width: stripW,
                          compact: true,
                          personal: true,
                        ),
                    ]),
                  ),
                ],
              ],
            );
            return scroll ? SingleChildScrollView(child: page) : page;
          }),
        ),
      ),
    );
  }
}
