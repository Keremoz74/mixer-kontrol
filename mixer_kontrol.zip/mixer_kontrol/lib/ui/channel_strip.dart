import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';
import 'bus_options.dart';
import 'channel_detail_screen.dart';
import 'eq_graph.dart';
import 'fader.dart';
import 'fx_screen.dart' show fxAccent;
import 'fx_sends_sheet.dart';
import 'gain_knob.dart';
import 'meter_bar.dart';
import 'strip_actions.dart';

/// X32/XR scribble-strip colors: 0 off, 1 red, 2 green, 3 yellow, 4 blue,
/// 5 magenta, 6 cyan, 7 white; 8-15 are the inverted versions of 0-7.
Color stripColor(Object? v) {
  const palette = [
    Color(0xFF5A5F66),
    Color(0xFFE5484D),
    Color(0xFF46A758),
    Color(0xFFF5D90A),
    Color(0xFF3E8EF7),
    Color(0xFFD864D8),
    Color(0xFF29C5D6),
    Color(0xFFEDEDED),
  ];
  final i = v is int ? v % 8 : 0;
  return palette[i];
}

/// "Sends on fader" accent, so it is always obvious which mix you are editing.
const Color sendsAccent = Color(0xFFFFB224);

class ChannelStrip extends StatelessWidget {
  const ChannelStrip({
    super.key,
    required this.controller,
    required this.strip,
    this.sendTarget,
    this.width = 72,
    this.isMaster = false,
    this.compact = false,
    this.highlight,
  });

  final MixerController controller;
  final Strip strip;
  final SendTarget? sendTarget;
  final double width;
  final bool isMaster;

  /// Short screens (phone in landscape): smaller header, mute and fader cap.
  final bool compact;

  /// Colour for a stand-out strip (Main LR, or the bus master in sends mode):
  /// tints the panel, fader fill and level readout.
  final Color? highlight;

  @override
  Widget build(BuildContext context) {
    final faderAddr = sendTarget == null ? strip.faderAddr : strip.sendLevelAddr(sendTarget!);
    final accent = highlight ?? (sendTarget != null ? sendsAccent : AppStyle.glowBlue);
    final thumbH = compact ? 34.0 : 44.0;
    final meterW = isMaster ? 8.0 : 6.0;

    return Container(
      width: width,
      margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
      padding: EdgeInsets.fromLTRB(4, 4, 4, compact ? 4 : 6),
      decoration: highlight != null
          ? AppStyle.masterPanel(highlight!)
          : AppStyle.panel(raised: isMaster, tint: sendTarget != null ? sendsAccent : null),
      child: Column(
        children: [
          _NameHeader(controller: controller, strip: strip, height: compact ? 28 : 36),
          if (strip.hasDetail) ...[
            SizedBox(height: compact ? 3 : 5),
            GainKnob(controller: controller, strip: strip, height: compact ? 26 : 32),
          ],
          if (strip.hasEq) ...[
            SizedBox(height: compact ? 3 : 5),
            _Shortcuts(controller: controller, strip: strip, height: compact ? 24 : 30),
          ],
          if (sendTarget == null && busTargetOf(controller.profile, strip) != null) ...[
            SizedBox(height: compact ? 3 : 5),
            BusOptionsButton(
              controller: controller,
              target: busTargetOf(controller.profile, strip)!,
              height: compact ? 24 : 28,
            ),
          ],
          SizedBox(height: compact ? 4 : 6),
          _MuteButton(controller: controller, addr: strip.onAddr, height: compact ? 28 : 34),
          SizedBox(height: compact ? 3 : 6),
          ValueListenableBuilder<Object?>(
            valueListenable: controller.param(faderAddr),
            builder: (context, v, _) => Text(
              formatDb(v is num ? v.toDouble() : 0),
              style: TextStyle(
                fontSize: compact ? 11 : 12,
                fontWeight: FontWeight.w600,
                fontFeatures: const [FontFeature.tabularFigures()],
                color: highlight ?? (sendTarget != null ? sendsAccent : Colors.white.withValues(alpha: 0.75)),
              ),
            ),
          ),
          SizedBox(height: compact ? 0 : 2),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (strip.hasMeter)
                  MeterBar(levels: controller.meters, id: strip.prefix, width: meterW, inset: thumbH / 2)
                else
                  SizedBox(width: meterW),
                Expanded(
                  child: ValueListenableBuilder<Object?>(
                    valueListenable: controller.param(faderAddr),
                    builder: (context, v, _) => VerticalFader(
                      value: v is num ? v.toDouble() : 0,
                      accent: accent,
                      thumbHeight: thumbH,
                      showScale: width >= 80,
                      onStart: () => controller.beginTouch(faderAddr),
                      onEnd: () => controller.endTouch(faderAddr),
                      onChanged: (x) => controller.setFader(faderAddr, x),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Names of the 8 scribble-strip colours (value 0-7; +8 = inverted).
const scribbleColorNames = ['Off', 'Red', 'Green', 'Yellow', 'Blue', 'Magenta', 'Cyan', 'White'];

/// A scribble strip: solid colour with dark/light text, or — for inverted
/// colours (8-15) — a dark chip with coloured text and border, like the console.
class ScribbleChip extends StatelessWidget {
  const ScribbleChip({
    super.key,
    required this.colorValue,
    required this.name,
    this.subtitle,
    this.height = 36,
  });

  final Object? colorValue;
  final String name;
  final String? subtitle;
  final double height;

  @override
  Widget build(BuildContext context) {
    final color = stripColor(colorValue);
    final inverted = colorValue is int && (colorValue as int) >= 8;
    final fg = inverted ? color : (color.computeLuminance() > 0.5 ? Colors.black : Colors.white);
    return Container(
      height: height,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 3),
      decoration: inverted
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              color: Colors.black.withValues(alpha: 0.55),
              border: Border.all(color: color, width: 1.5),
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color.lerp(color, Colors.white, 0.18)!, color],
              ),
              boxShadow: [BoxShadow(color: color.withValues(alpha: 0.35), blurRadius: 8)],
            ),
      child: subtitle != null
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  subtitle!,
                  maxLines: 1,
                  style: TextStyle(fontSize: 8, height: 1, color: fg.withValues(alpha: 0.7)),
                ),
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 11, height: 1.15, fontWeight: FontWeight.w700, color: fg),
                ),
              ],
            )
          : Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: fg),
            ),
    );
  }
}

class _NameHeader extends StatelessWidget {
  const _NameHeader({required this.controller, required this.strip, this.height = 36});
  final MixerController controller;
  final Strip strip;
  final double height;

  @override
  Widget build(BuildContext context) {
    final nameN = controller.param(strip.nameAddr);
    final colorN = controller.param(strip.colorAddr);
    return ListenableBuilder(
      listenable: Listenable.merge([nameN, colorN]),
      builder: (context, _) {
        final raw = nameN.value;
        final String name = raw is String && raw.trim().isNotEmpty ? raw : strip.defaultLabel;
        final custom = name != strip.defaultLabel;
        return InkWell(
          borderRadius: BorderRadius.circular(7),
          onTap: strip.hasEq
              ? () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChannelDetailScreen(controller: controller, strip: strip),
                    ),
                  )
              : null,
          onLongPress: () => showStripActions(context, controller, strip),
          child: ScribbleChip(
            colorValue: colorN.value,
            name: name,
            subtitle: custom ? strip.defaultLabel : null,
            height: height,
          ),
        );
      },
    );
  }
}

/// Name + scribble-strip colour editor (long-press a strip's name).
Future<void> editStripNameAndColor(BuildContext context, MixerController controller, Strip strip) async {
  final rawName = controller.param(strip.nameAddr).value;
  final text = TextEditingController(text: rawName is String ? rawName.trim() : '');
  final rawColor = controller.param(strip.colorAddr).value;
  var base = rawColor is int ? rawColor % 8 : 0; // 0-7
  var inverted = rawColor is int && rawColor >= 8;

  final saved = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) {
        final value = base + (inverted ? 8 : 0);
        final preview = text.text.trim().isEmpty ? strip.defaultLabel : text.text.trim();
        return AlertDialog(
          title: Text(strip.defaultLabel),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: SizedBox(
                    width: 120,
                    child: ScribbleChip(colorValue: value, name: preview, height: 40),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: text,
                  autofocus: false,
                  maxLength: 12,
                  decoration: const InputDecoration(labelText: 'Name', hintText: 'e.g. Vocal 1'),
                  onChanged: (_) => setLocal(() {}),
                ),
                const SizedBox(height: 4),
                const Text('Colour', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (var i = 0; i < 8; i++)
                      Tooltip(
                        message: scribbleColorNames[i],
                        child: GestureDetector(
                          onTap: () => setLocal(() => base = i),
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: inverted ? Colors.black54 : stripColor(i),
                              border: Border.all(
                                color: i == base ? Colors.white : stripColor(i),
                                width: i == base ? 3 : (inverted ? 2 : 1),
                              ),
                            ),
                            child: i == base
                                ? Icon(
                                    Icons.check,
                                    size: 20,
                                    color: inverted
                                        ? stripColor(i)
                                        : (stripColor(i).computeLuminance() > 0.5 ? Colors.black : Colors.white),
                                  )
                                : null,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  scribbleColorNames[base] + (inverted ? ' (inverted)' : ''),
                  style: const TextStyle(fontSize: 12, color: Colors.white60),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Inverted'),
                  subtitle: const Text('Coloured text on a dark strip'),
                  value: inverted,
                  onChanged: (v) => setLocal(() => inverted = v),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        );
      },
    ),
  );
  if (saved != true) return;
  controller.rename(strip, text.text.trim());
  controller.set(strip.colorAddr, base + (inverted ? 8 : 0));
}

/// EQ (live mini curve) and FX shortcut buttons on top of a strip.
/// Inputs get both; buses, matrices and Main LR get EQ only.
class _Shortcuts extends StatelessWidget {
  const _Shortcuts({required this.controller, required this.strip, required this.height});
  final MixerController controller;
  final Strip strip;
  final double height;

  @override
  Widget build(BuildContext context) {
    final eq = _ShortcutButton(
      height: height,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ChannelDetailScreen(controller: controller, strip: strip)),
      ),
      child: ValueListenableBuilder<Object?>(
        valueListenable: controller.param(strip.eqOnAddr),
        builder: (context, v, _) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
          child: EqThumbnail(controller: controller, strip: strip, color: AppStyle.glowBlue),
        ),
      ),
    );
    if (!strip.hasSends) return eq;
    return Row(
      children: [
        Expanded(flex: 3, child: eq),
        const SizedBox(width: 3),
        Expanded(
          flex: 2,
          child: _ShortcutButton(
            height: height,
            onTap: () => showFxSendsSheet(context, controller, strip),
            child: const Center(
              child: Text(
                'FX',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: fxAccent, letterSpacing: 0.5),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _ShortcutButton extends StatelessWidget {
  const _ShortcutButton({required this.height, required this.onTap, required this.child});
  final double height;
  final VoidCallback onTap;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.35),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(6),
        side: BorderSide(color: Colors.white.withValues(alpha: 0.10)),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: SizedBox(height: height, width: double.infinity, child: child),
      ),
    );
  }
}

class _MuteButton extends StatelessWidget {
  const _MuteButton({required this.controller, required this.addr, this.height = 34});
  final MixerController controller;
  final String addr;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final muted = v is num && v == 0;
        return GestureDetector(
          onTap: () => controller.toggleOn(addr),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            height: height,
            width: double.infinity,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              color: muted ? AppStyle.muteRed : Colors.black.withValues(alpha: 0.35),
              border: Border.all(
                color: muted ? const Color(0xFFFF8A8F) : Colors.white.withValues(alpha: 0.10),
              ),
              boxShadow: muted
                  ? [BoxShadow(color: AppStyle.muteRed.withValues(alpha: 0.6), blurRadius: 10)]
                  : null,
            ),
            child: Text(
              'MUTE',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: muted ? Colors.white : Colors.white.withValues(alpha: 0.55),
              ),
            ),
          ),
        );
      },
    );
  }
}
