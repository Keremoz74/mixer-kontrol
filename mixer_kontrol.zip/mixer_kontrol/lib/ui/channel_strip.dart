import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';
import 'channel_detail_screen.dart';
import 'fader.dart';
import 'meter_bar.dart';

/// X32/XR scribble-strip colors: 0 off, 1 red, 2 green, 3 yellow, 4 blue,
/// 5 magenta, 6 cyan, 7 white; 8-15 are the inverted versions of 0-7.
Color stripColor(Object? v) {
  const palette = [
    Color(0xFF5A5F66),
    Color(0xFFE5484D),
    Color(0xFF46A758),
    Color(0xFFF5D90A),
    Color(0xFF3E8EF7),
    Color(0xFFD864D8),
    Color(0xFF29C5D6),
    Color(0xFFEDEDED),
  ];
  final i = v is int ? v % 8 : 0;
  return palette[i];
}

/// "Sends on fader" accent, so it is always obvious which mix you are editing.
const Color sendsAccent = Color(0xFFFFB224);

class ChannelStrip extends StatelessWidget {
  const ChannelStrip({
    super.key,
    required this.controller,
    required this.strip,
    this.sendTarget,
    this.width = 72,
    this.isMaster = false,
    this.compact = false,
    this.highlight,
  });

  final MixerController controller;
  final Strip strip;
  final SendTarget? sendTarget;
  final double width;
  final bool isMaster;

  /// Short screens (phone in landscape): smaller header, mute and fader cap.
  final bool compact;

  /// Colour for a stand-out strip (Main LR, or the bus master in sends mode):
  /// tints the panel, fader fill and level readout.
  final Color? highlight;

  @override
  Widget build(BuildContext context) {
    final faderAddr = sendTarget == null ? strip.faderAddr : strip.sendLevelAddr(sendTarget!);
    final accent = highlight ?? (sendTarget != null ? sendsAccent : AppStyle.glowBlue);
    final thumbH = compact ? 34.0 : 44.0;
    final meterW = isMaster ? 8.0 : 6.0;

    return Container(
      width: width,
      margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
      padding: EdgeInsets.fromLTRB(4, 4, 4, compact ? 4 : 6),
      decoration: highlight != null
          ? AppStyle.masterPanel(highlight!)
          : AppStyle.panel(raised: isMaster, tint: sendTarget != null ? sendsAccent : null),
      child: Column(
        children: [
          _NameHeader(controller: controller, strip: strip, height: compact ? 28 : 36),
          SizedBox(height: compact ? 4 : 6),
          _MuteButton(controller: controller, addr: strip.onAddr, height: compact ? 28 : 34),
          SizedBox(height: compact ? 3 : 6),
          ValueListenableBuilder<Object?>(
            valueListenable: controller.param(faderAddr),
            builder: (context, v, _) => Text(
              formatDb(v is num ? v.toDouble() : 0),
              style: TextStyle(
                fontSize: compact ? 11 : 12,
                fontWeight: FontWeight.w600,
                fontFeatures: const [FontFeature.tabularFigures()],
                color: highlight ?? (sendTarget != null ? sendsAccent : Colors.white.withValues(alpha: 0.75)),
              ),
            ),
          ),
          SizedBox(height: compact ? 0 : 2),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (strip.hasMeter)
                  MeterBar(levels: controller.meters, id: strip.prefix, width: meterW, inset: thumbH / 2)
                else
                  SizedBox(width: meterW),
                Expanded(
                  child: ValueListenableBuilder<Object?>(
                    valueListenable: controller.param(faderAddr),
                    builder: (context, v, _) => VerticalFader(
                      value: v is num ? v.toDouble() : 0,
                      accent: accent,
                      thumbHeight: thumbH,
                      showScale: width >= 80,
                      onStart: () => controller.beginTouch(faderAddr),
                      onEnd: () => controller.endTouch(faderAddr),
                      onChanged: (x) => controller.setFader(faderAddr, x),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NameHeader extends StatelessWidget {
  const _NameHeader({required this.controller, required this.strip, this.height = 36});
  final MixerController controller;
  final Strip strip;
  final double height;

  @override
  Widget build(BuildContext context) {
    final nameN = controller.param(strip.nameAddr);
    final colorN = controller.param(strip.colorAddr);
    return ListenableBuilder(
      listenable: Listenable.merge([nameN, colorN]),
      builder: (context, _) {
        final raw = nameN.value;
        final String name = raw is String && raw.trim().isNotEmpty ? raw : strip.defaultLabel;
        final custom = name != strip.defaultLabel;
        final color = stripColor(colorN.value);
        final fg = color.computeLuminance() > 0.5 ? Colors.black : Colors.white;
        return InkWell(
          borderRadius: BorderRadius.circular(7),
          onTap: strip.hasDetail
              ? () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChannelDetailScreen(controller: controller, strip: strip),
                    ),
                  )
              : null,
          onLongPress: () => _rename(context, name),
          child: Container(
            height: height,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color.lerp(color, Colors.white, 0.18)!, color],
              ),
              boxShadow: [BoxShadow(color: color.withValues(alpha: 0.35), blurRadius: 8)],
            ),
            child: custom
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        strip.defaultLabel,
                        maxLines: 1,
                        style: TextStyle(fontSize: 8, height: 1, color: fg.withValues(alpha: 0.7)),
                      ),
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 11, height: 1.15, fontWeight: FontWeight.w700, color: fg),
                      ),
                    ],
                  )
                : Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: fg),
                  ),
          ),
        );
      },
    );
  }

  Future<void> _rename(BuildContext context, String current) async {
    final text = TextEditingController(text: current == strip.defaultLabel ? '' : current);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${strip.defaultLabel} name'),
        content: TextField(
          controller: text,
          autofocus: true,
          maxLength: 12,
          decoration: const InputDecoration(hintText: 'e.g. Vocal 1'),
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, text.text), child: const Text('Save')),
        ],
      ),
    );
    if (result != null) controller.rename(strip, result.trim());
  }
}

class _MuteButton extends StatelessWidget {
  const _MuteButton({required this.controller, required this.addr, this.height = 34});
  final MixerController controller;
  final String addr;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final muted = v is num && v == 0;
        return GestureDetector(
          onTap: () => controller.toggleOn(addr),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            height: height,
            width: double.infinity,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              color: muted ? AppStyle.muteRed : Colors.black.withValues(alpha: 0.35),
              border: Border.all(
                color: muted ? const Color(0xFFFF8A8F) : Colors.white.withValues(alpha: 0.10),
              ),
              boxShadow: muted
                  ? [BoxShadow(color: AppStyle.muteRed.withValues(alpha: 0.6), blurRadius: 10)]
                  : null,
            ),
            child: Text(
              'MUTE',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: muted ? Colors.white : Colors.white.withValues(alpha: 0.55),
              ),
            ),
          ),
        );
      },
    );
  }
}
