import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'channel_detail_screen.dart';
import 'fader.dart';
import 'meter_bar.dart';

/// X32/XR scribble-strip colors: 0 off, 1 red, 2 green, 3 yellow, 4 blue,
/// 5 magenta, 6 cyan, 7 white; 8-15 are the inverted versions of 0-7.
Color stripColor(Object? v) {
  const palette = [
    Color(0xFF5A5F66),
    Color(0xFFE5484D),
    Color(0xFF46A758),
    Color(0xFFF5D90A),
    Color(0xFF3E8EF7),
    Color(0xFFD864D8),
    Color(0xFF29C5D6),
    Color(0xFFEDEDED),
  ];
  final i = v is int ? v % 8 : 0;
  return palette[i];
}

/// "Sends on fader" accent, so it is always obvious which mix you are editing.
const Color sendsAccent = Color(0xFFFFB224);

class ChannelStrip extends StatelessWidget {
  const ChannelStrip({
    super.key,
    required this.controller,
    required this.strip,
    this.sendTarget,
    this.width = 72,
    this.isMaster = false,
  });

  final MixerController controller;
  final Strip strip;
  final SendTarget? sendTarget;
  final double width;
  final bool isMaster;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final faderAddr = sendTarget == null ? strip.faderAddr : strip.sendLevelAddr(sendTarget!);
    final accent = sendTarget != null ? sendsAccent : scheme.primary;

    return Container(
      width: width,
      margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
      decoration: BoxDecoration(
        color: isMaster ? scheme.surfaceContainerHigh : scheme.surfaceContainer,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          _NameHeader(controller: controller, strip: strip),
          const SizedBox(height: 6),
          _MuteButton(controller: controller, addr: strip.onAddr),
          const SizedBox(height: 6),
          ValueListenableBuilder<Object?>(
            valueListenable: controller.param(faderAddr),
            builder: (context, v, _) => Text(
              formatDb(v is num ? v.toDouble() : 0),
              style: TextStyle(
                fontSize: 12,
                fontFeatures: const [FontFeature.tabularFigures()],
                color: sendTarget != null ? sendsAccent : scheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (strip.hasMeter)
                  MeterBar(levels: controller.meters, id: strip.prefix, width: isMaster ? 8 : 6)
                else
                  SizedBox(width: isMaster ? 8 : 6),
                Expanded(
                  child: ValueListenableBuilder<Object?>(
                    valueListenable: controller.param(faderAddr),
                    builder: (context, v, _) => VerticalFader(
                      value: v is num ? v.toDouble() : 0,
                      accent: accent,
                      onStart: () => controller.beginTouch(faderAddr),
                      onEnd: () => controller.endTouch(faderAddr),
                      onChanged: (x) => controller.setFader(faderAddr, x),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            strip.defaultLabel,
            style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
            maxLines: 1,
            overflow: TextOverflow.clip,
          ),
        ],
      ),
    );
  }
}

class _NameHeader extends StatelessWidget {
  const _NameHeader({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final nameN = controller.param(strip.nameAddr);
    final colorN = controller.param(strip.colorAddr);
    return ListenableBuilder(
      listenable: Listenable.merge([nameN, colorN]),
      builder: (context, _) {
        final raw = nameN.value;
        final name = raw is String && raw.trim().isNotEmpty ? raw : strip.defaultLabel;
        final color = stripColor(colorN.value);
        final dark = color.computeLuminance() > 0.5;
        return InkWell(
          borderRadius: BorderRadius.circular(6),
          onTap: strip.hasDetail
              ? () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChannelDetailScreen(controller: controller, strip: strip),
                    ),
                  )
              : null,
          onLongPress: () => _rename(context, name),
          child: Container(
            height: 34,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(6)),
            child: Text(
              name,
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11,
                height: 1.1,
                fontWeight: FontWeight.w600,
                color: dark ? Colors.black : Colors.white,
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _rename(BuildContext context, String current) async {
    final text = TextEditingController(text: current == strip.defaultLabel ? '' : current);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${strip.defaultLabel} adı'),
        content: TextField(
          controller: text,
          autofocus: true,
          maxLength: 12,
          decoration: const InputDecoration(hintText: 'Örn. Vokal 1'),
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, text.text), child: const Text('Kaydet')),
        ],
      ),
    );
    if (result != null) controller.rename(strip, result.trim());
  }
}

class _MuteButton extends StatelessWidget {
  const _MuteButton({required this.controller, required this.addr});
  final MixerController controller;
  final String addr;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final muted = v is num && v == 0;
        return SizedBox(
          height: 34,
          width: double.infinity,
          child: Material(
            color: muted ? const Color(0xFFE5484D) : scheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(6),
            child: InkWell(
              borderRadius: BorderRadius.circular(6),
              onTap: () => controller.toggleOn(addr),
              child: Center(
                child: Text(
                  'MUTE',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                    color: muted ? Colors.white : scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
