import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/eq_math.dart';
import '../util/param_law.dart';

const bandColors = [
  Color(0xFFFF6B6B),
  Color(0xFFF5D90A),
  Color(0xFF46A758),
  Color(0xFF3E8EF7),
];

/// Display range of the graph's vertical axis, in dB.
const double _range = 18;

class _Band {
  _Band(this.type, this.fNorm, this.gNorm, this.qNorm);
  final EqType type;
  final double fNorm, gNorm, qNorm;
  double get hz => freqLaw.toReal(fNorm);
  double get db => isCut(type) ? 0 : eqGainLaw.toReal(gNorm);
  double get q => qLaw.toReal(qNorm);
}

class _EqState {
  _EqState(this.bands, this.eqOn, this.hpOn, this.hpfHz);
  final List<_Band> bands;
  final bool eqOn, hpOn;
  final double hpfHz;

  static _EqState read(MixerController c, Strip s) {
    const defTypes = [1, 2, 2, 4];
    const defFreqs = [100.0, 400.0, 2500.0, 10000.0];
    final n = c.profile.channelEqBands;
    return _EqState(
      [
        for (var b = 1; b <= n; b++)
          _Band(
            eqTypeOf(c.intOf(s.eqAddr(b, 'type'), defTypes[(b - 1) % 4])),
            c.numOf(s.eqAddr(b, 'f'), freqLaw.toNorm(defFreqs[(b - 1) % 4])),
            c.numOf(s.eqAddr(b, 'g'), 0.5),
            c.numOf(s.eqAddr(b, 'q'), qLaw.toNorm(2)),
          ),
      ],
      c.isOn(s.eqOnAddr),
      c.flagOf(s.hpOnAddr),
      hpfLaw.toReal(c.numOf(s.hpfAddr, hpfLaw.toNorm(80))),
    );
  }

  double totalDb(double hz) {
    var sum = 0.0;
    if (eqOn) {
      for (final b in bands) {
        sum += bandResponseDb(b.type, b.hz, b.db, b.q, hz);
      }
    }
    if (hpOn) sum += bandResponseDb(EqType.lowCut, hpfHz, 0, 0.707, hz);
    return sum;
  }
}

/// Interactive EQ curve: drag a numbered dot left/right for frequency and
/// up/down for gain. Tapping a dot selects that band.
class EqGraph extends StatefulWidget {
  const EqGraph({
    super.key,
    required this.controller,
    required this.strip,
    required this.selected,
    required this.onSelect,
  });

  final MixerController controller;
  final Strip strip;
  final int selected; // 1-based
  final ValueChanged<int> onSelect;

  @override
  State<EqGraph> createState() => _EqGraphState();
}

class _EqGraphState extends State<EqGraph> {
  int? _drag;

  List<String> get _addrs {
    final s = widget.strip;
    return [
      s.eqOnAddr,
      s.hpOnAddr,
      s.hpfAddr,
      for (var b = 1; b <= widget.controller.profile.channelEqBands; b++)
        for (final f in const ['type', 'f', 'g', 'q']) s.eqAddr(b, f),
    ];
  }

  Offset _dotPos(_Band b, Size size) {
    final mid = size.height / 2;
    return Offset(b.fNorm * size.width, mid - b.db / _range * mid);
  }

  int? _nearest(_EqState st, Offset p, Size size, {double maxDist = 56}) {
    int? best;
    var bestD = maxDist;
    for (var i = 0; i < st.bands.length; i++) {
      final d = (_dotPos(st.bands[i], size) - p).distance;
      if (d < bestD) {
        bestD = d;
        best = i + 1;
      }
    }
    return best;
  }

  void _moveTo(int band, Offset p, Size size, EqType type) {
    final c = widget.controller;
    final s = widget.strip;
    c.set(s.eqAddr(band, 'f'), (p.dx / size.width).clamp(0.0, 1.0));
    if (!isCut(type)) {
      final mid = size.height / 2;
      final db = ((mid - p.dy) / mid * _range).clamp(-15.0, 15.0);
      c.set(s.eqAddr(band, 'g'), eqGainLaw.toNorm(db));
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final scheme = Theme.of(context).colorScheme;
    return ListenableBuilder(
      listenable: Listenable.merge([for (final a in _addrs) c.param(a)]),
      builder: (context, _) {
        final st = _EqState.read(c, widget.strip);
        return LayoutBuilder(builder: (context, cons) {
          final size = Size(cons.maxWidth, cons.maxHeight);
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: (d) {
              final b = _nearest(st, d.localPosition, size);
              if (b != null) widget.onSelect(b);
            },
            onPanStart: (d) {
              final b = _nearest(st, d.localPosition, size) ?? widget.selected;
              _drag = b;
              widget.onSelect(b);
              c.beginTouch(widget.strip.eqAddr(b, 'f'));
              c.beginTouch(widget.strip.eqAddr(b, 'g'));
            },
            onPanUpdate: (d) {
              final b = _drag;
              if (b == null) return;
              _moveTo(b, d.localPosition, size, st.bands[b - 1].type);
            },
            onPanEnd: (_) => _endDrag(),
            onPanCancel: _endDrag,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomPaint(
                size: size,
                painter: _EqPainter(
                  st: st,
                  selected: widget.selected,
                  bg: Colors.black.withValues(alpha: 0.35),
                  grid: scheme.outlineVariant.withValues(alpha: 0.5),
                  label: scheme.onSurfaceVariant,
                  curve: st.eqOn ? scheme.primary : scheme.outline,
                ),
              ),
            ),
          );
        });
      },
    );
  }

  void _endDrag() {
    final b = _drag;
    if (b == null) return;
    widget.controller.endTouch(widget.strip.eqAddr(b, 'f'));
    widget.controller.endTouch(widget.strip.eqAddr(b, 'g'));
    _drag = null;
  }
}

class _EqPainter extends CustomPainter {
  _EqPainter({
    required this.st,
    required this.selected,
    required this.bg,
    required this.grid,
    required this.label,
    required this.curve,
  });

  final _EqState st;
  final int selected;
  final Color bg, grid, label, curve;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height, mid = h / 2;
    canvas.drawRect(Offset.zero & size, Paint()..color = bg);

    final gridPaint = Paint()
      ..color = grid
      ..strokeWidth = 1;
    final textStyle = TextStyle(color: label, fontSize: 10);

    // Frequency grid
    for (final hz in const [50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0, 10000.0]) {
      final x = freqLaw.toNorm(hz) * w;
      canvas.drawLine(Offset(x, 0), Offset(x, h), gridPaint);
      if (hz == 100 || hz == 1000 || hz == 10000) {
        _text(canvas, hz >= 1000 ? '${(hz / 1000).round()}k' : '${hz.round()}', Offset(x + 3, h - 14), textStyle);
      }
    }
    // Gain grid
    for (final db in const [-12.0, -6.0, 0.0, 6.0, 12.0]) {
      final y = mid - db / _range * mid;
      canvas.drawLine(
        Offset(0, y),
        Offset(w, y),
        db == 0 ? (Paint()..color = label.withValues(alpha: 0.6)..strokeWidth = 1) : gridPaint,
      );
      if (db != 0) _text(canvas, db > 0 ? '+${db.round()}' : '${db.round()}', Offset(3, y - 12), textStyle);
    }

    // Curve
    final path = Path();
    for (var x = 0.0; x <= w; x += 2) {
      final hz = freqLaw.toReal(x / w);
      final db = st.totalDb(hz).clamp(-_range * 1.5, _range * 1.5);
      final y = mid - db / _range * mid;
      if (x == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    final fill = Path.from(path)
      ..lineTo(w, mid)
      ..lineTo(0, mid)
      ..close();
    canvas.drawPath(fill, Paint()..color = curve.withValues(alpha: 0.18));
    canvas.drawPath(
      path,
      Paint()
        ..color = curve
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );

    // Band dots
    for (var i = 0; i < st.bands.length; i++) {
      final b = st.bands[i];
      final p = Offset(b.fNorm * w, mid - b.db / _range * mid);
      final color = bandColors[i % bandColors.length].withValues(alpha: st.eqOn ? 1 : 0.4);
      final isSel = selected == i + 1;
      final r = isSel ? 15.0 : 12.0;
      if (isSel) {
        canvas.drawCircle(p, r + 4, Paint()..color = color.withValues(alpha: 0.3));
      }
      canvas.drawCircle(p, r, Paint()..color = color);
      _text(
        canvas,
        '${i + 1}',
        p,
        const TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w700),
        center: true,
      );
    }
  }

  void _text(Canvas canvas, String s, Offset at, TextStyle style, {bool center = false}) {
    final tp = TextPainter(text: TextSpan(text: s, style: style), textDirection: TextDirection.ltr)..layout();
    final o = center ? at - Offset(tp.width / 2, tp.height / 2) : at;
    tp.paint(canvas, Offset(math.max(0, o.dx), o.dy));
  }

  @override
  bool shouldRepaint(_EqPainter old) => true;
}
