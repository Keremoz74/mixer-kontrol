import 'package:flutter/material.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_detail_screen.dart';
import 'channel_strip.dart';
import 'mixer_screen.dart';
import 'personal_autostart.dart';

/// Personal monitor mode: a musician's own mix only. Faders are the sends of
/// every input to one bus, plus that bus's master; nothing else on the
/// console can be reached. Leaving needs a long press (and the PIN, if set).
class PersonalScreen extends StatefulWidget {
  const PersonalScreen({
    super.key,
    required this.controller,
    required this.target,
    this.pin,
    this.meterRate = MeterRate.full,
    this.standalone = false,
  });
  final MixerController controller;
  final SendTarget target;
  final String? pin;

  /// Meter traffic while this screen is open (lower = room for more devices).
  final MeterRate meterRate;

  /// Opened straight at app start (no console page underneath): this screen
  /// owns the connection and leaving opens the full console.
  final bool standalone;

  @override
  State<PersonalScreen> createState() => _PersonalScreenState();
}

class _PersonalScreenState extends State<PersonalScreen> {
  MixerController get c => widget.controller;

  String get _busName {
    final n = c.param(widget.target.master.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n.trim() : widget.target.label;
  }

  MeterRate _previousRate = MeterRate.full;
  bool _handedOver = false;

  @override
  void initState() {
    super.initState();
    _previousRate = c.meterRate;
    c.meterRate = widget.meterRate;
  }

  @override
  void dispose() {
    if (widget.standalone && !_handedOver) {
      c.dispose();
    } else {
      c.meterRate = _previousRate;
    }
    super.dispose();
  }

  Future<void> _leave() async {
    if (!await checkPersonalPin(context, widget.pin)) return;
    if (!mounted) return;
    final auto = await PersonalAutoStart.load();
    if (auto != null && mounted) {
      final keep = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Open this mix at app start?'),
          content: Text('This device opens "${auto.label}" by itself when the app starts.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Turn off')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Keep')),
          ],
        ),
      );
      if (keep == null) return;
      if (!keep) await PersonalAutoStart.clear();
    }
    if (!mounted) return;
    if (widget.standalone) {
      _handedOver = true;
      c.meterRate = MeterRate.full;
      await Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => MixerScreen(controller: c)),
      );
    } else {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500;
    final stripW = size.shortestSide >= 600 ? 86.0 : 66.0;
    final strips = p.inputs;
    return PopScope(
      canPop: false,
      child: AppBackground(
        child: Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                SizedBox(
                  height: 48,
                  child: Row(
                    children: [
                      const SizedBox(width: 12),
                      const Icon(Icons.headphones, color: sendsAccent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ListenableBuilder(
                          listenable: c.param(widget.target.master.nameAddr),
                          builder: (context, _) => Text(
                            'My mix: $_busName',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: sendsAccent),
                          ),
                        ),
                      ),
                      // the EQ of this monitor bus: shapes only this person's mix
                      if (widget.target.master.hasEq)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: sendsAccent,
                              side: BorderSide(color: sendsAccent.withValues(alpha: 0.6)),
                              visualDensity: VisualDensity.compact,
                            ),
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder: (_) => ChannelDetailScreen(
                                  controller: c,
                                  strip: widget.target.master,
                                  eqOnly: true,
                                ),
                              ),
                            ),
                            icon: const Icon(Icons.graphic_eq, size: 18),
                            label: const Text('My EQ'),
                          ),
                        ),
                      Tooltip(
                        message: 'Hold to leave personal mode',
                        child: GestureDetector(
                          onLongPress: _leave,
                          onTap: () => ScaffoldMessenger.of(context)
                            ..hideCurrentSnackBar()
                            ..showSnackBar(const SnackBar(
                              content: Text('Press and hold to leave personal mode.'),
                              duration: Duration(seconds: 2),
                            )),
                          child: Container(
                            margin: const EdgeInsets.only(right: 10),
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.white24),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.lock, size: 16),
                                SizedBox(width: 6),
                                Text('Exit'),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                ListenableBuilder(
                  listenable: c,
                  builder: (context, _) => c.state == ConnState.connected
                      ? const SizedBox.shrink()
                      : Container(
                          width: double.infinity,
                          color: Colors.orange.withValues(alpha: 0.25),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          child:
                              const Text('Connection to the mixer lost. Reconnecting…', style: TextStyle(fontSize: 13)),
                        ),
                ),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: LayoutBuilder(builder: (context, cons) {
                          final fitW = (cons.maxWidth - 8) / strips.length - 4;
                          final w = fitW >= stripW ? fitW.clamp(stripW, 130.0) : stripW;
                          return ListView.builder(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            itemCount: strips.length,
                            itemBuilder: (context, i) => ChannelStrip(
                              controller: c,
                              strip: strips[i],
                              sendTarget: widget.target,
                              width: w,
                              compact: compact,
                              personal: true,
                            ),
                          );
                        }),
                      ),
                      Container(width: 1, margin: const EdgeInsets.symmetric(vertical: 8), color: Colors.white12),
                      const SizedBox(width: 4),
                      ChannelStrip(
                        controller: c,
                        strip: widget.target.master,
                        width: stripW + 10,
                        isMaster: true,
                        compact: compact,
                        personal: true,
                        highlight: sendsAccent,
                      ),
                      const SizedBox(width: 6),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
