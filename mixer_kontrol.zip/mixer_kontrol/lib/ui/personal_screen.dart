import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_strip.dart';

/// Personal monitor mode: a musician's own mix only. Faders are the sends of
/// every input to one bus, plus that bus's master; nothing else on the
/// console can be reached. Leaving needs a long press (and the PIN, if set).
class PersonalScreen extends StatefulWidget {
  const PersonalScreen({super.key, required this.controller, required this.target, this.pin});
  final MixerController controller;
  final SendTarget target;
  final String? pin;

  @override
  State<PersonalScreen> createState() => _PersonalScreenState();
}

class _PersonalScreenState extends State<PersonalScreen> {
  MixerController get c => widget.controller;

  String get _busName {
    final n = c.param(widget.target.master.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n.trim() : widget.target.label;
  }

  Future<void> _leave() async {
    final pin = widget.pin;
    if (pin != null && pin.isNotEmpty) {
      final text = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Enter PIN to leave'),
          content: TextField(
            controller: text,
            autofocus: true,
            obscureText: true,
            keyboardType: TextInputType.number,
            maxLength: 8,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, text.text == pin), child: const Text('Leave')),
          ],
        ),
      );
      if (ok != true) {
        if (ok == false && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Wrong PIN')));
        }
        return;
      }
    }
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500;
    final stripW = size.shortestSide >= 600 ? 86.0 : 66.0;
    final strips = p.inputs;
    return PopScope(
      canPop: false,
      child: AppBackground(
        child: Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                SizedBox(
                  height: 48,
                  child: Row(
                    children: [
                      const SizedBox(width: 12),
                      const Icon(Icons.headphones, color: sendsAccent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ListenableBuilder(
                          listenable: c.param(widget.target.master.nameAddr),
                          builder: (context, _) => Text(
                            'My mix: $_busName',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: sendsAccent),
                          ),
                        ),
                      ),
                      Tooltip(
                        message: 'Hold to leave personal mode',
                        child: GestureDetector(
                          onLongPress: _leave,
                          onTap: () => ScaffoldMessenger.of(context)
                            ..hideCurrentSnackBar()
                            ..showSnackBar(const SnackBar(
                              content: Text('Press and hold to leave personal mode.'),
                              duration: Duration(seconds: 2),
                            )),
                          child: Container(
                            margin: const EdgeInsets.only(right: 10),
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.white24),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.lock, size: 16),
                                SizedBox(width: 6),
                                Text('Exit'),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: LayoutBuilder(builder: (context, cons) {
                          final fitW = (cons.maxWidth - 8) / strips.length - 4;
                          final w = fitW >= stripW ? fitW.clamp(stripW, 130.0) : stripW;
                          return ListView.builder(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            itemCount: strips.length,
                            itemBuilder: (context, i) => ChannelStrip(
                              controller: c,
                              strip: strips[i],
                              sendTarget: widget.target,
                              width: w,
                              compact: compact,
                              personal: true,
                            ),
                          );
                        }),
                      ),
                      Container(width: 1, margin: const EdgeInsets.symmetric(vertical: 8), color: Colors.white12),
                      const SizedBox(width: 4),
                      ChannelStrip(
                        controller: c,
                        strip: widget.target.master,
                        width: stripW + 10,
                        isMaster: true,
                        compact: compact,
                        personal: true,
                        highlight: sendsAccent,
                      ),
                      const SizedBox(width: 6),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
