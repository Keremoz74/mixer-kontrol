import 'package:flutter/material.dart';

import '../mixer/copy_paste.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'assign_sheet.dart';
import 'channel_strip.dart' show editStripNameAndColor;
import 'undo_toast.dart';

const copyAccent = Color(0xFF5EB1FF);

String _stripName(MixerController c, Strip s) {
  final n = c.param(s.nameAddr).value;
  return n is String && n.trim().isNotEmpty ? '${n.trim()} (${s.defaultLabel})' : s.defaultLabel;
}

/// Long-press menu of a strip: name & colour, copy, paste.
Future<void> showStripActions(BuildContext context, MixerController c, Strip s) async {
  final clip = stripClipboard;
  final canPaste = clip != null &&
      clip.family == c.profile.family &&
      clip.source.type == s.type &&
      (clip.multi || clip.source.prefix != s.prefix);
  final several = c.profile.allStrips.where((t) => t.type == s.type).length > 1;
  final action = await showModalBottomSheet<String>(
    context: context,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    isScrollControlled: true, // phone landscape: the menu scrolls instead of overflowing
    builder: (context) => SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(_stripName(c, s), style: Theme.of(context).textTheme.titleMedium),
            ),
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Name & colour'),
              onTap: () => Navigator.pop(context, 'name'),
            ),
            if (hasAssignOptions(c.profile, s))
              ListTile(
                leading: const Icon(Icons.hub_outlined, color: assignAccent),
                title: const Text('DCA, mute groups, Main LR, link'),
                onTap: () => Navigator.pop(context, 'assign'),
              ),
            ListTile(
              leading: const Icon(Icons.copy, color: copyAccent),
              title: const Text('Copy settings'),
              subtitle: const Text('EQ, dynamics, sends… (never gain or +48V)'),
              onTap: () => Navigator.pop(context, 'copy'),
            ),
            if (several)
              ListTile(
                leading: const Icon(Icons.library_add_check_outlined, color: copyAccent),
                title: const Text('Copy several…'),
                subtitle: const Text('Pick strips from any page, then paste them where you like'),
                onTap: () => Navigator.pop(context, 'copyMany'),
              ),
            ListTile(
              enabled: canPaste,
              leading: Icon(Icons.content_paste, color: canPaste ? copyAccent : null),
              title: Text(canPaste
                  ? (clip.multi
                      ? 'Paste ${clip.sources.length} copied strips'
                      : 'Paste from ${_stripName(c, clip.source)}')
                  : 'Paste settings'),
              subtitle: Text(canPaste
                  ? (clip.multi ? 'Choose where each one goes' : 'Choose what to paste and onto which strips')
                  : (clip == null ? 'Copy a strip first' : 'Copied strip is a different kind')),
              onTap: () => Navigator.pop(context, 'paste'),
            ),
          ],
        ),
      ),
    ),
  );
  if (!context.mounted || action == null) return;
  switch (action) {
    case 'name':
      await editStripNameAndColor(context, c, s);
    case 'copy':
      await copyStrip(c, s);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Copied ${_stripName(c, s)}. Long-press another strip to paste.'),
      ));
    case 'copyMany':
      await _copySeveralDialog(context, c, s);
    case 'paste':
      stripClipboard!.multi ? await _pasteMapDialog(context, c, s) : await _pasteDialog(context, c, s);
    case 'assign':
      await showAssignSheet(context, c, s);
  }
}

Future<void> _pasteDialog(BuildContext context, MixerController c, Strip target) async {
  final clip = stripClipboard!;
  final p = c.profile;
  final available = sectionsFor(p, clip.source);
  final sections = {...copyDefaultSections.where(available.contains)};
  final candidates = [
    for (final t in pasteTargets(p, clip))
      if (t.prefix != clip.source.prefix) t
  ];
  final targets = <String>{target.prefix};

  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) => AlertDialog(
        title: Text('Paste from ${_stripName(c, clip.source)}'),
        content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('What', style: TextStyle(fontWeight: FontWeight.w700)),
                for (final sec in available)
                  CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: sections.contains(sec),
                    title: Text(copySectionLabels[sec]!),
                    onChanged: (v) => setLocal(() => v == true ? sections.add(sec) : sections.remove(sec)),
                  ),
                const SizedBox(height: 8),
                const Text('Onto', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final t in candidates)
                      FilterChip(
                        label: Text(t.defaultLabel),
                        selected: targets.contains(t.prefix),
                        selectedColor: copyAccent.withValues(alpha: 0.35),
                        onSelected: (v) => setLocal(() => v ? targets.add(t.prefix) : targets.remove(t.prefix)),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  'Preamp gain, +48V and inserts are never pasted.',
                  style: TextStyle(fontSize: 12, color: Colors.white54),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: sections.isEmpty || targets.isEmpty ? null : () => Navigator.pop(ctx, true),
            child: Text('Paste to ${targets.length}'),
          ),
        ],
      ),
    ),
  );
  if (ok != true || !context.mounted) return;
  final chosen = [
    for (final t in candidates)
      if (targets.contains(t.prefix)) t
  ];
  final before = pasteStrip(c, clip, chosen, sections);
  showUndoToast(
    context,
    'Pasted onto ${chosen.length} strip${chosen.length == 1 ? '' : 's'}',
    () => before.forEach(c.set),
  );
}

/// Picks several strips of [s]'s kind (from every page) and copies them.
Future<void> _copySeveralDialog(BuildContext context, MixerController c, Strip s) async {
  final all = [
    for (final t in c.profile.allStrips)
      if (t.type == s.type) t
  ];
  final chosen = <String>{s.prefix};
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) => AlertDialog(
        title: const Text('Copy several strips'),
        content: SizedBox(
          width: 480,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                        child: Text('${chosen.length} selected', style: const TextStyle(fontWeight: FontWeight.w700))),
                    TextButton(
                        onPressed: () => setLocal(() => chosen.addAll(all.map((t) => t.prefix))),
                        child: const Text('All')),
                    TextButton(onPressed: () => setLocal(chosen.clear), child: const Text('None')),
                  ],
                ),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final t in all)
                      FilterChip(
                        label: Text(_chipName(c, t)),
                        selected: chosen.contains(t.prefix),
                        selectedColor: copyAccent.withValues(alpha: 0.35),
                        onSelected: (v) => setLocal(() => v ? chosen.add(t.prefix) : chosen.remove(t.prefix)),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: chosen.isEmpty ? null : () => Navigator.pop(ctx, true),
            child: Text('Copy ${chosen.length}'),
          ),
        ],
      ),
    ),
  );
  if (ok != true || !context.mounted) return;
  final list = [
    for (final t in all)
      if (chosen.contains(t.prefix)) t
  ];
  await copyStrips(c, list);
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text('Copied ${list.length} strip${list.length == 1 ? '' : 's'}. '
        'Long-press a strip (any page) to paste them from there.'),
  ));
}

/// The strip's own name with its default label, short ("Vox · Ch 5").
String _chipName(MixerController c, Strip s) {
  final n = c.param(s.nameAddr).value;
  return n is String && n.trim().isNotEmpty && n.trim() != s.defaultLabel
      ? '${n.trim()} · ${s.defaultLabel}'
      : s.defaultLabel;
}

/// Pastes a multi-strip copy: each copied strip onto a target of its own,
/// in order from the long-pressed strip unless changed.
Future<void> _pasteMapDialog(BuildContext context, MixerController c, Strip first) async {
  final clip = stripClipboard!;
  final p = c.profile;
  final available = {for (final src in clip.sources) ...sectionsFor(p, src)};
  final availList = [
    for (final sec in CopySection.values)
      if (available.contains(sec)) sec
  ];
  final sections = {...copyDefaultSections.where(available.contains)};
  final candidates = pasteTargets(p, clip);
  final map = defaultPasteMap(p, clip, first);

  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(builder: (ctx, setLocal) {
      final used = <String, int>{};
      for (final t in map.values) {
        if (t != null) used[t.prefix] = (used[t.prefix] ?? 0) + 1;
      }
      final clash = used.values.any((n) => n > 1);
      final count = map.values.where((t) => t != null).length;
      return AlertDialog(
        title: Text('Paste ${clip.sources.length} strips'),
        content: SizedBox(
          width: 480,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(child: Text('Where', style: TextStyle(fontWeight: FontWeight.w700))),
                    // shift every target by one strip
                    IconButton(
                      tooltip: 'All one strip back',
                      onPressed: () => setLocal(() => _shift(map, candidates, -1)),
                      icon: const Icon(Icons.chevron_left),
                    ),
                    IconButton(
                      tooltip: 'All one strip on',
                      onPressed: () => setLocal(() => _shift(map, candidates, 1)),
                      icon: const Icon(Icons.chevron_right),
                    ),
                  ],
                ),
                for (final src in clip.sources)
                  Row(
                    children: [
                      Expanded(
                        child: Text(_chipName(c, src), maxLines: 1, overflow: TextOverflow.ellipsis),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 6),
                        child: Icon(Icons.arrow_forward, size: 16, color: Colors.white54),
                      ),
                      Expanded(
                        child: DropdownButton<String>(
                          isExpanded: true,
                          value: map[src.prefix]?.prefix ?? '',
                          items: [
                            const DropdownMenuItem(
                              value: '',
                              child: Text('— skip —', style: TextStyle(color: Colors.white54)),
                            ),
                            for (final t in candidates)
                              DropdownMenuItem(
                                value: t.prefix,
                                child: Text(
                                  _chipName(c, t),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: (used[t.prefix] ?? 0) > 1 ? const TextStyle(color: Color(0xFFFF6B6B)) : null,
                                ),
                              ),
                          ],
                          onChanged: (v) => setLocal(() {
                            map[src.prefix] =
                                v == null || v.isEmpty ? null : candidates.firstWhere((t) => t.prefix == v);
                          }),
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 12),
                const Text('What', style: TextStyle(fontWeight: FontWeight.w700)),
                for (final sec in availList)
                  CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: sections.contains(sec),
                    title: Text(copySectionLabels[sec]!),
                    onChanged: (v) => setLocal(() => v == true ? sections.add(sec) : sections.remove(sec)),
                  ),
                const SizedBox(height: 8),
                if (clash)
                  const Text(
                    'Two copied strips go onto the same strip: change one of them.',
                    style: TextStyle(fontSize: 12, color: Color(0xFFFF6B6B)),
                  ),
                const Text(
                  'Preamp gain, +48V and inserts are never pasted.',
                  style: TextStyle(fontSize: 12, color: Colors.white54),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: sections.isEmpty || count == 0 || clash ? null : () => Navigator.pop(ctx, true),
            child: Text('Paste $count'),
          ),
        ],
      );
    }),
  );
  if (ok != true || !context.mounted) return;
  final before = pasteMapped(c, clip, map, sections);
  final n = map.values.where((t) => t != null).length;
  showUndoToast(context, 'Pasted $n strip${n == 1 ? '' : 's'}', () => before.forEach(c.set));
}

/// Moves every target [by] strips (a target falling off either end: skipped).
void _shift(Map<String, Strip?> map, List<Strip> candidates, int by) {
  final idx = {for (var i = 0; i < candidates.length; i++) candidates[i].prefix: i};
  for (final k in map.keys.toList()) {
    final t = map[k];
    if (t == null) continue;
    final i = idx[t.prefix]! + by;
    map[k] = i >= 0 && i < candidates.length ? candidates[i] : null;
  }
}
