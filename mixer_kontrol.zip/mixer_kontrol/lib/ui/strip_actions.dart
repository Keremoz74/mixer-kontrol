import 'package:flutter/material.dart';

import '../mixer/copy_paste.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'assign_sheet.dart';
import 'channel_strip.dart' show editStripNameAndColor;
import 'undo_toast.dart';

const copyAccent = Color(0xFF5EB1FF);

String _stripName(MixerController c, Strip s) {
  final n = c.param(s.nameAddr).value;
  return n is String && n.trim().isNotEmpty ? '${n.trim()} (${s.defaultLabel})' : s.defaultLabel;
}

/// Long-press menu of a strip: name & colour, copy, paste.
Future<void> showStripActions(BuildContext context, MixerController c, Strip s) async {
  final clip = stripClipboard;
  final canPaste = clip != null &&
      clip.family == c.profile.family &&
      clip.source.type == s.type &&
      clip.source.prefix != s.prefix;
  final action = await showModalBottomSheet<String>(
    context: context,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    isScrollControlled: true, // phone landscape: the menu scrolls instead of overflowing
    builder: (context) => SafeArea(
      child: SingleChildScrollView(
       child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(_stripName(c, s), style: Theme.of(context).textTheme.titleMedium),
          ),
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('Name & colour'),
            onTap: () => Navigator.pop(context, 'name'),
          ),
          if (hasAssignOptions(c.profile, s))
            ListTile(
              leading: const Icon(Icons.hub_outlined, color: assignAccent),
              title: const Text('DCA, mute groups, Main LR, link'),
              onTap: () => Navigator.pop(context, 'assign'),
            ),
          ListTile(
            leading: const Icon(Icons.copy, color: copyAccent),
            title: const Text('Copy settings'),
            subtitle: const Text('EQ, dynamics, sends… (never gain or +48V)'),
            onTap: () => Navigator.pop(context, 'copy'),
          ),
          ListTile(
            enabled: canPaste,
            leading: Icon(Icons.content_paste, color: canPaste ? copyAccent : null),
            title: Text(canPaste ? 'Paste from ${_stripName(c, clip!.source)}' : 'Paste settings'),
            subtitle: Text(canPaste
                ? 'Choose what to paste and onto which strips'
                : (clip == null ? 'Copy a strip first' : 'Copied strip is a different kind')),
            onTap: () => Navigator.pop(context, 'paste'),
          ),
        ],
       ),
      ),
    ),
  );
  if (!context.mounted || action == null) return;
  switch (action) {
    case 'name':
      await editStripNameAndColor(context, c, s);
    case 'copy':
      await copyStrip(c, s);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Copied ${_stripName(c, s)}. Long-press another strip to paste.'),
      ));
    case 'paste':
      await _pasteDialog(context, c, s);
    case 'assign':
      await showAssignSheet(context, c, s);
  }
}

Future<void> _pasteDialog(BuildContext context, MixerController c, Strip target) async {
  final clip = stripClipboard!;
  final p = c.profile;
  final available = sectionsFor(p, clip.source);
  final sections = {...copyDefaultSections.where(available.contains)};
  final candidates = [for (final t in pasteTargets(p, clip)) if (t.prefix != clip.source.prefix) t];
  final targets = <String>{target.prefix};

  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) => AlertDialog(
        title: Text('Paste from ${_stripName(c, clip.source)}'),
        content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('What', style: TextStyle(fontWeight: FontWeight.w700)),
                for (final sec in available)
                  CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: sections.contains(sec),
                    title: Text(copySectionLabels[sec]!),
                    onChanged: (v) => setLocal(() => v == true ? sections.add(sec) : sections.remove(sec)),
                  ),
                const SizedBox(height: 8),
                const Text('Onto', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final t in candidates)
                      FilterChip(
                        label: Text(t.defaultLabel),
                        selected: targets.contains(t.prefix),
                        selectedColor: copyAccent.withValues(alpha: 0.35),
                        onSelected: (v) => setLocal(() => v ? targets.add(t.prefix) : targets.remove(t.prefix)),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  'Preamp gain, +48V and inserts are never pasted.',
                  style: TextStyle(fontSize: 12, color: Colors.white54),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: sections.isEmpty || targets.isEmpty ? null : () => Navigator.pop(ctx, true),
            child: Text('Paste to ${targets.length}'),
          ),
        ],
      ),
    ),
  );
  if (ok != true || !context.mounted) return;
  final chosen = [for (final t in candidates) if (targets.contains(t.prefix)) t];
  final before = pasteStrip(c, clip, chosen, sections);
  showUndoToast(
    context,
    'Pasted onto ${chosen.length} strip${chosen.length == 1 ? '' : 's'}',
    () => before.forEach(c.set),
  );
}
