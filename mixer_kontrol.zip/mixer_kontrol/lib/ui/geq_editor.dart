import 'package:flutter/material.dart';

import '../mixer/inserts.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'rta_view.dart';

/// Graphic EQ / TruEQ codes and whether they are dual (two independent halves).
const geqCodes = {'GEQ': false, 'TEQ': false, 'GEQ2': true, 'TEQ2': true};

const geqFreqs = [
  20.0, 25.0, 31.5, 40.0, 50.0, 63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0, 500.0, 630.0, //
  800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0, 10000.0, 12500.0,
  16000.0, 20000.0,
];

String geqFreqLabel(double hz) =>
    hz >= 1000 ? '${(hz / 1000).toStringAsFixed(hz % 1000 == 0 ? 0 : 1)}k' : hz.toStringAsFixed(hz % 1 == 0 ? 0 : 1);

/// Gain of a GEQ band: 0..1 ↔ -15..+15 dB.
double geqDb(double norm) => -15 + norm * 30;
double geqNorm(double db) => ((db + 15) / 30).clamp(0.0, 1.0);

/// Parameter number of band [band] (0-30) on half [side] (0 = A/L, 1 = B/R).
int geqPar(int band, int side) => side * 32 + band + 1;
int geqMasterPar(int side) => side * 32 + 32;

/// Strip whose insert uses [slot] (side [side]), for the RTA; null if none.
Strip? geqSourceStrip(MixerController c, int slot, int side, {bool dual = true}) {
  final p = c.profile;
  for (final s in p.insertStrips) {
    final v = c.param(p.insertSelAddr(s)).value;
    if (v is! num) continue;
    if (p.insertSlot(v.toInt()) == slot && (!dual || p.insertSide(v.toInt()) == side)) {
      return s;
    }
  }
  return null;
}

/// 31 band faders for a GEQ / TruEQ FX slot, with an optional RTA of the
/// strip the GEQ is inserted on.
class GeqEditor extends StatefulWidget {
  const GeqEditor({super.key, required this.controller, required this.slot, required this.dual});
  final MixerController controller;
  final int slot;
  final bool dual;

  @override
  State<GeqEditor> createState() => _GeqEditorState();
}

class _GeqEditorState extends State<GeqEditor> {
  int _side = 0;
  bool _rta = false;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    final p = c.profile;
    c.query([
      for (var side = 0; side < (widget.dual ? 2 : 1); side++) ...[
        for (var b = 0; b < 31; b++) p.fxParAddr(widget.slot, geqPar(b, side)),
        p.fxParAddr(widget.slot, geqMasterPar(side)),
      ],
      ...p.insertAddresses,
    ]);
  }

  @override
  void dispose() {
    if (_rta) c.unwatchRta();
    super.dispose();
  }

  void _toggleRta() {
    final src = geqSourceStrip(c, widget.slot, _side, dual: widget.dual) ?? c.profile.main;
    setState(() => _rta = !_rta);
    _rta ? c.watchRta(src) : c.unwatchRta();
  }

  void _flatten() {
    final p = c.profile;
    for (var b = 0; b < 31; b++) {
      c.set(p.fxParAddr(widget.slot, geqPar(b, _side)), 0.5);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final src = geqSourceStrip(c, widget.slot, _side, dual: widget.dual);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 6,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            if (widget.dual)
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: [
                  ButtonSegment(value: 0, label: Text(p.sideName(0))),
                  ButtonSegment(value: 1, label: Text(p.sideName(1))),
                ],
                selected: {_side},
                onSelectionChanged: (s) {
                  setState(() => _side = s.first);
                  if (_rta) {
                    c.watchRta(geqSourceStrip(c, widget.slot, _side, dual: widget.dual) ?? p.main);
                  }
                },
              ),
            FilterChip(
              avatar: const Icon(Icons.graphic_eq, size: 18),
              label: Text(_rta ? 'RTA: ${src?.defaultLabel ?? 'Main LR'}' : 'RTA'),
              selected: _rta,
              selectedColor: rtaColor.withValues(alpha: 0.35),
              onSelected: (_) => _toggleRta(),
            ),
            TextButton.icon(onPressed: _flatten, icon: const Icon(Icons.horizontal_rule), label: const Text('Flat')),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 260,
          child: LayoutBuilder(builder: (context, cons) {
            final bandW = (cons.maxWidth / 31).clamp(22.0, 60.0);
            final total = bandW * 31;
            final content = SizedBox(
              width: total,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  if (_rta)
                    Positioned.fill(
                      bottom: 22,
                      child: IgnorePointer(
                        child: CustomPaint(painter: RtaPainter(c.rta)),
                      ),
                    ),
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 22,
                    child: Center(child: Container(height: 1, color: Colors.white24)),
                  ),
                  Row(
                    children: [
                      for (var b = 0; b < 31; b++)
                        SizedBox(
                          width: bandW,
                          child: _BandFader(
                            controller: c,
                            addr: p.fxParAddr(widget.slot, geqPar(b, _side)),
                            label: geqFreqLabel(geqFreqs[b]),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            );
            return total > cons.maxWidth
                ? SingleChildScrollView(scrollDirection: Axis.horizontal, child: content)
                : content;
          }),
        ),
        const SizedBox(height: 6),
        const Text(
          'Drag a band up or down (±15 dB). Double-tap a band to reset it.',
          style: TextStyle(fontSize: 12, color: Colors.white54),
        ),
      ],
    );
  }
}

class _BandFader extends StatelessWidget {
  const _BandFader({required this.controller, required this.addr, required this.label});
  final MixerController controller;
  final String addr;
  final String label;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final norm = v is num ? v.toDouble().clamp(0.0, 1.0) : 0.5;
        final db = geqDb(norm);
        return Column(
          children: [
            Expanded(
              child: LayoutBuilder(builder: (context, cons) {
                final h = cons.maxHeight;
                void setFrom(double dy) => controller.set(addr, (1 - (dy / h)).clamp(0.0, 1.0));
                final y = (1 - norm) * h;
                final mid = h / 2;
                final col = db.abs() < 0.25 ? Colors.white38 : (db > 0 ? const Color(0xFF3DD68C) : const Color(0xFFFFB224));
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onVerticalDragStart: (d) {
                    controller.beginTouch(addr);
                    setFrom(d.localPosition.dy);
                  },
                  onVerticalDragUpdate: (d) => setFrom(d.localPosition.dy),
                  onVerticalDragEnd: (_) => controller.endTouch(addr),
                  onDoubleTap: () => controller.set(addr, 0.5),
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        right: 0,
                        top: y < mid ? y : mid,
                        height: (y - mid).abs(),
                        child: Center(child: Container(width: 4, color: col)),
                      ),
                      Positioned(
                        left: 2,
                        right: 2,
                        top: (y - 4).clamp(0.0, h - 8),
                        height: 8,
                        child: Container(
                          decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(3)),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ),
            SizedBox(
              height: 22,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(label, style: const TextStyle(fontSize: 9, color: Colors.white60)),
              ),
            ),
          ],
        );
      },
    );
  }
}
