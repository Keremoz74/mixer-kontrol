import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/eq_math.dart';
import '../util/param_law.dart';
import 'dynamics_panel.dart';
import 'eq_graph.dart';
import 'param_controls.dart';

/// Per-channel page: EQ curve on top (or right), preamp / band / pan settings
/// in a scrolling list. The EQ graph never sits inside the scroll view, so
/// dragging a band never fights with scrolling.
class ChannelDetailScreen extends StatefulWidget {
  const ChannelDetailScreen({super.key, required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  State<ChannelDetailScreen> createState() => _ChannelDetailScreenState();
}

class _ChannelDetailScreenState extends State<ChannelDetailScreen> {
  int _band = 1;

  MixerController get c => widget.controller;
  Strip get s => widget.strip;

  @override
  void initState() {
    super.initState();
    c.query(c.profile.detailAddresses(s));
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(length: 2, child: _scaffold(context));
  }

  Widget _scaffold(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        bottom: TabBar(
          tabs: [
            const Tab(text: 'EQ · Giriş'),
            Tab(
              child: ListenableBuilder(
                listenable: Listenable.merge([c.param(s.gateAddr('on')), c.param(s.dynAddr('on'))]),
                builder: (context, _) => Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Dinamik'),
                    if (c.flagOf(s.gateAddr('on'))) const _Dot(gateColor),
                    if (c.flagOf(s.dynAddr('on'))) const _Dot(compColor),
                  ],
                ),
              ),
            ),
          ],
        ),
        title: ListenableBuilder(
          listenable: c.param(s.nameAddr),
          builder: (context, _) {
            final n = c.param(s.nameAddr).value;
            final name = n is String && n.trim().isNotEmpty ? n : s.defaultLabel;
            return Text(name == s.defaultLabel ? name : '$name  ·  ${s.defaultLabel}');
          },
        ),
        actions: [
          ValueListenableBuilder<Object?>(
            valueListenable: c.param(s.onAddr),
            builder: (context, v, _) {
              final muted = v is num && v == 0;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: muted ? const Color(0xFFE5484D) : null,
                    foregroundColor: muted ? Colors.white : null,
                  ),
                  onPressed: () => c.toggleOn(s.onAddr),
                  child: const Text('MUTE'),
                ),
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        // Tabs switch by tapping only: a swipe would steal EQ band drags.
        child: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _eqTab(),
            DynamicsPanel(controller: c, strip: s),
          ],
        ),
      ),
    );
  }

  Widget _eqTab() {
    return LayoutBuilder(builder: (context, cons) {
          final wide = cons.maxWidth >= 700 ||
              (cons.maxWidth > cons.maxHeight && cons.maxWidth >= 560);
          final settings = ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
            children: [_bandCard(), _preampCard(), _panCard()],
          );
          if (wide) {
            return Row(
              children: [
                SizedBox(width: 340, child: settings),
                const VerticalDivider(width: 1),
                Expanded(child: _eqArea(expand: true)),
              ],
            );
          }
          return Column(
            children: [
              _eqArea(expand: false, graphHeight: (cons.maxHeight * 0.34).clamp(170.0, 260.0)),
              const Divider(height: 1),
              Expanded(child: settings),
            ],
          );
        });
  }

  // ---------------------------------------------------------------- EQ area

  Widget _eqArea({required bool expand, double graphHeight = 220}) {
    final graph = EqGraph(
      controller: c,
      strip: s,
      selected: _band,
      onSelect: (b) => setState(() => _band = b),
    );
    final bandRow = Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          ParamToggle(controller: c, addr: s.eqOnAddr, label: 'EQ'),
          const SizedBox(width: 8),
          Expanded(
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [
                for (var b = 1; b <= c.profile.channelEqBands; b++)
                  ButtonSegment(
                    value: b,
                    label: Text('$b', style: TextStyle(color: bandColors[(b - 1) % 4])),
                  ),
              ],
              selected: {_band},
              onSelectionChanged: (x) => setState(() => _band = x.first),
            ),
          ),
        ],
      ),
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
        children: [
          if (expand) Expanded(child: graph) else SizedBox(height: graphHeight, child: graph),
          bandRow,
        ],
      ),
    );
  }

  Widget _bandCard() {
    final b = _band;
    final color = bandColors[(b - 1) % 4];
    return ValueListenableBuilder<Object?>(
      valueListenable: c.param(s.eqAddr(b, 'type')),
      builder: (context, v, _) {
        final type = eqTypeOf(v is num ? v.toInt() : const [1, 2, 2, 4][(b - 1) % 4]);
        final cut = isCut(type);
        return SectionCard(
          title: 'EQ bandı $b',
          children: [
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final t in EqType.values)
                  ChoiceChip(
                    label: Text(eqTypeLabels[t.index]),
                    selected: t == type,
                    selectedColor: color.withValues(alpha: 0.35),
                    onSelected: (_) => c.set(s.eqAddr(b, 'type'), t.index),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            ParamSlider(
              controller: c,
              addr: s.eqAddr(b, 'f'),
              label: 'Frekans',
              color: color,
              format: (n) => formatHz(freqLaw.toReal(n)),
            ),
            ParamSlider(
              controller: c,
              addr: s.eqAddr(b, 'g'),
              label: 'Kazanç',
              color: color,
              enabled: !cut,
              resetNorm: 0.5,
              format: (n) => cut ? '—' : formatDbValue(eqGainLaw.toReal(n)),
            ),
            ParamSlider(
              controller: c,
              addr: s.eqAddr(b, 'q'),
              label: 'Q',
              color: color,
              enabled: type == EqType.peq || type == EqType.veq,
              fallback: qLaw.toNorm(2),
              format: (n) => qLaw.toReal(n).toStringAsFixed(1),
            ),
          ],
        );
      },
    );
  }

  // ---------------------------------------------------------------- preamp

  Widget _preampCard() {
    final p = c.profile;
    final deps = p.headampDependencies(s);
    return ListenableBuilder(
      listenable: Listenable.merge([for (final a in deps) c.param(a)]),
      builder: (context, _) => _preampCardFor(c.headampFor(s)),
    );
  }

  String? _queriedPreamp;

  Widget _preampCardFor(HeadampInfo ha) {
    final p = c.profile;
    // Once the preamp is known (or changes), fetch its gain and phantom.
    if (ha.prefix != null && ha.prefix != _queriedPreamp) {
      _queriedPreamp = ha.prefix;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) c.query([ha.gainAddr!, ha.phantomAddr!]);
      });
    }
    final small = Theme.of(context).textTheme.bodySmall;
    final String preampText = switch (ha.status) {
      HeadampStatus.resolved => 'Preamp: ${ha.name}',
      HeadampStatus.pending => 'Preamp yönlendirmesi okunuyor…',
      HeadampStatus.none => 'Bu kanalın kaynağında preamp yok (USB, kart, FX vb.); gain ve +48V kullanılamaz.',
    };
    return SectionCard(
      title: 'Giriş',
      children: [
        Text(preampText, style: small),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            if (ha.phantomAddr != null) _phantomChip(ha),
            ParamToggle(controller: c, addr: s.invertAddr, label: 'Ø Faz'),
            ParamToggle(controller: c, addr: s.hpOnAddr, label: 'Low Cut'),
          ],
        ),
        const SizedBox(height: 8),
        if (ha.gainAddr != null)
          ParamSlider(
            controller: c,
            addr: ha.gainAddr!,
            label: 'Gain',
            fallback: headampGainLaw.toNorm(0),
            format: (n) => formatDbValue(headampGainLaw.toReal(n)),
          )
        else if (ha.status == HeadampStatus.pending)
          const Opacity(
            opacity: 0.5,
            child: ListTile(
              dense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 4),
              title: Text('Gain'),
              trailing: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          ),
        if (p.hasTrim)
          ParamSlider(
            controller: c,
            addr: s.trimAddr,
            label: 'Trim (dijital)',
            resetNorm: 0.5,
            format: (n) => formatDbValue(trimLaw.toReal(n)),
          ),
        ValueListenableBuilder<Object?>(
          valueListenable: c.param(s.hpOnAddr),
          builder: (context, v, _) => ParamSlider(
            controller: c,
            addr: s.hpfAddr,
            label: 'Low Cut frekansı',
            enabled: v is num && v != 0,
            fallback: hpfLaw.toNorm(80),
            format: (n) => formatHz(hpfLaw.toReal(n)),
          ),
        ),
      ],
    );
  }

  /// +48V asks for confirmation before switching on, naming the preamp, since
  /// phantom power can damage some sources (e.g. ribbon mics).
  Widget _phantomChip(HeadampInfo ha) {
    final addr = ha.phantomAddr!;
    return ValueListenableBuilder<Object?>(
      valueListenable: c.param(addr),
      builder: (context, v, _) {
        final on = v is num && v != 0;
        return FilterChip(
          label: const Text('+48V'),
          selected: on,
          selectedColor: const Color(0xFFE5484D).withValues(alpha: 0.45),
          onSelected: (want) async {
            if (!want) {
              c.setFlag(addr, false);
              return;
            }
            final ok = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('+48V açılsın mı?'),
                content: Text('${ha.name} preamp\'ına fantom besleme verilecek. '
                    'Ribbon mikrofon veya hat seviyesinde bir cihaz bağlıysa zarar görebilir.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
                  FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Aç')),
                ],
              ),
            );
            if (ok == true) c.setFlag(addr, true);
          },
        );
      },
    );
  }

  Widget _panCard() {
    return SectionCard(
      title: 'Pan',
      children: [
        ParamSlider(
          controller: c,
          addr: s.panAddr,
          label: 'Sol / Sağ',
          resetNorm: 0.5,
          format: (n) => formatPan(panLaw.toReal(n)),
        ),
        Text(
          'Değere çift dokunarak ortalayabilirsiniz.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

/// Small "on" indicator next to a tab label.
class _Dot extends StatelessWidget {
  const _Dot(this.color);
  final Color color;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 6),
        child: Icon(Icons.circle, size: 8, color: color),
      );
}
