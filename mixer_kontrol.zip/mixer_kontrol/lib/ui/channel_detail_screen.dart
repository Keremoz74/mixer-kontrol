import 'package:flutter/material.dart';

import '../mixer/eq_presets.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/eq_math.dart';
import '../util/param_law.dart';
import 'app_style.dart';
import 'dynamics_panel.dart';
import 'eq_graph.dart';
import 'param_controls.dart';
import 'sends_panel.dart';

/// Per-channel page: EQ curve on top (or right), preamp / band / pan settings
/// in a scrolling list. The EQ graph never sits inside the scroll view, so
/// dragging a band never fights with scrolling.
class ChannelDetailScreen extends StatefulWidget {
  const ChannelDetailScreen({
    super.key,
    required this.controller,
    required this.strip,
    this.initialTab = 0,
  });
  final MixerController controller;
  final Strip strip;

  /// Input channels: 0 EQ · Input, 1 Dynamics, 2 Sends. Buses / Main LR
  /// only have the EQ page.
  final int initialTab;

  @override
  State<ChannelDetailScreen> createState() => _ChannelDetailScreenState();
}

class _ChannelDetailScreenState extends State<ChannelDetailScreen> {
  int _band = 1;

  MixerController get c => widget.controller;
  Strip get s => widget.strip;

  @override
  void initState() {
    super.initState();
    c.query(c.profile.detailAddresses(s));
  }

  @override
  Widget build(BuildContext context) {
    if (!s.hasDetail) {
      // Bus, matrix, Main LR: a single EQ page, no tabs.
      return AppBackground(child: _scaffold(context, tabs: false));
    }
    return DefaultTabController(
      length: 3,
      initialIndex: widget.initialTab.clamp(0, 2),
      child: AppBackground(child: _scaffold(context, tabs: true)),
    );
  }

  PreferredSizeWidget _tabBar({required bool scrollable}) {
    return TabBar(
      isScrollable: scrollable,
      tabAlignment: scrollable ? TabAlignment.start : null,
      dividerColor: scrollable ? Colors.transparent : null,
      tabs: [
        const Tab(text: 'EQ · Input'),
        Tab(
          child: ListenableBuilder(
            listenable: Listenable.merge([c.param(s.gateAddr('on')), c.param(s.dynAddr('on'))]),
            builder: (context, _) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Dynamics'),
                if (c.flagOf(s.gateAddr('on'))) const _Dot(gateColor),
                if (c.flagOf(s.dynAddr('on'))) const _Dot(compColor),
              ],
            ),
          ),
        ),
        const Tab(text: 'Sends'),
      ],
    );
  }

  Widget _scaffold(BuildContext context, {required bool tabs}) {
    final compact = MediaQuery.sizeOf(context).height < 500;
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: compact ? 48 : null,
        bottom: compact || !tabs ? null : _tabBar(scrollable: false),
        title: ListenableBuilder(
          listenable: c.param(s.nameAddr),
          builder: (context, _) {
            final n = c.param(s.nameAddr).value;
            final name = n is String && n.trim().isNotEmpty ? n : s.defaultLabel;
            final label = name == s.defaultLabel ? name : '$name  ·  ${s.defaultLabel}';
            final title = Text(
              tabs ? label : '$label  ·  EQ',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            );
            if (!compact || !tabs) return title;
            // Landscape phone: tabs share the title row to save height.
            return Row(
              children: [
                Flexible(flex: 2, child: title),
                const SizedBox(width: 12),
                Expanded(flex: 3, child: _tabBar(scrollable: true)),
              ],
            );
          },
        ),
        actions: [
          ValueListenableBuilder<Object?>(
            valueListenable: c.param(s.onAddr),
            builder: (context, v, _) {
              final muted = v is num && v == 0;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: muted ? const Color(0xFFE5484D) : null,
                    foregroundColor: muted ? Colors.white : null,
                  ),
                  onPressed: () => c.toggleOn(s.onAddr),
                  child: const Text('MUTE'),
                ),
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        // Tabs switch by tapping only: a swipe would steal EQ band drags.
        child: !tabs
            ? _eqTab()
            : TabBarView(
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _eqTab(),
                  DynamicsPanel(controller: c, strip: s),
                  SendsPanel(controller: c, strip: s),
                ],
              ),
      ),
    );
  }

  Widget _eqTab() {
    return LayoutBuilder(builder: (context, cons) {
          final wide = cons.maxWidth >= 700 ||
              (cons.maxWidth > cons.maxHeight && cons.maxWidth >= 560);
          final settings = ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
            children: [_bandCard(), if (s.hasDetail) ...[_preampCard(), _panCard()]],
          );
          if (wide) {
            return Row(
              children: [
                SizedBox(width: 340, child: settings),
                const VerticalDivider(width: 1),
                Expanded(child: _eqArea(expand: true)),
              ],
            );
          }
          return Column(
            children: [
              _eqArea(expand: false, graphHeight: (cons.maxHeight * 0.34).clamp(170.0, 260.0)),
              const Divider(height: 1),
              Expanded(child: settings),
            ],
          );
        });
  }

  // ---------------------------------------------------------------- EQ area

  Widget _eqArea({required bool expand, double graphHeight = 220}) {
    final graph = EqGraph(
      controller: c,
      strip: s,
      selected: _band,
      onSelect: (b) => setState(() => _band = b),
    );
    final bandRow = Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          ParamToggle(controller: c, addr: s.eqOnAddr, label: 'EQ'),
          const SizedBox(width: 6),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              visualDensity: VisualDensity.compact,
              padding: const EdgeInsets.symmetric(horizontal: 10),
            ),
            onPressed: _openPresets,
            icon: const Icon(Icons.auto_fix_high, size: 18),
            label: const Text('Presets'),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [
                for (var b = 1; b <= s.eqBands; b++)
                  ButtonSegment(
                    value: b,
                    label: Text('$b', style: TextStyle(color: bandColor(b, s.eqBands))),
                  ),
              ],
              selected: {_band},
              onSelectionChanged: (x) => setState(() => _band = x.first),
            ),
          ),
        ],
      ),
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
        children: [
          if (expand) Expanded(child: graph) else SizedBox(height: graphHeight, child: graph),
          bandRow,
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- presets

  Future<void> _openPresets() async {
    final picked = await showModalBottomSheet<EqPreset>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        builder: (context, scroll) => ListView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            Text('EQ presets', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            const Text(
              'Starting points — apply one, then fine-tune by ear.',
              style: TextStyle(fontSize: 12, color: Colors.white60),
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.horizontal_rule),
              title: const Text('Flat (reset EQ)'),
              subtitle: Text(s.hasDetail ? 'All bands 0 dB, low cut off' : 'All bands 0 dB'),
              onTap: () => Navigator.pop(context, const EqPreset('Flat', '', null, [])),
            ),
            if (s.hasDetail)
              for (final cat in eqPresetCategories) ...[
                Padding(
                  padding: const EdgeInsets.only(top: 12, bottom: 6),
                  child: Text(
                    cat,
                    style: const TextStyle(fontSize: 12, color: Colors.white60, fontWeight: FontWeight.w700),
                  ),
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final pr in channelEqPresets.where((x) => x.category == cat))
                      Tooltip(
                        message: pr.note.isEmpty ? pr.name : pr.note,
                        child: ActionChip(
                          label: Text(pr.name),
                          onPressed: () => Navigator.pop(context, pr),
                        ),
                      ),
                  ],
                ),
              ]
            else
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  'Instrument presets are for input channels. Buses and Main LR are best tuned to the room and speakers.',
                  style: TextStyle(fontSize: 12, color: Colors.white54),
                ),
              ),
          ],
        ),
      ),
    );
    if (picked == null || !mounted) return;
    final flat = picked.bands.isEmpty;
    final before = applyEq(
      c,
      s,
      flat ? flatBands(s.eqBands) : picked.bands,
      lowCutHz: flat ? null : picked.lowCutHz,
    );
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(flat ? 'EQ reset to flat' : 'Applied "${picked.name}"'),
        duration: const Duration(seconds: 6),
        action: SnackBarAction(label: 'Undo', onPressed: () => restoreEq(c, before)),
      ),
    );
  }

  Widget _bandCard() {
    final b = _band;
    final color = bandColor(b, s.eqBands);
    return ValueListenableBuilder<Object?>(
      valueListenable: c.param(s.eqAddr(b, 'type')),
      builder: (context, v, _) {
        final type = eqTypeOf(v is num ? v.toInt() : eqDefaultType(b, s.eqBands));
        final cut = isCut(type);
        return SectionCard(
          title: 'EQ band $b',
          children: [
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final t in EqType.values)
                  ChoiceChip(
                    label: Text(eqTypeLabels[t.index]),
                    selected: t == type,
                    selectedColor: color.withValues(alpha: 0.35),
                    onSelected: (_) => c.set(s.eqAddr(b, 'type'), t.index),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            ParamSlider(
              controller: c,
              addr: s.eqAddr(b, 'f'),
              label: 'Frequency',
              color: color,
              format: (n) => formatHz(freqLaw.toReal(n)),
            ),
            ParamSlider(
              controller: c,
              addr: s.eqAddr(b, 'g'),
              label: 'Gain',
              color: color,
              enabled: !cut,
              resetNorm: 0.5,
              format: (n) => cut ? '—' : formatDbValue(eqGainLaw.toReal(n)),
            ),
            ParamSlider(
              controller: c,
              addr: s.eqAddr(b, 'q'),
              label: 'Q',
              color: color,
              enabled: type == EqType.peq || type == EqType.veq,
              fallback: qLaw.toNorm(2),
              format: (n) => qLaw.toReal(n).toStringAsFixed(1),
            ),
          ],
        );
      },
    );
  }

  // ---------------------------------------------------------------- preamp

  Widget _preampCard() {
    final p = c.profile;
    final deps = p.headampDependencies(s);
    return ListenableBuilder(
      listenable: Listenable.merge([for (final a in deps) c.param(a)]),
      builder: (context, _) => _preampCardFor(c.headampFor(s)),
    );
  }

  String? _queriedPreamp;

  Widget _preampCardFor(HeadampInfo ha) {
    final p = c.profile;
    // Once the preamp is known (or changes), fetch its gain and phantom.
    if (ha.prefix != null && ha.prefix != _queriedPreamp) {
      _queriedPreamp = ha.prefix;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) c.query([ha.gainAddr!, ha.phantomAddr!]);
      });
    }
    final small = Theme.of(context).textTheme.bodySmall;
    final String preampText = switch (ha.status) {
      HeadampStatus.resolved => 'Preamp: ${ha.name}',
      HeadampStatus.pending => 'Reading preamp routing…',
      HeadampStatus.none => 'This channel\'s source has no preamp (USB, card, FX…), so gain and +48V are unavailable.',
    };
    return SectionCard(
      title: 'Input',
      children: [
        Text(preampText, style: small),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            if (ha.phantomAddr != null) _phantomChip(ha),
            ParamToggle(controller: c, addr: s.invertAddr, label: 'Ø Phase'),
            ParamToggle(controller: c, addr: s.hpOnAddr, label: 'Low Cut'),
          ],
        ),
        const SizedBox(height: 8),
        if (ha.gainAddr != null)
          ParamSlider(
            controller: c,
            addr: ha.gainAddr!,
            label: 'Gain',
            fallback: headampGainLaw.toNorm(0),
            format: (n) => formatDbValue(headampGainLaw.toReal(n)),
          )
        else if (ha.status == HeadampStatus.pending)
          const Opacity(
            opacity: 0.5,
            child: ListTile(
              dense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 4),
              title: Text('Gain'),
              trailing: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          ),
        if (p.hasTrim)
          ParamSlider(
            controller: c,
            addr: s.trimAddr,
            label: 'Trim (digital)',
            resetNorm: 0.5,
            format: (n) => formatDbValue(trimLaw.toReal(n)),
          ),
        ValueListenableBuilder<Object?>(
          valueListenable: c.param(s.hpOnAddr),
          builder: (context, v, _) => ParamSlider(
            controller: c,
            addr: s.hpfAddr,
            label: 'Low cut frequency',
            enabled: v is num && v != 0,
            fallback: hpfLaw.toNorm(80),
            format: (n) => formatHz(hpfLaw.toReal(n)),
          ),
        ),
      ],
    );
  }

  /// +48V asks for confirmation before switching on, naming the preamp, since
  /// phantom power can damage some sources (e.g. ribbon mics).
  Widget _phantomChip(HeadampInfo ha) {
    final addr = ha.phantomAddr!;
    return ValueListenableBuilder<Object?>(
      valueListenable: c.param(addr),
      builder: (context, v, _) {
        final on = v is num && v != 0;
        return FilterChip(
          label: const Text('+48V'),
          selected: on,
          selectedColor: const Color(0xFFE5484D).withValues(alpha: 0.45),
          onSelected: (want) async {
            if (!want) {
              c.setFlag(addr, false);
              return;
            }
            final ok = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Turn on +48V?'),
                content: Text('Phantom power will be sent to preamp ${ha.name}. '
                    'A ribbon mic or line-level device on that input could be damaged.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                  FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Turn on')),
                ],
              ),
            );
            if (ok == true) c.setFlag(addr, true);
          },
        );
      },
    );
  }

  Widget _panCard() {
    return SectionCard(
      title: 'Pan',
      children: [
        ParamSlider(
          controller: c,
          addr: s.panAddr,
          label: 'Left / Right',
          resetNorm: 0.5,
          format: (n) => formatPan(panLaw.toReal(n)),
        ),
        Text(
          'Double-tap the value to centre.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

/// Small "on" indicator next to a tab label.
class _Dot extends StatelessWidget {
  const _Dot(this.color);
  final Color color;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 6),
        child: Icon(Icons.circle, size: 8, color: color),
      );
}
