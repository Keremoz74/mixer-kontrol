import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';

/// Slider bound to one 0..1 OSC float, with a formatted readout.
/// Double-tap the readout to reset to [resetNorm].
class ParamSlider extends StatelessWidget {
  const ParamSlider({
    super.key,
    required this.controller,
    required this.addr,
    required this.label,
    required this.format,
    this.fallback = 0.5,
    this.resetNorm,
    this.enabled = true,
    this.color,
  });

  final MixerController controller;
  final String addr;
  final String label;
  final String Function(double norm) format;
  final double fallback;
  final double? resetNorm;
  final bool enabled;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final norm = (v is num ? v.toDouble() : fallback).clamp(0.0, 1.0);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
                children: [
                  Text(label, style: t.textTheme.labelLarge),
                  const Spacer(),
                  GestureDetector(
                    onDoubleTap: resetNorm == null || !enabled
                        ? null
                        : () => controller.set(addr, resetNorm!),
                    child: Text(
                      format(norm),
                      style: t.textTheme.labelLarge?.copyWith(
                        color: enabled ? (color ?? t.colorScheme.primary) : t.disabledColor,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: color,
                thumbColor: color,
                overlayShape: SliderComponentShape.noOverlay,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                child: Slider(
                  value: norm,
                  onChangeStart: (_) => controller.beginTouch(addr),
                  onChangeEnd: (_) => controller.endTouch(addr),
                  onChanged: enabled ? (x) => controller.set(addr, x) : null,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// On/off chip bound to an int OSC switch (0/1). Unknown value counts as off.
class ParamToggle extends StatelessWidget {
  const ParamToggle({
    super.key,
    required this.controller,
    required this.addr,
    required this.label,
    this.activeColor,
  });

  final MixerController controller;
  final String addr;
  final String label;
  final Color? activeColor;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final on = v is num && v != 0;
        return FilterChip(
          label: Text(label),
          selected: on,
          selectedColor: activeColor?.withValues(alpha: 0.35),
          onSelected: (x) => controller.setFlag(addr, x),
        );
      },
    );
  }
}

/// Row of chips for an int enum parameter (value = chip index).
class ParamChoice extends StatelessWidget {
  const ParamChoice({
    super.key,
    required this.controller,
    required this.addr,
    required this.labels,
    this.fallback = 0,
    this.color,
  });

  final MixerController controller;
  final String addr;
  final List<String> labels;
  final int fallback;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final sel = v is num ? v.toInt() : fallback;
        return Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (var i = 0; i < labels.length; i++)
              ChoiceChip(
                label: Text(labels[i]),
                selected: i == sel,
                selectedColor: color?.withValues(alpha: 0.35),
                visualDensity: VisualDensity.compact,
                onSelected: (_) => controller.set(addr, i),
              ),
          ],
        );
      },
    );
  }
}

class SectionCard extends StatelessWidget {
  const SectionCard({super.key, required this.title, required this.children, this.trailing});
  final String title;
  final List<Widget> children;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: Theme.of(context).textTheme.titleSmall)),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 6),
            ...children,
          ],
        ),
      ),
    );
  }
}
