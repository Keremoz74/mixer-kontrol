import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../osc/meters.dart';
import '../mixer/mixer_profile.dart';
import '../util/dyn_math.dart';
import '../util/param_law.dart';
import 'param_controls.dart';

const gateColor = Color(0xFFF5A524);
const compColor = Color(0xFF3E8EF7);

/// Gate + compressor for one input channel, with a live transfer curve.
class DynamicsPanel extends StatelessWidget {
  const DynamicsPanel({super.key, required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  MixerController get c => controller;

  /// Consoles whose compressor has fewer controls (Yamaha).
  bool get _basic => !c.profile.hasFullDynamics;
  Strip get s => strip;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final wide = cons.maxWidth >= 700 || (cons.maxWidth > cons.maxHeight && cons.maxWidth >= 560);
      final graph = _TransferGraph(controller: c, strip: s);
      if (wide) {
        return Row(
          children: [
            SizedBox(
              width: 340,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
                children: [_gateCard(), _compCard()],
              ),
            ),
            const VerticalDivider(width: 1),
            Expanded(child: Padding(padding: const EdgeInsets.all(12), child: graph)),
          ],
        );
      }
      return ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
        children: [
          SizedBox(height: 220, child: graph),
          const SizedBox(height: 12),
          _gateCard(),
          _compCard(),
        ],
      );
    });
  }

  Widget _gateCard() {
    return SectionCard(
      title: 'Gate',
      trailing: ParamToggle(controller: c, addr: s.gateAddr('on'), label: 'On', activeColor: gateColor),
      children: [
        if (c.profile.hasGrMeters) _GrMeter(levels: c.gainReduction, id: '${s.prefix}/gate', color: gateColor),
        if (!c.profile.isAh)
        ParamChoice(
          controller: c,
          addr: s.gateAddr('mode'),
          labels: gateModeLabels,
          fallback: 3,
          color: gateColor,
        ),
        const SizedBox(height: 8),
        ParamSlider(
          controller: c,
          addr: s.gateAddr('thr'),
          label: 'Threshold',
          color: gateColor,
          fallback: gateThrLaw.toNorm(-50),
          format: (n) => formatDbValue(gateThrLaw.toReal(n)),
        ),
        ParamSlider(
          controller: c,
          addr: s.gateAddr('range'),
          label: 'Range',
          color: gateColor,
          fallback: gateRangeLaw.toNorm(40),
          format: (n) => '${gateRangeLaw.toReal(n).toStringAsFixed(1)} dB',
        ),
        ..._timeSliders(s.gateAddr, gateColor),
      ],
    );
  }

  Widget _compCard() {
    return SectionCard(
      title: 'Compressor',
      trailing: ParamToggle(controller: c, addr: s.dynAddr('on'), label: 'On', activeColor: compColor),
      children: [
        if (c.profile.hasGrMeters) _GrMeter(levels: c.gainReduction, id: '${s.prefix}/dyn', color: compColor),
        if (!_basic) ...[
        Row(
          children: [
            Expanded(
              child: ParamChoice(
                controller: c,
                addr: s.dynAddr('mode'),
                labels: const ['Comp', 'Exp'],
                color: compColor,
              ),
            ),
            ParamToggle(controller: c, addr: s.dynAddr('auto'), label: 'Auto', activeColor: compColor),
          ],
        ),
        const SizedBox(height: 8),
        ],
        ParamSlider(
          controller: c,
          addr: s.dynAddr('thr'),
          label: 'Threshold',
          color: compColor,
          fallback: compThrLaw.toNorm(-20),
          format: (n) => formatDbValue(compThrLaw.toReal(n)),
        ),
        if (c.profile.compFields.contains('ratio')) ...[
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 4, 4, 2),
          child: Text('Ratio', style: _label),
        ),
        ParamChoice(
          controller: c,
          addr: s.dynAddr('ratio'),
          labels: [for (final r in compRatios) formatRatio(r)],
          fallback: 6,
          color: compColor,
        ),
        ],
        const SizedBox(height: 8),
        if (!_basic)
        ParamSlider(
          controller: c,
          addr: s.dynAddr('knee'),
          label: 'Knee',
          color: compColor,
          fallback: kneeLaw.toNorm(2),
          format: (n) => kneeLaw.toReal(n).toStringAsFixed(1),
        ),
        ParamSlider(
          controller: c,
          addr: s.dynAddr('mgain'),
          label: 'Makeup',
          color: compColor,
          fallback: 0,
          resetNorm: 0,
          format: (n) => formatDbValue(makeupLaw.toReal(n)),
        ),
        ..._timeSliders(s.dynAddr, compColor, hold: c.profile.compFields.contains('hold')),
        if (!_basic) ...[
        ParamSlider(
          controller: c,
          addr: s.dynAddr('mix'),
          label: 'Mix (parallel)',
          color: compColor,
          fallback: 1,
          resetNorm: 1,
          format: (n) => '%${mixLaw.toReal(n).round()}',
        ),
        Row(
          children: [
            Expanded(
              child: ParamChoice(
                controller: c,
                addr: s.dynAddr('det'),
                labels: const ['Peak', 'RMS'],
                color: compColor,
              ),
            ),
            Expanded(
              child: ParamChoice(
                controller: c,
                addr: s.dynAddr('env'),
                labels: const ['Lin', 'Log'],
                fallback: 1,
                color: compColor,
              ),
            ),
          ],
        ),
        ],
      ],
    );
  }

  List<Widget> _timeSliders(String Function(String) addr, Color color, {bool hold = true}) => [
        ParamSlider(
          controller: c,
          addr: addr('attack'),
          label: 'Attack',
          color: color,
          fallback: attackLaw.toNorm(10),
          format: (n) => formatMs(attackLaw.toReal(n)),
        ),
        if (hold)
        ParamSlider(
          controller: c,
          addr: addr('hold'),
          label: 'Hold',
          color: color,
          fallback: holdLaw.toNorm(20),
          format: (n) => formatMs(holdLaw.toReal(n)),
        ),
        ParamSlider(
          controller: c,
          addr: addr('release'),
          label: 'Release',
          color: color,
          fallback: releaseLaw.toNorm(150),
          format: (n) => formatMs(releaseLaw.toReal(n)),
        ),
      ];

  static const _label = TextStyle(fontSize: 14, fontWeight: FontWeight.w500);
}

/// Input level (x) against output level (y), -80…0 dB, with both thresholds.
class _TransferGraph extends StatelessWidget {
  const _TransferGraph({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final s = strip;
    final scheme = Theme.of(context).colorScheme;
    final addrs = [for (final f in gateFields) s.gateAddr(f), for (final f in dynFields) s.dynAddr(f)];
    return ListenableBuilder(
      listenable: Listenable.merge([for (final a in addrs) c.param(a)]),
      builder: (context, _) {
        final st = _DynState(
          gateOn: c.flagOf(s.gateAddr('on')),
          gateMode: c.intOf(s.gateAddr('mode'), 3),
          gateThr: gateThrLaw.toReal(c.numOf(s.gateAddr('thr'), gateThrLaw.toNorm(-50))),
          gateRange: gateRangeLaw.toReal(c.numOf(s.gateAddr('range'), gateRangeLaw.toNorm(40))),
          compOn: c.flagOf(s.dynAddr('on')),
          compMode: c.intOf(s.dynAddr('mode'), 0),
          compThr: compThrLaw.toReal(c.numOf(s.dynAddr('thr'), compThrLaw.toNorm(-20))),
          ratio: compRatios[c.intOf(s.dynAddr('ratio'), 6).clamp(0, compRatios.length - 1)],
          knee: kneeLaw.toReal(c.numOf(s.dynAddr('knee'), kneeLaw.toNorm(2))),
          makeup: makeupLaw.toReal(c.numOf(s.dynAddr('mgain'), 0)),
        );
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: CustomPaint(
            size: Size.infinite,
            painter: _TransferPainter(
              st,
              bg: Colors.black.withValues(alpha: 0.35),
              grid: scheme.outlineVariant.withValues(alpha: 0.5),
              label: scheme.onSurfaceVariant,
              curve: (st.gateOn || st.compOn) ? scheme.primary : scheme.outline,
            ),
          ),
        );
      },
    );
  }
}

class _DynState {
  const _DynState({
    required this.gateOn,
    required this.gateMode,
    required this.gateThr,
    required this.gateRange,
    required this.compOn,
    required this.compMode,
    required this.compThr,
    required this.ratio,
    required this.knee,
    required this.makeup,
  });
  final bool gateOn, compOn;
  final int gateMode, compMode;
  final double gateThr, gateRange, compThr, ratio, knee, makeup;

  double out(double inDb) {
    var y = inDb;
    if (gateOn) y = gateOut(y, mode: gateMode, thr: gateThr, range: gateRange);
    if (compOn) {
      y = compOut(y, mode: compMode, thr: compThr, ratio: ratio, knee: knee, makeup: makeup);
    }
    return y;
  }
}

class _TransferPainter extends CustomPainter {
  _TransferPainter(this.st, {required this.bg, required this.grid, required this.label, required this.curve});
  final _DynState st;
  final Color bg, grid, label, curve;

  static const _min = -80.0;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = bg);
    const pad = 26.0;
    final side = (size.shortestSide - pad - 8).clamp(40.0, double.infinity);
    final origin = Offset((size.width - side + pad) / 2, (size.height + side - pad) / 2 + 4);
    final plot = Rect.fromLTWH(origin.dx, origin.dy - side, side, side);
    double px(double db) => plot.left + (db - _min) / -_min * side;
    double py(double db) => plot.bottom - (db - _min) / -_min * side;

    final gridPaint = Paint()
      ..color = grid
      ..strokeWidth = 1;
    final ts = TextStyle(color: label, fontSize: 10);
    for (var db = _min; db <= 0; db += 20) {
      canvas.drawLine(Offset(px(db), plot.top), Offset(px(db), plot.bottom), gridPaint);
      canvas.drawLine(Offset(plot.left, py(db)), Offset(plot.right, py(db)), gridPaint);
      _text(canvas, '${db.round()}', Offset(px(db) - 8, plot.bottom + 4), ts);
      _text(canvas, '${db.round()}', Offset(plot.left - pad + 2, py(db) - 6), ts);
    }
    // Unity line
    canvas.drawLine(
      Offset(px(_min), py(_min)),
      Offset(px(0), py(0)),
      Paint()
        ..color = label.withValues(alpha: 0.35)
        ..strokeWidth = 1,
    );

    canvas.save();
    canvas.clipRect(plot);
    void thrLine(double db, Color color) {
      canvas.drawLine(
        Offset(px(db), plot.top),
        Offset(px(db), plot.bottom),
        Paint()
          ..color = color.withValues(alpha: 0.7)
          ..strokeWidth = 1.5,
      );
    }

    if (st.gateOn) thrLine(st.gateThr, gateColor);
    if (st.compOn) thrLine(st.compThr, compColor);

    final path = Path();
    for (var x = _min; x <= 0.001; x += 0.5) {
      final y = st.out(x);
      final p = Offset(px(x), py(y));
      if (x == _min) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = curve
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    canvas.restore();

    _text(canvas, 'input →', Offset(plot.right - 40, plot.bottom - 14), ts);
    _text(canvas, '↑ output', Offset(plot.left + 4, plot.top + 2), ts);
  }

  void _text(Canvas canvas, String s, Offset at, TextStyle style) {
    final tp = TextPainter(text: TextSpan(text: s, style: style), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, at);
  }

  @override
  bool shouldRepaint(_TransferPainter old) => true;
}

/// Live gain reduction of the gate / compressor (0 … -30 dB, right to left).
class _GrMeter extends StatelessWidget {
  const _GrMeter({required this.levels, required this.id, required this.color});
  final MeterLevels levels;
  final String id;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: ListenableBuilder(
        listenable: levels,
        builder: (context, _) {
          final v = levels.db(id);
          final gr = v.isFinite ? v.clamp(-30.0, 0.0) : 0.0;
          return Row(
            children: [
              const Text('GR', style: TextStyle(fontSize: 11, color: Colors.white60, fontWeight: FontWeight.w700)),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  alignment: Alignment.centerRight,
                  child: FractionallySizedBox(
                    widthFactor: -gr / 30,
                    child: Container(
                      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 52,
                child: Text(
                  gr > -0.3 ? '0 dB' : '${gr.toStringAsFixed(1)} dB',
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 11),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
