import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/param_law.dart';
import 'channel_detail_screen.dart';

const gainColor = Color(0xFFFF8A4C);

/// Preamp gain on a channel strip: drag up/down on the knob (fine, about
/// 0.25 dB per pixel; it never jumps). Tap opens the channel's input page.
/// A red dot shows +48V. Only works once the channel's preamp is known
/// (X32 routing), and is greyed out for sources without a preamp.
class GainKnob extends StatefulWidget {
  const GainKnob({super.key, required this.controller, required this.strip, this.height = 32});
  final MixerController controller;
  final Strip strip;
  final double height;

  @override
  State<GainKnob> createState() => _GainKnobState();
}

class _GainKnobState extends State<GainKnob> {
  String? _queried;
  double _drag = 0;
  bool _active = false;

  MixerController get c => widget.controller;

  /// Fine control: the full -12…+60 dB range takes ~290 px of drag.
  static const _dbPerPx = 0.25;

  @override
  Widget build(BuildContext context) {
    final deps = c.profile.headampDependencies(widget.strip);
    return ListenableBuilder(
      listenable: Listenable.merge([for (final a in deps) c.param(a)]),
      builder: (context, _) {
        final ha = c.headampFor(widget.strip);
        final gainAddr = ha.gainAddr;
        final phantomAddr = ha.phantomAddr;
        if (gainAddr == null || phantomAddr == null) {
          return _frame(
            child: Text(
              ha.status == HeadampStatus.pending ? '…' : 'no preamp',
              style: const TextStyle(fontSize: 9, color: Colors.white38),
            ),
          );
        }
        if (_queried != ha.prefix) {
          _queried = ha.prefix;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && c.param(gainAddr).value == null) c.query([gainAddr, phantomAddr]);
          });
        }
        return ListenableBuilder(
          listenable: Listenable.merge([c.param(gainAddr), c.param(phantomAddr)]),
          builder: (context, _) {
            final norm = c.numOf(gainAddr, headampGainLaw.toNorm(0)).clamp(0.0, 1.0);
            final known = c.param(gainAddr).value is num;
            final db = headampGainLaw.toReal(norm);
            final phantom = c.flagOf(phantomAddr);
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ChannelDetailScreen(controller: c, strip: widget.strip)),
              ),
              onVerticalDragStart: known
                  ? (_) {
                      _drag = norm;
                      c.beginTouch(gainAddr);
                      setState(() => _active = true);
                    }
                  : null,
              onVerticalDragUpdate: known
                  ? (d) {
                      _drag = (_drag - d.delta.dy * _dbPerPx / 72).clamp(0.0, 1.0);
                      // Snap to the console's 0.5 dB steps.
                      final stepped = headampGainLaw.toNorm((headampGainLaw.toReal(_drag) * 2).round() / 2);
                      c.set(gainAddr, stepped);
                    }
                  : null,
              onVerticalDragEnd: (_) => _end(gainAddr),
              onVerticalDragCancel: () => _end(gainAddr),
              child: _frame(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: widget.height - 6,
                      height: widget.height - 6,
                      child: CustomPaint(painter: _KnobPainter(norm, _active, known)),
                    ),
                    const SizedBox(width: 3),
                    // large system text: shrink the value / GAIN label to fit
                    Flexible(
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            known ? '${db >= 0 ? '+' : ''}${db.toStringAsFixed(db.abs() < 10 ? 1 : 0)}' : '—',
                            maxLines: 1,
                            style: TextStyle(
                              fontSize: 11,
                              height: 1.1,
                              fontWeight: FontWeight.w700,
                              color: _active ? gainColor : Colors.white,
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('GAIN', style: TextStyle(fontSize: 7, height: 1.1, color: Colors.white54)),
                              if (phantom) ...[
                                const SizedBox(width: 3),
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFFF4D57),
                                    shape: BoxShape.circle,
                                    boxShadow: [BoxShadow(color: Color(0xFFFF4D57), blurRadius: 4)],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _end(String addr) {
    if (_active) setState(() => _active = false);
    c.endTouch(addr);
  }

  Widget _frame({required Widget child}) => Container(
        height: widget.height,
        width: double.infinity,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 3),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.35),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: Colors.white.withValues(alpha: _active ? 0.35 : 0.10)),
        ),
        child: child,
      );
}

class _KnobPainter extends CustomPainter {
  _KnobPainter(this.norm, this.active, this.known);
  final double norm;
  final bool active, known;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide / 2 - 1.5;
    const start = math.pi * 0.75;
    const sweep = math.pi * 1.5;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawArc(
      rect,
      start,
      sweep,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round
        ..color = Colors.white.withValues(alpha: 0.15),
    );
    if (known) {
      canvas.drawArc(
        rect,
        start,
        sweep * norm,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..strokeCap = StrokeCap.round
          ..color = gainColor,
      );
    }
    canvas.drawCircle(c, r - 3, Paint()..color = active ? const Color(0xFF4A5468) : const Color(0xFF2A3142));
    final a = start + sweep * norm;
    canvas.drawLine(
      c,
      c + Offset(math.cos(a), math.sin(a)) * (r - 4),
      Paint()
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round
        ..color = known ? Colors.white : Colors.white38,
    );
  }

  @override
  bool shouldRepaint(_KnobPainter old) => old.norm != norm || old.active != active || old.known != known;
}
