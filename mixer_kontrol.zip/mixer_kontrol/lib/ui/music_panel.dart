import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';

/// Music from this tablet / phone, played wirelessly into the mixer.
///
/// The device sends its audio to a Bluetooth (or AirPlay) receiver plugged
/// into a mixer input; the user tells the app which input that is. The app
/// never routes anything by itself: it only offers that channel's level,
/// mute and monitor sends, and play / pause / next for the music app that is
/// playing on this device.

const _accent = Color(0xFF22C55E);

/// Which input the music comes in on, remembered per mixer model.
class MusicSource {
  MusicSource._();

  static String _key(MixerProfile p) => 'music_src_${p.family.name}_${p.model}';

  /// The assigned input of [p], or null.
  static Future<Strip?> load(MixerProfile p) async {
    try {
      final prefix = (await SharedPreferences.getInstance()).getString(_key(p));
      if (prefix == null) return null;
      for (final s in p.inputs) {
        if (s.prefix == prefix) return s;
      }
    } catch (_) {}
    return null;
  }

  static Future<void> save(MixerProfile p, Strip? s) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (s == null) {
        await prefs.remove(_key(p));
      } else {
        await prefs.setString(_key(p), s.prefix);
      }
    } catch (_) {}
  }
}

/// Play / pause / next / previous for whatever music app is playing on this
/// device (Android media keys; nothing on platforms without them).
class MediaKeys {
  MediaKeys._();
  static const _ch = MethodChannel('ozmix/media');

  static bool get supported => !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  static Future<bool> send(String key) async {
    if (!supported) return false;
    try {
      return await _ch.invokeMethod<bool>('key', {'key': key}) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Is music playing, and the Bluetooth output it goes to (null = none).
  static Future<({bool playing, String? output})> state() async {
    if (!supported) return (playing: false, output: null);
    try {
      final m = await _ch.invokeMapMethod<String, Object?>('state');
      return (playing: m?['playing'] == true, output: m?['output'] as String?);
    } catch (_) {
      return (playing: false, output: null);
    }
  }

  static Future<void> openPlayer() async {
    if (!supported) return;
    try {
      await _ch.invokeMethod('open');
    } catch (_) {}
  }
}

String _labelOf(MixerController c, Strip s) {
  final n = c.param(s.nameAddr).value;
  final name = n is String ? n.trim() : '';
  // "Music" adds nothing next to the music icon: just say where it comes in
  return name.isEmpty || name == 'Music' ? s.defaultLabel : '$name (${s.defaultLabel})';
}

/// Music button for the mixer screen's top bar.
class MusicButton extends StatefulWidget {
  const MusicButton({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MusicButton> createState() => _MusicButtonState();
}

class _MusicButtonState extends State<MusicButton> {
  Strip? _src;

  @override
  void initState() {
    super.initState();
    MusicSource.load(widget.controller.profile).then((s) {
      if (mounted) setState(() => _src = s);
    });
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: _src == null ? 'Music from this device' : 'Music: ${_src!.defaultLabel}',
      icon: Icon(Icons.music_note, color: _src == null ? null : _accent),
      onPressed: () async {
        final s = await showMusicSheet(context, widget.controller);
        if (mounted) setState(() => _src = s);
      },
    );
  }
}

/// Opens the music panel (or the input picker first, if nothing is
/// assigned yet). Returns the assigned input when it closes.
Future<Strip?> showMusicSheet(BuildContext context, MixerController c) async {
  var src = await MusicSource.load(c.profile);
  if (!context.mounted) return src;
  src ??= await _pickInput(context, c, null);
  if (src == null || !context.mounted) return src;
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _MusicPanel(controller: c, initial: src!),
  );
  return MusicSource.load(c.profile);
}

/// Lets the user choose the input the receiver is plugged into.
Future<Strip?> _pickInput(BuildContext context, MixerController c, Strip? current) async {
  final p = c.profile;
  final aux = [for (final s in p.inputs) if (s.type == StripType.auxIn) s];
  final ch = [for (final s in p.inputs) if (s.type == StripType.channel) s];
  var name = true;
  final picked = await showModalBottomSheet<Strip>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.8),
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              Text('Which input is the music on?', style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(
                'Plug a Bluetooth audio receiver into a free stereo input of the mixer and pair this '
                'device with it. Then pick that input here. The app only controls this channel; '
                'it never changes your routing.',
                style: Theme.of(ctx).textTheme.bodySmall?.copyWith(color: Colors.white70),
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: name,
                onChanged: (v) => setSt(() => name = v ?? true),
                title: const Text('Name the channel "Music" on the mixer'),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              if (aux.isNotEmpty) ...[
                const _Heading('Aux inputs (recommended)'),
                Wrap(spacing: 8, runSpacing: 8, children: [for (final s in aux) _choice(ctx, c, s, current)]),
              ],
              const _Heading('Channels'),
              Wrap(spacing: 8, runSpacing: 8, children: [for (final s in ch) _choice(ctx, c, s, current)]),
            ],
          ),
        ),
      ),
    ),
  );
  if (picked == null) return current;
  await MusicSource.save(c.profile, picked);
  if (name) c.rename(picked, 'Music');
  return picked;
}

Widget _choice(BuildContext ctx, MixerController c, Strip s, Strip? current) => ChoiceChip(
      label: Text(_labelOf(c, s)),
      selected: current?.prefix == s.prefix,
      selectedColor: _accent.withValues(alpha: 0.3),
      onSelected: (_) => Navigator.pop(ctx, s),
    );

class _Heading extends StatelessWidget {
  const _Heading(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 8),
        child: Text(text, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: _accent)),
      );
}

class _MusicPanel extends StatefulWidget {
  const _MusicPanel({required this.controller, required this.initial});
  final MixerController controller;
  final Strip initial;

  @override
  State<_MusicPanel> createState() => _MusicPanelState();
}

class _MusicPanelState extends State<_MusicPanel> {
  late Strip s = widget.initial;
  bool _playing = false;
  String? _output;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final st = await MediaKeys.state();
    if (mounted) {
      setState(() {
        _playing = st.playing;
        _output = st.output;
      });
    }
  }

  Future<void> _key(String k) async {
    await MediaKeys.send(k);
    await Future<void>.delayed(const Duration(milliseconds: 400));
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.music_note, color: _accent),
                const SizedBox(width: 8),
                Expanded(
                  child: ListenableBuilder(
                    listenable: c.param(s.nameAddr),
                    builder: (context, _) =>
                        Text('Music · ${_labelOf(c, s)}', style: t.textTheme.titleMedium, overflow: TextOverflow.ellipsis),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    final n = await _pickInput(context, c, s);
                    if (n != null && mounted) setState(() => s = n);
                  },
                  child: const Text('Change input'),
                ),
              ],
            ),
            if (MediaKeys.supported) ...[
              const SizedBox(height: 4),
              Text(
                _output != null ? 'This device plays to: $_output' : 'Not playing to a Bluetooth receiver yet — pair this device with it.',
                style: t.textTheme.bodySmall?.copyWith(color: _output != null ? Colors.white70 : AppStyle.muteRed),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(tooltip: 'Previous', iconSize: 32, onPressed: () => _key('prev'), icon: const Icon(Icons.skip_previous)),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    tooltip: _playing ? 'Pause' : 'Play',
                    iconSize: 40,
                    style: IconButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.black),
                    onPressed: () => _key('play'),
                    icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
                  ),
                  const SizedBox(width: 8),
                  IconButton(tooltip: 'Next', iconSize: 32, onPressed: () => _key('next'), icon: const Icon(Icons.skip_next)),
                  const SizedBox(width: 16),
                  IconButton(tooltip: 'Open music app', onPressed: MediaKeys.openPlayer, icon: const Icon(Icons.library_music)),
                ],
              ),
            ],
            const SizedBox(height: 8),
            _LevelRow(controller: c, strip: s),
            const SizedBox(height: 12),
            Text('Send to monitors', style: t.textTheme.labelLarge?.copyWith(color: _accent)),
            for (final target in c.profile.sendTargets) _SendRow(controller: c, strip: s, target: target),
          ],
        ),
      ),
    );
  }
}

/// Level (to main) and mute of the music channel.
class _LevelRow extends StatelessWidget {
  const _LevelRow({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final c = controller, s = strip;
    return ListenableBuilder(
      listenable: Listenable.merge([c.param(s.faderAddr), c.param(s.onAddr)]),
      builder: (context, _) {
        final on = c.isOn(s.onAddr);
        final f = c.faderOf(s.faderAddr);
        return Row(
          children: [
            SizedBox(width: 72, child: Text('${formatDb(f)} dB', textAlign: TextAlign.right)),
            Expanded(
              child: Slider(
                value: f.clamp(0.0, 1.0),
                activeColor: _accent,
                onChangeStart: (_) => c.beginTouch(s.faderAddr),
                onChangeEnd: (_) => c.endTouch(s.faderAddr),
                onChanged: (v) => c.setFader(s.faderAddr, v),
              ),
            ),
            FilledButton.tonal(
              style: FilledButton.styleFrom(
                backgroundColor: on ? null : AppStyle.muteRed,
                foregroundColor: on ? null : Colors.white,
              ),
              onPressed: () => c.toggleOn(s.onAddr),
              child: Text(on ? 'Mute' : 'Muted'),
            ),
          ],
        );
      },
    );
  }
}

/// One monitor send of the music channel: on/off and level.
class _SendRow extends StatelessWidget {
  const _SendRow({required this.controller, required this.strip, required this.target});
  final MixerController controller;
  final Strip strip;
  final SendTarget target;

  @override
  Widget build(BuildContext context) {
    final c = controller, s = strip, t = target;
    final lvl = s.sendLevelAddr(t), on = s.sendOnAddr(t);
    return ListenableBuilder(
      listenable: Listenable.merge([c.param(lvl), c.param(on), c.param(t.master.nameAddr)]),
      builder: (context, _) {
        final n = c.param(t.master.nameAddr).value;
        final label = n is String && n.trim().isNotEmpty ? n.trim() : t.label;
        final enabled = c.isOn(on);
        final v = c.faderOf(lvl);
        return Row(
          children: [
            SizedBox(
              width: 112,
              child: FilterChip(
                showCheckmark: false,
                label: FittedBox(fit: BoxFit.scaleDown, child: Text(label, maxLines: 1)),
                selected: enabled,
                selectedColor: _accent.withValues(alpha: 0.3),
                onSelected: (x) => c.setFlag(on, x),
              ),
            ),
            Expanded(
              child: Slider(
                value: v.clamp(0.0, 1.0),
                activeColor: enabled ? _accent : Colors.white24,
                onChangeStart: (_) => c.beginTouch(lvl),
                onChangeEnd: (_) => c.endTouch(lvl),
                onChanged: (x) => c.setFader(lvl, x),
              ),
            ),
            SizedBox(width: 52, child: Text(formatDb(v), textAlign: TextAlign.right)),
          ],
        );
      },
    );
  }
}
