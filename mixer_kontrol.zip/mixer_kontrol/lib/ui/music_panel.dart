import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';

/// Music from this tablet / phone, played wirelessly into the mixer.
///
/// The device sends its audio to a Bluetooth (or AirPlay) receiver plugged
/// into a mixer input; the user tells the app which input that is. The app
/// never routes anything by itself: it only offers that channel's level,
/// mute and monitor sends, and play / pause / next for the music app that is
/// playing on this device.

const _accent = Color(0xFF22C55E);

/// Which input the music comes in on, remembered per mixer model.
class MusicSource {
  MusicSource._();

  static String _key(MixerProfile p) => 'music_src_${p.family.name}_${p.model}';

  /// The assigned input of [p], or null.
  static Future<Strip?> load(MixerProfile p) async {
    try {
      final prefix = (await SharedPreferences.getInstance()).getString(_key(p));
      if (prefix == null) return null;
      for (final s in p.inputs) {
        if (s.prefix == prefix) return s;
      }
    } catch (_) {}
    return null;
  }

  static Future<void> save(MixerProfile p, Strip? s) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (s == null) {
        await prefs.remove(_key(p));
      } else {
        await prefs.setString(_key(p), s.prefix);
      }
    } catch (_) {}
  }
}

/// Play / pause / next / previous for whatever music app is playing on this
/// device (Android media keys; nothing on platforms without them).
class MediaKeys {
  MediaKeys._();
  static const _ch = MethodChannel('ozmix/media');

  static bool get supported => !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  static Future<bool> send(String key) async {
    if (!supported) return false;
    try {
      return await _ch.invokeMethod<bool>('key', {'key': key}) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// What this device is playing (any app: YouTube, Spotify...) and the
  /// Bluetooth output it goes to. Title / artist / app need the user's
  /// "notification access" ([access] false until then).
  static Future<NowPlaying> state() async {
    if (!supported) return const NowPlaying();
    try {
      final m = await _ch.invokeMapMethod<String, Object?>('state');
      if (m == null) return const NowPlaying();
      String? str(String k) {
        final v = m[k];
        return v is String && v.trim().isNotEmpty ? v.trim() : null;
      }

      final art = m['art'];
      return NowPlaying(
        access: m['access'] == true,
        playing: m['playing'] == true,
        output: str('output'),
        title: str('title'),
        artist: str('artist'),
        app: str('app'),
        package: str('package'),
        art: art is Uint8List && art.length < 512 * 1024 ? art : null,
      );
    } catch (_) {
      return const NowPlaying();
    }
  }

  /// Opens Android's "notification access" settings for this app.
  static Future<void> askAccess() async {
    if (!supported) return;
    try {
      await _ch.invokeMethod('access');
    } catch (_) {}
  }

  /// Opens the app that is playing ([package]), else the default music app.
  static Future<void> openPlayer([String? package]) async {
    if (!supported) return;
    try {
      await _ch.invokeMethod('open', {'package': package});
    } catch (_) {}
  }
}

class NowPlaying {
  const NowPlaying({
    this.access = false,
    this.playing = false,
    this.output,
    this.title,
    this.artist,
    this.app,
    this.package,
    this.art,
  });
  final bool access;
  final bool playing;
  final String? output;
  final String? title;
  final String? artist;
  final String? app;
  final String? package;
  final Uint8List? art;
}

String _labelOf(MixerController c, Strip s) {
  final n = c.param(s.nameAddr).value;
  final name = n is String ? n.trim() : '';
  // "Music" adds nothing next to the music icon: just say where it comes in
  return name.isEmpty || name == 'Music' ? s.defaultLabel : '$name (${s.defaultLabel})';
}

/// Music button for the mixer screen's top bar.
class MusicButton extends StatefulWidget {
  const MusicButton({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MusicButton> createState() => _MusicButtonState();
}

class _MusicButtonState extends State<MusicButton> {
  Strip? _src;

  @override
  void initState() {
    super.initState();
    MusicSource.load(widget.controller.profile).then((s) {
      if (mounted) setState(() => _src = s);
    });
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: _src == null ? 'Music from this device' : 'Music: ${_src!.defaultLabel}',
      icon: Icon(Icons.music_note, color: _src == null ? null : _accent),
      onPressed: () async {
        final s = await showMusicSheet(context, widget.controller);
        if (mounted) setState(() => _src = s);
      },
    );
  }
}

/// Opens the music panel (or the input picker first, if nothing is
/// assigned yet). Returns the assigned input when it closes.
Future<Strip?> showMusicSheet(BuildContext context, MixerController c) async {
  var src = await MusicSource.load(c.profile);
  if (!context.mounted) return src;
  src ??= await _pickInput(context, c, null);
  if (src == null || !context.mounted) return src;
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _MusicPanel(controller: c, initial: src!),
  );
  return MusicSource.load(c.profile);
}

/// Lets the user choose the input the receiver is plugged into.
Future<Strip?> _pickInput(BuildContext context, MixerController c, Strip? current) async {
  final p = c.profile;
  final aux = [for (final s in p.inputs) if (s.type == StripType.auxIn) s];
  final ch = [for (final s in p.inputs) if (s.type == StripType.channel) s];
  var name = true;
  final picked = await showModalBottomSheet<Strip>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.8),
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              Text('Which input is the music on?', style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(
                'Plug a Bluetooth audio receiver into a free stereo input of the mixer and pair this '
                'device with it. Then pick that input here. The app only controls this channel; '
                'it never changes your routing.',
                style: Theme.of(ctx).textTheme.bodySmall?.copyWith(color: Colors.white70),
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: name,
                onChanged: (v) => setSt(() => name = v ?? true),
                title: const Text('Name the channel "Music" on the mixer'),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              if (aux.isNotEmpty) ...[
                const _Heading('Aux inputs (recommended)'),
                Wrap(spacing: 8, runSpacing: 8, children: [for (final s in aux) _choice(ctx, c, s, current)]),
              ],
              const _Heading('Channels'),
              Wrap(spacing: 8, runSpacing: 8, children: [for (final s in ch) _choice(ctx, c, s, current)]),
            ],
          ),
        ),
      ),
    ),
  );
  if (picked == null) return current;
  await MusicSource.save(c.profile, picked);
  if (name) c.rename(picked, 'Music');
  return picked;
}

Widget _choice(BuildContext ctx, MixerController c, Strip s, Strip? current) => ChoiceChip(
      label: Text(_labelOf(c, s)),
      selected: current?.prefix == s.prefix,
      selectedColor: _accent.withValues(alpha: 0.3),
      onSelected: (_) => Navigator.pop(ctx, s),
    );

class _Heading extends StatelessWidget {
  const _Heading(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 8),
        child: Text(text, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: _accent)),
      );
}

class _MusicPanel extends StatefulWidget {
  const _MusicPanel({required this.controller, required this.initial});
  final MixerController controller;
  final Strip initial;

  @override
  State<_MusicPanel> createState() => _MusicPanelState();
}

class _MusicPanelState extends State<_MusicPanel> with WidgetsBindingObserver {
  late Strip s = widget.initial;
  NowPlaying _now = const NowPlaying();
  Timer? _poll;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
    // keep the track, play state and output current while the panel is open
    if (MediaKeys.supported) _poll = Timer.periodic(const Duration(seconds: 1), (_) => _refresh());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // back from the settings screen: show the track at once
    if (state == AppLifecycleState.resumed) _refresh();
  }

  @override
  void dispose() {
    _poll?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _refresh() async {
    final st = await MediaKeys.state();
    if (mounted) setState(() => _now = st);
  }

  Future<void> _key(String k) async {
    await MediaKeys.send(k);
    await Future<void>.delayed(const Duration(milliseconds: 400));
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.music_note, color: _accent),
                const SizedBox(width: 8),
                Expanded(
                  child: ListenableBuilder(
                    listenable: c.param(s.nameAddr),
                    builder: (context, _) =>
                        Text('Music · ${_labelOf(c, s)}', style: t.textTheme.titleMedium, overflow: TextOverflow.ellipsis),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    final n = await _pickInput(context, c, s);
                    if (n != null && mounted) setState(() => s = n);
                  },
                  child: const Text('Change input'),
                ),
              ],
            ),
            if (MediaKeys.supported) ...[
              const SizedBox(height: 4),
              _NowPlayingCard(now: _now),
              const SizedBox(height: 6),
              Text(
                _now.output != null
                    ? 'This device plays to: ${_now.output}'
                    : 'Not playing to a Bluetooth receiver yet — pair this device with it.',
                style: t.textTheme.bodySmall?.copyWith(color: _now.output != null ? Colors.white70 : AppStyle.muteRed),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(tooltip: 'Previous', iconSize: 32, onPressed: () => _key('prev'), icon: const Icon(Icons.skip_previous)),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    tooltip: _now.playing ? 'Pause' : 'Play',
                    iconSize: 40,
                    style: IconButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.black),
                    onPressed: () => _key('play'),
                    icon: Icon(_now.playing ? Icons.pause : Icons.play_arrow),
                  ),
                  const SizedBox(width: 8),
                  IconButton(tooltip: 'Next', iconSize: 32, onPressed: () => _key('next'), icon: const Icon(Icons.skip_next)),
                  const SizedBox(width: 16),
                  IconButton(
                    tooltip: _now.app != null ? 'Open ${_now.app}' : 'Open music app',
                    onPressed: () => MediaKeys.openPlayer(_now.package),
                    icon: const Icon(Icons.open_in_new),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 8),
            _MainAssign(controller: c, strip: s),
            _LevelRow(controller: c, strip: s),
            const SizedBox(height: 12),
            Text('Send to monitors', style: t.textTheme.labelLarge?.copyWith(color: _accent)),
            for (final target in c.profile.sendTargets) _SendRow(controller: c, strip: s, target: target),
          ],
        ),
      ),
    );
  }
}

/// Level (to main) and mute of the music channel.
class _LevelRow extends StatelessWidget {
  const _LevelRow({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final c = controller, s = strip;
    return ListenableBuilder(
      listenable: Listenable.merge([c.param(s.faderAddr), c.param(s.onAddr)]),
      builder: (context, _) {
        final on = c.isOn(s.onAddr);
        final f = c.faderOf(s.faderAddr);
        return Row(
          children: [
            SizedBox(width: 72, child: Text('${formatDb(f)} dB', textAlign: TextAlign.right)),
            Expanded(
              child: Slider(
                value: f.clamp(0.0, 1.0),
                activeColor: _accent,
                onChangeStart: (_) => c.beginTouch(s.faderAddr),
                onChangeEnd: (_) => c.endTouch(s.faderAddr),
                onChanged: (v) => c.setFader(s.faderAddr, v),
              ),
            ),
            FilledButton.tonal(
              style: FilledButton.styleFrom(
                backgroundColor: on ? null : AppStyle.muteRed,
                foregroundColor: on ? null : Colors.white,
              ),
              onPressed: () => c.toggleOn(s.onAddr),
              child: Text(on ? 'Mute' : 'Muted'),
            ),
          ],
        );
      },
    );
  }
}

/// One monitor send of the music channel: on/off and level.
class _SendRow extends StatelessWidget {
  const _SendRow({required this.controller, required this.strip, required this.target});
  final MixerController controller;
  final Strip strip;
  final SendTarget target;

  @override
  Widget build(BuildContext context) {
    final c = controller, s = strip, t = target;
    final lvl = s.sendLevelAddr(t), on = s.sendOnAddr(t);
    return ListenableBuilder(
      listenable: Listenable.merge([c.param(lvl), c.param(on), c.param(t.master.nameAddr)]),
      builder: (context, _) {
        final n = c.param(t.master.nameAddr).value;
        final label = n is String && n.trim().isNotEmpty ? n.trim() : t.label;
        final enabled = c.isOn(on);
        final v = c.faderOf(lvl);
        return Row(
          children: [
            SizedBox(
              width: 112,
              child: FilterChip(
                showCheckmark: false,
                label: FittedBox(fit: BoxFit.scaleDown, child: Text(label, maxLines: 1)),
                selected: enabled,
                selectedColor: _accent.withValues(alpha: 0.3),
                onSelected: (x) => c.setFlag(on, x),
              ),
            ),
            Expanded(
              child: Slider(
                value: v.clamp(0.0, 1.0),
                activeColor: enabled ? _accent : Colors.white24,
                onChangeStart: (_) => c.beginTouch(lvl),
                onChangeEnd: (_) => c.endTouch(lvl),
                onChanged: (x) => c.setFader(lvl, x),
              ),
            ),
            SizedBox(width: 52, child: Text(formatDb(v), textAlign: TextAlign.right)),
          ],
        );
      },
    );
  }
}

/// What is playing: cover, title, artist and app; or how to allow it.
class _NowPlayingCard extends StatelessWidget {
  const _NowPlayingCard({required this.now});
  final NowPlaying now;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final box = BoxDecoration(
      borderRadius: BorderRadius.circular(12),
      color: Colors.white.withValues(alpha: 0.05),
      border: Border.all(color: _accent.withValues(alpha: 0.35)),
    );
    if (!now.access) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: box,
        child: Row(
          children: [
            const Icon(Icons.queue_music, color: _accent),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'To see and control what YouTube, YouTube Music, Spotify… are playing, '
                'allow OzMix Control under "Notification access".',
                style: t.textTheme.bodySmall,
              ),
            ),
            const SizedBox(width: 8),
            FilledButton(onPressed: MediaKeys.askAccess, child: const Text('Allow')),
          ],
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: box,
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 56,
              height: 56,
              child: now.art != null
                  ? Image.memory(now.art!, fit: BoxFit.cover, gaplessPlayback: true)
                  : Container(color: Colors.white10, child: const Icon(Icons.music_note, color: Colors.white38)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(now.title ?? 'Nothing playing', maxLines: 1, overflow: TextOverflow.ellipsis, style: t.textTheme.titleSmall),
                if (now.artist != null)
                  Text(now.artist!, maxLines: 1, overflow: TextOverflow.ellipsis, style: t.textTheme.bodySmall?.copyWith(color: Colors.white70)),
                if (now.app != null)
                  Text(now.app!, maxLines: 1, overflow: TextOverflow.ellipsis, style: t.textTheme.labelSmall?.copyWith(color: _accent)),
              ],
            ),
          ),
          if (now.playing) const Icon(Icons.graphic_eq, color: _accent),
        ],
      ),
    );
  }
}

/// Main LR assignment of the music channel: without it the fader does not
/// reach the main mix (aux inputs often come unassigned).
class _MainAssign extends StatelessWidget {
  const _MainAssign({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final addr = controller.profile.mainAssignAddr(strip);
    if (addr == null) return const SizedBox.shrink();
    return ListenableBuilder(
      listenable: controller.param(addr),
      builder: (context, _) {
        final on = controller.flagOf(addr);
        return SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: on,
          activeThumbColor: _accent,
          onChanged: (v) => controller.setFlag(addr, v),
          title: const Text('Send to Main LR'),
          subtitle: Text(
            on ? 'The music plays through the main speakers.' : 'Off: the music does not reach the main speakers.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: on ? Colors.white60 : AppStyle.muteRed),
          ),
        );
      },
    );
  }
}
