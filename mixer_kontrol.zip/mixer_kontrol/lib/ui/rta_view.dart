import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/rta.dart';

const rtaColor = Color(0xFF29C5D6);

/// Spectrum drawn on the same log 20 Hz - 20 kHz axis as the EQ graph.
/// [minDb]..[maxDb] maps to bottom..top.
class RtaPainter extends CustomPainter {
  RtaPainter(this.data, {this.minDb = -90, this.maxDb = 0, this.color = rtaColor, this.marks = const []})
      : super(repaint: data);

  final RtaData data;
  final double minDb, maxDb;
  final Color color;

  /// Frequencies to mark (feedback candidates).
  final List<double> marks;

  @override
  void paint(Canvas canvas, Size size) {
    final db = data.db;
    if (db.isEmpty) return;
    final n = db.length;
    final w = size.width, h = size.height;
    double y(double v) => h - ((v - minDb) / (maxDb - minDb)).clamp(0.0, 1.0) * h;
    final path = Path()..moveTo(0, h);
    for (var i = 0; i < n; i++) {
      path.lineTo(i / (n - 1) * w, y(db[i]));
    }
    path
      ..lineTo(w, h)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color.withValues(alpha: 0.45), color.withValues(alpha: 0.06)],
        ).createShader(Offset.zero & size),
    );
    final peak = data.peak;
    if (peak.length == n) {
      final pp = Path();
      for (var i = 0; i < n; i++) {
        final pt = Offset(i / (n - 1) * w, y(peak[i]));
        i == 0 ? pp.moveTo(pt.dx, pt.dy) : pp.lineTo(pt.dx, pt.dy);
      }
      canvas.drawPath(
        pp,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = color.withValues(alpha: 0.7),
      );
    }
    for (final hz in marks) {
      final x = math.log(hz / 20) / math.log(1000) * w;
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, h),
        Paint()
          ..color = const Color(0xFFE5484D)
          ..strokeWidth = 2,
      );
    }
  }

  @override
  bool shouldRepaint(RtaPainter old) => old.data != data || old.marks != marks;
}

String formatHz(double hz) =>
    hz >= 1000 ? '${(hz / 1000).toStringAsFixed(hz >= 10000 ? 1 : 2)} kHz' : '${hz.round()} Hz';
