import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/rta.dart';

const rtaColor = Color(0xFF29C5D6);

/// Spectrum drawn on the same log 20 Hz - 20 kHz axis as the EQ graph.
/// [minDb]..[maxDb] maps to bottom..top.
class RtaPainter extends CustomPainter {
  RtaPainter(this.data,
      {this.minDb = -90, this.maxDb = 0, this.color = rtaColor, this.marks = const [], this.shape, this.span})
      : super(repaint: data);

  final RtaData data;

  /// Added to the spectrum (dB at a frequency): the EQ curve on a pre-EQ
  /// spectrum. Drawn at screen resolution, between the bands too, so a
  /// narrow cut shows at its full depth.
  final double Function(double hz)? shape;

  /// Auto range: show [span] dB below the loudest band (in 3 dB steps)
  /// instead of [minDb]…[maxDb]; the EQ screen uses the EQ graph's own scale
  /// so a cut looks as deep in the spectrum as in the curve.
  final double? span;
  final double minDb, maxDb;
  final Color color;

  /// Frequencies to mark (feedback candidates).
  final List<double> marks;

  @override
  void paint(Canvas canvas, Size size) {
    final db = data.db;
    if (db.isEmpty) return;
    final n = db.length;
    final w = size.width, h = size.height;
    var lo = minDb, hi = maxDb;
    final span = this.span;
    if (span != null) {
      final loud = db.reduce(math.max) + 3;
      final top = data.autoTop;
      // up at once, down only when clearly quieter (no jitter)
      if (top == null || loud > top || loud < top - 9) data.autoTop = (loud / 3).ceil() * 3.0;
      hi = data.autoTop!;
      lo = hi - span;
    }
    double y(double v) => h - ((v - lo) / (hi - lo)).clamp(0.0, 1.0) * h;
    final shape = this.shape;
    // points to draw: the bands themselves, or every 2 px with the shape
    final steps = shape == null ? n - 1 : math.max(n - 1, (w / 2).ceil());
    double at(List<double> v, int k) {
      final pos = k / steps * (n - 1);
      final i = pos.floor().clamp(0, n - 2);
      final t = pos - i;
      final base = v[i] + (v[i + 1] - v[i]) * t;
      return shape == null ? base : base + shape(20.0 * math.pow(1000.0, k / steps));
    }

    final path = Path()..moveTo(0, h);
    for (var k = 0; k <= steps; k++) {
      path.lineTo(k / steps * w, y(at(db, k)));
    }
    path
      ..lineTo(w, h)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color.withValues(alpha: 0.45), color.withValues(alpha: 0.06)],
        ).createShader(Offset.zero & size),
    );
    final peak = data.peak;
    if (peak.length == n) {
      final pp = Path();
      for (var k = 0; k <= steps; k++) {
        final pt = Offset(k / steps * w, y(at(peak, k)));
        k == 0 ? pp.moveTo(pt.dx, pt.dy) : pp.lineTo(pt.dx, pt.dy);
      }
      canvas.drawPath(
        pp,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = color.withValues(alpha: 0.7),
      );
    }
    for (final hz in marks) {
      final x = math.log(hz / 20) / math.log(1000) * w;
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, h),
        Paint()
          ..color = const Color(0xFFE5484D)
          ..strokeWidth = 2,
      );
    }
  }

  @override
  bool shouldRepaint(RtaPainter old) => old.data != data || old.marks != marks || shape != null || old.shape != null;
}
