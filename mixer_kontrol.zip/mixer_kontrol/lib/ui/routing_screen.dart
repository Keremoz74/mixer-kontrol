import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../mixer/routing.dart';
import 'app_style.dart';
import 'param_controls.dart';

const routeAccent = Color(0xFF46A758);

/// Routing (channel sources, input blocks), output patch incl. P16 / USB,
/// output delay; talkback & oscillator (X32); automix.
class RoutingScreen extends StatefulWidget {
  const RoutingScreen({super.key, required this.controller, this.initialTab = 0});
  final MixerController controller;
  final int initialTab;

  @override
  State<RoutingScreen> createState() => _RoutingScreenState();
}

class _RoutingScreenState extends State<RoutingScreen> {
  MixerController get c => widget.controller;
  MixerProfile get p => c.profile;

  @override
  void initState() {
    super.initState();
    c.query([...p.routingAddresses, ...p.talkOscAddresses, ...p.automixAddresses]);
  }

  @override
  Widget build(BuildContext context) {
    final tabs = <(String, Widget)>[
      ('Inputs', _inputsTab()),
      ('Outputs', _outputsTab()),
      if (p.hasTalkback) ('Talkback', _talkTab()),
      ('Automix', _automixTab()),
    ];
    return DefaultTabController(
      length: tabs.length,
      initialIndex: widget.initialTab.clamp(0, tabs.length - 1),
      child: AppBackground(
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Routing & setup'),
            bottom: TabBar(tabs: [for (final t in tabs) Tab(text: t.$1)]),
          ),
          body: TabBarView(children: [for (final t in tabs) t.$2]),
        ),
      ),
    );
  }

  Widget _warn(String text) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xFFFFB224).withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.info_outline, size: 18, color: Color(0xFFFFB224)),
            const SizedBox(width: 8),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 12))),
          ],
        ),
      );

  // ---------------------------------------------------------------- inputs

  Widget _inputsTab() {
    final labels = p.channelSourceLabels;
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        _warn('Routing changes are live: a wrong source silences a channel. Make a snapshot first.'),
        if (p.isX32) ...[
          const Text('Input blocks (In 1-32)', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          for (var b = 0; b < 4; b++)
            _EnumRow(
              controller: c,
              label: 'In ${b * 8 + 1}-${b * 8 + 8}',
              addr: MixerProfile.x32RoutingBlocks[b],
              labels: RoutingAddresses.x32BlockLabels,
            ),
          const SizedBox(height: 14),
        ],
        const Text('Channel sources', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        for (final s in p.channelStrips)
          _EnumRow(controller: c, label: _name(s), addr: p.channelSourceAddr(s), labels: labels),
      ],
    );
  }

  String _name(Strip s) {
    final n = c.param(s.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? '${s.defaultLabel} · ${n.trim()}' : s.defaultLabel;
  }

  // ---------------------------------------------------------------- outputs

  Widget _outputsTab() {
    final ports = p.outputPorts;
    final groups = <String, List<OutputPort>>{};
    for (final o in ports) {
      (groups[o.group] ??= []).add(o);
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        _warn(p.isX32
            ? 'Choose what each output carries and where it is tapped. P16 = Ultranet personal monitors. '
                'Local outputs also have a delay for speaker alignment.'
            : 'Choose what each aux output, P16 (Ultranet) channel and USB channel carries.'),
        for (final g in groups.entries) ...[
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 6),
            child: Text(g.key, style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          for (final o in g.value) _OutputRow(controller: c, port: o, labels: p.outputSourceLabels),
        ],
      ],
    );
  }

  // ---------------------------------------------------------------- talkback & oscillator

  Widget _talkTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        for (final ab in const ['A', 'B']) ...[
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 10),
            decoration: AppStyle.panel(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Text('Talkback $ab', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    const Spacer(),
                    _HoldTalk(controller: c, addr: p.talkEngageAddr(ab)),
                  ],
                ),
                ParamSlider(
                  controller: c,
                  addr: p.talkLevelAddr(ab),
                  label: 'Level',
                  format: (n) => '${(n * 100).round()}%',
                  color: routeAccent,
                ),
                const Text('Talk to', style: TextStyle(fontSize: 12, color: Colors.white70)),
                const SizedBox(height: 4),
                _MaskChips(controller: c, addr: p.talkDestAddr(ab), labels: p.talkDestLabels),
              ],
            ),
          ),
        ],
        Container(
          padding: const EdgeInsets.all(12),
          decoration: AppStyle.panel(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Text('Oscillator', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  const Spacer(),
                  ValueListenableBuilder<Object?>(
                    valueListenable: c.param(RoutingAddresses.oscOnAddr),
                    builder: (context, v, _) => Switch(
                      value: c.flagOf(RoutingAddresses.oscOnAddr),
                      activeTrackColor: const Color(0xFFE5484D),
                      onChanged: (on) => c.setFlag(RoutingAddresses.oscOnAddr, on),
                    ),
                  ),
                ],
              ),
              _warn('Turn the level down before switching the oscillator on.'),
              ParamChoice(
                controller: c,
                addr: RoutingAddresses.oscTypeAddr,
                labels: RoutingAddresses.oscTypeLabels,
                color: routeAccent,
              ),
              const SizedBox(height: 6),
              ParamSlider(
                controller: c,
                addr: RoutingAddresses.oscLevelAddr,
                label: 'Level',
                fallback: 0,
                format: (n) => '${(n * 100).round()}%',
                color: routeAccent,
              ),
              ParamSlider(
                controller: c,
                addr: RoutingAddresses.oscFreqAddr,
                label: 'Frequency (sine)',
                format: (n) {
                  final hz = 20 * math.pow(1000, n).toDouble();
                  return hz >= 1000 ? '${(hz / 1000).toStringAsFixed(1)} kHz' : '${hz.round()} Hz';
                },
                color: routeAccent,
              ),
              _EnumRow(
                controller: c,
                label: 'Destination',
                addr: RoutingAddresses.oscDestAddr,
                labels: RoutingAddresses.oscDestLabels,
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------- automix

  Widget _automixTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        _warn(p.isX32
            ? 'Automix (X32 firmware 4 or newer) balances speech mics automatically. It works on channels 1-8.'
            : 'Automix balances speech mics automatically: put the mics in group X or Y and switch the group on.'),
        Row(
          children: [
            for (final xy in const ['X', 'Y'])
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  decoration: AppStyle.panel(),
                  child: ValueListenableBuilder<Object?>(
                    valueListenable: c.param(p.automixEnableAddr(xy)),
                    builder: (context, v, _) => SwitchListTile(
                      activeTrackColor: routeAccent,
                      title: Text('Group $xy'),
                      value: c.flagOf(p.automixEnableAddr(xy)),
                      onChanged: (on) => c.setFlag(p.automixEnableAddr(xy), on),
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 12),
        for (final s in p.automixStrips)
          Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            decoration: AppStyle.panel(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(_name(s), style: const TextStyle(fontWeight: FontWeight.w600))),
                    ParamChoice(
                      controller: c,
                      addr: p.automixGroupAddr(s),
                      labels: const ['Off', 'X', 'Y'],
                      color: routeAccent,
                    ),
                  ],
                ),
                ParamSlider(
                  controller: c,
                  addr: p.automixWeightAddr(s),
                  label: 'Weight',
                  resetNorm: 0.5,
                  format: (n) {
                    final db = -12 + n * 24;
                    return '${db >= 0 ? '+' : ''}${db.toStringAsFixed(1)} dB';
                  },
                  color: routeAccent,
                ),
              ],
            ),
          ),
      ],
    );
  }
}

/// Label + drop-down for an int enum parameter.
class _EnumRow extends StatelessWidget {
  const _EnumRow({required this.controller, required this.label, required this.addr, required this.labels});
  final MixerController controller;
  final String label;
  final String addr;
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final i = v is num ? v.toInt() : null;
        return Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(
            children: [
              Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis)),
              DropdownButton<int>(
                value: i != null && i >= 0 && i < labels.length ? i : null,
                hint: const Text('…'),
                underline: const SizedBox.shrink(),
                items: [for (var k = 0; k < labels.length; k++) DropdownMenuItem(value: k, child: Text(labels[k]))],
                onChanged: (k) {
                  if (k != null) controller.set(addr, k);
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _OutputRow extends StatelessWidget {
  const _OutputRow({required this.controller, required this.port, required this.labels});
  final MixerController controller;
  final OutputPort port;
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.fromLTRB(12, 4, 8, 4),
      decoration: AppStyle.panel(),
      child: Column(
        children: [
          _EnumRow(controller: c, label: port.label, addr: port.srcAddr, labels: labels),
          if (port.posAddr != null)
            _EnumRow(controller: c, label: '   tap point', addr: port.posAddr!, labels: routingTapLabels),
          if (port.delayOn != null)
            ListenableBuilder(
              listenable: Listenable.merge([c.param(port.delayOn!), c.param(port.delayTime!)]),
              builder: (context, _) {
                final on = c.flagOf(port.delayOn!);
                return Row(
                  children: [
                    const Text('   delay'),
                    Switch(value: on, onChanged: (v) => c.setFlag(port.delayOn!, v), activeTrackColor: routeAccent),
                    Expanded(
                      child: Slider(
                        value: c.numOf(port.delayTime!, 0).clamp(0.0, 1.0),
                        onChangeStart: (_) => c.beginTouch(port.delayTime!),
                        onChangeEnd: (_) => c.endTouch(port.delayTime!),
                        onChanged: on ? (v) => c.set(port.delayTime!, v) : null,
                      ),
                    ),
                    SizedBox(
                      width: 92,
                      child: Text(() {
                        final ms = RoutingAddresses.delayMs(c.numOf(port.delayTime!, 0));
                        return '${ms.toStringAsFixed(1)} ms · ${(ms * 0.343).toStringAsFixed(1)} m';
                      }(), style: const TextStyle(fontSize: 11)),
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }
}

/// Bitmask as chips (bit i = label i).
class _MaskChips extends StatelessWidget {
  const _MaskChips({required this.controller, required this.addr, required this.labels});
  final MixerController controller;
  final String addr;
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) => Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (var i = 0; i < labels.length; i++)
            FilterChip(
              label: Text(labels[i]),
              selected: controller.maskBit(addr, i),
              selectedColor: routeAccent.withValues(alpha: 0.4),
              onSelected: (on) => controller.setMaskBit(addr, i, on),
            ),
        ],
      ),
    );
  }
}

/// Press and hold to talk.
class _HoldTalk extends StatelessWidget {
  const _HoldTalk({required this.controller, required this.addr});
  final MixerController controller;
  final String addr;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Object?>(
      valueListenable: controller.param(addr),
      builder: (context, v, _) {
        final on = controller.flagOf(addr);
        return GestureDetector(
          onTapDown: (_) => controller.setFlag(addr, true),
          onTapUp: (_) => controller.setFlag(addr, false),
          onTapCancel: () => controller.setFlag(addr, false),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: on ? routeAccent : Colors.black.withValues(alpha: 0.35),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: routeAccent),
            ),
            child: Text('TALK', style: TextStyle(fontWeight: FontWeight.w800, color: on ? Colors.black : routeAccent)),
          ),
        );
      },
    );
  }
}
