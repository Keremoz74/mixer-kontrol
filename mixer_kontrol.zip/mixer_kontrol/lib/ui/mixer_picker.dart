import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'mixer_art.dart';
import 'mixer_catalog.dart';
import 'mixer_photo.dart';

typedef ConnectModel = Future<void> Function(MixerModel model, String host);
typedef DemoModel = void Function(MixerModel model);

/// "Select your mixer": one tile per brand (plain names, no logos).
class BrandGrid extends StatelessWidget {
  const BrandGrid({super.key, required this.lastHost, required this.onConnect, required this.onDemo});
  final String Function() lastHost;
  final ConnectModel onConnect;
  final DemoModel onDemo;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final cols = box.maxWidth >= 480 ? 3 : 2;
      return GridView(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: cols,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          mainAxisExtent: 64,
        ),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          for (final b in MixerCatalog.brands)
            _Tile(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => ModelPickerScreen(brand: b, lastHost: lastHost, onConnect: onConnect, onDemo: onDemo),
                ),
              ),
              // a small drawing beside the name: the tiles stay compact
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(
                  children: [
                    MixerArt(spec: MixerCatalog.of(b)[MixerCatalog.showcase[b] ?? 0].art, width: 58, height: 38),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(b,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                          Text('${MixerCatalog.of(b).length} models',
                              style: const TextStyle(fontSize: 11, color: Colors.white54)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      );
    });
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.child, required this.onTap});
  final Widget child;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(decoration: AppStyle.panel(raised: true), child: child),
      ),
    );
  }
}

/// The models of one brand, each with its picture.
class ModelPickerScreen extends StatelessWidget {
  const ModelPickerScreen({
    super.key,
    required this.brand,
    required this.lastHost,
    required this.onConnect,
    required this.onDemo,
  });
  final String brand;
  final String Function() lastHost;
  final ConnectModel onConnect;
  final DemoModel onDemo;

  @override
  Widget build(BuildContext context) {
    final models = MixerCatalog.of(brand);
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(title: Text(brand)),
        body: SafeArea(
          top: false,
          child: LayoutBuilder(builder: (context, box) {
            // compact rows like the brand grid: small picture beside the name
            final cols = (box.maxWidth / 260).floor().clamp(1, 4);
            return GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: cols,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                mainAxisExtent: 64,
              ),
              itemCount: models.length,
              itemBuilder: (context, i) {
                final m = models[i];
                return _Tile(
                  onTap: () => showModelSheet(context, m, lastHost: lastHost(), onConnect: onConnect, onDemo: onDemo),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        MixerPicture(model: m, width: 58, height: 38, radius: 6),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(m.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                              Text(m.info,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 11, color: Colors.white54)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }),
        ),
      ),
    );
  }
}

/// Picture, connect by IP, demo, and the person's own photo for one model.
Future<void> showModelSheet(
  BuildContext context,
  MixerModel m, {
  required String lastHost,
  required ConnectModel onConnect,
  required DemoModel onDemo,
}) {
  final host = TextEditingController(text: lastHost);
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    builder: (ctx) {
      final size = MediaQuery.sizeOf(ctx);
      final picW = (size.width - 32).clamp(200.0, 520.0);
      Future<void> connect() async {
        final h = host.text.trim();
        if (h.isEmpty) return;
        Navigator.pop(ctx);
        await onConnect(m, h);
      }

      Future<void> photo(ImageSource src) async {
        final ok = await MixerPhotos.pick(m.id, src);
        if (!ok && ctx.mounted) {
          ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('No photo was added.')));
        }
      }

      return Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(ctx).bottom),
        child: SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: size.height * 0.9),
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                Center(child: MixerPicture(model: m, width: picW, height: picW * 0.56, radius: 14)),
                const SizedBox(height: 10),
                Text('${m.brand} ${m.name}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                Text(m.info, style: const TextStyle(color: Colors.white60)),
                const SizedBox(height: 14),
                TextField(
                  controller: host,
                  keyboardType: m.family == MixerFamily.tascam
                      ? TextInputType.url
                      : const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: 'Mixer IP address',
                    hintText: m.family == MixerFamily.tascam ? '192.168.1.50 or 192.168.1.50:9000' : '192.168.1.50',
                    border: const OutlineInputBorder(),
                  ),
                  onSubmitted: (_) => connect(),
                ),
                if (_hint(m) case final hint?)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(hint, style: const TextStyle(fontSize: 12, color: Colors.white60)),
                  ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(onPressed: connect, icon: const Icon(Icons.link), label: const Text('Connect')),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Navigator.pop(ctx);
                          onDemo(m);
                        },
                        icon: const Icon(Icons.play_circle_outline),
                        label: const Text('Try demo'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const Text('Your photo', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                const Text(
                  'Show a photo of your own mixer instead of the drawing. It stays on this device.',
                  style: TextStyle(fontSize: 12, color: Colors.white60),
                ),
                const SizedBox(height: 8),
                ValueListenableBuilder<int>(
                  valueListenable: MixerPhotos.changes,
                  builder: (context, _, __) => FutureBuilder(
                    future: MixerPhotos.fileFor(m.id),
                    builder: (context, snap) => Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () => photo(ImageSource.camera),
                          icon: const Icon(Icons.photo_camera_outlined),
                          label: const Text('Take photo'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => photo(ImageSource.gallery),
                          icon: const Icon(Icons.photo_library_outlined),
                          label: const Text('From gallery'),
                        ),
                        if (snap.data != null)
                          TextButton.icon(
                            onPressed: () => MixerPhotos.remove(m.id),
                            icon: const Icon(Icons.delete_outline),
                            label: const Text('Use the drawing'),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

String? _hint(MixerModel m) => switch (m.family) {
      MixerFamily.yamaha => 'Use the console\'s "For Mixer Control" IP address.',
      MixerFamily.allenHeath => 'dLive: the MixRack\'s IP. The app talks MIDI over TCP 51325 on MIDI channel 1.',
      MixerFamily.wing => 'Turn off Setup → Remote → Remote lock on the console.',
      MixerFamily.tascam => 'Ember+ on TCP 9000; add :port if your console uses another one.',
      MixerFamily.presonus => 'Connects like UC Surface (TCP 53000).',
      _ => null,
    };
