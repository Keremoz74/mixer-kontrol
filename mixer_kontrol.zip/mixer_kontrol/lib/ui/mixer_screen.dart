import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_strip.dart';
import 'fx_screen.dart';
import 'help_screen.dart';
import 'recorder_screen.dart';
import 'snapshots_screen.dart';

class MixerScreen extends StatefulWidget {
  const MixerScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MixerScreen> createState() => _MixerScreenState();
}

class _MixerScreenState extends State<MixerScreen> {
  int _tab = 0; // 0 inputs, 1 buses, 2 DCA, 3 matrix (X32)
  SendTarget? _send; // inputs: null = Main LR mix
  SendTarget? _mtxSend; // matrix tab: null = matrix outputs

  /// The "sends on fader" target of the current tab, if any.
  SendTarget? get _activeSend => switch (_tab) {
        0 => _send,
        3 => _mtxSend,
        _ => null,
      };

  /// Tabs that have a Mix picker.
  bool get _hasMixPicker => _tab == 0 || _tab == 3;

  /// Selected bank per tab; -1 = all strips in one scrolling row.
  final Map<int, int> _bankByTab = {};

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    // Full screen: every pixel of height goes to the faders.
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    c.dispose();
    super.dispose();
  }

  String _targetLabel(SendTarget t) {
    final n = c.param(t.master.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n : t.label;
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500; // phone in landscape
    final isTablet = size.shortestSide >= 600;
    final stripW = isTablet ? 86.0 : 66.0;

    final all = switch (_tab) {
      0 => p.inputs,
      1 => p.hasMatrix ? p.mixBuses : p.buses,
      3 => _mtxSend == null ? p.matrices : p.matrixSources,
      _ => p.dcas,
    };
    final banks = makeBanks(all);
    final bankIdx = (_bankByTab[_tab] ?? 0).clamp(-1, banks.length - 1);
    final strips = bankIdx < 0 ? all : banks[bankIdx].strips;
    final active = _activeSend;
    final sendsOn = active != null;
    final pinned = active?.master ?? p.main;

    final stripsArea = Row(
      children: [
        Expanded(
          child: LayoutBuilder(builder: (context, cons) {
            // A bank that fits is spread across the whole width, like a
            // console layer; otherwise strips keep their size and scroll.
            final avail = cons.maxWidth - 8;
            final fitW = avail / strips.length - 4;
            final w = fitW >= stripW ? fitW.clamp(stripW, 130.0) : stripW;
            return ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              itemCount: strips.length,
              itemBuilder: (context, i) => ChannelStrip(
                key: ValueKey('${strips[i].prefix}-$_tab-${active?.mixIndex}'),
                controller: c,
                strip: strips[i],
                sendTarget: active,
                width: w,
                compact: compact,
              ),
            );
          }),
        ),
        Container(width: 1, margin: const EdgeInsets.symmetric(vertical: 8), color: Colors.white12),
        const SizedBox(width: 4),
        ChannelStrip(
          controller: c,
          strip: pinned,
          width: stripW + 10,
          isMaster: true,
          compact: compact,
          highlight: sendsOn ? sendsAccent : AppStyle.mainTeal,
        ),
        const SizedBox(width: 6),
      ],
    );

    return AppBackground(
      child: Scaffold(
        appBar: compact ? null : _appBar(),
        body: SafeArea(
          top: compact,
          child: Column(
            children: [
              if (compact)
                _compactBar(sendsOn, banks, bankIdx)
              else ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
                  child: _tabSelector(dense: false),
                ),
                if (banks.length > 1 || _hasMixPicker)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
                    child: Row(
                      children: [
                        if (banks.length > 1) _bankMenu(banks, bankIdx),
                        const Spacer(),
                        if (_hasMixPicker) _mixMenu(sendsOn),
                      ],
                    ),
                  ),
                if (sendsOn) _sendsBanner(),
              ],
              Expanded(child: stripsArea),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- bars

  PreferredSizeWidget _appBar() {
    return AppBar(
      toolbarHeight: 48,
      title: ListenableBuilder(
        listenable: c,
        builder: (context, _) => Text(
          '${c.mixerName} · ${c.profile.model}',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
      ),
      actions: [
        ListenableBuilder(listenable: c, builder: (context, _) => _StatusChip(controller: c)),
        IconButton(tooltip: 'FX Rack', icon: const Icon(Icons.auto_awesome), onPressed: _openFx),
        IconButton(tooltip: 'Snapshots', icon: const Icon(Icons.bookmarks_outlined), onPressed: _openSnapshots),
        IconButton(tooltip: 'Recorder', icon: const Icon(Icons.fiber_manual_record_outlined), onPressed: _openRecorder),
        if (!c.isDemo)
          IconButton(tooltip: 'Resync', icon: const Icon(Icons.sync), onPressed: c.refreshAll),
        IconButton(tooltip: 'User guide', icon: const Icon(Icons.info_outline), onPressed: () => openHelp(context)),
        const SizedBox(width: 4),
      ],
    );
  }

  void _openFx() => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => FxScreen(controller: c)),
      );

  void _openSnapshots() => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => SnapshotsScreen(controller: c)),
      );

  void _openRecorder() => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => RecorderScreen(controller: c)),
      );

  /// Landscape: FX, snapshots and resync share one menu to save width.
  Widget _moreMenu() {
    return PopupMenuButton<String>(
      tooltip: 'More',
      icon: const Icon(Icons.more_vert),
      onSelected: (v) {
        switch (v) {
          case 'fx':
            _openFx();
          case 'snap':
            _openSnapshots();
          case 'rec':
            _openRecorder();
          case 'sync':
            c.refreshAll();
          case 'help':
            openHelp(context);
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'fx',
          child: ListTile(leading: Icon(Icons.auto_awesome), title: Text('FX Rack'), dense: true),
        ),
        const PopupMenuItem(
          value: 'snap',
          child: ListTile(leading: Icon(Icons.bookmarks_outlined), title: Text('Snapshots'), dense: true),
        ),
        const PopupMenuItem(
          value: 'rec',
          child: ListTile(leading: Icon(Icons.fiber_manual_record_outlined), title: Text('Recorder'), dense: true),
        ),
        if (!c.isDemo)
          const PopupMenuItem(
            value: 'sync',
            child: ListTile(leading: Icon(Icons.sync), title: Text('Resync'), dense: true),
          ),
        const PopupMenuItem(
          value: 'help',
          child: ListTile(leading: Icon(Icons.info_outline), title: Text('User guide'), dense: true),
        ),
      ],
    );
  }

  /// Landscape phone: everything on one 44 px row.
  Widget _compactBar(bool sendsOn, List<StripBank> banks, int bankIdx) {
    return SizedBox(
      height: 46,
      child: Row(
        children: [
          IconButton(
            tooltip: 'Disconnect',
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          // The middle scrolls sideways if it ever doesn't fit (narrow phones,
          // camera notches), so the ⋮ menu on the right is always on screen.
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 150),
                    child: ListenableBuilder(
                      listenable: c,
                      builder: (context, _) => Text(
                        '${c.mixerName} · ${c.profile.model}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _tabSelector(dense: true),
                  if (banks.length > 1) ...[
                    const SizedBox(width: 8),
                    _bankMenu(banks, bankIdx),
                  ],
                  if (_hasMixPicker) ...[
                    const SizedBox(width: 8),
                    _mixMenu(sendsOn),
                  ],
                  const SizedBox(width: 8),
                  ListenableBuilder(
                    listenable: c,
                    builder: (context, _) => _StatusChip(controller: c, dotOnly: true),
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ),
          ),
          _moreMenu(),
        ],
      ),
    );
  }

  Widget _tabSelector({required bool dense}) {
    return SegmentedButton<int>(
      showSelectedIcon: false,
      style: dense
          ? const ButtonStyle(
              visualDensity: VisualDensity(horizontal: -2, vertical: -3),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            )
          : null,
      // Landscape: icons only (with tooltips) to save width.
      segments: [
        ButtonSegment(
          value: 0,
          tooltip: 'Inputs',
          label: dense ? null : const Text('Inputs'),
          icon: const Icon(Icons.mic),
        ),
        ButtonSegment(
          value: 1,
          tooltip: 'Buses',
          label: dense ? null : const Text('Buses'),
          icon: const Icon(Icons.call_split),
        ),
        if (c.profile.hasMatrix)
          ButtonSegment(
            value: 3,
            tooltip: 'Matrix',
            label: dense ? null : const Text('Matrix'),
            icon: const Icon(Icons.grid_view),
          ),
        ButtonSegment(
          value: 2,
          tooltip: 'DCA',
          label: dense ? null : const Text('DCA'),
          icon: const Icon(Icons.tune),
        ),
      ],
      selected: {_tab},
      onSelectionChanged: (s) => setState(() => _tab = s.first),
    );
  }

  void _selectBank(int i) => setState(() => _bankByTab[_tab] = i);

  /// Landscape: bank picker as a compact drop-down ("1-8 ▾").
  Widget _bankMenu(List<StripBank> banks, int bankIdx) {
    final label = bankIdx < 0 ? 'All' : banks[bankIdx].label;
    return PopupMenuButton<int>(
      tooltip: 'Channel bank',
      initialValue: bankIdx,
      onSelected: _selectBank,
      itemBuilder: (context) => [
        for (var i = 0; i < banks.length; i++) PopupMenuItem(value: i, child: Text(banks[i].label)),
        const PopupMenuDivider(),
        const PopupMenuItem(value: -1, child: Text('All (scroll)')),
      ],
      child: _pill(label, Icons.view_column_outlined, AppStyle.glowBlue, highlighted: true),
    );
  }

  Widget _pill(String text, IconData? icon, Color color, {required bool highlighted}) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(17),
        color: highlighted ? color.withValues(alpha: 0.18) : Colors.white.withValues(alpha: 0.06),
        border: Border.all(color: highlighted ? color.withValues(alpha: 0.8) : Colors.white24),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 16, color: highlighted ? color : Colors.white70),
            const SizedBox(width: 6),
          ],
          Text(
            text,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: highlighted ? color : Colors.white,
            ),
          ),
          Icon(Icons.arrow_drop_down, color: highlighted ? color : Colors.white70),
        ],
      ),
    );
  }

  /// "Mix: Main LR ▾" pill; opens a tidy grid of all mixes.
  Widget _mixMenu(bool sendsOn) {
    final a = _activeSend;
    final label = a != null ? _targetLabel(a) : (_tab == 3 ? 'Matrix outputs' : 'Main LR');
    return GestureDetector(
      onTap: _openMixSheet,
      child: _pill(
        'Mix: $label',
        Icons.call_split,
        sendsOn ? sendsAccent : AppStyle.mainTeal,
        highlighted: true,
      ),
    );
  }

  /// Grid of mix targets: Main LR, then buses (and FX sends on XR), each tile
  /// in the bus's own colour with its name.
  Future<void> _openMixSheet() async {
    final picked = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (context) {
        final matrix = _tab == 3;
        final targets = matrix ? c.profile.matrixTargets : c.profile.sendTargets;
        final current = _activeSend;
        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  matrix ? 'Bus and Main LR faders send to' : 'Faders control',
                  style: const TextStyle(fontSize: 13, color: Colors.white60, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _mixTile(
                      label: matrix ? 'Matrix outputs' : 'Main LR',
                      sub: matrix ? 'Matrix 1-${targets.length} faders' : 'Main mix',
                      color: AppStyle.mainTeal,
                      selected: current == null,
                      isHome: true,
                      onTap: () => Navigator.pop(context, 0),
                    ),
                    for (final t in targets)
                      _mixTile(
                        label: _targetLabel(t),
                        sub: _targetLabel(t) != t.label
                            ? t.label
                            : (matrix
                                ? 'Delay / zone / feed'
                                : (t.master.type == StripType.fxSend ? 'FX send' : 'Monitor / aux mix')),
                        color: stripColor(c.param(t.master.colorAddr).value),
                        selected: current?.mixIndex == t.mixIndex,
                        onTap: () => Navigator.pop(context, t.mixIndex),
                      ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (_tab == 3) {
        _mtxSend = picked == 0 ? null : c.profile.matrixTargets.firstWhere((t) => t.mixIndex == picked);
      } else {
        _send = picked == 0 ? null : c.profile.sendTargets.firstWhere((t) => t.mixIndex == picked);
      }
    });
  }

  Widget _mixTile({
    required String label,
    required String sub,
    required Color color,
    required bool selected,
    required VoidCallback onTap,
    bool isHome = false,
  }) {
    final accent = selected ? (isHome ? AppStyle.mainTeal : sendsAccent) : color;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 104,
        height: 58,
        padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? accent.withValues(alpha: 0.22) : Colors.white.withValues(alpha: 0.05),
          border: Border.all(
            color: selected ? accent : Colors.white.withValues(alpha: 0.10),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 4,
              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: selected ? accent : Colors.white,
                    ),
                  ),
                  Text(sub, maxLines: 1, style: const TextStyle(fontSize: 11, color: Colors.white54)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sendsBanner() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
      padding: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: sendsAccent.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        'Faders show sends to ${_targetLabel(_activeSend!)}',
        textAlign: TextAlign.center,
        style: const TextStyle(color: sendsAccent, fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }

}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.controller, this.dotOnly = false});
  final MixerController controller;

  /// Landscape: just the glowing dot (the text is in its tooltip).
  final bool dotOnly;

  @override
  Widget build(BuildContext context) {
    final (text, color) = controller.isDemo
        ? ('Demo', const Color(0xFF8B5CF6))
        : controller.state == ConnState.connected
            ? ('Connected', const Color(0xFF3DD68C))
            : ('Offline', AppStyle.muteRed);
    if (dotOnly) {
      return Tooltip(
        message: text,
        child: Container(
          width: 12,
          height: 12,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: color, blurRadius: 8)],
          ),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color, blurRadius: 6)],
            ),
          ),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
        ],
      ),
    );
  }
}
