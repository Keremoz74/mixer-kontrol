import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'channel_strip.dart';

class MixerScreen extends StatefulWidget {
  const MixerScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MixerScreen> createState() => _MixerScreenState();
}

class _MixerScreenState extends State<MixerScreen> {
  int _tab = 0; // 0 inputs, 1 buses, 2 DCA
  SendTarget? _send; // null = Main LR mix

  MixerController get c => widget.controller;

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final scheme = Theme.of(context).colorScheme;
    final isTablet = MediaQuery.sizeOf(context).shortestSide >= 600;
    final stripW = isTablet ? 84.0 : 66.0;

    final strips = switch (_tab) {
      0 => p.inputs,
      1 => p.buses,
      _ => p.dcas,
    };
    final sendsOn = _send != null && _tab == 0;
    final pinned = sendsOn ? _send!.master : p.main;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 48,
        title: ListenableBuilder(
          listenable: c,
          builder: (context, _) => Text(
            '${c.mixerName} · ${p.model}',
            style: const TextStyle(fontSize: 16),
          ),
        ),
        actions: [
          ListenableBuilder(listenable: c, builder: (context, _) => _StatusChip(controller: c)),
          if (!c.isDemo)
            IconButton(
              tooltip: 'Yeniden senkronize et',
              icon: const Icon(Icons.sync),
              onPressed: c.refreshAll,
            ),
          IconButton(
            tooltip: 'Bağlantıyı kes',
            icon: const Icon(Icons.logout),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
              child: SegmentedButton<int>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 0, label: Text('Girişler'), icon: Icon(Icons.mic)),
                  ButtonSegment(value: 1, label: Text('Buslar'), icon: Icon(Icons.call_split)),
                  ButtonSegment(value: 2, label: Text('DCA'), icon: Icon(Icons.tune)),
                ],
                selected: {_tab},
                onSelectionChanged: (s) => setState(() => _tab = s.first),
              ),
            ),
            if (_tab == 0) _mixSelector(scheme),
            if (sendsOn)
              Container(
                width: double.infinity,
                color: sendsAccent.withValues(alpha: 0.15),
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(
                  'Faderlar ${_send!.label} gönderimlerini gösteriyor',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: sendsAccent, fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      itemCount: strips.length,
                      itemBuilder: (context, i) => ChannelStrip(
                        key: ValueKey('${strips[i].prefix}-${_send?.mixIndex}'),
                        controller: c,
                        strip: strips[i],
                        sendTarget: sendsOn ? _send : null,
                        width: stripW,
                      ),
                    ),
                  ),
                  const VerticalDivider(width: 1),
                  ChannelStrip(
                    controller: c,
                    strip: pinned,
                    width: stripW + 10,
                    isMaster: true,
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// "Sends on fader": pick Main LR or a bus; input faders then control that mix.
  Widget _mixSelector(ColorScheme scheme) {
    final targets = c.profile.sendTargets;
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: ChoiceChip(
              label: const Text('Ana LR'),
              selected: _send == null,
              onSelected: (_) => setState(() => _send = null),
            ),
          ),
          for (final t in targets)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ListenableBuilder(
                listenable: c.param(t.master.nameAddr),
                builder: (context, _) {
                  final n = c.param(t.master.nameAddr).value;
                  final label = n is String && n.trim().isNotEmpty ? n : t.label;
                  final selected = _send?.mixIndex == t.mixIndex;
                  return ChoiceChip(
                    label: Text(label),
                    selected: selected,
                    selectedColor: sendsAccent.withValues(alpha: 0.35),
                    onSelected: (_) => setState(() => _send = selected ? null : t),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.controller});
  final MixerController controller;

  @override
  Widget build(BuildContext context) {
    final (text, color) = controller.isDemo
        ? ('Demo', Colors.blueGrey)
        : controller.state == ConnState.connected
            ? ('Bağlı', const Color(0xFF46A758))
            : ('Bağlantı yok', const Color(0xFFE5484D));
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 10, color: color),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
