import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../midi/midi_control.dart';
import '../mixer/mixer_profile.dart';
import '../mixer/user_layers.dart';
import 'app_style.dart';
import 'assign_sheet.dart';
import 'channel_strip.dart';
import 'feedback_screen.dart';
import 'fx_bus_screen.dart';
import 'fx_screen.dart';
import 'help_screen.dart';
import 'layers_screen.dart';
import 'meters_screen.dart';
import 'midi_screen.dart';
import 'personal_autostart.dart';
import 'personal_screen.dart';
import 'routing_screen.dart';
import 'recorder_screen.dart';
import 'snapshots_screen.dart';

class MixerScreen extends StatefulWidget {
  const MixerScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MixerScreen> createState() => _MixerScreenState();
}

class _MixerScreenState extends State<MixerScreen> {
  int _tab = 0; // 0 inputs, 1 buses, 2 DCA, 3 matrix (X32)
  SendTarget? _send; // inputs: null = Main LR mix
  SendTarget? _mtxSend; // matrix tab: null = matrix outputs
  int? _spill; // DCA tab: DCA whose members are shown
  List<UserLayer> _layers = []; // tab 4
  MidiControl? _midi;

  Future<void> _loadLayers() async {
    final l = await UserLayerStore.load(c.profile.family);
    if (mounted) setState(() => _layers = l);
  }

  /// The "sends on fader" target of the current tab, if any.
  SendTarget? get _activeSend => switch (_tab) {
        0 => _send,
        3 => _mtxSend,
        _ => null,
      };

  /// Tabs that have a Mix picker.
  bool get _hasMixPicker => _tab == 0 || _tab == 3;

  /// Selected bank per tab; -1 = all strips in one scrolling row.
  final Map<int, int> _bankByTab = {};

  /// Strips per bank: 8, 16, or 0 = full screen (a whole group squeezed to
  /// the screen width). Kept between sessions.
  int _bankSize = 8;

  /// Menu values of the bank-size choices (bank indexes are >= -1).
  static const _sizeItems = {-108: 8, -116: 16, -100: 0};

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    // Full screen: every pixel of height goes to the faders.
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SharedPreferences.getInstance().then((p) {
      if (mounted && p.getBool('mute_lock') == true) c.muteLock.value = true;
      final bs = p.getInt('bank_size');
      if (mounted && bs != null && (bs == 8 || bs == 16 || bs == 0)) setState(() => _bankSize = bs);
    }).catchError((_) {});
    _loadLayers();
  }

  void _toggleMuteLock() {
    final v = !c.muteLock.value;
    c.muteLock.value = v;
    SharedPreferences.getInstance().then((p) => p.setBool('mute_lock', v)).catchError((_) => false);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(v ? 'Mute lock ON: mute buttons are locked.' : 'Mute lock OFF.'),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  Widget _muteLockButton() => ValueListenableBuilder<bool>(
        valueListenable: c.muteLock,
        builder: (context, locked, _) => IconButton(
          tooltip: locked ? 'Mute lock on (tap to unlock)' : 'Mute lock off (tap to lock)',
          onPressed: _toggleMuteLock,
          icon: Icon(locked ? Icons.lock : Icons.lock_open, color: locked ? AppStyle.muteRed : null),
        ),
      );

  Widget _monitorButton() {
    final p = c.profile;
    return ListenableBuilder(
      listenable: Listenable.merge([
        c.param(MixerProfile.soloAnyAddr),
        for (final st in p.allStrips)
          if (p.soloAddr(st) != null) c.param(p.soloAddr(st)!),
      ]),
      builder: (context, _) {
        final any = c.anySolo;
        return IconButton(
          tooltip: any ? 'Solo active: monitor & clear solo' : 'Monitor & solo',
          onPressed: () => showMonitorSheet(context, c),
          icon: Icon(Icons.headphones, color: any ? soloYellow : null),
          style: any ? IconButton.styleFrom(backgroundColor: soloYellow.withValues(alpha: 0.18)) : null,
        );
      },
    );
  }

  Future<void> _openSpill(int dca) async {
    await c.queryGroups();
    if (!mounted) return;
    setState(() => _spill = dca);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _midi?.disconnectAll();
    _midi?.dispose();
    c.dispose();
    super.dispose();
  }

  String _targetLabel(SendTarget t) {
    final n = c.param(t.master.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n : t.label;
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500; // phone in landscape
    final isTablet = size.shortestSide >= 600;
    final stripW = isTablet ? 86.0 : 66.0;

    final spill = _tab == 2 ? _spill : null;
    final all = switch (_tab) {
      0 => p.inputs,
      1 => [...p.buses.where((s) => s.type != StripType.matrix), if (p.mono != null) p.mono!],
      3 => _mtxSend == null ? p.matrices : p.matrixSources,
      4 => _layers.isEmpty ? <Strip>[] : _layers.first.stripsIn(p),
      _ => spill != null ? [p.dcas[spill - 1], ...c.dcaMembers(spill)] : p.dcas,
    };
    final banks = _tab == 4
        ? [for (final l in _layers) StripBank(l.name, l.stripsIn(p))]
        : (spill != null ? <StripBank>[StripBank('DCA $spill', all)] : makeBanks(all, size: _bankSize));
    final bankIdx = (_bankByTab[_tab] ?? 0).clamp(-1, banks.length - 1);
    final strips = _tab == 4
        ? (banks.isEmpty ? <Strip>[] : (bankIdx < 0 ? [for (final b in banks) ...b.strips] : banks[bankIdx].strips))
        : (bankIdx < 0 ? all : banks[bankIdx].strips);
    // (also with a single page, so a changed page size can be set back)
    final showBanks = banks.length > 1 || (_tab != 4 && spill == null && _bankSize != 8);
    final active = _activeSend;
    final sendsOn = active != null;
    final pinned = active?.master ?? p.main;

    final stripsArea = Row(
      children: [
        Expanded(
          child: LayoutBuilder(
            builder: (context, cons) {
              // A bank that fits is spread across the whole width, like a
              // console layer; otherwise strips keep their size and scroll.
              // Full screen: every strip of the page on screen, slimmer if
              // need be (down to a still usable width; past that it scrolls).
              final avail = cons.maxWidth - 8;
              var fitW = avail / strips.length - 4;
              if (fitW < 56) fitW += 2; // slim strips have 1 px margins
              // (phones keep strips wide enough for a finger: 16 still fit
              // in landscape, a full page of 32 scrolls)
              final minW = _bankSize != 8 && bankIdx >= 0 ? (isTablet ? 30.0 : 46.0) : stripW;
              final w = fitW >= minW ? fitW.clamp(minW, 130.0) : minW;
              return ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 4),
                itemCount: strips.length,
                itemBuilder: (context, i) => ChannelStrip(
                  key: ValueKey('${strips[i].prefix}-$_tab-${active?.mixIndex}-$spill'),
                  controller: c,
                  strip: strips[i],
                  sendTarget: active,
                  width: w,
                  compact: compact,
                  highlight: spill != null && i == 0 ? AppStyle.glowBlue : null,
                  onSpill: _tab == 2 && spill == null && strips[i].isDca && c.profile.hasGroupMembership
                      ? () => _openSpill(strips[i].index)
                      : null,
                ),
              );
            },
          ),
        ),
        Container(width: 1, margin: const EdgeInsets.symmetric(vertical: 8), color: Colors.white12),
        const SizedBox(width: 4),
        ChannelStrip(
          controller: c,
          strip: pinned,
          width: stripW + 10,
          isMaster: true,
          compact: compact,
          highlight: sendsOn ? sendsAccent : AppStyle.mainTeal,
        ),
        const SizedBox(width: 6),
      ],
    );

    return AppBackground(
      child: Scaffold(
        appBar: compact ? null : _appBar(),
        body: SafeArea(
          top: compact,
          child: Column(
            children: [
              if (compact)
                _compactBar(sendsOn, banks, bankIdx, showBanks)
              else ...[
                Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 6), child: _tabSelector(dense: false)),
                if (showBanks || _hasMixPicker)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
                    child: Row(
                      children: [
                        if (showBanks) _bankMenu(banks, bankIdx),
                        const Spacer(),
                        if (_hasMixPicker) _mixMenu(sendsOn),
                      ],
                    ),
                  ),
                if (sendsOn) _sendsBanner(),
              ],
              if (_tab == 2 && (spill != null || c.profile.muteGroupCount > 0)) _groupBar(spill, compact),
              Expanded(
                child: _tab == 4 && strips.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text(
                              'No layers yet (or this layer is empty).',
                              style: TextStyle(color: Colors.white60),
                            ),
                            const SizedBox(height: 10),
                            FilledButton.icon(
                              onPressed: _openLayers,
                              icon: const Icon(Icons.dashboard_customize),
                              label: const Text('Edit my layers'),
                            ),
                          ],
                        ),
                      )
                    : stripsArea,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- bars

  PreferredSizeWidget _appBar() {
    return AppBar(
      toolbarHeight: 48,
      title: ListenableBuilder(
        listenable: c,
        builder: (context, _) => Text(
          '${c.mixerName} · ${c.profile.model}',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
      ),
      actions: [
        ListenableBuilder(
          listenable: c,
          builder: (context, _) => _StatusChip(controller: c),
        ),
        if (c.profile.hasSolo) _monitorButton(),
        _muteLockButton(),
        // Phones in portrait: the rest goes in the ⋮ menu so the title fits.
        if (MediaQuery.sizeOf(context).width < 700)
          _moreMenu()
        else ...[
          if (c.profile.hasFxPage)
            IconButton(
              tooltip: c.profile.hasFx ? 'FX Rack' : 'FX',
              icon: const Icon(Icons.auto_awesome),
              onPressed: _openFx,
            ),
          IconButton(tooltip: 'Snapshots', icon: const Icon(Icons.bookmarks_outlined), onPressed: _openSnapshots),
          if (c.profile.hasRecorder)
            IconButton(
              tooltip: 'Recorder',
              icon: const Icon(Icons.fiber_manual_record_outlined),
              onPressed: _openRecorder,
            ),
          _moreMenu(),
        ],
        const SizedBox(width: 4),
      ],
    );
  }

  void _push(Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  Future<void> _openLayers() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => LayersScreen(controller: c)));
    await _loadLayers();
  }

  /// Pick a bus, optionally a PIN, then lock the app to that musician's mix.
  Future<void> _enterPersonal() async {
    final targets = c.profile.busTargets;
    final pin = TextEditingController();
    SendTarget? picked;
    // X32: light meters by default (5 updates/s); XR: full, Off frees the most room.
    var meters = c.supportsLightMeters ? MeterRate.light : MeterRate.full;
    var autoStart = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Personal monitor mode'),
          content: SizedBox(
            width: 380,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Hand this device to a musician: they only see and change their own monitor mix.',
                    style: TextStyle(fontSize: 13, color: Colors.white70),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final t in targets)
                        ChoiceChip(
                          label: Text(_targetLabel(t)),
                          selected: picked == t,
                          selectedColor: sendsAccent.withValues(alpha: 0.4),
                          onSelected: (_) => setLocal(() => picked = t),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: pin,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    maxLength: 8,
                    decoration: const InputDecoration(
                      labelText: 'PIN to leave (optional)',
                      helperText: 'Without a PIN, leaving needs a long press on Exit.',
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text('Meters', style: TextStyle(fontSize: 13, color: Colors.white70)),
                  const SizedBox(height: 6),
                  SegmentedButton<MeterRate>(
                    showSelectedIcon: false,
                    segments: [
                      const ButtonSegment(value: MeterRate.full, label: Text('Full')),
                      if (c.supportsLightMeters) const ButtonSegment(value: MeterRate.light, label: Text('Light')),
                      const ButtonSegment(value: MeterRate.off, label: Text('Off')),
                    ],
                    selected: {meters},
                    onSelectionChanged: (v) => setLocal(() => meters = v.first),
                  ),
                  const SizedBox(height: 4),
                  Text(
                      switch (meters) {
                        MeterRate.full => 'Live meters, as on the main console screen.',
                        MeterRate.light =>
                          '5 meter updates a second instead of 20: less Wi-Fi load, room for more musicians.',
                        MeterRate.off =>
                          'No meters: the least Wi-Fi load. Best when many musicians use the mixer\'s own Wi-Fi.',
                      },
                      style: const TextStyle(fontSize: 12, color: Colors.white60)),
                  if (!c.isDemo)
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: autoStart,
                      onChanged: (v) => setLocal(() => autoStart = v),
                      title: const Text('Open this mix when the app starts'),
                      subtitle: const Text(
                        'For a musician\'s own phone or tablet: the app connects and goes straight to this mix.',
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: picked == null ? null : () => Navigator.pop(ctx, true), child: const Text('Start')),
          ],
        ),
      ),
    );
    if (ok != true || picked == null || !mounted) return;
    final digits = pin.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (autoStart && !c.isDemo) {
      final n = c.param(picked!.master.nameAddr).value;
      await PersonalAutoStart(
        host: c.host,
        family: c.profile.family,
        model: c.profile.model,
        mixIndex: picked!.mixIndex,
        label: n is String && n.trim().isNotEmpty ? n.trim() : picked!.label,
        pin: digits.isEmpty ? null : digits,
        meters: meters,
      ).save();
    }
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            PersonalScreen(controller: c, target: picked!, pin: digits.isEmpty ? null : digits, meterRate: meters),
      ),
    );
  }

  void _openFx() => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => c.profile.hasFx ? FxScreen(controller: c) : FxBusScreen(controller: c),
        ),
      );

  void _openSnapshots() => Navigator.push(context, MaterialPageRoute(builder: (_) => SnapshotsScreen(controller: c)));

  void _openRecorder() => Navigator.push(context, MaterialPageRoute(builder: (_) => RecorderScreen(controller: c)));

  /// Landscape: FX, snapshots and resync share one menu to save width.
  Widget _moreMenu() {
    return PopupMenuButton<String>(
      tooltip: 'More',
      icon: const Icon(Icons.more_vert),
      onSelected: (v) {
        switch (v) {
          case 'fx':
            _openFx();
          case 'fxbus':
            _push(FxBusScreen(controller: c));
          case 'snap':
            _openSnapshots();
          case 'rec':
            _openRecorder();
          case 'sync':
            c.refreshAll();
          case 'help':
            openHelp(context);
          case 'meters':
            _push(MetersScreen(controller: c));
          case 'feedback':
            _push(FeedbackScreen(controller: c));
          case 'personal':
            _enterPersonal();
          case 'layers':
            _openLayers();
          case 'midi':
            _push(MidiScreen(midi: _midi ??= MidiControl(c)));
          case 'routing':
            _push(RoutingScreen(controller: c));
          case 'talk':
            _push(RoutingScreen(controller: c, initialTab: 2));
          case 'automix':
            _push(RoutingScreen(controller: c, initialTab: c.profile.family == MixerFamily.x32 ? 3 : 2));
        }
      },
      itemBuilder: (context) => [
        if (c.profile.hasFxPage)
          PopupMenuItem(
            value: 'fx',
            child: ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: Text(c.profile.hasFx ? 'FX Rack' : 'FX'),
              dense: true,
            ),
          ),
        const PopupMenuItem(
          value: 'snap',
          child: ListTile(leading: Icon(Icons.bookmarks_outlined), title: Text('Snapshots'), dense: true),
        ),
        if (c.profile.hasFx)
          const PopupMenuItem(
            value: 'fxbus',
            child: ListTile(leading: Icon(Icons.call_split), title: Text('FX sends & returns'), dense: true),
          ),
        if (c.profile.hasRecorder)
          const PopupMenuItem(
            value: 'rec',
            child: ListTile(leading: Icon(Icons.fiber_manual_record_outlined), title: Text('Recorder'), dense: true),
          ),
        const PopupMenuDivider(),
        if (c.profile.hasMeters)
          const PopupMenuItem(
            value: 'meters',
            child: ListTile(leading: Icon(Icons.bar_chart), title: Text('Meters'), dense: true),
          ),
        const PopupMenuItem(
          value: 'personal',
          child: ListTile(leading: Icon(Icons.person_outline), title: Text('Personal monitor mode'), dense: true),
        ),
        const PopupMenuItem(
          value: 'layers',
          child: ListTile(leading: Icon(Icons.dashboard_customize), title: Text('My layers'), dense: true),
        ),
        const PopupMenuItem(
          value: 'midi',
          child: ListTile(leading: Icon(Icons.piano), title: Text('MIDI controller'), dense: true),
        ),
        if (c.profile.hasAnalyzer)
          const PopupMenuItem(
            value: 'feedback',
            child: ListTile(leading: Icon(Icons.hearing), title: Text('Feedback finder'), dense: true),
          ),
        if (c.profile.hasRouting)
          const PopupMenuItem(
            value: 'routing',
            child: ListTile(leading: Icon(Icons.alt_route), title: Text('Routing & outputs'), dense: true),
          ),
        if (c.profile.family == MixerFamily.x32)
          const PopupMenuItem(
            value: 'talk',
            child: ListTile(
              leading: Icon(Icons.record_voice_over_outlined),
              title: Text('Talkback & oscillator'),
              dense: true,
            ),
          ),
        if (c.profile.hasRouting)
          const PopupMenuItem(
            value: 'automix',
            child: ListTile(leading: Icon(Icons.auto_mode), title: Text('Automix'), dense: true),
          ),
        const PopupMenuDivider(),
        if (!c.isDemo)
          const PopupMenuItem(
            value: 'sync',
            child: ListTile(leading: Icon(Icons.sync), title: Text('Resync'), dense: true),
          ),
        const PopupMenuItem(
          value: 'help',
          child: ListTile(leading: Icon(Icons.info_outline), title: Text('User guide'), dense: true),
        ),
      ],
    );
  }

  /// Landscape phone: everything on one 44 px row.
  Widget _compactBar(bool sendsOn, List<StripBank> banks, int bankIdx, bool showBanks) {
    return SizedBox(
      height: 46,
      child: Row(
        children: [
          IconButton(
            tooltip: 'Disconnect',
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          // Everything fits without scrolling: the title shrinks first, then
          // the mix name, so the pills are never cut off at the edge.
          Expanded(
            child: Row(
              children: [
                // the full name, shrunk to fit rather than cut to "Dem…"
                Flexible(
                  flex: 2,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 150),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: ListenableBuilder(
                        listenable: c,
                        builder: (context, _) => Text(
                          '${c.mixerName} · ${c.profile.model}',
                          maxLines: 1,
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                _tabSelector(dense: true),
                if (showBanks) ...[const SizedBox(width: 8), _bankMenu(banks, bankIdx)],
                if (_hasMixPicker) ...[
                  const SizedBox(width: 8),
                  // the mix pill gets the larger share of any spare width
                  Flexible(flex: 3, child: _mixMenu(sendsOn, dense: true)),
                ],
                const SizedBox(width: 8),
                ListenableBuilder(
                  listenable: c,
                  builder: (context, _) => _StatusChip(controller: c, dotOnly: true),
                ),
                const SizedBox(width: 4),
              ],
            ),
          ),
          if (c.profile.hasSolo) _monitorButton(),
          _muteLockButton(),
          _moreMenu(),
        ],
      ),
    );
  }

  /// DCA tab: mute group masters, or the spill banner.
  Widget _groupBar(int? spill, bool compact) {
    if (spill != null) {
      final members = c.dcaMembers(spill);
      return Container(
        margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
        padding: const EdgeInsets.fromLTRB(12, 2, 4, 2),
        decoration: BoxDecoration(
          color: AppStyle.glowBlue.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                members.isEmpty
                    ? 'Nothing is assigned to DCA $spill (long-press a strip → DCA)'
                    : 'DCA $spill spill: ${members.length} strip${members.length == 1 ? '' : 's'}',
                style: const TextStyle(color: AppStyle.glowBlue, fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ),
            TextButton.icon(
              onPressed: () => setState(() => _spill = null),
              icon: const Icon(Icons.close, size: 16),
              label: const Text('Close'),
            ),
          ],
        ),
      );
    }
    final p = c.profile;
    return SizedBox(
      height: compact ? 34 : 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(8, 0, 8, 4),
        children: [
          Center(
            child: Text(
              'Mute groups ',
              style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: 0.6), fontWeight: FontWeight.w600),
            ),
          ),
          for (var g = 1; g <= p.muteGroupCount; g++)
            Padding(
              padding: const EdgeInsets.only(left: 6),
              child: ListenableBuilder(
                listenable: Listenable.merge([c.param(p.muteGroupAddr(g)), c.muteLock]),
                builder: (context, _) {
                  final on = c.flagOf(p.muteGroupAddr(g));
                  return GestureDetector(
                    onTap: () {
                      if (c.muteLock.value) {
                        ScaffoldMessenger.of(context)
                          ..hideCurrentSnackBar()
                          ..showSnackBar(
                            const SnackBar(content: Text('Mute lock is on.'), duration: Duration(seconds: 2)),
                          );
                        return;
                      }
                      c.setFlag(p.muteGroupAddr(g), !on);
                    },
                    child: Container(
                      width: 64,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        color: on ? AppStyle.muteRed : Colors.black.withValues(alpha: 0.35),
                        border: Border.all(color: on ? const Color(0xFFFF8A8F) : Colors.white24),
                        boxShadow:
                            on ? [BoxShadow(color: AppStyle.muteRed.withValues(alpha: 0.5), blurRadius: 8)] : null,
                      ),
                      child: Text(
                        'MUTE $g',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: on ? Colors.white : Colors.white70,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _tabSelector({required bool dense}) {
    // Landscape: icons only (with tooltips) to save width. Portrait: the icon
    // above a one-line label that shrinks to fit (never wraps letter by letter).
    ButtonSegment<int> seg(int value, String text, IconData icon, {String? tooltip}) => ButtonSegment(
          value: value,
          tooltip: tooltip ?? text,
          icon: dense ? Icon(icon) : null,
          label: dense
              ? null
              : FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icon, size: 18),
                      const SizedBox(height: 2),
                      Text(text, maxLines: 1, softWrap: false, style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
        );

    return SegmentedButton<int>(
      showSelectedIcon: false,
      style: dense
          ? const ButtonStyle(
              visualDensity: VisualDensity(horizontal: -2, vertical: -3),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            )
          : const ButtonStyle(
              padding: WidgetStatePropertyAll(EdgeInsets.symmetric(horizontal: 4, vertical: 6)),
              visualDensity: VisualDensity(horizontal: -4, vertical: 0),
            ),
      segments: [
        seg(0, 'Inputs', Icons.mic),
        seg(1, c.profile.busWord, Icons.call_split),
        if (c.profile.hasMatrix) seg(3, 'Matrix', Icons.grid_view),
        seg(2, 'DCA', Icons.tune),
        seg(4, 'Layers', Icons.dashboard_customize, tooltip: 'My layers'),
      ],
      selected: {_tab},
      onSelectionChanged: (s) => setState(() => _tab = s.first),
    );
  }

  void _selectBank(int i) {
    final size = _sizeItems[i];
    if (size == null) {
      setState(() => _bankByTab[_tab] = i);
      return;
    }
    // A new page size: every tab starts again at its first page.
    setState(() {
      _bankSize = size;
      _bankByTab.clear();
    });
    SharedPreferences.getInstance().then((p) => p.setInt('bank_size', size)).catchError((_) => false);
  }

  /// Landscape: bank picker as a compact drop-down ("1-8 ▾").
  Widget _bankMenu(List<StripBank> banks, int bankIdx) {
    final label = bankIdx < 0 ? 'All' : banks[bankIdx].label;
    return PopupMenuButton<int>(
      tooltip: 'Channel bank',
      // (no initialValue: the menu opens below the pill with the page sizes
      // on top; scrolled to the current bank they'd sit off a short screen)
      onSelected: _selectBank,
      itemBuilder: (context) => [
        // the page size first (for this and every other tab), so it is
        // always in reach, also on a short landscape screen
        if (_tab != 4) ...[
          const PopupMenuItem(
            enabled: false,
            height: 26,
            child: Text('STRIPS PER PAGE', style: TextStyle(fontSize: 11, letterSpacing: 0.8)),
          ),
          for (final e in _sizeItems.entries)
            CheckedPopupMenuItem(
              value: e.key,
              height: 40,
              checked: _bankSize == e.value,
              child: Text(e.value == 0 ? 'Full screen' : '${e.value}'),
            ),
          const PopupMenuDivider(),
        ],
        for (var i = 0; i < banks.length; i++)
          PopupMenuItem(value: i, height: 40, child: _bankItem(banks[i].label, i == bankIdx)),
        const PopupMenuDivider(),
        PopupMenuItem(value: -1, height: 40, child: _bankItem('All (scroll)', bankIdx < 0)),
      ],
      child: _pill(label, Icons.view_column_outlined, AppStyle.glowBlue, highlighted: true),
    );
  }

  /// A bank in the menu; the current one in blue and bold.
  Widget _bankItem(String text, bool current) => Text(
        text,
        style: current ? const TextStyle(color: AppStyle.glowBlue, fontWeight: FontWeight.w700) : null,
      );

  Widget _pill(String text, IconData? icon, Color color, {required bool highlighted, bool shrink = false}) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(17),
        color: highlighted ? color.withValues(alpha: 0.18) : Colors.white.withValues(alpha: 0.06),
        border: Border.all(color: highlighted ? color.withValues(alpha: 0.8) : Colors.white24),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 16, color: highlighted ? color : Colors.white70),
            const SizedBox(width: 6),
          ],
          // shrink: the pill sits in a Flexible and its text may be cut short
          if (shrink)
            Flexible(
              child: FittedBox(fit: BoxFit.scaleDown, child: _pillText(text, color, highlighted)),
            )
          else
            _pillText(text, color, highlighted),
          Icon(Icons.arrow_drop_down, color: highlighted ? color : Colors.white70),
        ],
      ),
    );
  }

  Widget _pillText(String text, Color color, bool highlighted) => Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: highlighted ? color : Colors.white),
      );

  /// "Mix: Main LR ▾" pill; opens a tidy grid of all mixes.
  Widget _mixMenu(bool sendsOn, {bool dense = false}) {
    final a = _activeSend;
    final label = a != null ? _targetLabel(a) : (_tab == 3 ? 'Matrix outputs' : 'Main LR');
    return GestureDetector(
      onTap: _openMixSheet,
      child: _pill(
        // landscape: the mix icon says "mix", the pill shows just the name
        dense ? label : 'Mix: $label',
        Icons.call_split,
        sendsOn ? sendsAccent : AppStyle.mainTeal,
        highlighted: true,
        shrink: dense,
      ),
    );
  }

  /// Grid of mix targets: Main LR, then buses (and FX sends on XR), each tile
  /// in the bus's own colour with its name.
  Future<void> _openMixSheet() async {
    final picked = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (context) {
        final matrix = _tab == 3;
        final targets = matrix ? c.profile.matrixTargets : c.profile.sendTargets;
        final current = _activeSend;
        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  matrix ? 'Bus and Main LR faders send to' : 'Faders control',
                  style: const TextStyle(fontSize: 13, color: Colors.white60, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _mixTile(
                      label: matrix ? 'Matrix outputs' : 'Main LR',
                      sub: matrix ? 'Matrix 1-${targets.length} faders' : 'Main mix',
                      color: AppStyle.mainTeal,
                      selected: current == null,
                      isHome: true,
                      onTap: () => Navigator.pop(context, 0),
                    ),
                    for (final t in targets)
                      _mixTile(
                        label: _targetLabel(t),
                        sub: _targetLabel(t) != t.label
                            ? t.label
                            : (matrix
                                ? 'Delay / zone / feed'
                                : (t.master.type == StripType.fxSend ? 'FX send' : 'Monitor / aux mix')),
                        color: stripColor(c.param(t.master.colorAddr).value),
                        selected: current?.mixIndex == t.mixIndex,
                        onTap: () => Navigator.pop(context, t.mixIndex),
                      ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (_tab == 3) {
        _mtxSend = picked == 0 ? null : c.profile.matrixTargets.firstWhere((t) => t.mixIndex == picked);
      } else {
        _send = picked == 0 ? null : c.profile.sendTargets.firstWhere((t) => t.mixIndex == picked);
      }
    });
  }

  Widget _mixTile({
    required String label,
    required String sub,
    required Color color,
    required bool selected,
    required VoidCallback onTap,
    bool isHome = false,
  }) {
    final accent = selected ? (isHome ? AppStyle.mainTeal : sendsAccent) : color;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 104,
        height: 58,
        padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? accent.withValues(alpha: 0.22) : Colors.white.withValues(alpha: 0.05),
          border: Border.all(
            color: selected ? accent : Colors.white.withValues(alpha: 0.10),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 4,
              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: selected ? accent : Colors.white,
                    ),
                  ),
                  Text(sub, maxLines: 1, style: const TextStyle(fontSize: 11, color: Colors.white54)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sendsBanner() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
      padding: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(color: sendsAccent.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(8)),
      child: Text(
        'Faders show sends to ${_targetLabel(_activeSend!)}',
        textAlign: TextAlign.center,
        style: const TextStyle(color: sendsAccent, fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.controller, this.dotOnly = false});
  final MixerController controller;

  /// Landscape: just the glowing dot (the text is in its tooltip).
  final bool dotOnly;

  @override
  Widget build(BuildContext context) {
    final (text, color) = controller.isDemo
        ? ('Demo', const Color(0xFF8B5CF6))
        : controller.state == ConnState.connected
            ? ('Connected', const Color(0xFF3DD68C))
            : ('Offline', AppStyle.muteRed);
    if (dotOnly) {
      return Tooltip(
        message: text,
        child: Container(
          width: 12,
          height: 12,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: color, blurRadius: 8)],
          ),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color, blurRadius: 6)],
            ),
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color),
          ),
        ],
      ),
    );
  }
}
