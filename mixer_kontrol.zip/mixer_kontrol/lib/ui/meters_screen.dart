import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../osc/meters.dart';
import 'app_style.dart';
import 'channel_strip.dart' show stripColor;

/// Every level on one page (like the console's meter bridge), with gate and
/// compressor gain reduction on the input channels.
class MetersScreen extends StatefulWidget {
  const MetersScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MetersScreen> createState() => _MetersScreenState();
}

class _MetersScreenState extends State<MetersScreen> {
  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    c.watchGainReduction();
  }

  @override
  void dispose() {
    c.unwatchGainReduction();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final groups = <(String, List<Strip>)>[
      ('Inputs', [for (final s in p.inputs) if (s.hasMeter) s]),
      ('Buses', [for (final s in p.buses) if (s.hasMeter) s]),
      ('Main', [p.main, if (p.mono != null) p.mono!]),
    ];
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('Meters')),
        body: LayoutBuilder(builder: (context, cons) {
          final cols = cons.maxWidth >= 1000 ? 3 : (cons.maxWidth >= 640 ? 2 : 1);
          return ListView(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
            children: [
              const _Legend(),
              for (final (title, strips) in groups)
                if (strips.isNotEmpty) ...[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 14, 4, 6),
                    child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white70)),
                  ),
                  GridView.count(
                    crossAxisCount: cols,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 4,
                    crossAxisSpacing: 12,
                    childAspectRatio: (cons.maxWidth / cols) / 30,
                    children: [for (final s in strips) _MeterRow(controller: c, strip: s)],
                  ),
                ],
            ],
          );
        }),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) {
    Widget dot(Color col, String t) => Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 4),
          Text(t, style: const TextStyle(fontSize: 11, color: Colors.white60)),
        ]);
    return Wrap(spacing: 14, runSpacing: 4, children: [
      dot(const Color(0xFF3DD68C), 'Level (-60…0 dBFS)'),
      dot(_gateColor, 'Gate reduction'),
      dot(_compColor, 'Compressor reduction'),
    ]);
  }
}

const _gateColor = Color(0xFF5EB1FF);
const _compColor = Color(0xFFFFB224);

class _MeterRow extends StatelessWidget {
  const _MeterRow({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Row(
      children: [
        SizedBox(
          width: 86,
          child: ListenableBuilder(
            listenable: Listenable.merge([c.param(strip.nameAddr), c.param(strip.colorAddr)]),
            builder: (context, _) {
              final n = c.param(strip.nameAddr).value;
              final name = n is String && n.trim().isNotEmpty ? n.trim() : strip.defaultLabel;
              return Row(children: [
                Container(
                  width: 4,
                  height: 16,
                  decoration: BoxDecoration(
                    color: stripColor(c.param(strip.colorAddr).value),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                ),
              ]);
            },
          ),
        ),
        Expanded(
          child: RepaintBoundary(
            child: CustomPaint(
              size: const Size(double.infinity, 22),
              painter: _RowPainter(
                c.meters,
                c.gainReduction,
                strip.prefix,
                hasGr: strip.type == StripType.channel,
                muted: () => !c.isOn(strip.onAddr),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _RowPainter extends CustomPainter {
  _RowPainter(this.levels, this.gr, this.id, {required this.hasGr, required this.muted})
      : super(repaint: Listenable.merge([levels, gr]));

  final MeterLevels levels;
  final MeterLevels gr;
  final String id;
  final bool hasGr;
  final bool Function() muted;

  @override
  void paint(Canvas canvas, Size size) {
    final barH = hasGr ? size.height * 0.55 : size.height * 0.7;
    final top = (size.height - (hasGr ? size.height : barH)) / 2;
    final bg = Paint()..color = Colors.black.withValues(alpha: 0.4);
    final r = RRect.fromRectAndRadius(Rect.fromLTWH(0, top, size.width, barH), const Radius.circular(3));
    canvas.drawRRect(r, bg);
    final db = levels.db(id);
    if (db.isFinite) {
      final f = ((db + 60) / 60).clamp(0.0, 1.0);
      final col = db > -3 ? AppStyle.muteRed : (db > -12 ? const Color(0xFFF5D90A) : const Color(0xFF3DD68C));
      final paint = Paint()..color = muted() ? col.withValues(alpha: 0.35) : col;
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(0, top, size.width * f, barH), const Radius.circular(3)),
        paint,
      );
    }
    // -18 dBFS (nominal) tick
    final tick = Paint()..color = Colors.white30..strokeWidth = 1;
    final x18 = size.width * (42 / 60);
    canvas.drawLine(Offset(x18, top), Offset(x18, top + barH), tick);
    if (!hasGr) return;
    final grTop = top + barH + 2;
    final grH = (size.height - barH - 2) / 2 - 1;
    void grBar(String key, Color col, double y) {
      final v = gr.db(key);
      if (!v.isFinite || v >= -0.3) return;
      final f = (-v / 30).clamp(0.0, 1.0);
      // reduction grows from the right edge to the left, like a console GR meter
      canvas.drawRect(Rect.fromLTWH(size.width * (1 - f), y, size.width * f, grH), Paint()..color = col);
    }

    grBar('$id/gate', _gateColor, grTop);
    grBar('$id/dyn', _compColor, grTop + grH + 1);
  }

  @override
  bool shouldRepaint(_RowPainter old) => old.id != id;
}
