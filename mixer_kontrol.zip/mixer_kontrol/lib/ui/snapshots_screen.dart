import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../mixer/snapshot_store.dart';
import 'app_style.dart';
import 'console_snapshots_tab.dart';

const snapAccent = Color(0xFF5EB1FF);

/// Snapshot library: save the current mix, recall, rename, update, delete.
class SnapshotsScreen extends StatefulWidget {
  const SnapshotsScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<SnapshotsScreen> createState() => _SnapshotsScreenState();
}

class _SnapshotsScreenState extends State<SnapshotsScreen> {
  List<Snapshot> _all = [];
  bool _loading = true;

  /// Non-null while saving or recalling: progress 0..1 and a label.
  double? _progress;
  String _progressLabel = '';

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    SnapshotStore.load().then((list) {
      if (!mounted) return;
      setState(() {
        _all = list..sort((a, b) => b.savedAt.compareTo(a.savedAt));
        _loading = false;
      });
    });
  }

  Future<void> _persist() => SnapshotStore.save(_all);

  // ---------------------------------------------------------------- actions

  Future<Map<String, Object>> _captureCurrent(String label) async {
    setState(() {
      _progress = 0;
      _progressLabel = label;
    });
    await c.syncForSnapshot(onProgress: (p) {
      if (mounted) setState(() => _progress = p);
    });
    final values = c.captureSnapshot();
    if (mounted) setState(() => _progress = null);
    return values;
  }

  Future<void> _saveNew() async {
    final name = await _askName('Save snapshot', 'Snapshot ${_all.length + 1}');
    if (name == null) return;
    final values = await _captureCurrent('Reading the mix…');
    final snap = Snapshot(
      id: SnapshotStore.newId(),
      name: name,
      family: c.profile.family,
      model: c.profile.model,
      savedAt: DateTime.now(),
      values: values,
    );
    setState(() => _all.insert(0, snap));
    await _persist();
    _toast('Saved "${snap.name}"');
  }

  Future<void> _overwrite(Snapshot s) async {
    if (!_compatible(s)) return;
    final ok = await _confirm('Update "${s.name}"?', 'It will be replaced with the current mix.', 'Update');
    if (!ok) return;
    final values = await _captureCurrent('Reading the mix…');
    setState(() {
      s.values = values;
      s.savedAt = DateTime.now();
    });
    await _persist();
    _toast('Updated "${s.name}"');
  }

  Future<void> _recall(Snapshot s) async {
    if (!_compatible(s)) return;
    final ok = await _confirm(
      'Recall "${s.name}"?',
      'Faders, mutes, EQ, dynamics, sends, pan, names and FX will change. '
          'Preamp gain and +48V are not touched.',
      'Recall',
    );
    if (!ok) return;
    setState(() {
      _progress = 0;
      _progressLabel = 'Recalling…';
    });
    await c.recallSnapshot(s.values, onProgress: (p) {
      if (mounted) setState(() => _progress = p);
    });
    if (!mounted) return;
    setState(() => _progress = null);
    _toast('Recalled "${s.name}"');
  }

  Future<void> _rename(Snapshot s) async {
    final name = await _askName('Rename snapshot', s.name);
    if (name == null) return;
    setState(() => s.name = name);
    await _persist();
  }

  Future<void> _delete(Snapshot s) async {
    final ok = await _confirm('Delete "${s.name}"?', 'This cannot be undone.', 'Delete');
    if (!ok) return;
    setState(() => _all.remove(s));
    await _persist();
  }

  bool _compatible(Snapshot s) {
    if (s.family == c.profile.family) return true;
    final other = switch (s.family) {
      MixerFamily.x32 => 'X32 / M32',
      MixerFamily.xr => 'XR / MR',
      MixerFamily.yamaha => 'Yamaha console',
      MixerFamily.allenHeath => 'Allen & Heath console',
    };
    _toast('"${s.name}" was saved on an $other and can only be recalled there.');
    return false;
  }

  // ---------------------------------------------------------------- dialogs

  Future<String?> _askName(String title, String initial) {
    final text = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: text,
          autofocus: true,
          maxLength: 40,
          decoration: const InputDecoration(hintText: 'e.g. Sunday service'),
          onSubmitted: (v) => Navigator.pop(ctx, v.trim().isEmpty ? null : v.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, text.text.trim().isEmpty ? null : text.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirm(String title, String body, String action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(action)),
        ],
      ),
    );
    return ok == true;
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------------------------------------------------------- UI

  @override
  Widget build(BuildContext context) {
    final busy = _progress != null;
    final deviceTab = Stack(
            children: [
              if (_loading)
                const Center(child: CircularProgressIndicator())
              else if (_all.isEmpty)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'No snapshots yet.\nSet up your mix, then tap "Save current mix".',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, height: 1.4),
                    ),
                  ),
                )
              else
                ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
                  itemCount: _all.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) => _tile(_all[i], busy),
                ),
              if (busy)
                Positioned.fill(
                  child: ColoredBox(
                    color: Colors.black54,
                    child: Center(
                      child: Container(
                        width: 260,
                        padding: const EdgeInsets.all(20),
                        decoration: AppStyle.masterPanel(snapAccent),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(_progressLabel, style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 14),
                            LinearProgressIndicator(value: _progress, color: snapAccent),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              if (!busy)
                Positioned(
                  right: 16,
                  bottom: 16,
                  child: FloatingActionButton.extended(
                    heroTag: 'device-save',
                    backgroundColor: snapAccent,
                    foregroundColor: Colors.black,
                    onPressed: _saveNew,
                    icon: const Icon(Icons.save_alt),
                    label: const Text('Save current mix'),
                  ),
                ),
            ],
          );

    // Consoles whose own scene memory the app can't reach yet: device only.
    if (!c.profile.hasConsoleLibrary) {
      return AppBackground(
        child: Scaffold(
          appBar: AppBar(title: const Text('Snapshots')),
          body: SafeArea(top: false, child: deviceTab),
        ),
      );
    }
    return AppBackground(
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Snapshots'),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.graphic_eq), text: 'On mixer'),
                Tab(icon: Icon(Icons.phone_android), text: 'On this device'),
              ],
            ),
          ),
          body: SafeArea(
            top: false,
            child: TabBarView(
              children: [
                ConsoleSnapshotsTab(controller: c),
                deviceTab,
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _tile(Snapshot s, bool busy) {
    final ok = s.family == c.profile.family;
    final d = s.savedAt;
    String two(int n) => n.toString().padLeft(2, '0');
    final when = '${two(d.day)}.${two(d.month)}.${d.year}  ${two(d.hour)}:${two(d.minute)}';
    return Opacity(
      opacity: ok ? 1 : 0.5,
      child: Container(
        decoration: AppStyle.panel(),
        child: ListTile(
          contentPadding: const EdgeInsets.fromLTRB(14, 4, 4, 4),
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: snapAccent.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: snapAccent.withValues(alpha: 0.6)),
            ),
            child: const Icon(Icons.bookmark, color: snapAccent, size: 20),
          ),
          title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${s.model}  ·  $when', style: const TextStyle(fontSize: 12, color: Colors.white60)),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              FilledButton.tonal(
                onPressed: busy || !ok ? null : () => _recall(s),
                child: const Text('Recall'),
              ),
              PopupMenuButton<String>(
                enabled: !busy,
                onSelected: (v) => switch (v) {
                  'update' => _overwrite(s),
                  'rename' => _rename(s),
                  _ => _delete(s),
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(value: 'update', child: Text('Update with current mix')),
                  PopupMenuItem(value: 'rename', child: Text('Rename')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
