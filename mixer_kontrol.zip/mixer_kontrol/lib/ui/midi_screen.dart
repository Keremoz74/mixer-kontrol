import 'package:flutter/material.dart';
import 'package:flutter_midi_command/flutter_midi_command.dart';

import '../midi/midi_control.dart';
import 'app_style.dart';

const midiAccent = Color(0xFFFF7AB6);

/// Connect a USB MIDI controller and map its knobs, faders and buttons.
class MidiScreen extends StatefulWidget {
  const MidiScreen({super.key, required this.midi});
  final MidiControl midi;

  @override
  State<MidiScreen> createState() => _MidiScreenState();
}

class _MidiScreenState extends State<MidiScreen> {
  MidiControl get m => widget.midi;
  List<MidiDevice> _devices = const [];
  bool _scanning = false;
  String _filter = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _scanning = true);
    final d = await m.devices();
    if (!mounted) return;
    setState(() {
      _devices = d;
      _scanning = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('MIDI controller')),
        body: ListenableBuilder(
          listenable: m,
          builder: (context, _) {
            final targets = m.targets
                .where((t) => _filter.isEmpty || t.label.toLowerCase().contains(_filter.toLowerCase()))
                .toList();
            final reverse = {for (final e in m.mappings.entries) e.value: e.key};
            return ListView(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
              children: [
                const Text(
                  'Plug a USB MIDI controller into the tablet / phone (USB-C or an OTG adapter), connect it here, '
                  'then tap Learn on a control below and move a fader or press a button on the controller.',
                  style: TextStyle(fontSize: 13, color: Colors.white70),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Text('Devices', style: TextStyle(fontWeight: FontWeight.w700)),
                    const Spacer(),
                    if (m.connectedName != null)
                      TextButton(onPressed: m.disconnectAll, child: const Text('Disconnect')),
                    IconButton(
                      tooltip: 'Refresh',
                      onPressed: _scanning ? null : _refresh,
                      icon: const Icon(Icons.refresh),
                    ),
                  ],
                ),
                if (m.error != null) Text(m.error!, style: const TextStyle(color: Color(0xFFE5484D))),
                if (_devices.isEmpty)
                  Text(_scanning ? 'Looking…' : 'No MIDI device found.', style: const TextStyle(color: Colors.white54)),
                for (final d in _devices)
                  Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    decoration: AppStyle.panel(),
                    child: ListTile(
                      leading: const Icon(Icons.piano, color: midiAccent),
                      title: Text(d.name),
                      trailing: m.connectedName == d.name
                          ? const Icon(Icons.check_circle, color: midiAccent)
                          : FilledButton(
                              style: FilledButton.styleFrom(backgroundColor: midiAccent, foregroundColor: Colors.black),
                              onPressed: () => m.connect(d),
                              child: const Text('Connect'),
                            ),
                    ),
                  ),
                if (m.lastSource != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('Last received: ${m.lastSource!.label}',
                        style: const TextStyle(fontSize: 12, color: midiAccent)),
                  ),
                if (m.learning != null)
                  Container(
                    margin: const EdgeInsets.only(top: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: AppStyle.masterPanel(midiAccent),
                    child: Row(
                      children: [
                        Expanded(child: Text('Move a control for: ${m.learning!.label}')),
                        TextButton(onPressed: m.cancelLearn, child: const Text('Cancel')),
                      ],
                    ),
                  ),
                const SizedBox(height: 14),
                TextField(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Find a control (e.g. "Ch 3", "mute", "Bus")',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  onChanged: (v) => setState(() => _filter = v),
                ),
                const SizedBox(height: 8),
                for (final t in targets.take(200))
                  ListTile(
                    dense: true,
                    title: Text(t.label),
                    subtitle: reverse[t.id] != null
                        ? Text(MidiSource.fromKey(reverse[t.id]!)?.label ?? '', style: const TextStyle(color: midiAccent))
                        : null,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (reverse[t.id] != null)
                          IconButton(
                            tooltip: 'Remove mapping',
                            onPressed: () => m.unmap(reverse[t.id]!),
                            icon: const Icon(Icons.link_off, size: 20),
                          ),
                        OutlinedButton(
                          onPressed: () => m.startLearn(t),
                          child: Text(m.learning?.id == t.id ? 'Waiting…' : 'Learn'),
                        ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
