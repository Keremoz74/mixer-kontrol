import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import 'app_style.dart';

const consoleAccent = Color(0xFF19D3BD);

/// The mixer's own snapshot (XR) / scene (X32) library, read from the
/// console. Load, save into a slot, rename by re-saving, delete.
class ConsoleSnapshotsTab extends StatefulWidget {
  const ConsoleSnapshotsTab({super.key, required this.controller});
  final MixerController controller;

  @override
  State<ConsoleSnapshotsTab> createState() => _ConsoleSnapshotsTabState();
}

class _ConsoleSnapshotsTabState extends State<ConsoleSnapshotsTab> {
  bool _showEmpty = false;
  bool _busy = false;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() => c.query(c.profile.consoleLibraryAddresses);

  List<Listenable> get _listenables => [
        c.param(c.profile.consoleCurrentAddr),
        for (final i in c.profile.consoleSlots) ...[
          c.param(c.profile.consoleNameAddr(i)),
          if (c.profile.consoleHasDataAddr(i) != null) c.param(c.profile.consoleHasDataAddr(i)!),
        ],
      ];

  // ---------------------------------------------------------------- actions

  Future<void> _load(int slot) async {
    final item = c.profile.consoleItemName.toLowerCase();
    final name = c.consoleSlotName(slot);
    final ok = await _confirm(
      'Load "${name.isEmpty ? '${c.profile.consoleItemName} ${c.profile.consoleSlotLabel(slot)}' : name}"?',
      'The mixer recalls this $item from its own memory. '
          'What changes (including preamp gain and +48V) depends on the $item\'s recall settings on the console.',
      'Load',
    );
    if (!ok) return;
    setState(() => _busy = true);
    await c.consoleLoad(slot);
    if (!mounted) return;
    setState(() => _busy = false);
    _toast('Loaded ${c.profile.consoleItemName.toLowerCase()} ${c.profile.consoleSlotLabel(slot)}');
  }

  Future<void> _save(int slot) async {
    final p = c.profile;
    final used = c.consoleSlotUsed(slot);
    final name = await _askName(
      used ? 'Overwrite ${p.consoleItemName} ${p.consoleSlotLabel(slot)}' : 'Save to ${p.consoleItemName} ${p.consoleSlotLabel(slot)}',
      used ? c.consoleSlotName(slot) : '',
    );
    if (name == null) return;
    c.consoleSave(slot, name);
    _toast('Saved "$name" on the mixer');
  }

  Future<void> _saveToFirstEmpty() async {
    final p = c.profile;
    final free = p.consoleSlots.where((i) => !c.consoleSlotUsed(i)).toList();
    if (free.isEmpty) {
      _toast('All ${p.consoleSlotCount} slots are used. Overwrite one from its menu.');
      return;
    }
    await _save(free.first);
  }

  Future<void> _delete(int slot) async {
    final ok = await _confirm(
      'Delete "${c.consoleSlotName(slot)}" from the mixer?',
      'It is removed from the console\'s memory and cannot be undone.',
      'Delete',
    );
    if (ok) c.consoleDelete(slot);
  }

  // ---------------------------------------------------------------- dialogs

  Future<String?> _askName(String title, String initial) {
    final text = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: text,
          autofocus: true,
          maxLength: 32,
          decoration: const InputDecoration(hintText: 'e.g. Sunday service'),
          onSubmitted: (v) => Navigator.pop(ctx, v.trim().isEmpty ? null : v.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, text.text.trim().isEmpty ? null : text.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirm(String title, String body, String action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(action)),
        ],
      ),
    );
    return ok == true;
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------------------------------------------------------- UI

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    return ListenableBuilder(
      listenable: Listenable.merge(_listenables),
      builder: (context, _) {
        final slots = p.consoleSlots.where((i) => _showEmpty || c.consoleSlotUsed(i)).toList();
        final usedCount = p.consoleSlots.where(c.consoleSlotUsed).length;
        return Stack(
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '$usedCount of ${p.consoleSlotCount} ${p.consoleItemName.toLowerCase()}s on the mixer',
                          style: const TextStyle(color: Colors.white70, fontSize: 13),
                        ),
                      ),
                      FilterChip(
                        label: const Text('Empty slots'),
                        selected: _showEmpty,
                        onSelected: (v) => setState(() => _showEmpty = v),
                      ),
                      IconButton(tooltip: 'Reload from mixer', icon: const Icon(Icons.refresh), onPressed: _refresh),
                    ],
                  ),
                ),
                Expanded(
                  child: slots.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(32),
                            child: Text(
                              c.isDemo
                                  ? 'No ${p.consoleItemName.toLowerCase()}s.'
                                  : 'No ${p.consoleItemName.toLowerCase()}s found on the mixer yet.\n'
                                      'If there should be some, tap ↻ to read them again.',
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white70, height: 1.4),
                            ),
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
                          itemCount: slots.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (context, i) => _tile(slots[i]),
                        ),
                ),
              ],
            ),
            Positioned(
              right: 16,
              bottom: 16,
              child: FloatingActionButton.extended(
                heroTag: 'console-save',
                backgroundColor: consoleAccent,
                foregroundColor: Colors.black,
                onPressed: _busy ? null : _saveToFirstEmpty,
                icon: const Icon(Icons.save_alt),
                label: const Text('Save to mixer'),
              ),
            ),
            if (_busy)
              const Positioned.fill(
                child: ColoredBox(
                  color: Colors.black54,
                  child: Center(child: CircularProgressIndicator()),
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _tile(int slot) {
    final p = c.profile;
    final used = c.consoleSlotUsed(slot);
    final current = c.consoleCurrent == slot && used;
    final name = c.consoleSlotName(slot);
    return Container(
      decoration: current ? AppStyle.masterPanel(consoleAccent) : AppStyle.panel(),
      child: ListTile(
        contentPadding: const EdgeInsets.fromLTRB(12, 2, 4, 2),
        leading: Container(
          width: 44,
          height: 36,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: (used ? consoleAccent : Colors.white24).withValues(alpha: 0.18),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            p.consoleSlotLabel(slot),
            style: TextStyle(fontWeight: FontWeight.w800, color: used ? consoleAccent : Colors.white38),
          ),
        ),
        title: Text(
          used ? (name.isEmpty ? '(no name)' : name) : 'Empty',
          style: TextStyle(
            fontWeight: used ? FontWeight.w700 : FontWeight.w400,
            color: used ? Colors.white : Colors.white38,
          ),
        ),
        subtitle: current ? const Text('Last loaded', style: TextStyle(fontSize: 12, color: consoleAccent)) : null,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (used)
              FilledButton.tonal(onPressed: _busy ? null : () => _load(slot), child: const Text('Load'))
            else
              TextButton(onPressed: _busy ? null : () => _save(slot), child: const Text('Save here')),
            PopupMenuButton<String>(
              enabled: !_busy,
              onSelected: (v) => switch (v) {
                'save' => _save(slot),
                _ => _delete(slot),
              },
              itemBuilder: (context) => [
                PopupMenuItem(value: 'save', child: Text(used ? 'Overwrite with current mix' : 'Save current mix here')),
                if (used) const PopupMenuItem(value: 'delete', child: Text('Delete from mixer')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
