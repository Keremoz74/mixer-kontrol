import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app_version.dart';
import 'app_style.dart';

/// Small in-app user guide, English / Turkish.
void openHelp(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const HelpScreen()));
}

class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key});

  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> {
  static const _prefKey = 'help_lang';
  String _lang = PlatformDispatcher.instance.locale.languageCode == 'tr' ? 'tr' : 'en';

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final v = p.getString(_prefKey);
      if (mounted && (v == 'en' || v == 'tr')) setState(() => _lang = v!);
    }).catchError((_) {});
  }

  void _setLang(String l) {
    setState(() => _lang = l);
    SharedPreferences.getInstance().then((p) => p.setString(_prefKey, l)).catchError((_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final tr = _lang == 'tr';
    final sections = tr ? _tr : _en;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr ? 'Kullanım kılavuzu' : 'User guide'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: SegmentedButton<String>(
              showSelectedIcon: false,
              style: const ButtonStyle(visualDensity: VisualDensity.compact),
              segments: const [
                ButtonSegment(value: 'en', label: Text('EN')),
                ButtonSegment(value: 'tr', label: Text('TR')),
              ],
              selected: {_lang},
              onSelectionChanged: (s) => _setLang(s.first),
            ),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 32),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 4, 4, 12),
                child: Text(
                  tr
                      ? '$appName ile Behringer X32 / M32 ve X Air / MR mikserleri tablet veya telefondan yönetirsiniz. Bir başlığa dokunarak açın.'
                      : '$appName controls Behringer X32 / M32 and X Air / MR mixers from a phone or tablet. Tap a topic to open it.',
                  style: const TextStyle(color: Colors.white70),
                ),
              ),
              for (final s in sections)
                Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: AppStyle.panel(),
                  child: Theme(
                    data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                    child: ExpansionTile(
                      leading: Icon(s.icon, color: AppStyle.glowBlue),
                      title: Text(s.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                      childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                      expandedCrossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (final line in s.lines)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Padding(
                                  padding: EdgeInsets.only(top: 7, right: 8),
                                  child: Icon(Icons.circle, size: 5, color: Colors.white54),
                                ),
                                Expanded(child: Text(line, style: const TextStyle(height: 1.35))),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Text(
                '$appName $appVersion',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.white38),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Section {
  const _Section(this.icon, this.title, this.lines);
  final IconData icon;
  final String title;
  final List<String> lines;
}

const _en = [
  _Section(Icons.wifi, 'Connecting', [
    'Put the phone/tablet on the same Wi-Fi network as the mixer (the mixer\'s own access point or your router).',
    'Mixers found on the network appear on the start screen automatically. Tap one to connect.',
    'Not found? Type the mixer\'s IP address in the Mixer IP address field and connect.',
    'The X32 / M32 demo and XR18 / MR18 demo let you try every screen without a mixer.',
    'Leave the app open on stage: the connection is kept alive in the background every few seconds.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'Yamaha consoles', [
    'TF, DM3, DM7, QL and CL series: choose "Yamaha" on the connect screen and enter the console\'s "For Mixer Control" IP address (the app connects over TCP port 49280). Auto also tries Yamaha last. The app reads how many channels, buses, DCAs and mute groups the console has.',
    'Available: faders, ON / mute, names, colours, pan, meters, CUE, gain and HPF, 4-band EQ, gate and compressor, sends to every AUX / MIX and FX bus (sends on fader, personal monitor mode), matrices, STEREO assign, DCAs and DCA assignment, mute group switches, monitor level, and the console\'s own scenes (recall and store).',
    'FX (top bar or ⋮ → FX): the FX bus masters and FX returns side by side, and every input\'s send to the chosen FX bus as faders. Choose the effect type and its settings on the console. CL, QL and DM7 feed their effect rack from MIX buses and bring it back on input channels: tap ⚙ on the FX page once to pick them (buses named Reverb, Delay, FX… are picked automatically).',
    'Not reachable through Yamaha\'s remote control protocol, so hidden while a Yamaha is connected: effect type and settings, input / output patching, the USB recorder and the spectrum analyser (RTA, feedback finder).',
  ]),
  _Section(Icons.settings_input_composite_outlined, 'Allen & Heath consoles', [
    'SQ, CQ, Qu, dLive and Avantis: choose "Allen & Heath" on the connect screen, pick the console, and enter its IP address (dLive: the MixRack). The app talks MIDI over TCP (port 51325) on MIDI channel 1, the consoles\' default.',
    'Available: faders and mutes of channels, FX returns, mixes / auxes, FX sends, matrices, Main LR and DCAs; sends to every mix and FX bus (sends on fader, personal monitor mode, the FX page); Main LR assign; mute groups; scene recall. Qu: PAFL and channel names. dLive / Avantis: names, colours, preamp gain and +48 V (socket = channel number), HPF and 4-band EQ.',
    'Allen & Heath\'s MIDI protocol has no meters, dynamics, FX editing, routing or scene storing, so those are hidden. SQ: set the console\'s MIDI fader law to "Linear Taper" (the default).',
  ]),
  _Section(Icons.settings_input_component_outlined, 'Behringer WING', [
    'WING, WING Compact and WING Rack: choose "Behringer WING" on the connect screen and enter the console\'s IP address (OSC on UDP 2223; meters on TCP 2222). Auto also tries a WING. Turn off Setup → Remote → Remote lock, or the console ignores changes.',
    'Available: 40 channels, 8 aux inputs, 16 buses, 8 matrices, Main 1 and 16 DCAs with meters; sends; Main assign; preamp gain, +48 V, trim and phase; low cut; 6-band EQ (low, 4 bells, high); gate and compressor; DCA and mute group membership; 8 mute groups; solo; scene recall from the open show.',
    'Effect models and parameters, routing, Mains 2-4 and storing scenes are not shown. The FX page lets you pick the buses that feed your effects.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'TASCAM Sonicview', [
    'Sonicview 16 and 24: choose "TASCAM" on the connect screen and enter the console\'s IP address. The app talks Ember+ on TCP port 9000; if your console uses another port, type IP:port. The first sync browses the console\'s parameter tree and takes a few seconds.',
    'Available: 40 channels, 2 ST IN, 4 FX returns, 22 MIX buses, 4 FX buses, Main and 8 DCAs with meters; sends to every MIX and FX bus; Main assign; analog preamp gain and +48 V (Analog 1-16 / 1-24, assumed to feed channels 1-16 / 1-24), digital trim and phase; HPF; 4-band EQ; gate / expander and compressor; DCA and mute group membership; 8 mute groups; solo; recall of the 128 snapshots.',
    'Not shown: strip colours, effect parameters, routing and storing snapshots.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'PreSonus StudioLive', [
    'StudioLive Series III consoles and racks: choose "PreSonus" on the connect screen and enter the console\'s IP address. The app connects like UC Surface (UCNet, TCP 53000) and reads the console\'s size from it.',
    'Available: every input channel, Aux inputs, FX returns, Aux and FX buses, Main and DCAs with meters; sends; Main assign; preamp gain, +48 V and polarity; high-pass filter; 4-band EQ; gate / expander and compressor; DCA membership; mute groups; solo.',
    'The StudioLive sends EQ and dynamics settings as 0-100 % positions without units, so those knobs show positions rather than exact Hz / dB. Not shown: effect parameters, routing, scenes and projects.',
  ]),
  _Section(Icons.tune, 'Mixer screen', [
    'Tabs at the top: Inputs, Buses, DCA and Matrix (X32/M32 only).',
    'The bank button switches between channel groups (1-8, 9-16 …) or All to scroll everything.',
    'Drag a fader to change the level; double-tap resets it to 0 dB. Tap the button under a fader to mute.',
    'Main LR always stays on the right and is coloured differently so you never confuse it.',
    'The gain knob on each input strip sets the preamp gain. EQ and FX shortcuts open the channel directly at that page.',
    'The top bar (the ⋮ menu in landscape) opens FX Rack, Snapshots, Recorder, Resync and this guide (i).',
  ]),
  _Section(Icons.headphones, 'Monitor mixes (sends on fader)', [
    'Tap the "Main LR ▾" pill and pick a bus: the faders now show how much of each channel goes to that bus (e.g. a musician\'s in-ear mix).',
    'Open the same pill and choose Main LR to go back to the normal faders.',
    'On the X32/M32 the Matrix tab works the same way for matrix outputs.',
  ]),
  _Section(Icons.call_split, 'Bus options: Pre / Post / Group', [
    'Under every bus strip there is a small orange button showing the send point: PRE, POST, GRP …',
    'Tap it to choose where all channels feed the bus from: In, Pre EQ, Post EQ, Pre fader, Post fader or Group.',
    'Pre fader: for monitors / in-ears (channel faders don\'t change the mix). Post fader: for effects and recording. Group: subgroups.',
    'Stereo link joins two neighbouring buses (e.g. Bus 3-4) into one stereo mix; switch it off for two mono mixes.',
    'On the X32/M32 the send point is shared by each bus pair (1-2, 3-4 …).',
    'A single channel can have its own send point: open the channel, Sends tab, and use the small PRE / POST row above each level.',
  ]),
  _Section(Icons.headphones_outlined, 'Solo & monitor', [
    'Every strip has an S button next to MUTE: it sends that strip to the phones / monitor output without touching the main mix.',
    'While anything is soloed the headphone icon at the top turns yellow. Tap it for the monitor level and Clear solo.',
    'The channel page also has a SOLO button at the top.',
  ]),
  _Section(Icons.lock_outline, 'Mute lock', [
    'The lock button at the top locks every MUTE button and mute group in the app, so a stray tap can\'t mute anything during a show.',
    'Tap it again to unlock. The setting is remembered. It only affects this device, not the console.',
  ]),
  _Section(Icons.hub_outlined, 'DCA, mute groups, Main LR & stereo link', [
    'Long-press a strip name → "DCA, mute groups, Main LR, link" (or the hub icon on the channel page).',
    'Pick the DCAs and mute groups the strip belongs to, whether it goes to Main LR, and (X32/M32) to the M/C bus.',
    'Stereo link joins an odd/even pair (Ch 1+2, Bus 3+4 …): the console mirrors the settings and pan becomes balance.',
    'DCA tab: the MUTE 1-6 (X Air: 1-4) buttons switch the mute groups. SPILL under a DCA shows just the strips in that DCA; Close goes back.',
    'X32/M32: the M/C bus is on the Buses tab. Its LR+M / LCR button sets the mode.',
  ]),
  _Section(Icons.graphic_eq, 'RTA, meters, graphic EQ & feedback finder', [
    'Channel / bus page, EQ tab: switch RTA on to see the live spectrum behind the EQ curve. On the X32 this also selects that strip on the console (its analyser follows the selection).',
    '⋮ → Meters: every level on one page, with gate (blue) and compressor (orange) gain reduction on the input channels. The Dynamics tab also shows GR live.',
    'FX Rack: a slot holding a Graphic EQ or TruEQ shows 31 band faders; RTA shows the strip the EQ is inserted on. Flat resets all bands.',
    '⋮ → Feedback finder: pick an output, raise it slowly until it rings, then tap Cut on the frequency shown. It notches a free band of that output\'s EQ (3 dB per tap, Q 8). Undo is available.',
  ]),
  _Section(Icons.alt_route, 'Routing, outputs, talkback & automix', [
    '⋮ → Routing & outputs. Inputs: which source feeds each channel (and on the X32 the input blocks: local, AES50, card).',
    'Outputs: what each output carries and its tap point, including P16 / Ultranet personal monitors and (XR) the USB channels to the computer. X32 local outputs have a delay for speaker alignment (ms and metres).',
    'Routing changes are live: make a snapshot first. Snapshots never store routing.',
    'X32 / M32: Talkback A/B (hold TALK, choose who hears you) and the oscillator (sine / pink / white noise; turn the level down before switching it on).',
    'Automix: put speech mics in group X or Y and switch the group on (X32: channels 1-8, firmware 4+).',
  ]),
  _Section(Icons.person_outline, 'Personal monitor mode', [
    '⋮ → Personal monitor mode: pick the musician\'s bus (and an optional PIN), then hand over the device.',
    'They only see their own mix: each fader is how much of a channel they hear, OFF switches that channel out of their mix. Nothing else on the console can be changed.',
    'To leave: press and hold Exit (and enter the PIN if one was set).',
    'Meters: Full shows live meters. Light (X32/M32) sends 5 meter updates a second instead of 20. Off sends none. Light or Off leaves more Wi-Fi room when several musicians use their phones, especially on the mixer\'s own Wi-Fi.',
    'Open this mix when the app starts: for a musician\'s own phone or tablet. From then on the app connects by itself and goes straight to their mix; if the mixer is not on yet, it keeps trying. Turn it off when leaving the mode, or with the × on the connect screen (PIN needed if one was set).',
  ]),
  _Section(Icons.dashboard_customize, 'My layers', [
    '⋮ → My layers: build fader layers from any strips (e.g. "Vocals": Ch 1-4 + FX 1). Tap strips in the order you want them.',
    'They appear in the Layers tab; the bank button switches between them. Layers are saved on this device.',
  ]),
  _Section(Icons.piano, 'MIDI controller', [
    '⋮ → MIDI controller: plug a USB MIDI controller into the device (USB-C or an OTG adapter) and tap Connect.',
    'Tap Learn next to a fader, mute, solo or mute group, then move a fader / knob or press a button on the controller.',
    'Faders follow CC values; buttons (notes or CCs) toggle. Mute lock also blocks MIDI mutes.',
  ]),
  _Section(Icons.flight, 'Preparing a show offline', [
    'Open the X32 / M32 demo or XR18 / MR18 demo on the start screen and set up the mix as you like.',
    'Snapshots → Save current mix. At the venue, connect to the real mixer, open Snapshots and Recall it.',
    'Snapshots never change preamp gain, +48V or routing, so they are safe to recall on a different stage box.',
  ]),
  _Section(Icons.sd_card_outlined, 'X-LIVE card (X32 / M32)', [
    'Recorder → X-LIVE card: record, pause, play and stop the multitrack SD card recorder, with elapsed and remaining time.',
    'Sessions, card selection and track routing stay on the console.',
  ]),
  _Section(Icons.equalizer, 'Channel page', [
    'Tap a channel name or the EQ shortcut to open it.',
    'EQ: drag a point to change frequency and gain, pinch with two fingers to change Q (width). Presets give a quick starting point.',
    'Input: phase, trim, low cut, +48V phantom power and gain.',
    'Dynamics: gate and compressor with threshold, ratio, attack and release.',
    'Sends: every bus and FX send of this channel on one page.',
    'Insert: put an FX slot in the channel (e.g. a de-esser or a tube compressor).',
  ]),
  _Section(Icons.copy_all, 'Copy, paste, name & colour', [
    'Long-press a channel name to open its actions.',
    'Copy a channel, then paste its EQ, dynamics, sends etc. onto other channels. You choose which parts; undo is available.',
    'Copy several: pick any number of channels from any page. Long-press the channel to paste from: each copied channel goes onto the next one in order, or choose a target for each (◀ ▶ moves them all).',
    'Rename a channel and pick its colour from the same menu. Gain and +48V are never copied.',
  ]),
  _Section(Icons.auto_awesome, 'FX Rack', [
    'Shows the mixer\'s effect slots. Tap a slot to change the effect type and its parameters.',
    'FX sends: set how much of each channel goes to each effect.',
  ]),
  _Section(Icons.bookmarks_outlined, 'Snapshots', [
    'Save current mix stores the whole mix on the device; Recall brings it back.',
    'On mixer: save to and load from the mixer\'s own scene / snapshot library.',
    'Before removing or reinstalling the app, save your mixes to the mixer (On mixer → Save).',
  ]),
  _Section(Icons.fiber_manual_record_outlined, 'Recorder', [
    'Control the mixer\'s USB recorder (X32 / XR18 with USB) — record, stop and play.',
    'Or record on the tablet itself through a USB audio connection.',
  ]),
  _Section(Icons.health_and_safety_outlined, 'Tips for safe use', [
    'Turn speaker volume down before turning +48V on or off.',
    'Before a show, make a snapshot of the working mix so you can return to it.',
    'Keep the device charging and its screen from locking during a show.',
    'The app only talks to the mixer on your local network; it sends nothing to the internet.',
  ]),
];

const _tr = [
  _Section(Icons.wifi, 'Bağlanma', [
    'Telefonu/tableti mikserle aynı Wi-Fi ağına bağlayın (mikserin kendi erişim noktası veya modeminiz).',
    'Ağdaki mikserler açılış ekranında kendiliğinden görünür. Bağlanmak için birine dokunun.',
    'Bulunamadı mı? Mikserin IP adresini Mixer IP address alanına yazıp bağlanın.',
    'X32 / M32 demo ve XR18 / MR18 demo ile mikser olmadan tüm ekranları deneyebilirsiniz.',
    'Sahnede uygulamayı açık bırakın: bağlantı birkaç saniyede bir arka planda canlı tutulur.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'Yamaha mikserler', [
    'TF, DM3, DM7, QL ve CL serisi: bağlantı ekranında "Yamaha"yı seçin ve mikserin "For Mixer Control" IP adresini girin (uygulama TCP 49280 portundan bağlanır). Auto seçeneği de en son Yamaha\'yı dener. Uygulama mikserdeki kanal, bus, DCA ve mute grubu sayısını kendisi okur.',
    'Kullanılabilenler: fader, ON / mute, isim, renk, pan, metreler, CUE, gain ve HPF, 4 bant EQ, gate ve kompresör, tüm AUX / MIX ve FX bus send\'leri (sends on fader, kişisel monitör modu), matrix\'ler, STEREO ataması, DCA\'lar ve DCA ataması, mute grubu düğmeleri, monitör seviyesi ve mikserin kendi sahneleri (çağırma ve kaydetme).',
    'FX (üst çubuk veya ⋮ → FX): FX bus master\'ları ve FX return\'ler yan yana, altta da her kanalın seçilen FX bus\'ına send\'i fader olarak. Efekt türünü ve ayarlarını mikserden seçin. CL, QL ve DM7 efekt rack\'ini MIX bus\'larından besler ve dönüşü giriş kanallarına alır: FX sayfasında ⚙ ile bunları bir kez seçin (adı Reverb, Delay, FX… olanlar kendiliğinden seçilir).',
    'Yamaha\'nın uzaktan kontrol protokolünde bulunmadığı için Yamaha bağlıyken gizlenenler: efekt türü ve ayarları, giriş / çıkış patch\'i, USB kayıt cihazı ve spektrum analizörü (RTA, feedback bulucu).',
  ]),
  _Section(Icons.settings_input_composite_outlined, 'Allen & Heath mikserler', [
    'SQ, CQ, Qu, dLive ve Avantis: bağlantı ekranında "Allen & Heath"i seçin, mikseri seçin ve IP adresini girin (dLive: MixRack). Uygulama TCP üzerinden MIDI ile (port 51325), mikserlerin varsayılanı olan MIDI kanal 1\'de konuşur.',
    'Kullanılabilenler: kanal, FX return, mix / aux, FX send, matrix, Main LR ve DCA fader\'ları ve mute\'ları; tüm mix ve FX bus send\'leri (sends on fader, kişisel monitör modu, FX sayfası); Main LR ataması; mute grupları; sahne çağırma. Qu: PAFL ve kanal isimleri. dLive / Avantis: isim, renk, preamp gain ve +48 V (soket = kanal numarası), HPF ve 4 bant EQ.',
    'Allen & Heath\'ın MIDI protokolünde metre, dinamik, FX düzenleme, routing ve sahne kaydetme olmadığı için bunlar gizlenir. SQ: mikserin MIDI fader law ayarı "Linear Taper" (varsayılan) olmalı.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'Behringer WING', [
    'WING, WING Compact ve WING Rack: bağlantı ekranında "Behringer WING"i seçin ve mikserin IP adresini girin (OSC: UDP 2223; metreler: TCP 2222). Auto seçeneği de WING\'i dener. Mikserde Setup → Remote → Remote lock kapalı olmalı, yoksa değişiklikler yok sayılır.',
    'Kullanılabilenler: metreleriyle 40 kanal, 8 aux giriş, 16 bus, 8 matrix, Main 1 ve 16 DCA; send\'ler; Main ataması; preamp gain, +48 V, trim ve faz; low cut; 6 bant EQ (low, 4 bell, high); gate ve kompresör; DCA ve mute grubu üyeliği; 8 mute grubu; solo; açık show\'dan sahne çağırma.',
    'Efekt modelleri ve parametreleri, routing, Main 2-4 ve sahne kaydetme gösterilmez. FX sayfasında efektlerinizi besleyen bus\'ları seçebilirsiniz.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'TASCAM Sonicview', [
    'Sonicview 16 ve 24: bağlantı ekranında "TASCAM"ı seçin ve mikserin IP adresini girin. Uygulama TCP 9000 portunda Ember+ ile konuşur; mikseriniz başka port kullanıyorsa IP:port yazın. İlk eşitleme mikserin parametre ağacını taradığı için birkaç saniye sürer.',
    'Kullanılabilenler: metreleriyle 40 kanal, 2 ST IN, 4 FX return, 22 MIX bus, 4 FX bus, Main ve 8 DCA; tüm MIX ve FX bus send\'leri; Main ataması; analog preamp gain ve +48 V (Analog 1-16 / 1-24, kanal 1-16 / 1-24\'ü beslediği varsayılır), dijital trim ve faz; HPF; 4 bant EQ; gate / expander ve kompresör; DCA ve mute grubu üyeliği; 8 mute grubu; solo; 128 snapshot\'ı çağırma.',
    'Gösterilmeyenler: kanal renkleri, efekt parametreleri, routing ve snapshot kaydetme.',
  ]),
  _Section(Icons.settings_input_component_outlined, 'PreSonus StudioLive', [
    'StudioLive Series III mikserler ve rack\'ler: bağlantı ekranında "PreSonus"u seçin ve mikserin IP adresini girin. Uygulama UC Surface gibi bağlanır (UCNet, TCP 53000) ve mikserin boyutlarını kendisi okur.',
    'Kullanılabilenler: metreleriyle tüm giriş kanalları, Aux girişleri, FX return\'ler, Aux ve FX bus\'lar, Main ve DCA\'lar; send\'ler; Main ataması; preamp gain, +48 V ve polarite; high-pass filtre; 4 bant EQ; gate / expander ve kompresör; DCA üyeliği; mute grupları; solo.',
    'StudioLive EQ ve dinamik ayarlarını birimsiz %0-100 konum olarak gönderir; bu düğmeler tam Hz / dB yerine konumu gösterir. Gösterilmeyenler: efekt parametreleri, routing, sahneler ve projeler.',
  ]),
  _Section(Icons.tune, 'Mikser ekranı', [
    'Üstteki sekmeler: Inputs (girişler), Buses, DCA ve Matrix (sadece X32/M32).',
    'Bank düğmesi kanal grupları arasında geçer (1-8, 9-16 …) veya All ile hepsi kaydırılarak görünür.',
    'Seviyeyi değiştirmek için fader\'ı sürükleyin; çift dokunuş 0 dB\'ye döndürür. Fader\'ın altındaki düğme mute yapar.',
    'Main LR her zaman sağda durur ve farklı renktedir, karıştırmazsınız.',
    'Giriş kanallarındaki gain düğmesi preamp kazancını ayarlar. EQ ve FX kısayolları kanalı doğrudan o sayfada açar.',
    'Üst çubuk (yatayda ⋮ menüsü) FX Rack, Snapshots, Recorder, Resync ve bu kılavuzu (i) açar.',
  ]),
  _Section(Icons.headphones, 'Monitör mixleri (sends on fader)', [
    '"Main LR ▾" düğmesine dokunup bir bus seçin: fader\'lar artık her kanalın o bus\'a ne kadar gittiğini gösterir (örn. bir müzisyenin kulak içi mixi).',
    'Normal fader\'lara dönmek için aynı düğmeden Main LR\'yi seçin.',
    'X32/M32\'de Matrix sekmesi matrix çıkışları için aynı şekilde çalışır.',
  ]),
  _Section(Icons.call_split, 'Bus seçenekleri: Pre / Post / Group', [
    'Her bus kanalının altında gönderim noktasını gösteren küçük turuncu bir düğme vardır: PRE, POST, GRP …',
    'Dokunarak tüm kanalların bus\'a nereden gideceğini seçin: In, Pre EQ, Post EQ, Pre fader, Post fader veya Group.',
    'Pre fader: monitör / kulak içi için (kanal fader\'ları mixi değiştirmez). Post fader: efekt ve kayıt için. Group: alt gruplar için.',
    'Stereo link komşu iki bus\'ı (örn. Bus 3-4) tek bir stereo mix yapar; kapatırsanız iki ayrı mono mix olur.',
    'X32/M32\'de gönderim noktası her bus çifti için ortaktır (1-2, 3-4 …).',
    'Tek bir kanala ayrı gönderim noktası verebilirsiniz: kanalı açın, Sends sekmesinde her seviyenin üstündeki küçük PRE / POST satırını kullanın.',
  ]),
  _Section(Icons.headphones_outlined, 'Solo ve monitör', [
    'Her kanalda MUTE\'un yanında bir S düğmesi var: o kanalı ana mixi değiştirmeden kulaklık / monitör çıkışında dinletir.',
    'Bir şey solo\'dayken üstteki kulaklık simgesi sarı yanar. Dokunarak monitör seviyesini ayarlayın veya Clear solo ile hepsini kapatın.',
    'Kanal sayfasının üstünde de SOLO düğmesi vardır.',
  ]),
  _Section(Icons.lock_outline, 'Mute kilidi', [
    'Üstteki kilit düğmesi uygulamadaki tüm MUTE düğmelerini ve mute gruplarını kilitler; gösteri sırasında yanlış dokunuş bir şeyi kapatamaz.',
    'Açmak için tekrar dokunun. Ayar hatırlanır. Sadece bu cihazı etkiler, mikseri değil.',
  ]),
  _Section(Icons.hub_outlined, 'DCA, mute grupları, Main LR ve stereo link', [
    'Kanal adına uzun basın → "DCA, mute groups, Main LR, link" (veya kanal sayfasındaki hub simgesi).',
    'Kanalın hangi DCA\'lara ve mute gruplarına ait olduğunu, Main LR\'ye (X32/M32\'de M/C bus\'a da) gidip gitmeyeceğini seçin.',
    'Stereo link tek/çift bir çifti birleştirir (Ch 1+2, Bus 3+4 …): mikser ayarları eşler, pan balance olur.',
    'DCA sekmesi: MUTE 1-6 (X Air\'de 1-4) düğmeleri mute gruplarını açıp kapatır. DCA altındaki SPILL sadece o DCA\'daki kanalları gösterir; Close ile geri dönersiniz.',
    'X32/M32: M/C bus Buses sekmesindedir. Üzerindeki LR+M / LCR düğmesi modu seçer.',
  ]),
  _Section(Icons.graphic_eq, 'RTA, metreler, grafik EQ ve feedback bulucu', [
    'Kanal / bus sayfası, EQ sekmesi: RTA\'yı açınca EQ eğrisinin arkasında canlı spektrum görünür. X32\'de bu, kanalı mikserde de seçer (analizör seçili kanalı izler).',
    '⋮ → Meters: tüm seviyeler tek sayfada; giriş kanallarında gate (mavi) ve kompresör (turuncu) kazanç azaltması. Dynamics sekmesi de GR\'yi canlı gösterir.',
    'FX Rack: Graphic EQ veya TruEQ yüklü bir slotta 31 bant fader\'ı çıkar; RTA, EQ\'nun insert edildiği kanalı gösterir. Flat tüm bantları sıfırlar.',
    '⋮ → Feedback finder: bir çıkış seçin, çınlayana kadar yavaşça açın, gösterilen frekansta Cut\'a dokunun. O çıkışın EQ\'sundaki boş bir bantla dar bir kesim yapar (dokunuş başına 3 dB, Q 8). Geri alma vardır.',
  ]),
  _Section(Icons.alt_route, 'Routing, çıkışlar, talkback ve automix', [
    '⋮ → Routing & outputs. Inputs: her kanalı hangi kaynağın beslediği (X32\'de ayrıca giriş blokları: local, AES50, kart).',
    'Outputs: her çıkışın neyi taşıdığı ve alım noktası; P16 / Ultranet kişisel monitörler ve (XR) bilgisayara giden USB kanalları dahil. X32 local çıkışlarında hoparlör hizalaması için delay vardır (ms ve metre).',
    'Routing değişiklikleri anında uygulanır: önce snapshot alın. Snapshot\'lar routing\'i hiç kaydetmez.',
    'X32 / M32: Talkback A/B (TALK\'a basılı tutun, kimin duyacağını seçin) ve osilatör (sinüs / pembe / beyaz gürültü; açmadan önce seviyeyi kısın).',
    'Automix: konuşma mikrofonlarını X veya Y grubuna koyup grubu açın (X32: kanal 1-8, firmware 4+).',
  ]),
  _Section(Icons.person_outline, 'Kişisel monitör modu', [
    '⋮ → Personal monitor mode: müzisyenin bus\'ını (ve isterseniz bir PIN) seçin, sonra cihazı verin.',
    'Sadece kendi mixini görür: her fader o kanalı ne kadar duyduğudur, OFF o kanalı mixinden çıkarır. Mikserdeki başka hiçbir şey değiştirilemez.',
    'Çıkmak için: Exit\'e basılı tutun (PIN varsa girin).',
    'Metreler: Full canlı metreleri gösterir. Light (X32/M32) saniyede 20 yerine 5 metre güncellemesi gönderir. Off hiç metre göndermez. Light veya Off, birkaç müzisyen telefonunu kullanırken (özellikle mikserin kendi Wi-Fi\'ında) daha fazla yer açar.',
    'Uygulama açılınca bu mixi aç: müzisyenin kendi telefonu veya tableti için. Bundan sonra uygulama kendi kendine bağlanır ve doğrudan onun mixini açar; mikser henüz açık değilse denemeye devam eder. Moddan çıkarken ya da bağlantı ekranındaki × ile kapatılır (PIN varsa sorulur).',
  ]),
  _Section(Icons.dashboard_customize, 'Kendi katmanlarım (My layers)', [
    '⋮ → My layers: istediğiniz kanallardan fader katmanları oluşturun (örn. "Vokaller": Ch 1-4 + FX 1). Kanallara istediğiniz sırayla dokunun.',
    'Layers sekmesinde görünürler; bank düğmesi aralarında geçiş yapar. Katmanlar bu cihazda saklanır.',
  ]),
  _Section(Icons.piano, 'MIDI kontrolcü', [
    '⋮ → MIDI controller: USB MIDI kontrolcüyü cihaza takın (USB-C veya OTG adaptörü) ve Connect\'e dokunun.',
    'Bir fader, mute, solo veya mute grubunun yanındaki Learn\'e dokunup kontrolcüde bir fader / düğme oynatın.',
    'Fader\'lar CC değerini izler; düğmeler (nota veya CC) aç/kapa yapar. Mute kilidi MIDI mute\'larını da engeller.',
  ]),
  _Section(Icons.flight, 'Gösteriyi önceden hazırlama (çevrimdışı)', [
    'Açılış ekranında X32 / M32 demo veya XR18 / MR18 demo\'yu açıp mixi istediğiniz gibi kurun.',
    'Snapshots → Save current mix. Mekânda gerçek miksere bağlanın, Snapshots\'ı açıp Recall\'a dokunun.',
    'Snapshot\'lar preamp gain, +48V ve routing\'i asla değiştirmez; farklı bir stage box\'ta da güvenle geri çağrılır.',
  ]),
  _Section(Icons.sd_card_outlined, 'X-LIVE kart (X32 / M32)', [
    'Recorder → X-LIVE card: çok kanallı SD kart kaydını başlatın, duraklatın, çalın ve durdurun; geçen ve kalan süreyle.',
    'Session, kart seçimi ve kanal yönlendirmesi mikserde ayarlanır.',
  ]),
  _Section(Icons.equalizer, 'Kanal sayfası', [
    'Açmak için kanal adına veya EQ kısayoluna dokunun.',
    'EQ: noktayı sürükleyerek frekans ve kazancı, iki parmakla sıkıştırarak Q\'yu (genişlik) değiştirin. Hazır ayarlar hızlı bir başlangıç verir.',
    'Input: faz, trim, low cut, +48V fantom besleme ve gain.',
    'Dynamics: threshold, ratio, attack ve release ile gate ve kompresör.',
    'Sends: bu kanalın tüm bus ve FX gönderimleri tek sayfada.',
    'Insert: kanala bir FX slotu ekleyin (örn. de-esser veya tüp kompresör).',
  ]),
  _Section(Icons.copy_all, 'Kopyala, yapıştır, ad ve renk', [
    'Kanal işlemlerini açmak için kanal adına uzun basın.',
    'Bir kanalı kopyalayın, sonra EQ, dinamik, gönderim vb. ayarlarını diğer kanallara yapıştırın. Hangi bölümlerin gideceğini siz seçersiniz; geri alma vardır.',
    'Aynı menüden kanalın adını ve rengini değiştirin. Gain ve +48V asla kopyalanmaz.',
  ]),
  _Section(Icons.auto_awesome, 'FX Rack', [
    'Mikserin efekt slotlarını gösterir. Efekt türünü ve parametrelerini değiştirmek için bir slota dokunun.',
    'FX sends: her kanalın her efekte ne kadar gideceğini ayarlayın.',
  ]),
  _Section(Icons.bookmarks_outlined, 'Snapshots (kayıtlı mixler)', [
    'Save current mix tüm mixi cihaza kaydeder; Recall geri getirir.',
    'On mixer: mikserin kendi sahne / snapshot kütüphanesine kaydedin ve oradan yükleyin.',
    'Uygulamayı silmeden veya yeniden kurmadan önce mixlerinizi miksere kaydedin (On mixer → Save).',
  ]),
  _Section(Icons.fiber_manual_record_outlined, 'Kayıt (Recorder)', [
    'Mikserin USB kaydedicisini yönetin (X32 / USB\'li XR18) — kayıt, durdur ve çal.',
    'Ya da USB ses bağlantısı ile doğrudan tablete kayıt alın.',
  ]),
  _Section(Icons.health_and_safety_outlined, 'Güvenli kullanım ipuçları', [
    '+48V\'u açıp kapatmadan önce hoparlör seviyesini kısın.',
    'Gösteriden önce çalışan mixin bir snapshot\'ını alın, gerekirse geri dönersiniz.',
    'Gösteri sırasında cihazı şarjda tutun ve ekran kilidini kapatın.',
    'Uygulama yalnızca yerel ağınızdaki mikserle konuşur; internete hiçbir şey göndermez.',
  ]),
];
