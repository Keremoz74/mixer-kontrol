import 'package:flutter/material.dart';

import '../mixer/inserts.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'fx_screen.dart';
import 'param_controls.dart';

/// "Plugin" slot of a channel / bus: insert one of the console's own effects.
class InsertPanel extends StatefulWidget {
  const InsertPanel({super.key, required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  State<InsertPanel> createState() => _InsertPanelState();
}

class _InsertPanelState extends State<InsertPanel> {
  MixerController get c => widget.controller;
  Strip get s => widget.strip;
  MixerProfile get p => c.profile;

  @override
  void initState() {
    super.initState();
    c.query(p.insertAddresses);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([for (final a in p.insertAddresses) c.param(a)]),
      builder: (context, _) {
        final selV = c.param(p.insertSelAddr(s)).value;
        final sel = selV is num ? selV.toInt() : null;
        final slot = sel == null ? null : p.insertSlot(sel);
        final uses = slotUses(c);
        final type = slot == null ? null : uses[slot]?.type;
        return ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
          children: [
            SectionCard(
              title: 'Insert (plugin)',
              trailing: ParamToggle(controller: c, addr: p.insertOnAddr(s), label: 'On', activeColor: fxAccent),
              children: [
                const Text(
                  'Uses one of the mixer\'s own effects on this channel, like a plugin.',
                  style: TextStyle(fontSize: 12, color: Colors.white60),
                ),
                if (p.insertPosAddr(s) != null) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Text('Position  '),
                      Expanded(
                        child: ParamChoice(
                        controller: c,
                        addr: p.insertPosAddr(s)!,
                        labels: const ['Pre (before EQ)', 'Post'],
                        color: fxAccent,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
            if (sel == null)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('Reading…', style: TextStyle(color: Colors.white60))),
              )
            else if (sel == 0)
              _empty()
            else if (slot == null)
              _card(
                title: p.insertLabel(sel),
                subtitle: 'External insert through an aux output / input.',
                actions: [
                  OutlinedButton(onPressed: () => removeInsert(c, s), child: const Text('Remove')),
                ],
              )
            else
              _card(
                title: type?.name ?? 'Effect',
                subtitle: '${p.insertLabel(sel)}'
                    '${dualFxCodes.contains(type?.code) ? '  ·  dual effect: this channel uses side ${p.sideName(p.insertSide(sel))}' : ''}',
                actions: [
                  FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: fxAccent, foregroundColor: Colors.black),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => FxScreen(controller: c, initialSlot: slot)),
                    ),
                    icon: const Icon(Icons.tune),
                    label: const Text('Edit'),
                  ),
                  OutlinedButton(onPressed: _addPlugin, child: const Text('Change')),
                  TextButton(onPressed: () => removeInsert(c, s), child: const Text('Remove')),
                ],
              ),
          ],
        );
      },
    );
  }

  Widget _empty() => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Column(
          children: [
            const Icon(Icons.extension_outlined, size: 40, color: Colors.white38),
            const SizedBox(height: 8),
            const Text('No plugin on this channel', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: fxAccent, foregroundColor: Colors.black),
              onPressed: _addPlugin,
              icon: const Icon(Icons.add),
              label: const Text('Add plugin'),
            ),
          ],
        ),
      );

  Widget _card({required String title, required String subtitle, required List<Widget> actions}) => Container(
        margin: const EdgeInsets.only(top: 4),
        padding: const EdgeInsets.all(14),
        decoration: AppStyle.masterPanel(fxAccent),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.extension, color: fxAccent),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white70)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: actions),
          ],
        ),
      );

  // ---------------------------------------------------------------- add flow

  Future<void> _addPlugin() async {
    final plugin = await showModalBottomSheet<PluginDef>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        builder: (context, scroll) => ListView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            Text('Add plugin', style: Theme.of(context).textTheme.titleMedium),
            for (final g in pluginGroups) ...[
              Padding(
                padding: const EdgeInsets.only(top: 14, bottom: 6),
                child: Text(g, style: const TextStyle(fontSize: 12, color: Colors.white60, fontWeight: FontWeight.w700)),
              ),
              for (final pl in pluginCatalog.where((x) => x.goodFor.contains(g)))
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.extension, color: fxAccent),
                  title: Text(pl.name),
                  subtitle: Text(pl.blurb, style: const TextStyle(fontSize: 12)),
                  onTap: () => Navigator.pop(context, pl),
                ),
            ],
          ],
        ),
      ),
    );
    if (plugin == null || !mounted) return;

    final options = slotOptions(c, s, plugin);
    if (options.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('No free FX slot can run ${plugin.name} right now. Free one in the FX Rack first.'),
      ));
      return;
    }
    final opt = await showDialog<SlotOption>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text('Where should ${plugin.name} run?'),
        children: [
          for (var i = 0; i < options.length; i++)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, options[i]),
              child: Row(
                children: [
                  Icon(
                    i == 0 ? Icons.star : Icons.circle_outlined,
                    size: 18,
                    color: i == 0 ? fxAccent : Colors.white38,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'FX${options[i].slot} ${p.sideName(options[i].side)}${i == 0 ? '  (suggested)' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          options[i].warning.isEmpty
                              ? (options[i].changesType ? 'Free slot' : 'Shares a slot already running ${plugin.name}')
                              : options[i].warning,
                          style: TextStyle(
                            fontSize: 12,
                            color: options[i].warning.isEmpty ? Colors.white60 : const Color(0xFFF5A524),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
    if (opt == null || !mounted) return;
    await insertPlugin(c, s, plugin, opt);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('${plugin.name} inserted (FX${opt.slot} ${p.sideName(opt.side)})'),
    ));
  }
}
