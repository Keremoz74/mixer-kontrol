import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../util/fader_math.dart';
import 'app_style.dart';
import 'fx_screen.dart';
import 'param_controls.dart';

/// The bus that feeds FX [slot] (1-4), or null if none / not known yet.
///
/// XR: fixed, FX 1-4 are fed by mix sends 07-10.
/// X32: chosen on the console per slot via /fx/N/source (1-16 = MIX 1-16,
/// 0 = slot used as an insert).
SendTarget? fxFeed(MixerController c, int slot) {
  final p = c.profile;
  if (p.family == MixerFamily.xr) {
    for (final t in p.sendTargets) {
      if (t.mixIndex == 6 + slot) return t;
    }
    return null;
  }
  final v = c.param(p.fxSourceAddr(slot)).value;
  if (v is! num) return null;
  final i = v.toInt();
  if (i < 1 || i > p.sendTargets.length) return null;
  return p.sendTargets[i - 1];
}

/// Quick FX sends for one channel: one row per effect (FX 1-4) with the
/// effect's name, on/off and send level.
Future<void> showFxSendsSheet(BuildContext context, MixerController c, Strip strip) {
  final p = c.profile;
  if (p.isExternal) {
    final targets = [for (final t in p.sendTargets) if (t.master.type == StripType.fxSend) t];
    c.query([
      for (final t in targets) ...[t.master.nameAddr, strip.sendLevelAddr(t), strip.sendOnAddr(t)],
    ]);
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (context) => _BusFxSendsSheet(controller: c, strip: strip, targets: targets),
    );
  }
  c.query([
    for (var slot = 1; slot <= 4; slot++) p.fxTypeAddr(slot),
    if (p.family == MixerFamily.x32)
      for (var slot = 1; slot <= 4; slot++) p.fxSourceAddr(slot),
    for (final t in p.sendTargets) ...[strip.sendLevelAddr(t), strip.sendOnAddr(t)],
  ]);
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    builder: (context) => _FxSendsSheet(controller: c, strip: strip),
  );
}

class _FxSendsSheet extends StatelessWidget {
  const _FxSendsSheet({required this.controller, required this.strip});
  final MixerController controller;
  final Strip strip;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final p = c.profile;
    final name = c.param(strip.nameAddr).value;
    final title = name is String && name.trim().isNotEmpty ? name : strip.defaultLabel;
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.85),
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          children: [
            Text('$title  ·  FX sends', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            for (var slot = 1; slot <= 4; slot++)
              ListenableBuilder(
                listenable: Listenable.merge([
                  c.param(p.fxTypeAddr(slot)),
                  if (p.family == MixerFamily.x32) c.param(p.fxSourceAddr(slot)),
                ]),
                builder: (context, _) => _row(context, slot),
              ),
            const SizedBox(height: 4),
            OutlinedButton.icon(
              onPressed: () {
                final nav = Navigator.of(context);
                nav.pop();
                nav.push(MaterialPageRoute(builder: (_) => FxScreen(controller: c)));
              },
              icon: const Icon(Icons.auto_awesome),
              label: const Text('Open FX Rack'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(BuildContext context, int slot) {
    final c = controller;
    final p = c.profile;
    final type = fxTypeInSlot(c, slot);
    final feed = fxFeed(c, slot);
    final x32 = p.family == MixerFamily.x32;
    final srcKnown = !x32 || c.param(p.fxSourceAddr(slot)).value is num;
    String sub;
    if (feed != null) {
      final n = c.param(feed.master.nameAddr).value;
      final busName = n is String && n.trim().isNotEmpty ? n : feed.label;
      sub = x32 ? 'via $busName' : '';
    } else {
      sub = srcKnown ? 'Used as an insert, no send' : 'Reading…';
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 0),
      decoration: AppStyle.panel(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: fxAccent.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text('FX $slot', style: const TextStyle(color: fxAccent, fontWeight: FontWeight.w800, fontSize: 12)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(type?.name ?? '—', style: const TextStyle(fontWeight: FontWeight.w700)),
                    if (sub.isNotEmpty) Text(sub, style: const TextStyle(fontSize: 11, color: Colors.white54)),
                  ],
                ),
              ),
              if (feed != null)
                ValueListenableBuilder<Object?>(
                  valueListenable: c.param(strip.sendOnAddr(feed)),
                  builder: (context, v, _) => Switch(
                    value: c.isOn(strip.sendOnAddr(feed)),
                    activeTrackColor: fxAccent,
                    onChanged: (on) => c.setFlag(strip.sendOnAddr(feed), on),
                  ),
                ),
            ],
          ),
          if (feed != null)
            ParamSlider(
              controller: c,
              addr: strip.sendLevelAddr(feed),
              label: 'Send',
              color: fxAccent,
              fallback: 0,
              resetNorm: unityFader,
              format: formatDb,
            )
          else
            const SizedBox(height: 8),
        ],
      ),
    );
  }
}


/// FX sends of one channel on consoles whose effects aren't edited from the
/// app (Yamaha, Allen & Heath): one row per FX bus with on/off and level.
class _BusFxSendsSheet extends StatelessWidget {
  const _BusFxSendsSheet({required this.controller, required this.strip, required this.targets});
  final MixerController controller;
  final Strip strip;
  final List<SendTarget> targets;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final name = c.param(strip.nameAddr).value;
    final title = name is String && name.trim().isNotEmpty ? name : strip.defaultLabel;
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.85),
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          children: [
            Text('$title  ·  FX sends', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            if (targets.isEmpty)
              const Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: Text(
                  'This console feeds its effects from ordinary buses: use the FX page (⋮ → FX) to pick them.',
                  style: TextStyle(color: Colors.white60),
                ),
              ),
            for (final t in targets)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.fromLTRB(12, 8, 8, 0),
                decoration: AppStyle.panel(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: ValueListenableBuilder<Object?>(
                            valueListenable: c.param(t.master.nameAddr),
                            builder: (context, v, _) => Text(
                              v is String && v.trim().isNotEmpty ? v.trim() : t.label,
                              style: const TextStyle(fontWeight: FontWeight.w700, color: fxAccent),
                            ),
                          ),
                        ),
                        ValueListenableBuilder<Object?>(
                          valueListenable: c.param(strip.sendOnAddr(t)),
                          builder: (context, v, _) => Switch(
                            value: c.isOn(strip.sendOnAddr(t)),
                            activeTrackColor: fxAccent,
                            onChanged: (on) => c.setFlag(strip.sendOnAddr(t), on),
                          ),
                        ),
                      ],
                    ),
                    ParamSlider(
                      controller: c,
                      addr: strip.sendLevelAddr(t),
                      label: 'Send',
                      color: fxAccent,
                      fallback: 0,
                      resetNorm: unityFader,
                      format: formatDb,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
