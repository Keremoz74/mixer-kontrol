import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_strip.dart' show sendsAccent;
import 'personal_screen.dart';

/// A personal mix this device opens by itself when the app starts
/// (a musician's phone or tablet that should never show the full console).
class PersonalAutoStart {
  const PersonalAutoStart({
    required this.host,
    required this.family,
    required this.mixIndex,
    required this.label,
    this.pin,
    this.meters = MeterRate.full,
  });

  final String host;
  final MixerFamily family;
  final int mixIndex;
  final String label;
  final String? pin;
  final MeterRate meters;

  static const _key = 'personal_autostart';

  Map<String, Object?> toJson() => {
        'host': host,
        'family': family.name,
        'mix': mixIndex,
        'label': label,
        'pin': pin,
        'meters': meters.name,
      };

  static PersonalAutoStart? fromJson(Map<String, Object?> j) {
    final host = j['host'], fam = j['family'], mix = j['mix'];
    if (host is! String || fam is! String || mix is! int) return null;
    final family = MixerFamily.values.where((f) => f.name == fam).firstOrNull;
    if (family == null || host.trim().isEmpty) return null;
    final pin = j['pin'];
    final meters = MeterRate.values.where((m) => m.name == j['meters']).firstOrNull ?? MeterRate.full;
    final label = j['label'];
    return PersonalAutoStart(
      host: host,
      family: family,
      mixIndex: mix,
      label: label is String ? label : 'Mix $mix',
      pin: pin is String && pin.isNotEmpty ? pin : null,
      meters: meters,
    );
  }

  static Future<PersonalAutoStart?> load() async {
    try {
      final raw = (await SharedPreferences.getInstance()).getString(_key);
      if (raw == null) return null;
      final j = jsonDecode(raw);
      return j is Map<String, Object?> ? fromJson(j) : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setString(_key, jsonEncode(toJson()));

  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);
}

/// Asks for the PIN (if one is set). Returns true when the person may go on.
Future<bool> checkPersonalPin(BuildContext context, String? pin, {String title = 'Enter PIN to leave'}) async {
  if (pin == null || pin.isEmpty) return true;
  final text = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: text,
        autofocus: true,
        obscureText: true,
        keyboardType: TextInputType.number,
        maxLength: 8,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, text.text == pin), child: const Text('OK')),
      ],
    ),
  );
  if (ok == false && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Wrong PIN')));
  }
  return ok == true;
}

/// Shown at app start when a personal mix is set to open by itself: keeps
/// trying to reach the mixer, then opens the musician's mix directly.
class PersonalLaunchScreen extends StatefulWidget {
  const PersonalLaunchScreen({super.key, required this.config});
  final PersonalAutoStart config;

  @override
  State<PersonalLaunchScreen> createState() => _PersonalLaunchScreenState();
}

class _PersonalLaunchScreenState extends State<PersonalLaunchScreen> {
  int _tries = 0;
  bool _stopped = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loop();
  }

  @override
  void dispose() {
    _stopped = true;
    super.dispose();
  }

  Future<void> _loop() async {
    while (!_stopped && mounted) {
      setState(() => _tries++);
      try {
        final c = await MixerController.connect(widget.config.host, family: widget.config.family);
        if (_stopped || !mounted) {
          c.dispose();
          return;
        }
        final target = c.profile.busTargets.where((t) => t.mixIndex == widget.config.mixIndex).firstOrNull;
        if (target == null) {
          c.dispose();
          setState(() => _error = 'This mixer has no ${widget.config.label}. Cancel and set up personal mode again.');
          return;
        }
        await Navigator.pushReplacement(
          context,
          MaterialPageRoute<void>(
            builder: (_) => PersonalScreen(
              controller: c,
              target: target,
              pin: widget.config.pin,
              meterRate: widget.config.meters,
              standalone: true,
            ),
          ),
        );
        return;
      } catch (_) {
        if (!mounted || _stopped) return;
        await Future<void>.delayed(const Duration(seconds: 3));
      }
    }
  }

  Future<void> _cancel() async {
    if (!await checkPersonalPin(context, widget.config.pin, title: 'Enter PIN to cancel')) return;
    _stopped = true;
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: AppBackground(
        child: Scaffold(
          body: SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.headphones, size: 56, color: sendsAccent),
                    const SizedBox(height: 16),
                    Text('My mix: ${widget.config.label}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: sendsAccent)),
                    const SizedBox(height: 12),
                    if (_error != null)
                      Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.orangeAccent))
                    else ...[
                      const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3)),
                      const SizedBox(height: 12),
                      Text(
                        _tries <= 1
                            ? 'Connecting to the mixer at ${widget.config.host}…'
                            : 'Waiting for the mixer at ${widget.config.host}… (try $_tries)\n'
                                'Check that this device is on the mixer\'s Wi-Fi.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                    const SizedBox(height: 24),
                    TextButton.icon(
                      onPressed: _cancel,
                      icon: const Icon(Icons.close),
                      label: const Text('Cancel'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
