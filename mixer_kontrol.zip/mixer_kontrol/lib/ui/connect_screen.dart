import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../ah/ah_layout.dart';
import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../osc/discovery.dart';
import '../app_version.dart';
import 'app_style.dart';
import 'channel_strip.dart' show sendsAccent;
import 'help_screen.dart';
import 'mixer_art.dart';
import 'mixer_screen.dart';
import 'personal_autostart.dart';

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  static const _prefHost = 'last_host';

  final _host = TextEditingController();
  MixerFamily? _family; // null = auto detect
  String _ahModel = 'SQ';
  List<DiscoveredMixer> _found = [];
  bool _scanning = false;
  bool _busy = false;
  PersonalAutoStart? _auto;

  @override
  void initState() {
    super.initState();
    PersonalAutoStart.load().then((a) {
      if (a == null || !mounted) return;
      setState(() => _auto = a);
      _openAuto(a);
    });
    SharedPreferences.getInstance().then((p) {
      final h = p.getString(_prefHost);
      if (h != null && mounted) _host.text = h;
    });
    _scan();
  }

  Future<void> _scan() async {
    setState(() => _scanning = true);
    final list = await MixerDiscovery.scan();
    if (!mounted) return;
    setState(() {
      _found = list;
      _scanning = false;
    });
  }

  Future<void> _connect(String host, MixerFamily? family) async {
    host = host.trim();
    if (host.isEmpty) return;
    setState(() => _busy = true);
    try {
      final c = await MixerController.connect(host, family: family, model: _ahModel);
      (await SharedPreferences.getInstance()).setString(_prefHost, host);
      if (!mounted) {
        c.dispose();
        return;
      }
      await Navigator.push(context, MaterialPageRoute(builder: (_) => MixerScreen(controller: c)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Could not connect: $e\nAre the mixer and this device on the same network?'),
        ));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openAuto(PersonalAutoStart a) => Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => PersonalLaunchScreen(config: a)),
      ).then((_) async {
        // back here: auto-start may have been switched off on the way
        final now = await PersonalAutoStart.load();
        if (mounted) setState(() => _auto = now);
      });

  Future<void> _turnOffAuto(PersonalAutoStart a) async {
    if (!await checkPersonalPin(context, a.pin, title: 'Enter PIN to turn off')) return;
    await PersonalAutoStart.clear();
    if (mounted) setState(() => _auto = null);
  }

  void _demo(MixerFamily f, {String? model}) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MixerScreen(controller: MixerController.demo(f, model: model))),
    );
  }

  /// Yamaha series to try in demo mode (a real console reports its own size).
  static const _yamahaDemos = [
    ('TF5', 'TF series (TF1 / TF3 / TF5 / TF-RACK)', '32 ch · 20 AUX · 8 DCA'),
    ('DM3', 'DM3 / DM3 Standard', '16 ch · 6 MIX · 8 DCA'),
    ('DM7', 'DM7 / DM7 Compact', '72 ch · 48 MIX · 24 DCA'),
    ('QL5', 'QL series (QL1 / QL5)', '64 ch · 16 MIX · 16 DCA'),
    ('CL5', 'CL series (CL1 / CL3 / CL5)', '72 ch · 24 MIX · 16 DCA'),
  ];

  Future<void> _pickAhDemo() async {
    final model = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text('Allen & Heath demo', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              ),
              for (final (label, id) in AhLayout.models)
                ListTile(leading: const Icon(Icons.tune), title: Text(label), onTap: () => Navigator.pop(ctx, id)),
            ],
          ),
        ),
      ),
    );
    if (model != null && mounted) _demo(MixerFamily.allenHeath, model: model);
  }

  Future<void> _pickYamahaDemo() async {
    final model = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 4),
                child: Text('Yamaha demo', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text(
                  'Sizes are typical for each series; a connected console reports its own.',
                  style: TextStyle(fontSize: 12, color: Colors.white60),
                ),
              ),
              for (final (m, title, sub) in _yamahaDemos)
                ListTile(
                  leading: const Icon(Icons.tune),
                  title: Text(title),
                  subtitle: Text(sub),
                  onTap: () => Navigator.pop(ctx, m),
                ),
            ],
          ),
        ),
      ),
    );
    if (model != null && mounted) _demo(MixerFamily.yamaha, model: model);
  }

  @override
  Widget build(BuildContext context) => AppBackground(child: _page(context));

  Widget _page(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      floatingActionButton: FloatingActionButton.small(
        tooltip: 'User guide',
        heroTag: 'help',
        backgroundColor: const Color(0xFF1C2333),
        foregroundColor: Colors.white70,
        onPressed: () => openHelp(context),
        child: const Icon(Icons.info_outline),
      ),
      appBar: AppBar(
        toolbarHeight: 72,
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset('assets/logo.png', width: 44, height: 44),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(appName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                Text(appTagline, style: TextStyle(fontSize: 12, color: Colors.white60)),
              ],
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
                children: [
                  if (_auto case final a?)
                    Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: ListTile(
                        leading: const Icon(Icons.headphones, color: sendsAccent),
                        title: Text('Personal mix at start: ${a.label}'),
                        subtitle: Text('${a.host} · opens by itself when the app starts'),
                        trailing: Wrap(
                          spacing: 4,
                          children: [
                            IconButton(
                              tooltip: 'Turn off',
                              icon: const Icon(Icons.close),
                              onPressed: () => _turnOffAuto(a),
                            ),
                            IconButton(
                              tooltip: 'Open',
                              icon: const Icon(Icons.play_arrow),
                              onPressed: () => _openAuto(a),
                            ),
                          ],
                        ),
                      ),
                    ),
                  Row(
                    children: [
                      Expanded(child: Text('Mixers on the network', style: t.titleMedium)),
                      if (_scanning)
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      else
                        IconButton(onPressed: _scan, icon: const Icon(Icons.refresh), tooltip: 'Search again'),
                    ],
                  ),
                  if (!_scanning && _found.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('No mixer found. You can connect by IP address below.'),
                    ),
                  for (final m in _found)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _MixerCard(
                        family: MixerProfile.familyFromModel(m.model) ?? MixerFamily.xr,
                        title: m.name,
                        subtitle: '${m.model}  ·  ${m.ip}  ·  FW ${m.firmware}',
                        onTap: () => _connect(m.ip, MixerProfile.familyFromModel(m.model)),
                      ),
                    ),
                  const SizedBox(height: 24),
                  Text('Connect by IP', style: t.titleMedium),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _host,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Mixer IP address',
                      hintText: '192.168.1.50',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (v) => _connect(v, _family),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final (f, label) in const [
                        (null, 'Auto'),
                        (MixerFamily.x32, 'X32 / M32'),
                        (MixerFamily.xr, 'XR / MR'),
                        (MixerFamily.yamaha, 'Yamaha'),
                        (MixerFamily.allenHeath, 'Allen & Heath'),
                        (MixerFamily.wing, 'Behringer WING'),
                        (MixerFamily.tascam, 'TASCAM'),
                      ])
                        ChoiceChip(
                          label: Text(label),
                          selected: _family == f,
                          onSelected: (_) => setState(() => _family = f),
                        ),
                    ],
                  ),
                  if (_family == MixerFamily.yamaha)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'Yamaha TF, DM3, DM7, QL, CL. Use the console\'s "For Mixer Control" IP address.',
                        style: TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                    ),
                  if (_family == MixerFamily.wing)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'WING, WING Compact, WING Rack. Turn off Setup → Remote → Remote lock on the console.',
                        style: TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                    ),
                  if (_family == MixerFamily.tascam)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'Sonicview 16 / 24 over Ember+ (TCP 9000). If your console uses another Ember+ port, enter it as IP:port. The first sync takes a few seconds.',
                        style: TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                    ),
                  if (_family == MixerFamily.allenHeath) ...[
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      initialValue: _ahModel,
                      decoration: const InputDecoration(labelText: 'Console', border: OutlineInputBorder()),
                      items: [
                        for (final (label, id) in AhLayout.models) DropdownMenuItem(value: id, child: Text(label)),
                      ],
                      onChanged: (v) => setState(() => _ahModel = v ?? _ahModel),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'Connects over MIDI TCP (port 51325). Use the console\'s (or MixRack\'s) IP address and MIDI channel 1.',
                        style: TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                    ),
                  ],
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _connect(_host.text, _family),
                    icon: const Icon(Icons.link),
                    label: const Text('Connect'),
                  ),
                  const SizedBox(height: 32),
                  Text('Try without a mixer', style: t.titleMedium),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.x32,
                    title: 'X32 / M32 demo',
                    subtitle: '32 channels · 16 buses · 8 FX',
                    onTap: () => _demo(MixerFamily.x32),
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.xr,
                    title: 'XR18 / MR18 demo',
                    subtitle: '16 channels · 6 buses · 4 FX',
                    onTap: () => _demo(MixerFamily.xr),
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.yamaha,
                    title: 'Yamaha demo',
                    subtitle: 'TF · DM3 · DM7 · QL · CL',
                    onTap: _pickYamahaDemo,
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.allenHeath,
                    title: 'Allen & Heath demo',
                    subtitle: 'SQ · CQ · Qu · dLive · Avantis',
                    onTap: _pickAhDemo,
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.wing,
                    title: 'Behringer WING demo',
                    subtitle: '40 channels · 16 buses · 8 matrices · 16 DCAs',
                    onTap: () => _demo(MixerFamily.wing),
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.tascam,
                    title: 'TASCAM Sonicview demo',
                    subtitle: '40 channels · 22 MIX · 4 FX · 8 DCAs',
                    onTap: () => _demo(MixerFamily.tascam),
                  ),
                  const SizedBox(height: 24),
                  const Center(
                    child: Text(
                      '$appName $appVersion',
                      style: TextStyle(fontSize: 12, color: Colors.white38),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_busy)
            const ColoredBox(
              color: Colors.black45,
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}


/// Mixer entry with its illustration (discovered consoles and demos).
class _MixerCard extends StatelessWidget {
  const _MixerCard({required this.family, required this.title, required this.subtitle, required this.onTap});
  final MixerFamily family;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.fromLTRB(10, 10, 12, 10),
          decoration: AppStyle.panel(raised: true),
          child: Row(
            children: [
              MixerArt(family: family, width: 104, height: 64),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white60)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white54),
            ],
          ),
        ),
      ),
    );
  }
}
