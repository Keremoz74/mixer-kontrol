import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../osc/discovery.dart';
import '../app_version.dart';
import 'app_style.dart';
import 'channel_strip.dart' show sendsAccent;
import 'help_screen.dart';
import 'mixer_art.dart';
import 'mixer_screen.dart';
import 'personal_autostart.dart';

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  static const _prefHost = 'last_host';

  final _host = TextEditingController();
  MixerFamily? _family; // null = auto detect
  List<DiscoveredMixer> _found = [];
  bool _scanning = false;
  bool _busy = false;
  PersonalAutoStart? _auto;

  @override
  void initState() {
    super.initState();
    PersonalAutoStart.load().then((a) {
      if (a == null || !mounted) return;
      setState(() => _auto = a);
      _openAuto(a);
    });
    SharedPreferences.getInstance().then((p) {
      final h = p.getString(_prefHost);
      if (h != null && mounted) _host.text = h;
    });
    _scan();
  }

  Future<void> _scan() async {
    setState(() => _scanning = true);
    final list = await MixerDiscovery.scan();
    if (!mounted) return;
    setState(() {
      _found = list;
      _scanning = false;
    });
  }

  Future<void> _connect(String host, MixerFamily? family) async {
    host = host.trim();
    if (host.isEmpty) return;
    setState(() => _busy = true);
    try {
      final c = await MixerController.connect(host, family: family);
      (await SharedPreferences.getInstance()).setString(_prefHost, host);
      if (!mounted) {
        c.dispose();
        return;
      }
      await Navigator.push(context, MaterialPageRoute(builder: (_) => MixerScreen(controller: c)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Could not connect: $e\nAre the mixer and this device on the same network?'),
        ));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openAuto(PersonalAutoStart a) => Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => PersonalLaunchScreen(config: a)),
      ).then((_) async {
        // back here: auto-start may have been switched off on the way
        final now = await PersonalAutoStart.load();
        if (mounted) setState(() => _auto = now);
      });

  Future<void> _turnOffAuto(PersonalAutoStart a) async {
    if (!await checkPersonalPin(context, a.pin, title: 'Enter PIN to turn off')) return;
    await PersonalAutoStart.clear();
    if (mounted) setState(() => _auto = null);
  }

  void _demo(MixerFamily f) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MixerScreen(controller: MixerController.demo(f))),
    );
  }

  @override
  Widget build(BuildContext context) => AppBackground(child: _page(context));

  Widget _page(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      floatingActionButton: FloatingActionButton.small(
        tooltip: 'User guide',
        heroTag: 'help',
        backgroundColor: const Color(0xFF1C2333),
        foregroundColor: Colors.white70,
        onPressed: () => openHelp(context),
        child: const Icon(Icons.info_outline),
      ),
      appBar: AppBar(
        toolbarHeight: 72,
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset('assets/logo.png', width: 44, height: 44),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(appName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                Text(appTagline, style: TextStyle(fontSize: 12, color: Colors.white60)),
              ],
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
                children: [
                  if (_auto case final a?)
                    Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: ListTile(
                        leading: const Icon(Icons.headphones, color: sendsAccent),
                        title: Text('Personal mix at start: ${a.label}'),
                        subtitle: Text('${a.host} · opens by itself when the app starts'),
                        trailing: Wrap(
                          spacing: 4,
                          children: [
                            IconButton(
                              tooltip: 'Turn off',
                              icon: const Icon(Icons.close),
                              onPressed: () => _turnOffAuto(a),
                            ),
                            IconButton(
                              tooltip: 'Open',
                              icon: const Icon(Icons.play_arrow),
                              onPressed: () => _openAuto(a),
                            ),
                          ],
                        ),
                      ),
                    ),
                  Row(
                    children: [
                      Expanded(child: Text('Mixers on the network', style: t.titleMedium)),
                      if (_scanning)
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      else
                        IconButton(onPressed: _scan, icon: const Icon(Icons.refresh), tooltip: 'Search again'),
                    ],
                  ),
                  if (!_scanning && _found.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('No mixer found. You can connect by IP address below.'),
                    ),
                  for (final m in _found)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _MixerCard(
                        family: MixerProfile.familyFromModel(m.model) ?? MixerFamily.xr,
                        title: m.name,
                        subtitle: '${m.model}  ·  ${m.ip}  ·  FW ${m.firmware}',
                        onTap: () => _connect(m.ip, MixerProfile.familyFromModel(m.model)),
                      ),
                    ),
                  const SizedBox(height: 24),
                  Text('Connect by IP', style: t.titleMedium),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _host,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Mixer IP address',
                      hintText: '192.168.1.50',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (v) => _connect(v, _family),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final (f, label) in const [
                        (null, 'Auto'),
                        (MixerFamily.x32, 'X32 / M32'),
                        (MixerFamily.xr, 'XR / MR'),
                        (MixerFamily.yamaha, 'Yamaha (beta)'),
                      ])
                        ChoiceChip(
                          label: Text(label),
                          selected: _family == f,
                          onSelected: (_) => setState(() => _family = f),
                        ),
                    ],
                  ),
                  if (_family == MixerFamily.yamaha)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'Yamaha TF, DM3, DM7, QL, CL (experimental): faders, mutes, names, colours, '
                        'sends and DCAs. Use the console\'s "For Mixer Control" IP address.',
                        style: TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                    ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _connect(_host.text, _family),
                    icon: const Icon(Icons.link),
                    label: const Text('Connect'),
                  ),
                  const SizedBox(height: 32),
                  Text('Try without a mixer', style: t.titleMedium),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.x32,
                    title: 'X32 / M32 demo',
                    subtitle: '32 channels · 16 buses · 8 FX',
                    onTap: () => _demo(MixerFamily.x32),
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.xr,
                    title: 'XR18 / MR18 demo',
                    subtitle: '16 channels · 6 buses · 4 FX',
                    onTap: () => _demo(MixerFamily.xr),
                  ),
                  const SizedBox(height: 8),
                  _MixerCard(
                    family: MixerFamily.yamaha,
                    title: 'Yamaha TF demo (beta)',
                    subtitle: '32 channels · 20 AUX · 8 DCA',
                    onTap: () => _demo(MixerFamily.yamaha),
                  ),
                  const SizedBox(height: 24),
                  const Center(
                    child: Text(
                      '$appName $appVersion',
                      style: TextStyle(fontSize: 12, color: Colors.white38),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_busy)
            const ColoredBox(
              color: Colors.black45,
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}


/// Mixer entry with its illustration (discovered consoles and demos).
class _MixerCard extends StatelessWidget {
  const _MixerCard({required this.family, required this.title, required this.subtitle, required this.onTap});
  final MixerFamily family;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.fromLTRB(10, 10, 12, 10),
          decoration: AppStyle.panel(raised: true),
          child: Row(
            children: [
              MixerArt(family: family, width: 104, height: 64),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white60)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white54),
            ],
          ),
        ),
      ),
    );
  }
}
