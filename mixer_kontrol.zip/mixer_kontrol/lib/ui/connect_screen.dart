import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../osc/discovery.dart';
import 'app_style.dart';
import 'mixer_screen.dart';

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  static const _prefHost = 'last_host';

  final _host = TextEditingController();
  MixerFamily? _family; // null = auto detect
  List<DiscoveredMixer> _found = [];
  bool _scanning = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final h = p.getString(_prefHost);
      if (h != null && mounted) _host.text = h;
    });
    _scan();
  }

  Future<void> _scan() async {
    setState(() => _scanning = true);
    final list = await MixerDiscovery.scan();
    if (!mounted) return;
    setState(() {
      _found = list;
      _scanning = false;
    });
  }

  Future<void> _connect(String host, MixerFamily? family) async {
    host = host.trim();
    if (host.isEmpty) return;
    setState(() => _busy = true);
    try {
      final c = await MixerController.connect(host, family: family);
      (await SharedPreferences.getInstance()).setString(_prefHost, host);
      if (!mounted) {
        c.dispose();
        return;
      }
      await Navigator.push(context, MaterialPageRoute(builder: (_) => MixerScreen(controller: c)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Could not connect: $e\nAre the mixer and this device on the same network?'),
        ));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _demo(MixerFamily f) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MixerScreen(controller: MixerController.demo(f))),
    );
  }

  @override
  Widget build(BuildContext context) => AppBackground(child: _page(context));

  Widget _page(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Mixer Control')),
      body: Stack(
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Expanded(child: Text('Mixers on the network', style: t.titleMedium)),
                      if (_scanning)
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      else
                        IconButton(onPressed: _scan, icon: const Icon(Icons.refresh), tooltip: 'Search again'),
                    ],
                  ),
                  if (!_scanning && _found.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('No mixer found. You can connect by IP address below.'),
                    ),
                  for (final m in _found)
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.graphic_eq),
                        title: Text('${m.name} (${m.model})'),
                        subtitle: Text('${m.ip}  ·  FW ${m.firmware}'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => _connect(m.ip, MixerProfile.familyFromModel(m.model)),
                      ),
                    ),
                  const SizedBox(height: 24),
                  Text('Connect by IP', style: t.titleMedium),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _host,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Mixer IP address',
                      hintText: '192.168.1.50',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (v) => _connect(v, _family),
                  ),
                  const SizedBox(height: 12),
                  SegmentedButton<MixerFamily?>(
                    segments: const [
                      ButtonSegment(value: null, label: Text('Auto')),
                      ButtonSegment(value: MixerFamily.x32, label: Text('X32 / M32')),
                      ButtonSegment(value: MixerFamily.xr, label: Text('XR / MR')),
                    ],
                    selected: {_family},
                    onSelectionChanged: (s) => setState(() => _family = s.first),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _connect(_host.text, _family),
                    icon: const Icon(Icons.link),
                    label: const Text('Connect'),
                  ),
                  const SizedBox(height: 32),
                  Text('Try without a mixer', style: t.titleMedium),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => _demo(MixerFamily.x32),
                          child: const Text('X32 demo'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => _demo(MixerFamily.xr),
                          child: const Text('XR18 demo'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (_busy)
            const ColoredBox(
              color: Colors.black45,
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}
