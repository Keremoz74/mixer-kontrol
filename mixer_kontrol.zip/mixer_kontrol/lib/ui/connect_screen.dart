import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../osc/discovery.dart';
import '../app_version.dart';
import 'app_style.dart';
import 'ble_probe_screen.dart';
import 'channel_strip.dart' show sendsAccent;
import 'help_screen.dart';
import 'mixer_art.dart';
import 'mixer_catalog.dart';
import 'mixer_photo.dart';
import 'mixer_picker.dart';
import 'mixer_screen.dart';
import 'personal_autostart.dart';

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  static const _prefHost = 'last_host';

  final _host = TextEditingController();
  List<DiscoveredMixer> _found = [];
  bool _scanning = false;
  bool _busy = false;
  PersonalAutoStart? _auto;

  @override
  void initState() {
    super.initState();
    PersonalAutoStart.load().then((a) {
      if (a == null || !mounted) return;
      setState(() => _auto = a);
      _openAuto(a);
    });
    SharedPreferences.getInstance().then((p) {
      final h = p.getString(_prefHost);
      if (h != null && mounted) _host.text = h;
    });
    _scan();
  }

  Future<void> _scan() async {
    setState(() => _scanning = true);
    final list = await MixerDiscovery.scan();
    if (!mounted) return;
    setState(() {
      _found = list;
      _scanning = false;
    });
  }

  Future<void> _connect(String host, MixerFamily? family, {String? model}) async {
    host = host.trim();
    if (host.isEmpty) return;
    setState(() => _busy = true);
    try {
      final c = await MixerController.connect(host, family: family, model: model);
      if (family != MixerFamily.flow) (await SharedPreferences.getInstance()).setString(_prefHost, host);
      if (!mounted) {
        c.dispose();
        return;
      }
      await Navigator.push(context, MaterialPageRoute(builder: (_) => MixerScreen(controller: c)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Could not connect: $e\nAre the mixer and this device on the same network?'),
        ));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openAuto(PersonalAutoStart a) => Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => PersonalLaunchScreen(config: a)),
      ).then((_) async {
        // back here: auto-start may have been switched off on the way
        final now = await PersonalAutoStart.load();
        if (mounted) setState(() => _auto = now);
      });

  Future<void> _turnOffAuto(PersonalAutoStart a) async {
    if (!await checkPersonalPin(context, a.pin, title: 'Enter PIN to turn off')) return;
    await PersonalAutoStart.clear();
    if (mounted) setState(() => _auto = null);
  }

  void _demo(MixerFamily f, {String? model}) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MixerScreen(controller: MixerController.demo(f, model: model))),
    );
  }

  Future<void> _connectModel(MixerModel m, String host) =>
      _connect(host, m.family, model: m.family == MixerFamily.allenHeath ? m.model : null);

  void _demoModel(MixerModel m) => _demo(m.family, model: m.model);

  @override
  Widget build(BuildContext context) => AppBackground(child: _page(context));

  Widget _page(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      floatingActionButton: FloatingActionButton.small(
        tooltip: 'User guide',
        heroTag: 'help',
        backgroundColor: const Color(0xFF1C2333),
        foregroundColor: Colors.white70,
        onPressed: () => openHelp(context),
        child: const Icon(Icons.info_outline),
      ),
      appBar: AppBar(
        toolbarHeight: 72,
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset('assets/logo.png', width: 44, height: 44),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(appName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                Text(appTagline, style: TextStyle(fontSize: 12, color: Colors.white60)),
              ],
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
                children: [
                  if (_auto case final a?)
                    Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: ListTile(
                        leading: const Icon(Icons.headphones, color: sendsAccent),
                        title: Text('Personal mix at start: ${a.label}'),
                        subtitle: Text('${a.host} · opens by itself when the app starts'),
                        trailing: Wrap(
                          spacing: 4,
                          children: [
                            IconButton(
                              tooltip: 'Turn off',
                              icon: const Icon(Icons.close),
                              onPressed: () => _turnOffAuto(a),
                            ),
                            IconButton(
                              tooltip: 'Open',
                              icon: const Icon(Icons.play_arrow),
                              onPressed: () => _openAuto(a),
                            ),
                          ],
                        ),
                      ),
                    ),
                  Row(
                    children: [
                      Expanded(child: Text('Mixers on the network', style: t.titleMedium)),
                      if (_scanning)
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      else
                        IconButton(onPressed: _scan, icon: const Icon(Icons.refresh), tooltip: 'Search again'),
                    ],
                  ),
                  if (!_scanning && _found.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('No mixer found. You can connect by IP address below.'),
                    ),
                  for (final m in _found)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _MixerCard(
                        picture: _pictureFor(m.model, MixerProfile.familyFromModel(m.model) ?? MixerFamily.xr),
                        title: m.name,
                        subtitle: '${m.model}  ·  ${m.ip}  ·  FW ${m.firmware}',
                        onTap: () => _connect(m.ip, MixerProfile.familyFromModel(m.model)),
                      ),
                    ),
                  const SizedBox(height: 24),
                  Text('Select your mixer', style: t.titleMedium),
                  const SizedBox(height: 2),
                  const Text(
                    'Pick the brand, then your model: connect, try a demo or add a photo of your own mixer.',
                    style: TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                  const SizedBox(height: 10),
                  BrandGrid(lastHost: () => _host.text, onConnect: _connectModel, onDemo: _demoModel),
                  const SizedBox(height: 24),
                  // FLOW 8: not on the network; Bluetooth or a USB cable
                  Text('Behringer FLOW 8', style: t.titleMedium),
                  const SizedBox(height: 2),
                  const Text(
                    'Bluetooth: close the FLOW Mix app first. USB: connect with a USB-C (OTG) cable.',
                    style: TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.tonalIcon(
                          onPressed: _busy
                              ? null
                              : () => Navigator.push(
                                    context,
                                    MaterialPageRoute<void>(builder: (_) => const BleProbeScreen()),
                                  ),
                          icon: const Icon(Icons.bluetooth_searching),
                          label: const Text('Find by Bluetooth'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : () => _connect('USB', MixerFamily.flow),
                          icon: const Icon(Icons.usb),
                          label: const Text('USB cable'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  Text('Connect by IP (auto detect)', style: t.titleMedium),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _host,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Mixer IP address',
                      hintText: '192.168.1.50',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (v) => _connect(v, null),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text(
                      'Finds X32 / M32, XR / MR, Yamaha, WING, TASCAM and PreSonus by itself. '
                      'Allen & Heath: choose the model above.',
                      style: TextStyle(fontSize: 12, color: Colors.white60),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _connect(_host.text, null),
                    icon: const Icon(Icons.link),
                    label: const Text('Connect'),
                  ),
                  const SizedBox(height: 24),
                  const Center(
                    child: Text(
                      '$appName $appVersion',
                      style: TextStyle(fontSize: 12, color: Colors.white38),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_busy)
            const ColoredBox(
              color: Colors.black45,
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}

/// The person's photo or the illustration of a reported model.
Widget _pictureFor(String reported, MixerFamily family) {
  final m = MixerCatalog.match(reported);
  return m != null
      ? MixerPicture(model: m, width: 104, height: 64, radius: 8)
      : MixerArt(family: family, width: 104, height: 64);
}

/// Mixer entry with its picture (consoles found on the network).
class _MixerCard extends StatelessWidget {
  const _MixerCard({required this.picture, required this.title, required this.subtitle, required this.onTap});
  final Widget picture;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.fromLTRB(10, 10, 12, 10),
          decoration: AppStyle.panel(raised: true),
          child: Row(
            children: [
              SizedBox(width: 104, height: 64, child: picture),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white60)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white54),
            ],
          ),
        ),
      ),
    );
  }
}
