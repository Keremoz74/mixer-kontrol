import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:share_plus/share_plus.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';

const recRed = Color(0xFFFF4D57);

String _clock(Duration d) {
  String two(int n) => n.toString().padLeft(2, '0');
  final h = d.inHours;
  return h > 0
      ? '$h:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}'
      : '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';
}

/// Recording: the mixer's own USB-stick recorder, and recording the mix
/// onto this tablet through the mixer's USB audio.
class RecorderScreen extends StatelessWidget {
  const RecorderScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: DefaultTabController(
        length: controller.profile.family == MixerFamily.x32 ? 3 : 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Recorder'),
            bottom: TabBar(
              isScrollable: controller.profile.family == MixerFamily.x32,
              tabs: [
                const Tab(icon: Icon(Icons.usb), text: 'Mixer USB stick'),
                const Tab(icon: Icon(Icons.tablet_android), text: 'Record to tablet'),
                if (controller.profile.family == MixerFamily.x32)
                  const Tab(icon: Icon(Icons.sd_card_outlined), text: 'X-LIVE card'),
              ],
            ),
          ),
          body: SafeArea(
            top: false,
            child: TabBarView(
              children: [
                _MixerRecorderTab(controller: controller),
                const _TabletRecorderTab(),
                if (controller.profile.family == MixerFamily.x32) _XLiveTab(controller: controller),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ======================================================================
// Mixer USB stick recorder

class _MixerRecorderTab extends StatefulWidget {
  const _MixerRecorderTab({required this.controller});
  final MixerController controller;

  @override
  State<_MixerRecorderTab> createState() => _MixerRecorderTabState();
}

class _MixerRecorderTabState extends State<_MixerRecorderTab> {
  Timer? _poll;
  final Stopwatch _since = Stopwatch();
  int? _lastState;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    if (c.isDemo) {
      c.param(MixerProfile.tapeStateAddr).value ??= 0;
      c.param(MixerProfile.tapeFileAddr).value ??= 'DEMO_001.wav';
    }
    _query();
    // Refresh the state every second while this page is open (the clock is
    // kept here, from when recording / playback started).
    _poll = Timer.periodic(const Duration(seconds: 1), (_) {
      _query();
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  void _query() {
    if (!c.isDemo) c.query(const [MixerProfile.tapeStateAddr, MixerProfile.tapeFileAddr]);
  }

  int get _state {
    final v = c.param(MixerProfile.tapeStateAddr).value;
    return v is num ? v.toInt() : -1;
  }

  void _send(int state) {
    c.set(MixerProfile.tapeStateAddr, state);
  }

  void _track(int state) {
    if (state == _lastState) return;
    final running = state == 2 || state == 4;
    final wasRunning = _lastState == 2 || _lastState == 4;
    if (running && !wasRunning) {
      _since
        ..reset()
        ..start();
    } else if (state == 0) {
      _since
        ..stop()
        ..reset();
    } else if (!running) {
      _since.stop();
    }
    _lastState = state;
  }

  Future<void> _record() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Start recording?'),
        content: const Text(
          'The mixer records to the USB stick plugged into it. '
          'What it records (usually Main LR) is set on the console.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: recRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Record'),
          ),
        ],
      ),
    );
    if (ok == true) _send(4);
  }

  @override
  Widget build(BuildContext context) {
    if (!c.profile.hasUsbRecorder) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'This mixer has no built-in USB-stick recorder (the XR18 / MR18 don\'t).\n'
            'Use "Record to tablet" instead.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, height: 1.4),
          ),
        ),
      );
    }
    return ListenableBuilder(
      listenable: Listenable.merge([
        c.param(MixerProfile.tapeStateAddr),
        c.param(MixerProfile.tapeFileAddr),
      ]),
      builder: (context, _) {
        final st = _state;
        _track(st);
        final recording = st == 4;
        final playing = st == 2;
        final paused = st == 1 || st == 3;
        final f = c.param(MixerProfile.tapeFileAddr).value;
        final file = f is String && f.trim().isNotEmpty ? f.trim() : '—';
        final label = switch (st) {
          -1 => 'Reading…',
          0 => 'Stopped',
          1 => 'Playback paused',
          2 => 'Playing',
          3 => 'Recording paused',
          4 => 'Recording',
          5 => 'Fast forward',
          6 => 'Rewind',
          _ => 'State $st',
        };
        final color = recording ? recRed : (playing ? AppStyle.mainTeal : Colors.white54);
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: recording ? AppStyle.masterPanel(recRed) : AppStyle.panel(raised: true),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.circle, size: 14, color: color),
                      const SizedBox(width: 8),
                      Text(label, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: color)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _clock(_since.elapsed),
                    style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800, letterSpacing: 2),
                  ),
                  const SizedBox(height: 4),
                  Text(file, style: const TextStyle(color: Colors.white60)),
                  const SizedBox(height: 18),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _btn(Icons.fiber_manual_record, 'Record', recRed, recording ? null : _record, filled: true),
                      _btn(Icons.pause, 'Pause', Colors.white, (recording || playing) ? () => _send(recording ? 3 : 1) : null),
                      _btn(Icons.play_arrow, 'Play', AppStyle.mainTeal, (recording || playing) ? null : () => _send(paused && st == 3 ? 4 : 2)),
                      _btn(Icons.stop, 'Stop', Colors.white, st == 0 ? null : () => _send(0)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Plug a USB stick into the mixer. The recorder\'s source (usually Main LR) and the '
              'file list are set on the console. Files are WAV, on the stick.',
              style: TextStyle(fontSize: 12, color: Colors.white54, height: 1.4),
            ),
          ],
        );
      },
    );
  }

  Widget _btn(IconData icon, String label, Color color, VoidCallback? onTap, {bool filled = false}) {
    return SizedBox(
      width: 110,
      height: 56,
      child: filled
          ? FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white),
              onPressed: onTap,
              icon: Icon(icon),
              label: Text(label),
            )
          : OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: color),
              onPressed: onTap,
              icon: Icon(icon),
              label: Text(label),
            ),
    );
  }
}

// ======================================================================
// Record to tablet (USB audio from the mixer)

class _TabletRecorderTab extends StatefulWidget {
  const _TabletRecorderTab();

  @override
  State<_TabletRecorderTab> createState() => _TabletRecorderTabState();
}

class _TabletRecorderTabState extends State<_TabletRecorderTab> {
  final AudioRecorder _rec = AudioRecorder();
  List<InputDevice> _devices = [];
  InputDevice? _device;
  bool _recording = false;
  final Stopwatch _clockWatch = Stopwatch();
  Timer? _tick;
  StreamSubscription<Amplitude>? _ampSub;
  double _level = -60;
  List<File> _files = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadDevices();
    _loadFiles();
  }

  @override
  void dispose() {
    _tick?.cancel();
    _ampSub?.cancel();
    _rec.dispose();
    super.dispose();
  }

  Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/recordings');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<void> _loadDevices() async {
    try {
      final list = await _rec.listInputDevices();
      if (!mounted) return;
      setState(() {
        _devices = list;
        // Prefer the mixer's USB audio when it is plugged in.
        _device = list.where((d) => d.label.toLowerCase().contains('usb')).firstOrNull ?? _device;
      });
    } catch (_) {
      // Device listing not available: the system default input is used.
    }
  }

  Future<void> _loadFiles() async {
    final d = await _dir();
    final files = d.listSync().whereType<File>().where((f) => f.path.endsWith('.wav')).toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    if (mounted) setState(() => _files = files);
  }

  Future<void> _start() async {
    setState(() => _error = null);
    if (!await _rec.hasPermission()) {
      setState(() => _error = 'Audio recording permission was not given.');
      return;
    }
    final d = await _dir();
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final name = 'OzMix_${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}${two(now.second)}.wav';
    try {
      await _rec.start(
        RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 48000,
          numChannels: 2,
          device: _device,
          autoGain: false,
          echoCancel: false,
          noiseSuppress: false,
        ),
        path: '${d.path}/$name',
      );
    } catch (e) {
      setState(() => _error = 'Could not start recording: $e');
      return;
    }
    _ampSub = _rec.onAmplitudeChanged(const Duration(milliseconds: 120)).listen((a) {
      if (mounted) setState(() => _level = a.current.isFinite ? a.current : -60);
    });
    _clockWatch
      ..reset()
      ..start();
    _tick = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (mounted) setState(() {});
    });
    setState(() => _recording = true);
  }

  Future<void> _stop() async {
    await _rec.stop();
    await _ampSub?.cancel();
    _ampSub = null;
    _tick?.cancel();
    _clockWatch.stop();
    setState(() {
      _recording = false;
      _level = -60;
    });
    await _loadFiles();
  }

  Future<void> _share(File f) async {
    await SharePlus.instance.share(ShareParams(files: [XFile(f.path)], text: f.uri.pathSegments.last));
  }

  Future<void> _delete(File f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete recording?'),
        content: Text(f.uri.pathSegments.last),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    await f.delete();
    await _loadFiles();
  }

  @override
  Widget build(BuildContext context) {
    final levelFrac = ((_level + 60) / 60).clamp(0.0, 1.0);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: _recording ? AppStyle.masterPanel(recRed) : AppStyle.panel(raised: true),
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                key: ValueKey('${_device?.id}-${_devices.length}'),
                initialValue: _device?.id,
                decoration: const InputDecoration(labelText: 'Input', border: OutlineInputBorder()),
                items: [
                  const DropdownMenuItem(value: null, child: Text('System default')),
                  for (final d in _devices) DropdownMenuItem(value: d.id, child: Text(d.label)),
                ],
                onChanged: _recording
                    ? null
                    : (id) => setState(() => _device = _devices.where((d) => d.id == id).firstOrNull),
              ),
              const SizedBox(height: 16),
              Text(
                _clock(_clockWatch.elapsed),
                style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800, letterSpacing: 2),
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _recording ? levelFrac : 0,
                  minHeight: 8,
                  color: levelFrac > 0.9 ? recRed : const Color(0xFF3DD68C),
                  backgroundColor: Colors.white12,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: 200,
                height: 56,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: _recording ? Colors.white : recRed,
                    foregroundColor: _recording ? Colors.black : Colors.white,
                  ),
                  onPressed: _recording ? _stop : _start,
                  icon: Icon(_recording ? Icons.stop : Icons.fiber_manual_record),
                  label: Text(_recording ? 'Stop' : 'Record'),
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: const TextStyle(color: recRed)),
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'Connect the mixer\'s USB audio port to the tablet (USB-C OTG cable / adapter), then pick it as the '
          'input. The tablet records the first two USB channels in stereo, so on the mixer route Main LR '
          '(or the mix you want) to USB / card outputs 1-2. Without a cable, the tablet\'s own microphone is used.',
          style: TextStyle(fontSize: 12, color: Colors.white54, height: 1.4),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: Text('Recordings', style: Theme.of(context).textTheme.titleMedium)),
            IconButton(tooltip: 'Find inputs again', icon: const Icon(Icons.refresh), onPressed: _loadDevices),
          ],
        ),
        if (_files.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Text('No recordings yet.', style: TextStyle(color: Colors.white54)),
          ),
        for (final f in _files)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            decoration: AppStyle.panel(),
            child: ListTile(
              leading: const Icon(Icons.audio_file, color: recRed),
              title: Text(f.uri.pathSegments.last, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('${(f.lengthSync() / (1024 * 1024)).toStringAsFixed(1)} MB'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(tooltip: 'Share / save', icon: const Icon(Icons.share), onPressed: () => _share(f)),
                  IconButton(tooltip: 'Delete', icon: const Icon(Icons.delete_outline), onPressed: () => _delete(f)),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// ======================================================================
// X-LIVE SD card recorder (X32 / M32 with the X-LIVE expansion card)
//   /-stat/urec/state 0 STOP, 1 PAUSE, 2 PLAY, 3 RECORD
//   /-stat/urec/etime elapsed (ms), /-stat/urec/rtime remaining (ms)

class _XLiveTab extends StatefulWidget {
  const _XLiveTab({required this.controller});
  final MixerController controller;

  @override
  State<_XLiveTab> createState() => _XLiveTabState();
}

class _XLiveTabState extends State<_XLiveTab> {
  static const stateAddr = '/-stat/urec/state';
  static const etimeAddr = '/-stat/urec/etime';
  static const rtimeAddr = '/-stat/urec/rtime';
  Timer? _poll;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    if (c.isDemo) {
      c.param(stateAddr).value ??= 0;
      c.param(etimeAddr).value ??= 0;
      c.param(rtimeAddr).value ??= 4 * 3600 * 1000;
    }
    _refresh();
    _poll = Timer.periodic(const Duration(seconds: 1), (_) => _refresh());
  }

  void _refresh() {
    if (c.isDemo) {
      if (c.intOf(stateAddr, 0) == 3) {
        c.param(etimeAddr).value = c.intOf(etimeAddr, 0) + 1000;
        c.param(rtimeAddr).value = c.intOf(rtimeAddr, 0) - 1000;
      }
      return;
    }
    c.query(const [stateAddr, etimeAddr, rtimeAddr]);
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  String _hms(int ms) {
    final d = Duration(milliseconds: ms < 0 ? 0 : ms);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
  }

  Future<void> _record() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Start multitrack recording?'),
        content: const Text('The X-LIVE card records to its SD cards the channels routed to it on the console.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Record')),
        ],
      ),
    );
    if (ok == true) c.set(stateAddr, 3);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([c.param(stateAddr), c.param(etimeAddr), c.param(rtimeAddr)]),
      builder: (context, _) {
        final v = c.param(stateAddr).value;
        final st = v is num ? v.toInt() : -1;
        final rec = st == 3;
        final label = switch (st) {
          0 => 'Stopped',
          1 => 'Paused',
          2 => 'Playing',
          3 => 'Recording',
          -1 => 'No answer yet (is an X-LIVE card fitted?)',
          _ => 'State $st',
        };
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: rec ? AppStyle.masterPanel(recRed) : AppStyle.panel(raised: true),
              child: Column(
                children: [
                  Text(label, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: rec ? recRed : Colors.white70)),
                  const SizedBox(height: 10),
                  Text(_hms(c.intOf(etimeAddr, 0)),
                      style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800, letterSpacing: 2)),
                  Text('Remaining on card: ${_hms(c.intOf(rtimeAddr, 0))}',
                      style: const TextStyle(color: Colors.white60)),
                  const SizedBox(height: 18),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: recRed, foregroundColor: Colors.white),
                        onPressed: rec ? null : _record,
                        icon: const Icon(Icons.fiber_manual_record),
                        label: const Text('Record'),
                      ),
                      OutlinedButton.icon(
                        onPressed: st == 3 || st == 2 ? () => c.set(stateAddr, 1) : null,
                        icon: const Icon(Icons.pause),
                        label: const Text('Pause'),
                      ),
                      OutlinedButton.icon(
                        onPressed: st == 0 || st == 1 ? () => c.set(stateAddr, 2) : null,
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('Play'),
                      ),
                      OutlinedButton.icon(
                        onPressed: st > 0 ? () => c.set(stateAddr, 0) : null,
                        icon: const Icon(Icons.stop),
                        label: const Text('Stop'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Sessions, card selection and track routing are set on the console. '
              'This control is new: please check it once on your console before a show.',
              style: TextStyle(fontSize: 12, color: Colors.white54, height: 1.4),
            ),
          ],
        );
      },
    );
  }
}
