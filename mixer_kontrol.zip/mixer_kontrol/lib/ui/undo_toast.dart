import 'dart:async';

import 'package:flutter/material.dart';

/// A small "done — Undo" note in the bottom-right corner that goes away by
/// itself after [seconds] (it never covers the whole bottom of the screen).
void showUndoToast(BuildContext context, String message, VoidCallback onUndo, {int seconds = 3}) {
  final messenger = ScaffoldMessenger.of(context);
  final screen = MediaQuery.sizeOf(context);
  const edge = 12.0;
  final width = (screen.width - 2 * edge).clamp(160.0, 320.0);
  messenger.hideCurrentSnackBar();
  final ctrl = messenger.showSnackBar(
    SnackBar(
      behavior: SnackBarBehavior.floating,
      margin: EdgeInsets.only(left: screen.width - width - edge, right: edge, bottom: edge),
      padding: const EdgeInsets.only(left: 14, right: 4),
      duration: Duration(seconds: seconds),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      backgroundColor: const Color(0xFF263044),
      content: Text(
        message,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 13, color: Colors.white),
      ),
      action: SnackBarAction(label: 'Undo', textColor: const Color(0xFF7FE3C4), onPressed: onUndo),
    ),
  );
  // Snack bars with an action can stay up (accessibility settings, newer
  // Flutter): close it ourselves on time.
  Timer(Duration(seconds: seconds), () {
    try {
      ctrl.close();
    } catch (_) {}
  });
}
