import 'package:flutter/painting.dart';

import '../mixer/mixer_profile.dart';

/// Kind of hardware, for the illustrations.
enum ArtKind { desk, rack, stagebox, touchDesk }

/// Body finish: the quickest way to tell series apart at a glance.
enum ArtTone { charcoal, black, graphite, silver, navy }

/// Where the dense block of knobs and keys sits in the back section.
enum ArtBlock { none, left, right, both }

/// What a model's (original, generic) illustration shows: its form and the
/// layout that tells it apart (fader groups, where the screens are, knob
/// blocks, the inputs on a stage box). Never a copy of the real product.
class ArtSpec {
  const ArtSpec(
    this.kind, {
    this.faders = 8,
    this.masters = 1,
    this.screens = 1,
    this.screen = 0.20,
    this.size = 1.0,
    this.jacks = 12,
    this.units = 2,
    this.bays,
    this.tail = 0,
    this.screenAt = 0.5,
    this.screenBays,
    this.block = ArtBlock.none,
    this.chKnobs = false,
    this.meters = false,
    this.raised = false,
    this.encoders = 0,
    this.rows,
    this.outs = 0,
    this.antenna = false,
    this.tone = ArtTone.charcoal,
    this.bridge = false,
    this.rightCol = false,
    this.lineRow = false,
    this.aspect,
    this.look,
  });

  final ArtKind kind;

  /// Channel faders and master faders on the surface.
  final int faders;
  final int masters;

  /// Number of screens and the width of each (fraction of the body; 0 = none).
  final int screens;
  final double screen;

  /// Relative width of the body (small desks look smaller).
  final double size;

  /// Input sockets (stage boxes, racks).
  final int jacks;

  /// Rack height in units.
  final int units;

  /// Fader groups left to right (default: banks of 8 out of [faders]).
  final List<int>? bays;

  /// Faders after the master section (a second bank on the right).
  final int tail;

  /// Centre of the screen area across the body (0 = left, 1 = right).
  final double screenAt;

  /// One screen over each of these fader groups instead of [screenAt].
  final List<int>? screenBays;

  /// Dense block of channel-strip knobs in the back section.
  final ArtBlock block;

  /// A knob above every channel, and LED meters beside the scribble strips.
  final bool chKnobs;
  final bool meters;

  /// The screen stands up on its own housing (swivel screen).
  final bool raised;

  /// Row of encoders under the screen (fader-less touch mixers).
  final int encoders;

  /// Stage box / front panel: input sockets per row, XLR outputs, Wi-Fi.
  final List<int>? rows;
  final int outs;
  final bool antenna;

  /// Body colour, and a meter bridge along the back.
  final ArtTone tone;
  final bool bridge;

  /// A column of keys (scenes, assign, mute groups) at the right edge.
  final bool rightCol;

  /// Front panels: the second row holds line (jack) inputs, not combos.
  final bool lineRow;

  /// Width / height of the body seen from above (default: from the faders).
  final double? aspect;

  /// A panel drawn after a reference photo of this model (see mixer_art).
  final String? look;

  /// The fader groups actually drawn.
  List<int> get groups {
    if (bays != null) return bays!;
    if (faders <= 0) return const [];
    final g = <int>[];
    for (var left = faders; left > 0; left -= 8) {
      g.add(left >= 8 ? 8 : left);
    }
    return g;
  }
}

/// One console model on the mixer picker.
class MixerModel {
  const MixerModel({
    required this.id,
    required this.brand,
    required this.name,
    required this.family,
    required this.art,
    required this.info,
    this.model,
  });

  /// Stable key (photos are stored under it).
  final String id;
  final String brand;
  final String name;
  final MixerFamily family;
  final ArtSpec art;

  /// Short line under the name (channels, buses…).
  final String info;

  /// Model id the driver needs (Allen & Heath) or the demo should size to.
  final String? model;
}

class MixerCatalog {
  static const brands = ['Allen & Heath', 'Behringer', 'Midas', 'PreSonus', 'TASCAM', 'Yamaha'];

  /// Which model's drawing stands for the brand on its tile (index in [of]).
  static const showcase = {'Allen & Heath': 0, 'Behringer': 0, 'Midas': 0, 'PreSonus': 2, 'TASCAM': 1, 'Yamaha': 2};

  /// Brand colour: rim light on the drawings and the glow of the tiles.
  static const _accents = {
    'Allen & Heath': Color(0xFFA855F7),
    'Behringer': Color(0xFFF59E0B),
    'Midas': Color(0xFFF7B731),
    'PreSonus': Color(0xFF4F9BFF),
    'TASCAM': Color(0xFF22D3EE),
    'Yamaha': Color(0xFF3E8EF7),
  };
  static Color accentOf(String brand) => _accents[brand] ?? const Color(0xFF3E8EF7);
  static Color accentOfFamily(MixerFamily? f) => switch (f) {
        MixerFamily.x32 || MixerFamily.xr || MixerFamily.wing => _accents['Behringer']!,
        MixerFamily.yamaha => _accents['Yamaha']!,
        MixerFamily.allenHeath => _accents['Allen & Heath']!,
        MixerFamily.tascam => _accents['TASCAM']!,
        MixerFamily.presonus => _accents['PreSonus']!,
        null => const Color(0xFF3E8EF7),
      };

  /// Series line under the brand on its tile.
  static const series = {
    'Allen & Heath': 'SQ · CQ · Qu · Avantis · dLive',
    'Behringer': 'X32 · XR · WING',
    'Midas': 'M32 · MR',
    'PreSonus': 'StudioLive',
    'TASCAM': 'Sonicview 16 · 24',
    'Yamaha': 'TF · DM · QL · CL',
  };

  static List<MixerModel> of(String brand) => [for (final m in all) if (m.brand == brand) m];

  static MixerModel? byId(String id) {
    for (final m in all) {
      if (m.id == id) return m;
    }
    return null;
  }

  /// The catalog entry for a model name a console reports (discovery, /xinfo).
  static MixerModel? match(String reported) {
    final r = reported.toUpperCase().replaceAll(RegExp(r'[\s_-]'), '');
    String? id;
    if (r.contains('XR12')) id = 'behringer_xr12';
    if (r.contains('XR16')) id = 'behringer_xr16';
    if (r.contains('XR18') || r == 'X18') id = 'behringer_xr18';
    if (r.contains('MR12')) id = 'midas_mr12';
    if (r.contains('MR18')) id = 'midas_mr18';
    if (r.contains('X32')) {
      id = r.contains('RACK')
          ? 'behringer_x32rack'
          : r.contains('COMPACT')
              ? 'behringer_x32compact'
              : r.contains('PRODUCER')
                  ? 'behringer_x32producer'
                  : 'behringer_x32';
    }
    if (r.contains('M32')) id = r.contains('M32C') ? 'midas_m32c' : (r.contains('M32R') ? 'midas_m32r' : 'midas_m32');
    if (r.contains('WING')) id = r.contains('RACK') ? 'behringer_wingrack' : (r.contains('COMPACT') ? 'behringer_wingcompact' : 'behringer_wing');
    return id == null ? null : byId(id);
  }

  static const all = <MixerModel>[
    // ---------------------------------------------------------------- Allen & Heath
    // SQ: 7" touch screen right of centre, processing keys/knobs to its left
    MixerModel(id: 'ah_sq5', brand: 'Allen & Heath', name: 'SQ-5', family: MixerFamily.allenHeath, model: 'SQ',
        info: '48 ch · 12 mix · 3 matrix',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.20, screenAt: 0.66, block: ArtBlock.left, size: 0.80, tone: ArtTone.black)),
    MixerModel(id: 'ah_sq6', brand: 'Allen & Heath', name: 'SQ-6', family: MixerFamily.allenHeath, model: 'SQ',
        info: '48 ch · 12 mix · 3 matrix',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, screen: 0.17, screenAt: 0.68, block: ArtBlock.left, size: 0.92, tone: ArtTone.black)),
    MixerModel(id: 'ah_sq7', brand: 'Allen & Heath', name: 'SQ-7', family: MixerFamily.allenHeath, model: 'SQ',
        info: '48 ch · 12 mix · 3 matrix',
        art: ArtSpec(ArtKind.touchDesk, faders: 32, screen: 0.14, screenAt: 0.70, block: ArtBlock.left, tone: ArtTone.black)),
    // CQ: no faders: a tablet-style touch screen, a few encoders, side handles
    MixerModel(id: 'ah_cq12t', brand: 'Allen & Heath', name: 'CQ-12T', family: MixerFamily.allenHeath, model: 'CQ',
        info: '16 ch · 6 out · touch only',
        art: ArtSpec(ArtKind.touchDesk, faders: 0, masters: 0, screen: 0.56, encoders: 4, size: 0.55, tone: ArtTone.graphite)),
    MixerModel(id: 'ah_cq18t', brand: 'Allen & Heath', name: 'CQ-18T', family: MixerFamily.allenHeath, model: 'CQ',
        info: '16 ch · 6 out · touch only',
        art: ArtSpec(ArtKind.touchDesk, faders: 0, masters: 0, screen: 0.56, encoders: 4, antenna: true, size: 0.65, tone: ArtTone.graphite)),
    MixerModel(id: 'ah_cq20b', brand: 'Allen & Heath', name: 'CQ-20B', family: MixerFamily.allenHeath, model: 'CQ',
        info: '16 ch · 6 out · stage box',
        art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [8, 8], outs: 6, antenna: true, size: 0.8, tone: ArtTone.graphite)),
    // Qu: touch screen top right, SuperStrip knobs on the left
    MixerModel(id: 'ah_qu16', brand: 'Allen & Heath', name: 'Qu-16', family: MixerFamily.allenHeath, model: 'QU16',
        info: '16 ch · 7 mix · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.18, screenAt: 0.78, block: ArtBlock.left, size: 0.80, rightCol: true, tone: ArtTone.silver)),
    MixerModel(id: 'ah_qu24', brand: 'Allen & Heath', name: 'Qu-24', family: MixerFamily.allenHeath, model: 'QU24',
        info: '24 ch · 7 mix · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, screen: 0.15, screenAt: 0.80, block: ArtBlock.left, size: 0.92, rightCol: true, tone: ArtTone.silver)),
    MixerModel(id: 'ah_qu32', brand: 'Allen & Heath', name: 'Qu-32', family: MixerFamily.allenHeath, model: 'QU32',
        info: '32 ch · 7 mix · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 32, screen: 0.13, screenAt: 0.82, block: ArtBlock.left, rightCol: true, tone: ArtTone.silver)),
    MixerModel(id: 'ah_qusb', brand: 'Allen & Heath', name: 'Qu-SB', family: MixerFamily.allenHeath, model: 'QU32',
        info: '32 ch · stage box', art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [8, 8], outs: 8, tone: ArtTone.silver)),
    MixerModel(id: 'ah_qupac', brand: 'Allen & Heath', name: 'Qu-Pac', family: MixerFamily.allenHeath, model: 'QU32',
        info: '32 ch · compact rack', art: ArtSpec(ArtKind.rack, units: 4, screens: 1, screen: 0.26, jacks: 16, tone: ArtTone.silver)),
    // dLive surface / Avantis: two big screens, one over each bank of 12
    MixerModel(id: 'ah_dlive', brand: 'Allen & Heath', name: 'dLive', family: MixerFamily.allenHeath, model: 'DLIVE',
        info: '128 ch · MixRack + surface',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, bays: [12, 12], masters: 0, screens: 2, screen: 0.34,
            screenBays: [0, 1], chKnobs: true, meters: true, tone: ArtTone.charcoal, bridge: true, raised: true)),
    MixerModel(id: 'ah_avantis', brand: 'Allen & Heath', name: 'Avantis', family: MixerFamily.allenHeath, model: 'AVANTIS',
        info: '64 ch · 42 bus',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, bays: [12, 12], masters: 1, screens: 2, screen: 0.38,
            screenBays: [0, 1], chKnobs: true, size: 0.95, tone: ArtTone.graphite, raised: true)),

    // ---------------------------------------------------------------- Behringer
    // X32 family: big channel-strip block on the left, small screen top right,
    // input banks, a bus bank and the main fader
    MixerModel(id: 'behringer_x32', brand: 'Behringer', name: 'X32', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · 8 FX',
        art: ArtSpec(ArtKind.desk, faders: 24, bays: [8, 8, 8], masters: 1, screen: 0.13, screenAt: 0.72,
            block: ArtBlock.left, meters: true, tone: ArtTone.graphite)),
    MixerModel(id: 'behringer_x32compact', brand: 'Behringer', name: 'X32 Compact', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · 8 FX',
        art: ArtSpec(ArtKind.desk, faders: 16, masters: 1, screen: 0.18, screenAt: 0.74, block: ArtBlock.left,
            meters: true, size: 0.78, rightCol: true, tone: ArtTone.graphite)),
    MixerModel(id: 'behringer_x32producer', brand: 'Behringer', name: 'X32 Producer', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · 8 FX',
        art: ArtSpec(ArtKind.desk, faders: 16, masters: 1, screen: 0.20, screenAt: 0.76, block: ArtBlock.left, size: 0.68, rightCol: true, tone: ArtTone.graphite)),
    MixerModel(id: 'behringer_x32rack', brand: 'Behringer', name: 'X32 Rack', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · rack', art: ArtSpec(ArtKind.rack, units: 3, screen: 0.22, jacks: 16, tone: ArtTone.graphite)),
    // X Air: front panel with handles, input rows, outputs and a Wi-Fi antenna
    MixerModel(id: 'behringer_xr12', brand: 'Behringer', name: 'X Air XR12', family: MixerFamily.xr, model: 'XR12',
        info: '12 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [4, 8], outs: 4, antenna: true, size: 0.70, lineRow: true, tone: ArtTone.black)),
    MixerModel(id: 'behringer_xr16', brand: 'Behringer', name: 'X Air XR16', family: MixerFamily.xr, model: 'XR16',
        info: '16 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [8, 8], outs: 6, antenna: true, size: 0.82, lineRow: true, tone: ArtTone.black)),
    MixerModel(id: 'behringer_xr18', brand: 'Behringer', name: 'X Air XR18', family: MixerFamily.xr, model: 'XR18',
        info: '18 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [8, 8], outs: 8, antenna: true, tone: ArtTone.black)),
    // WING: 10" swivel screen in the middle, banks of 12 either side
    MixerModel(id: 'behringer_wing', brand: 'Behringer', name: 'WING', family: MixerFamily.wing, model: 'WING',
        info: '40 ch · 16 bus · 8 matrix',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, bays: [12, 12], masters: 1, screen: 0.30, raised: true,
            block: ArtBlock.both, tone: ArtTone.black)),
    MixerModel(id: 'behringer_wingcompact', brand: 'Behringer', name: 'WING Compact', family: MixerFamily.wing,
        model: 'WING Compact', info: '40 ch · 16 bus · 8 matrix',
        art: ArtSpec(ArtKind.touchDesk, faders: 12, bays: [12], masters: 1, screen: 0.40, screenAt: 0.60, raised: true,
            block: ArtBlock.left, size: 0.80, tone: ArtTone.black)),
    MixerModel(id: 'behringer_wingrack', brand: 'Behringer', name: 'WING Rack', family: MixerFamily.wing, model: 'WING Rack',
        info: '40 ch · 16 bus · rack', art: ArtSpec(ArtKind.rack, units: 3, screen: 0.34, jacks: 8, tone: ArtTone.black)),

    // ---------------------------------------------------------------- Midas
    MixerModel(id: 'midas_m32', brand: 'Midas', name: 'M32 / M32 Live', family: MixerFamily.x32, model: 'M32',
        info: '32 ch · 16 bus · 8 FX',
        art: ArtSpec(ArtKind.desk, faders: 24, bays: [8, 8, 8], masters: 1, screen: 0.13, screenAt: 0.74,
            block: ArtBlock.left, meters: true, tone: ArtTone.charcoal)),
    MixerModel(id: 'midas_m32r', brand: 'Midas', name: 'M32R / M32R Live', family: MixerFamily.x32, model: 'M32R',
        info: '32 ch · 16 bus · 8 FX',
        art: ArtSpec(ArtKind.desk, faders: 16, masters: 1, screen: 0.20, screenAt: 0.76, block: ArtBlock.left, size: 0.72, rightCol: true, tone: ArtTone.charcoal)),
    MixerModel(id: 'midas_m32c', brand: 'Midas', name: 'M32C', family: MixerFamily.x32, model: 'M32C',
        info: '32 ch · 16 bus · rack', art: ArtSpec(ArtKind.rack, units: 1, screens: 0, jacks: 0, tone: ArtTone.charcoal)),
    MixerModel(id: 'midas_mr12', brand: 'Midas', name: 'MR12', family: MixerFamily.xr, model: 'MR12',
        info: '12 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [4, 8], outs: 4, antenna: true, size: 0.70, lineRow: true, tone: ArtTone.charcoal)),
    MixerModel(id: 'midas_mr18', brand: 'Midas', name: 'MR18', family: MixerFamily.xr, model: 'MR18',
        info: '18 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, screens: 0, rows: [8, 8], outs: 8, antenna: true, tone: ArtTone.charcoal)),

    // ---------------------------------------------------------------- PreSonus
    // StudioLive III: Fat Channel knob block left, touch screen in the middle
    MixerModel(id: 'presonus_16', brand: 'PreSonus', name: 'StudioLive 16', family: MixerFamily.presonus,
        model: 'StudioLive 16', info: '16 ch · 8 aux · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 1, screen: 0.18, screenAt: 0.58, block: ArtBlock.left, size: 0.8, tone: ArtTone.navy)),
    MixerModel(id: 'presonus_24', brand: 'PreSonus', name: 'StudioLive 24', family: MixerFamily.presonus,
        model: 'StudioLive 24', info: '24 ch · 16 aux · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 1, screen: 0.15, screenAt: 0.56, block: ArtBlock.left, size: 0.92, tone: ArtTone.navy)),
    MixerModel(id: 'presonus_32', brand: 'PreSonus', name: 'StudioLive 32', family: MixerFamily.presonus,
        model: 'StudioLive 32', info: '32 ch · 16 aux · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 32, masters: 1, screen: 0.13, screenAt: 0.55, block: ArtBlock.left, tone: ArtTone.navy)),
    // the S models: input banks, the master in the middle, a bank of 8 on the right
    MixerModel(id: 'presonus_32s', brand: 'PreSonus', name: 'StudioLive 32S / 32SC / 32SX', family: MixerFamily.presonus,
        model: 'StudioLive 32', info: '32 ch · 16 aux · compact',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 1, tail: 8, screen: 0.16, screenAt: 0.58,
            block: ArtBlock.left, size: 0.84, tone: ArtTone.navy)),
    MixerModel(id: 'presonus_64s', brand: 'PreSonus', name: 'StudioLive 64S', family: MixerFamily.presonus,
        model: 'StudioLive 64S', info: '64 ch · 32 aux · 8 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 1, tail: 8, screen: 0.14, screenAt: 0.56,
            block: ArtBlock.left, tone: ArtTone.navy)),
    MixerModel(id: 'presonus_rack', brand: 'PreSonus', name: 'StudioLive 16R / 24R / 32R', family: MixerFamily.presonus,
        model: 'StudioLive 32', info: 'rack · up to 32 ch', art: ArtSpec(ArtKind.rack, units: 3, screens: 0, jacks: 16, tone: ArtTone.navy)),

    // ---------------------------------------------------------------- TASCAM
    // Sonicview: one 7" touch screen above each bank of 8
    MixerModel(id: 'tascam_sv16', brand: 'TASCAM', name: 'Sonicview 16', family: MixerFamily.tascam, model: 'Sonicview 16',
        info: '40 ch · 22 mix · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 1, screens: 2, screen: 0.30, screenBays: [0, 1],
            block: ArtBlock.right, size: 0.85, tone: ArtTone.black)),
    MixerModel(id: 'tascam_sv24', brand: 'TASCAM', name: 'Sonicview 24', family: MixerFamily.tascam, model: 'Sonicview 24',
        info: '40 ch · 22 mix · 4 FX',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 1, screens: 3, screen: 0.22, screenBays: [0, 1, 2],
            block: ArtBlock.right, tone: ArtTone.black)),

    // ---------------------------------------------------------------- Yamaha
    // TF: touch screen left of centre with the Touch and Turn knob beside it
    MixerModel(id: 'yamaha_tf1', brand: 'Yamaha', name: 'TF1', family: MixerFamily.yamaha, model: 'TF1',
        info: '16 faders · 20 aux',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.22, screenAt: 0.42, block: ArtBlock.right, size: 0.78, look: 'tf', aspect: 0.97, tone: ArtTone.silver)),
    MixerModel(id: 'yamaha_tf3', brand: 'Yamaha', name: 'TF3', family: MixerFamily.yamaha, model: 'TF3',
        info: '24 faders · 20 aux',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, screen: 0.18, screenAt: 0.40, block: ArtBlock.right, size: 0.9, look: 'tf', aspect: 1.17, tone: ArtTone.silver)),
    MixerModel(id: 'yamaha_tf5', brand: 'Yamaha', name: 'TF5', family: MixerFamily.yamaha, model: 'TF5',
        info: '32 faders · 20 aux',
        art: ArtSpec(ArtKind.touchDesk, faders: 32, screen: 0.15, screenAt: 0.40, block: ArtBlock.right, look: 'tf', aspect: 1.37, tone: ArtTone.silver)),
    MixerModel(id: 'yamaha_tfrack', brand: 'Yamaha', name: 'TF-RACK', family: MixerFamily.yamaha, model: 'TF5',
        info: '40 ch · 20 aux · rack', art: ArtSpec(ArtKind.rack, units: 3, screen: 0.30, jacks: 16, look: 'tfrack', tone: ArtTone.black)),
    // DM3: 8 faders on the left, a large screen on the right
    MixerModel(id: 'yamaha_dm3', brand: 'Yamaha', name: 'DM3 / DM3 Standard', family: MixerFamily.yamaha, model: 'DM3',
        info: '16 ch · 6 mix',
        art: ArtSpec(ArtKind.touchDesk, faders: 8, masters: 1, screen: 0.44, screenAt: 0.68, size: 0.62, look: 'dm3', aspect: 1.02, tone: ArtTone.black)),
    // DM7: a 12" screen above each bank of 12, knob over every channel
    MixerModel(id: 'yamaha_dm7', brand: 'Yamaha', name: 'DM7', family: MixerFamily.yamaha, model: 'DM7',
        info: '72 ch · 48 mix',
        art: ArtSpec(ArtKind.touchDesk, faders: 24, bays: [12, 12], masters: 0, screens: 2, screen: 0.36,
            screenBays: [0, 1], chKnobs: true, look: 'dm7', aspect: 1.95, tone: ArtTone.black)),
    MixerModel(id: 'yamaha_dm7c', brand: 'Yamaha', name: 'DM7 Compact', family: MixerFamily.yamaha, model: 'DM7',
        info: '72 ch · 48 mix',
        art: ArtSpec(ArtKind.touchDesk, faders: 12, bays: [12], masters: 0, screens: 1, screen: 0.62,
            screenBays: [0], chKnobs: true, block: ArtBlock.right, size: 0.78, look: 'dm7c', aspect: 0.98, tone: ArtTone.black)),
    // QL: screen in the middle, Selected Channel knobs on the left, meters per channel
    MixerModel(id: 'yamaha_ql1', brand: 'Yamaha', name: 'QL1', family: MixerFamily.yamaha, model: 'QL1',
        info: '32 ch · 16 mix',
        art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 2, screen: 0.24, screenAt: 0.58, block: ArtBlock.left,
            chKnobs: true, meters: true, size: 0.78, look: 'ql', aspect: 1.05, tone: ArtTone.charcoal)),
    MixerModel(id: 'yamaha_ql5', brand: 'Yamaha', name: 'QL5', family: MixerFamily.yamaha, model: 'QL5',
        info: '64 ch · 16 mix',
        art: ArtSpec(ArtKind.touchDesk, faders: 32, masters: 2, screen: 0.18, screenAt: 0.56, block: ArtBlock.left,
            chKnobs: true, meters: true, look: 'ql', aspect: 1.5, tone: ArtTone.charcoal)),
    // CL: input banks on the left, the Centralogic bank under the screen
    MixerModel(id: 'yamaha_cl1', brand: 'Yamaha', name: 'CL1', family: MixerFamily.yamaha, model: 'CL1',
        info: '48 ch · 24 mix',
        art: ArtSpec(ArtKind.touchDesk, bays: [8, 8], tail: 0, look: 'cl', aspect: 1.22, faders: 16, masters: 2, screen: 0.30, screenBays: [1], block: ArtBlock.left,
            chKnobs: true, meters: true, size: 0.78, tone: ArtTone.black, bridge: true)),
    MixerModel(id: 'yamaha_cl3', brand: 'Yamaha', name: 'CL3', family: MixerFamily.yamaha, model: 'CL3',
        info: '64 ch · 24 mix',
        art: ArtSpec(ArtKind.touchDesk, bays: [8, 8, 8], tail: 0, look: 'cl', aspect: 1.6, faders: 24, masters: 2, screen: 0.24, screenBays: [2], block: ArtBlock.left,
            chKnobs: true, meters: true, size: 0.9, tone: ArtTone.black, bridge: true)),
    MixerModel(id: 'yamaha_cl5', brand: 'Yamaha', name: 'CL5', family: MixerFamily.yamaha, model: 'CL5',
        info: '72 ch · 24 mix',
        art: ArtSpec(ArtKind.touchDesk, bays: [8, 8, 8], tail: 8, look: 'cl', aspect: 1.95, faders: 24, masters: 2, screen: 0.20, screenBays: [3], block: ArtBlock.left,
            chKnobs: true, meters: true, tone: ArtTone.black, bridge: false)),
  ];
}
