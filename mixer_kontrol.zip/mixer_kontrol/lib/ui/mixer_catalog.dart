import '../mixer/mixer_profile.dart';

/// Kind of hardware, for the illustrations.
enum ArtKind { desk, rack, stagebox, touchDesk }

/// What a model's (original, generic) illustration shows: its form and the
/// controls that tell it apart. Never a copy of the real product.
class ArtSpec {
  const ArtSpec(
    this.kind, {
    this.faders = 8,
    this.masters = 1,
    this.screens = 1,
    this.screen = 0.20,
    this.size = 1.0,
    this.jacks = 12,
    this.units = 2,
  });

  final ArtKind kind;

  /// Channel faders and master faders on the surface.
  final int faders;
  final int masters;

  /// Number of screens and the width of each (fraction of the body; 0 = none).
  final int screens;
  final double screen;

  /// Relative width of the body (small desks look smaller).
  final double size;

  /// Input sockets (stage boxes, racks).
  final int jacks;

  /// Rack height in units.
  final int units;
}

/// One console model on the mixer picker.
class MixerModel {
  const MixerModel({
    required this.id,
    required this.brand,
    required this.name,
    required this.family,
    required this.art,
    required this.info,
    this.model,
  });

  /// Stable key (photos are stored under it).
  final String id;
  final String brand;
  final String name;
  final MixerFamily family;
  final ArtSpec art;

  /// Short line under the name (channels, buses…).
  final String info;

  /// Model id the driver needs (Allen & Heath) or the demo should size to.
  final String? model;
}

class MixerCatalog {
  static const brands = ['Allen & Heath', 'Behringer', 'Midas', 'PreSonus', 'TASCAM', 'Yamaha'];

  /// Which model's drawing stands for the brand on its tile (index in [of]).
  static const showcase = {'Allen & Heath': 0, 'Behringer': 0, 'Midas': 0, 'PreSonus': 2, 'TASCAM': 1, 'Yamaha': 2};

  static List<MixerModel> of(String brand) => [for (final m in all) if (m.brand == brand) m];

  static MixerModel? byId(String id) {
    for (final m in all) {
      if (m.id == id) return m;
    }
    return null;
  }

  /// The catalog entry for a model name a console reports (discovery, /xinfo).
  static MixerModel? match(String reported) {
    final r = reported.toUpperCase().replaceAll(RegExp(r'[\s_-]'), '');
    String? id;
    if (r.contains('XR12')) id = 'behringer_xr12';
    if (r.contains('XR16')) id = 'behringer_xr16';
    if (r.contains('XR18') || r == 'X18') id = 'behringer_xr18';
    if (r.contains('MR12')) id = 'midas_mr12';
    if (r.contains('MR18')) id = 'midas_mr18';
    if (r.contains('X32')) {
      id = r.contains('RACK')
          ? 'behringer_x32rack'
          : r.contains('COMPACT')
              ? 'behringer_x32compact'
              : r.contains('PRODUCER')
                  ? 'behringer_x32producer'
                  : 'behringer_x32';
    }
    if (r.contains('M32')) id = r.contains('M32C') ? 'midas_m32c' : (r.contains('M32R') ? 'midas_m32r' : 'midas_m32');
    if (r.contains('WING')) id = r.contains('RACK') ? 'behringer_wingrack' : (r.contains('COMPACT') ? 'behringer_wingcompact' : 'behringer_wing');
    return id == null ? null : byId(id);
  }

  static const all = <MixerModel>[
    // ---------------------------------------------------------------- Allen & Heath
    MixerModel(id: 'ah_sq5', brand: 'Allen & Heath', name: 'SQ-5', family: MixerFamily.allenHeath, model: 'SQ',
        info: '48 ch · 12 mix · 3 matrix', art: ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.24, size: 0.80)),
    MixerModel(id: 'ah_sq6', brand: 'Allen & Heath', name: 'SQ-6', family: MixerFamily.allenHeath, model: 'SQ',
        info: '48 ch · 12 mix · 3 matrix', art: ArtSpec(ArtKind.touchDesk, faders: 24, screen: 0.22, size: 0.92)),
    MixerModel(id: 'ah_sq7', brand: 'Allen & Heath', name: 'SQ-7', family: MixerFamily.allenHeath, model: 'SQ',
        info: '48 ch · 12 mix · 3 matrix', art: ArtSpec(ArtKind.touchDesk, faders: 32, screen: 0.20, size: 1.0)),
    MixerModel(id: 'ah_cq12t', brand: 'Allen & Heath', name: 'CQ-12T', family: MixerFamily.allenHeath, model: 'CQ',
        info: '16 ch · 6 out · touch only', art: ArtSpec(ArtKind.touchDesk, faders: 0, masters: 0, screen: 0.62, size: 0.62)),
    MixerModel(id: 'ah_cq18t', brand: 'Allen & Heath', name: 'CQ-18T', family: MixerFamily.allenHeath, model: 'CQ',
        info: '16 ch · 6 out', art: ArtSpec(ArtKind.touchDesk, faders: 8, masters: 1, screen: 0.40, size: 0.72)),
    MixerModel(id: 'ah_cq20b', brand: 'Allen & Heath', name: 'CQ-20B', family: MixerFamily.allenHeath, model: 'CQ',
        info: '16 ch · 6 out · stage box', art: ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0)),
    MixerModel(id: 'ah_qu16', brand: 'Allen & Heath', name: 'Qu-16', family: MixerFamily.allenHeath, model: 'QU16',
        info: '16 ch · 7 mix · 4 FX', art: ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.20, size: 0.80)),
    MixerModel(id: 'ah_qu24', brand: 'Allen & Heath', name: 'Qu-24', family: MixerFamily.allenHeath, model: 'QU24',
        info: '24 ch · 7 mix · 4 FX', art: ArtSpec(ArtKind.touchDesk, faders: 24, screen: 0.18, size: 0.92)),
    MixerModel(id: 'ah_qu32', brand: 'Allen & Heath', name: 'Qu-32', family: MixerFamily.allenHeath, model: 'QU32',
        info: '32 ch · 7 mix · 4 FX', art: ArtSpec(ArtKind.touchDesk, faders: 32, screen: 0.16, size: 1.0)),
    MixerModel(id: 'ah_qusb', brand: 'Allen & Heath', name: 'Qu-SB', family: MixerFamily.allenHeath, model: 'QU32',
        info: '32 ch · stage box', art: ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0)),
    MixerModel(id: 'ah_qupac', brand: 'Allen & Heath', name: 'Qu-Pac', family: MixerFamily.allenHeath, model: 'QU32',
        info: '32 ch · compact rack', art: ArtSpec(ArtKind.rack, units: 4, screens: 1, screen: 0.26, jacks: 16)),
    MixerModel(id: 'ah_dlive', brand: 'Allen & Heath', name: 'dLive', family: MixerFamily.allenHeath, model: 'DLIVE',
        info: '128 ch · MixRack + surface', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 0, screens: 2, screen: 0.30)),
    MixerModel(id: 'ah_avantis', brand: 'Allen & Heath', name: 'Avantis', family: MixerFamily.allenHeath, model: 'AVANTIS',
        info: '64 ch · 42 bus', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 0, screens: 2, screen: 0.32, size: 0.95)),

    // ---------------------------------------------------------------- Behringer
    MixerModel(id: 'behringer_x32', brand: 'Behringer', name: 'X32', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · 8 FX', art: ArtSpec(ArtKind.desk, faders: 16, masters: 9, screen: 0.14)),
    MixerModel(id: 'behringer_x32compact', brand: 'Behringer', name: 'X32 Compact', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · 8 FX', art: ArtSpec(ArtKind.desk, faders: 8, masters: 9, screen: 0.16, size: 0.78)),
    MixerModel(id: 'behringer_x32producer', brand: 'Behringer', name: 'X32 Producer', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · 8 FX', art: ArtSpec(ArtKind.desk, faders: 8, masters: 9, screen: 0.18, size: 0.68)),
    MixerModel(id: 'behringer_x32rack', brand: 'Behringer', name: 'X32 Rack', family: MixerFamily.x32, model: 'X32',
        info: '32 ch · 16 bus · rack', art: ArtSpec(ArtKind.rack, units: 3, screen: 0.22, jacks: 16)),
    MixerModel(id: 'behringer_xr12', brand: 'Behringer', name: 'X Air XR12', family: MixerFamily.xr, model: 'XR12',
        info: '12 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, jacks: 8, screens: 0, size: 0.78)),
    MixerModel(id: 'behringer_xr16', brand: 'Behringer', name: 'X Air XR16', family: MixerFamily.xr, model: 'XR16',
        info: '16 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, jacks: 10, screens: 0, size: 0.88)),
    MixerModel(id: 'behringer_xr18', brand: 'Behringer', name: 'X Air XR18', family: MixerFamily.xr, model: 'XR18',
        info: '18 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0)),
    MixerModel(id: 'behringer_wing', brand: 'Behringer', name: 'WING', family: MixerFamily.wing, model: 'WING',
        info: '40 ch · 16 bus · 8 matrix', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 1, screen: 0.30)),
    MixerModel(id: 'behringer_wingcompact', brand: 'Behringer', name: 'WING Compact', family: MixerFamily.wing,
        model: 'WING Compact', info: '40 ch · 16 bus · 8 matrix',
        art: ArtSpec(ArtKind.touchDesk, faders: 12, masters: 1, screen: 0.34, size: 0.8)),
    MixerModel(id: 'behringer_wingrack', brand: 'Behringer', name: 'WING Rack', family: MixerFamily.wing, model: 'WING Rack',
        info: '40 ch · 16 bus · rack', art: ArtSpec(ArtKind.rack, units: 3, screen: 0.34, jacks: 8)),

    // ---------------------------------------------------------------- Midas
    MixerModel(id: 'midas_m32', brand: 'Midas', name: 'M32 / M32 Live', family: MixerFamily.x32, model: 'M32',
        info: '32 ch · 16 bus · 8 FX', art: ArtSpec(ArtKind.desk, faders: 16, masters: 9, screen: 0.14)),
    MixerModel(id: 'midas_m32r', brand: 'Midas', name: 'M32R / M32R Live', family: MixerFamily.x32, model: 'M32R',
        info: '32 ch · 16 bus · 8 FX', art: ArtSpec(ArtKind.desk, faders: 8, masters: 9, screen: 0.18, size: 0.72)),
    MixerModel(id: 'midas_m32c', brand: 'Midas', name: 'M32C', family: MixerFamily.x32, model: 'M32C',
        info: '32 ch · 16 bus · rack', art: ArtSpec(ArtKind.rack, units: 3, screens: 0, jacks: 0)),
    MixerModel(id: 'midas_mr12', brand: 'Midas', name: 'MR12', family: MixerFamily.xr, model: 'MR12',
        info: '12 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, jacks: 8, screens: 0, size: 0.78)),
    MixerModel(id: 'midas_mr18', brand: 'Midas', name: 'MR18', family: MixerFamily.xr, model: 'MR18',
        info: '18 in · 6 bus · Wi-Fi', art: ArtSpec(ArtKind.stagebox, jacks: 16, screens: 0)),

    // ---------------------------------------------------------------- PreSonus
    MixerModel(id: 'presonus_16', brand: 'PreSonus', name: 'StudioLive 16', family: MixerFamily.presonus,
        model: 'StudioLive 16', info: '16 ch · 8 aux · 4 FX', art: ArtSpec(ArtKind.desk, faders: 16, masters: 1, screen: 0.16, size: 0.8)),
    MixerModel(id: 'presonus_24', brand: 'PreSonus', name: 'StudioLive 24', family: MixerFamily.presonus,
        model: 'StudioLive 24', info: '24 ch · 16 aux · 4 FX', art: ArtSpec(ArtKind.desk, faders: 24, masters: 1, screen: 0.15, size: 0.92)),
    MixerModel(id: 'presonus_32', brand: 'PreSonus', name: 'StudioLive 32', family: MixerFamily.presonus,
        model: 'StudioLive 32', info: '32 ch · 16 aux · 4 FX', art: ArtSpec(ArtKind.desk, faders: 32, masters: 1, screen: 0.14)),
    MixerModel(id: 'presonus_32s', brand: 'PreSonus', name: 'StudioLive 32S / 32SC / 32SX', family: MixerFamily.presonus,
        model: 'StudioLive 32', info: '32 ch · 16 aux · compact', art: ArtSpec(ArtKind.desk, faders: 16, masters: 1, screen: 0.16, size: 0.8)),
    MixerModel(id: 'presonus_64s', brand: 'PreSonus', name: 'StudioLive 64S', family: MixerFamily.presonus,
        model: 'StudioLive 64S', info: '64 ch · 32 aux · 8 FX', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 1, screen: 0.18)),
    MixerModel(id: 'presonus_rack', brand: 'PreSonus', name: 'StudioLive 16R / 24R / 32R', family: MixerFamily.presonus,
        model: 'StudioLive 32', info: 'rack · up to 32 ch', art: ArtSpec(ArtKind.rack, units: 3, screens: 0, jacks: 16)),

    // ---------------------------------------------------------------- TASCAM
    MixerModel(id: 'tascam_sv16', brand: 'TASCAM', name: 'Sonicview 16', family: MixerFamily.tascam, model: 'Sonicview 16',
        info: '40 ch · 22 mix · 4 FX', art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 1, screen: 0.32, size: 0.85)),
    MixerModel(id: 'tascam_sv24', brand: 'TASCAM', name: 'Sonicview 24', family: MixerFamily.tascam, model: 'Sonicview 24',
        info: '40 ch · 22 mix · 4 FX', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 1, screens: 2, screen: 0.24)),

    // ---------------------------------------------------------------- Yamaha
    MixerModel(id: 'yamaha_tf1', brand: 'Yamaha', name: 'TF1', family: MixerFamily.yamaha, model: 'TF1',
        info: '16 faders · 20 aux', art: ArtSpec(ArtKind.touchDesk, faders: 16, screen: 0.22, size: 0.78)),
    MixerModel(id: 'yamaha_tf3', brand: 'Yamaha', name: 'TF3', family: MixerFamily.yamaha, model: 'TF3',
        info: '24 faders · 20 aux', art: ArtSpec(ArtKind.touchDesk, faders: 24, screen: 0.20, size: 0.9)),
    MixerModel(id: 'yamaha_tf5', brand: 'Yamaha', name: 'TF5', family: MixerFamily.yamaha, model: 'TF5',
        info: '32 faders · 20 aux', art: ArtSpec(ArtKind.touchDesk, faders: 32, screen: 0.18)),
    MixerModel(id: 'yamaha_tfrack', brand: 'Yamaha', name: 'TF-RACK', family: MixerFamily.yamaha, model: 'TF5',
        info: '40 ch · 20 aux · rack', art: ArtSpec(ArtKind.rack, units: 3, screen: 0.30, jacks: 16)),
    MixerModel(id: 'yamaha_dm3', brand: 'Yamaha', name: 'DM3 / DM3 Standard', family: MixerFamily.yamaha, model: 'DM3',
        info: '16 ch · 6 mix', art: ArtSpec(ArtKind.touchDesk, faders: 8, masters: 1, screen: 0.40, size: 0.66)),
    MixerModel(id: 'yamaha_dm7', brand: 'Yamaha', name: 'DM7', family: MixerFamily.yamaha, model: 'DM7',
        info: '72 ch · 48 mix', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 0, screens: 2, screen: 0.30)),
    MixerModel(id: 'yamaha_dm7c', brand: 'Yamaha', name: 'DM7 Compact', family: MixerFamily.yamaha, model: 'DM7',
        info: '72 ch · 48 mix', art: ArtSpec(ArtKind.touchDesk, faders: 12, masters: 0, screens: 1, screen: 0.40, size: 0.8)),
    MixerModel(id: 'yamaha_ql1', brand: 'Yamaha', name: 'QL1', family: MixerFamily.yamaha, model: 'QL1',
        info: '32 ch · 16 mix', art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 2, screen: 0.22, size: 0.78)),
    MixerModel(id: 'yamaha_ql5', brand: 'Yamaha', name: 'QL5', family: MixerFamily.yamaha, model: 'QL5',
        info: '64 ch · 16 mix', art: ArtSpec(ArtKind.touchDesk, faders: 32, masters: 2, screen: 0.18)),
    MixerModel(id: 'yamaha_cl1', brand: 'Yamaha', name: 'CL1', family: MixerFamily.yamaha, model: 'CL1',
        info: '48 ch · 24 mix', art: ArtSpec(ArtKind.touchDesk, faders: 16, masters: 2, screen: 0.22, size: 0.78)),
    MixerModel(id: 'yamaha_cl3', brand: 'Yamaha', name: 'CL3', family: MixerFamily.yamaha, model: 'CL3',
        info: '64 ch · 24 mix', art: ArtSpec(ArtKind.touchDesk, faders: 24, masters: 2, screen: 0.20, size: 0.9)),
    MixerModel(id: 'yamaha_cl5', brand: 'Yamaha', name: 'CL5', family: MixerFamily.yamaha, model: 'CL5',
        info: '72 ch · 24 mix', art: ArtSpec(ArtKind.touchDesk, faders: 32, masters: 2, screen: 0.18)),
  ];
}
