import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import '../mixer/user_layers.dart';
import 'app_style.dart';
import 'channel_strip.dart' show stripColor;

/// Create, rename, fill and delete custom fader layers.
class LayersScreen extends StatefulWidget {
  const LayersScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<LayersScreen> createState() => _LayersScreenState();
}

class _LayersScreenState extends State<LayersScreen> {
  MixerController get c => widget.controller;
  List<UserLayer> _layers = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    UserLayerStore.load(c.profile.family).then((l) {
      if (!mounted) return;
      setState(() {
        _layers = l;
        _loaded = true;
      });
    });
  }

  Future<void> _save() => UserLayerStore.save(c.profile.family, _layers);

  Future<String?> _askName(String initial) {
    final t = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Layer name'),
        content: TextField(controller: t, autofocus: true, maxLength: 24),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, t.text.trim()), child: const Text('OK')),
        ],
      ),
    );
  }

  Future<void> _add() async {
    final name = await _askName('Layer ${_layers.length + 1}');
    if (name == null || name.isEmpty) return;
    final l = UserLayer(name, []);
    setState(() => _layers.add(l));
    await _save();
    if (mounted) await _edit(l);
  }

  Future<void> _edit(UserLayer l) async {
    final p = c.profile;
    final chosen = [...l.prefixes];
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(ctx).height * 0.85),
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                Text(l.name, style: Theme.of(ctx).textTheme.titleMedium),
                const Text('Tap strips in the order you want them (max 32).',
                    style: TextStyle(fontSize: 12, color: Colors.white54)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final s in p.allStrips)
                      FilterChip(
                        avatar: CircleAvatar(backgroundColor: stripColor(c.param(s.colorAddr).value), radius: 6),
                        label: Text(chosen.contains(s.prefix)
                            ? '${chosen.indexOf(s.prefix) + 1}. ${_label(s)}'
                            : _label(s)),
                        selected: chosen.contains(s.prefix),
                        onSelected: (v) => setLocal(() {
                          if (v && chosen.length < 32) {
                            chosen.add(s.prefix);
                          } else {
                            chosen.remove(s.prefix);
                          }
                        }),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    setState(() => l.prefixes = chosen);
    await _save();
  }

  String _label(Strip s) {
    final n = c.param(s.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n.trim() : s.defaultLabel;
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('My layers')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _layers.length >= 32 ? null : _add,
          icon: const Icon(Icons.add),
          label: const Text('New layer'),
        ),
        body: !_loaded
            ? const Center(child: CircularProgressIndicator())
            : _layers.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Build your own fader layers from any channels, buses and DCAs '
                        '(e.g. "Vocals" or "Drums"). They appear in the Layers tab.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white60),
                      ),
                    ),
                  )
                : ReorderableListView(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
                    onReorder: (a, b) {
                      setState(() {
                        if (b > a) b--;
                        _layers.insert(b, _layers.removeAt(a));
                      });
                      _save();
                    },
                    children: [
                      for (final l in _layers)
                        Container(
                          key: ObjectKey(l),
                          margin: const EdgeInsets.only(bottom: 6),
                          decoration: AppStyle.panel(),
                          child: ListTile(
                            title: Text(l.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(
                              l.stripsIn(c.profile).isEmpty
                                  ? 'Empty'
                                  : l.stripsIn(c.profile).map(_label).join(', '),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () => _edit(l),
                            trailing: PopupMenuButton<String>(
                              onSelected: (v) async {
                                if (v == 'rename') {
                                  final n = await _askName(l.name);
                                  if (n != null && n.isNotEmpty) {
                                    setState(() => l.name = n);
                                    await _save();
                                  }
                                } else if (v == 'delete') {
                                  setState(() => _layers.remove(l));
                                  await _save();
                                }
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(value: 'rename', child: Text('Rename')),
                                PopupMenuItem(value: 'delete', child: Text('Delete')),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
      ),
    );
  }
}
