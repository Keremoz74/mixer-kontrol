import 'package:flutter/material.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';

const busOptAccent = Color(0xFFF5A524);

const _tapHelp = [
  'Straight from the input (before low cut and EQ)',
  'After the low cut, before the EQ',
  'After the EQ, before the fader',
  'Independent of the channel faders: monitors / in-ears',
  'Follows the channel faders: effects, recording, zones',
  'Subgroup: the channel fader sets the level into the bus',
];

SendTarget? busTargetOf(MixerProfile p, Strip s) {
  for (final t in p.busTargets) {
    if (t.master.prefix == s.prefix) return t;
  }
  return null;
}

/// Small button under a bus strip: shows the send point (PRE / POST / GRP…)
/// and the stereo link; opens the bus options.
class BusOptionsButton extends StatelessWidget {
  const BusOptionsButton({super.key, required this.controller, required this.target, this.height = 30});
  final MixerController controller;
  final SendTarget target;
  final double height;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final p = c.profile;
    return ListenableBuilder(
      listenable: Listenable.merge([
        c.param(p.busLinkAddr(target.mixIndex)),
        for (final s in p.tapStrips) c.param(p.tapAddr(s, target.mixIndex)),
      ]),
      builder: (context, _) {
        final tap = c.busTap(target);
        final linked = c.busLinked(target);
        final text = tap == null ? '…' : (tap < 0 ? 'MIXED' : MixerController.tapShort[tap]);
        return Material(
          color: Colors.black.withValues(alpha: 0.35),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
            side: BorderSide(color: busOptAccent.withValues(alpha: 0.4)),
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => showBusOptions(context, c, target),
            child: SizedBox(
              height: height,
              width: double.infinity,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    child: Text(
                      text,
                      maxLines: 1,
                      overflow: TextOverflow.clip,
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: busOptAccent),
                    ),
                  ),
                  if (linked) ...[
                    const SizedBox(width: 3),
                    const Icon(Icons.link, size: 13, color: busOptAccent),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

Future<void> showBusOptions(BuildContext context, MixerController c, SendTarget t) {
  final p = c.profile;
  c.query([p.busLinkAddr(t.mixIndex), for (final s in p.tapStrips) p.tapAddr(s, t.mixIndex)]);
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF111724),
    showDragHandle: true,
    builder: (context) => _BusOptionsSheet(controller: c, target: t),
  );
}

class _BusOptionsSheet extends StatelessWidget {
  const _BusOptionsSheet({required this.controller, required this.target});
  final MixerController controller;
  final SendTarget target;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final p = c.profile;
    final a = p.pairStart(target.mixIndex);
    final pair = 'Bus $a-${a + 1}';
    final n = c.param(target.master.nameAddr).value;
    final title = n is String && n.trim().isNotEmpty ? '${n.trim()} (${target.label})' : target.label;
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.85),
        child: ListenableBuilder(
          listenable: Listenable.merge([
            c.param(p.busLinkAddr(target.mixIndex)),
            for (final s in p.tapStrips) c.param(p.tapAddr(s, target.mixIndex)),
          ]),
          builder: (context, _) {
            final tap = c.busTap(target);
            final linked = c.busLinked(target);
            return ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 14),
                const Text('Send point for all channels', style: TextStyle(fontWeight: FontWeight.w700)),
                if (p.tapPerPair)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      'On the X32 this is shared by $pair.',
                      style: const TextStyle(fontSize: 12, color: Colors.white54),
                    ),
                  ),
                if (tap == -1)
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text(
                      'Channels currently differ. Choosing one sets them all.',
                      style: TextStyle(fontSize: 12, color: busOptAccent),
                    ),
                  ),
                const SizedBox(height: 6),
                for (var i = 0; i < MixerController.tapLabels.length; i++)
                  Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    decoration: i == tap ? AppStyle.masterPanel(busOptAccent) : AppStyle.panel(),
                    child: ListTile(
                      dense: true,
                      leading: Icon(
                        i == tap ? Icons.radio_button_checked : Icons.radio_button_off,
                        color: i == tap ? busOptAccent : Colors.white38,
                      ),
                      title: Text(
                        MixerController.tapLabels[i],
                        style: TextStyle(fontWeight: i == 3 || i == 4 || i == 5 ? FontWeight.w700 : FontWeight.w500),
                      ),
                      subtitle: Text(_tapHelp[i], style: const TextStyle(fontSize: 11)),
                      onTap: () => c.setBusTap(target, i),
                    ),
                  ),
                const SizedBox(height: 8),
                Container(
                  decoration: AppStyle.panel(),
                  child: SwitchListTile(
                    activeTrackColor: busOptAccent,
                    secondary: Icon(linked ? Icons.link : Icons.link_off, color: linked ? busOptAccent : Colors.white54),
                    title: Text('Stereo link $pair'),
                    subtitle: Text(
                      linked
                          ? 'The two buses work as one stereo mix.'
                          : 'Each bus is a separate mono mix.',
                      style: const TextStyle(fontSize: 12),
                    ),
                    value: linked,
                    onChanged: (v) => c.setBusLinked(target, v),
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Each channel\'s send point can also be set on its own, in the channel\'s Sends tab.',
                  style: TextStyle(fontSize: 12, color: Colors.white54),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
