import 'package:flutter/material.dart';

import '../mixer/fx_catalog.dart';
import '../mixer/mixer_controller.dart';
import 'app_style.dart';
import 'param_controls.dart';

const fxAccent = Color(0xFFB57CFF);

/// FX rack: choose a slot, pick its effect, adjust its parameters.
class FxScreen extends StatefulWidget {
  const FxScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<FxScreen> createState() => _FxScreenState();
}

class _FxScreenState extends State<FxScreen> {
  int _slot = 1;
  bool _allParams = false;

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    final p = c.profile;
    c.query([for (var s = 1; s <= p.fxSlots; s++) p.fxTypeAddr(s)]);
    _querySlot(1);
  }

  void _querySlot(int slot) {
    final p = c.profile;
    c.query([
      p.fxTypeAddr(slot),
      for (var i = 1; i <= (_allParams ? fxParamsMax : fxParamsShown); i++) p.fxParAddr(slot, i),
    ]);
  }

  FxType? _typeOf(int slot) {
    final list = c.profile.fxTypesForSlot(slot);
    final v = c.param(c.profile.fxTypeAddr(slot)).value;
    if (v is! num) return null;
    final i = v.toInt();
    if (i < 0 || i >= list.length) return null;
    return fxCatalog[list[i]];
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    return AppBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('FX Rack')),
        body: SafeArea(
          top: false,
          child: Column(
            children: [
              SizedBox(
                height: 74,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: [
                    for (var s = 1; s <= p.fxSlots; s++)
                      Padding(
                        padding: const EdgeInsets.only(right: 8, bottom: 8),
                        child: ListenableBuilder(
                          listenable: c.param(p.fxTypeAddr(s)),
                          builder: (context, _) => _slotTile(s),
                        ),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: ListenableBuilder(
                  listenable: c.param(p.fxTypeAddr(_slot)),
                  builder: (context, _) => _slotPanel(_slot),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _slotTile(int slot) {
    final t = _typeOf(slot);
    final selected = slot == _slot;
    final insertOnly = c.profile.fxTypesForSlot(slot) == fxInsertList;
    return GestureDetector(
      onTap: () {
        setState(() => _slot = slot);
        _querySlot(slot);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: 132,
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? fxAccent.withValues(alpha: 0.20) : Colors.white.withValues(alpha: 0.05),
          border: Border.all(
            color: selected ? fxAccent : Colors.white.withValues(alpha: 0.10),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'FX $slot${insertOnly ? '  · insert' : ''}',
              style: TextStyle(fontSize: 11, color: selected ? fxAccent : Colors.white60, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 2),
            Text(
              t?.name ?? '—',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }

  Widget _slotPanel(int slot) {
    final p = c.profile;
    final t = _typeOf(slot);
    final count = _allParams ? fxParamsMax : fxParamsShown;
    return LayoutBuilder(builder: (context, cons) {
      final cols = cons.maxWidth >= 900 ? 3 : (cons.maxWidth >= 560 ? 2 : 1);
      return CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: AppStyle.masterPanel(fxAccent),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t == null ? 'FX $slot' : '${fxCategoryLabels[t.category]} · ${t.code}',
                            style: const TextStyle(fontSize: 12, color: Colors.white70),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            t?.name ?? 'Reading…',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                          ),
                        ],
                      ),
                    ),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: fxAccent, foregroundColor: Colors.black),
                      onPressed: () => _chooseType(slot),
                      icon: const Icon(Icons.swap_horiz),
                      label: const Text('Change'),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            sliver: SliverToBoxAdapter(
              child: Text(
                'Parameters are numbered in the order the console uses for this effect.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: cols,
                mainAxisExtent: 76,
                crossAxisSpacing: 10,
                mainAxisSpacing: 6,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, i) => Container(
                  padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
                  decoration: AppStyle.panel(),
                  child: ParamSlider(
                    controller: c,
                    addr: p.fxParAddr(slot, i + 1),
                    label: 'Parameter ${i + 1}',
                    color: fxAccent,
                    fallback: 0.5,
                    format: (n) => '${(n * 100).round()}%',
                  ),
                ),
                childCount: count,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
              child: TextButton.icon(
                onPressed: () {
                  setState(() => _allParams = !_allParams);
                  _querySlot(slot);
                },
                icon: Icon(_allParams ? Icons.expand_less : Icons.expand_more),
                label: Text(_allParams ? 'Show first $fxParamsShown parameters' : 'Show all $fxParamsMax parameters'),
              ),
            ),
          ),
        ],
      );
    });
  }

  Future<void> _chooseType(int slot) async {
    final p = c.profile;
    final list = p.fxTypesForSlot(slot);
    final current = _typeOf(slot);
    final picked = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111724),
      showDragHandle: true,
      builder: (context) {
        final byCat = <FxCategory, List<int>>{};
        for (var i = 0; i < list.length; i++) {
          final t = fxCatalog[list[i]];
          if (t != null) (byCat[t.category] ??= []).add(i);
        }
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          builder: (context, scroll) => ListView(
            controller: scroll,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              Text('Effect for FX $slot', style: Theme.of(context).textTheme.titleMedium),
              for (final cat in FxCategory.values)
                if (byCat[cat] != null) ...[
                  Padding(
                    padding: const EdgeInsets.only(top: 16, bottom: 8),
                    child: Text(
                      fxCategoryLabels[cat]!,
                      style: const TextStyle(fontSize: 12, color: Colors.white60, fontWeight: FontWeight.w700),
                    ),
                  ),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final i in byCat[cat]!)
                        ChoiceChip(
                          label: Text(fxCatalog[list[i]]!.name),
                          selected: current?.code == list[i],
                          selectedColor: fxAccent.withValues(alpha: 0.35),
                          onSelected: (_) => Navigator.pop(context, i),
                        ),
                    ],
                  ),
                ],
            ],
          ),
        );
      },
    );
    if (picked == null || !mounted) return;
    final newType = fxCatalog[list[picked]]!;
    if (current?.code == newType.code) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Load ${newType.name}?'),
        content: Text(
          'FX $slot${current == null ? '' : ' (${current.name})'} will be replaced and its settings reset.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Load')),
        ],
      ),
    );
    if (ok != true) return;
    c.set(p.fxTypeAddr(slot), picked);
    // The console resets the parameters for the new effect; read them back.
    Future<void>.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _querySlot(slot);
    });
  }
}
