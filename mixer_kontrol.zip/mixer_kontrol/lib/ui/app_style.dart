import 'package:flutter/material.dart';

/// Shared look: a deep console-blue background with soft light glows, and
/// "glass" panels for strips and cards.
class AppStyle {
  static const bgTop = Color(0xFF172033);
  static const bgBottom = Color(0xFF07090E);
  static const glowBlue = Color(0xFF3E8EF7);
  static const glowViolet = Color(0xFF8B5CF6);
  static const muteRed = Color(0xFFE5484D);

  /// Main LR gets its own colour so the master section never blends in.
  static const mainTeal = Color(0xFF19D3BD);

  /// Strongly tinted panel for the pinned master strip.
  static BoxDecoration masterPanel(Color c) => BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [c.withValues(alpha: 0.30), c.withValues(alpha: 0.07)],
        ),
        border: Border.all(color: c.withValues(alpha: 0.75), width: 1.5),
        boxShadow: [BoxShadow(color: c.withValues(alpha: 0.28), blurRadius: 16)],
      );

  static BoxDecoration panel({bool raised = false, Color? tint}) => BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color.lerp(Colors.white, tint, tint == null ? 0 : 0.5)!.withValues(alpha: raised ? 0.11 : 0.07),
            Colors.white.withValues(alpha: raised ? 0.04 : 0.02),
          ],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: raised ? 0.14 : 0.08)),
      );
}

/// Full-screen background used behind every page (set in MaterialApp.builder).
class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppStyle.bgTop, AppStyle.bgBottom],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Soft coloured light sources, like stage wash on a console surface.
          const _Glow(alignment: Alignment(0.9, -1.1), color: AppStyle.glowBlue, radius: 0.9),
          const _Glow(alignment: Alignment(-1.0, 1.2), color: AppStyle.glowViolet, radius: 0.8),
          child,
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  const _Glow({required this.alignment, required this.color, required this.radius});
  final Alignment alignment;
  final Color color;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: alignment,
            radius: radius,
            colors: [color.withValues(alpha: 0.22), color.withValues(alpha: 0)],
          ),
        ),
      ),
    );
  }
}
