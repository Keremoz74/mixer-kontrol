import 'package:flutter/material.dart';

import '../osc/meters.dart';

/// Segmented LED-style level meter (-60…0 dBFS). Repaints straight from
/// [levels] without rebuilding any widgets.
class MeterBar extends StatelessWidget {
  const MeterBar({
    super.key,
    required this.levels,
    required this.id,
    this.width = 6,
    this.inset = 22,
  });

  final MeterLevels levels;
  final String id;
  final double width;

  /// Top/bottom inset, so the meter lines up with the fader travel.
  final double inset;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox(
        width: width,
        child: CustomPaint(
          size: Size.infinite,
          painter: _MeterPainter(levels, id, inset),
        ),
      ),
    );
  }
}

class _MeterPainter extends CustomPainter {
  _MeterPainter(this.levels, this.id, this.inset) : super(repaint: levels);

  final MeterLevels levels;
  final String id;
  final double inset;

  static const _floor = -60.0;
  static const _green = Color(0xFF3DD68C);
  static const _yellow = Color(0xFFF5D90A);
  static const _red = Color(0xFFFF4D57);

  Color _colorFor(double db) => db >= -6 ? _red : (db >= -18 ? _yellow : _green);

  @override
  void paint(Canvas canvas, Size size) {
    final top = inset;
    final bottom = size.height - inset;
    final h = bottom - top;
    if (h <= 0) return;

    // Housing
    canvas.drawRRect(
      RRect.fromLTRBR(0, top - 2, size.width, bottom + 2, const Radius.circular(2)),
      Paint()..color = const Color(0xFF030406),
    );

    // LEDs: ~4 px each with a 1.5 px gap, unlit ones faintly visible.
    const seg = 4.0, gap = 1.5;
    final count = (h / (seg + gap)).floor().clamp(4, 200);
    final db = levels.db(id);
    final lit = db.isInfinite || db <= _floor ? 0.0 : ((db - _floor) / -_floor).clamp(0.0, 1.0);
    for (var i = 0; i < count; i++) {
      final frac = (i + 0.5) / count; // 0 at bottom
      final segDb = _floor + frac * -_floor;
      final y1 = bottom - i * (seg + gap);
      final r = Rect.fromLTRB(1, y1 - seg, size.width - 1, y1);
      final on = frac <= lit;
      final c = _colorFor(segDb);
      canvas.drawRect(r, Paint()..color = on ? c : c.withValues(alpha: 0.10));
    }

    // Clip indicator
    if (!db.isInfinite && db >= 0) {
      canvas.drawCircle(
        Offset(size.width / 2, top - 7),
        size.width / 2,
        Paint()
          ..color = _red
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
      );
    }
  }

  @override
  bool shouldRepaint(_MeterPainter old) => old.id != id || old.levels != levels || old.inset != inset;
}
