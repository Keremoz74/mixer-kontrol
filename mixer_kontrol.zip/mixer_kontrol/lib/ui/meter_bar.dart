import 'package:flutter/material.dart';

import '../osc/meters.dart';

/// Thin vertical level meter (-60..0 dBFS). Repaints straight from [levels]
/// without rebuilding any widgets.
class MeterBar extends StatelessWidget {
  const MeterBar({super.key, required this.levels, required this.id, this.width = 6});

  final MeterLevels levels;
  final String id;
  final double width;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return RepaintBoundary(
      child: SizedBox(
        width: width,
        child: CustomPaint(
          size: Size.infinite,
          painter: _MeterPainter(levels, id, scheme.surfaceContainerHighest),
        ),
      ),
    );
  }
}

class _MeterPainter extends CustomPainter {
  _MeterPainter(this.levels, this.id, this.bg) : super(repaint: levels);

  final MeterLevels levels;
  final String id;
  final Color bg;

  static const _floor = -60.0;
  static const _green = Color(0xFF46A758);
  static const _yellow = Color(0xFFF5D90A);
  static const _red = Color(0xFFE5484D);

  // Keep the meter inside the same vertical travel as the fader track.
  static const _inset = 22.0; // half the fader thumb height

  @override
  void paint(Canvas canvas, Size size) {
    final top = _inset;
    final bottom = size.height - _inset;
    final h = bottom - top;
    if (h <= 0) return;
    final r = Radius.circular(size.width / 2);

    canvas.drawRRect(RRect.fromLTRBR(0, top, size.width, bottom, r), Paint()..color = bg);

    final db = levels.db(id);
    if (db.isInfinite || db <= _floor) return;
    double y(double d) => bottom - ((d - _floor) / -_floor).clamp(0.0, 1.0) * h;

    final level = db.clamp(_floor, 0.0);
    void seg(double from, double to, Color c) {
      if (level <= from) return;
      canvas.drawRect(Rect.fromLTRB(0, y(level < to ? level : to), size.width, y(from)), Paint()..color = c);
    }

    canvas.save();
    canvas.clipRRect(RRect.fromLTRBR(0, top, size.width, bottom, r));
    seg(_floor, -18, _green);
    seg(-18, -6, _yellow);
    seg(-6, 0, _red);
    canvas.restore();

    // Clip indicator at the very top
    if (db >= 0) {
      canvas.drawCircle(Offset(size.width / 2, top - 6), size.width / 2, Paint()..color = _red);
    }
  }

  @override
  bool shouldRepaint(_MeterPainter old) => old.id != id || old.levels != levels || old.bg != bg;
}
