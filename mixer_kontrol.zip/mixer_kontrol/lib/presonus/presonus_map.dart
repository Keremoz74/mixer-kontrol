// Translation between the app's own (X32-style) addresses and the PreSonus
// StudioLive Series III "UCNet" parameter keys (line/ch1/volume …), as
// documented by the open-source presonus-studiolive-api (MIT) and real
// console state dumps.
//
// App → StudioLive: /ch/NN → line/chN, /auxin/NN → return/chN (Aux In),
// /fxrtn/NN → fxreturn/chN, /bus/NN → aux/chN, /fxsend/N → fxbus/chN,
// /main/st → main/ch1, /dca/N → filtergroup/chN, /config/mute/N →
// mutegroup/mutegroupN. Values on the wire are 0..1 floats.

import 'dart:math' as math;

import '../util/fader_math.dart';
import '../util/param_law.dart';

enum PresonusKind {
  fader,
  muteInv,
  onOff,
  name,
  color,
  norm, // 0..1 passed through (pan, EQ, dynamics)
  preampGain,
  gateMode,
  maskBit,
}

class PresonusParam {
  const PresonusParam(this.key, this.kind, {this.bit = 0});
  final String key;
  final PresonusKind kind;
  final int bit;
}

class PresonusLayout {
  const PresonusLayout({
    this.lines = 32,
    this.returns = 3,
    this.fxReturns = 4,
    this.auxes = 16,
    this.fxBuses = 4,
    this.dcas = 8,
    this.muteGroups = 8,
  });
  final int lines, returns, fxReturns, auxes, fxBuses, dcas, muteGroups;

  static const models = ['StudioLive 16', 'StudioLive 24', 'StudioLive 32', 'StudioLive 64S'];

  factory PresonusLayout.forModel(String model) {
    final m = model.toUpperCase();
    if (m.contains('64')) return const PresonusLayout(lines: 64, auxes: 32, fxBuses: 8, fxReturns: 8, dcas: 24);
    if (m.contains('32')) return const PresonusLayout(lines: 32, auxes: 16, dcas: 24);
    if (m.contains('24')) return const PresonusLayout(lines: 24, auxes: 16, dcas: 8);
    return const PresonusLayout(lines: 16, auxes: 8, dcas: 8);
  }

  // App meter blob layout.
  int get meterLine => 0;
  int get meterReturn => lines;
  int get meterFxReturn => meterReturn + returns * 2;
  int get meterAux => meterFxReturn + fxReturns * 2;
  int get meterMain => meterAux + auxes;
  int get meterCount => meterMain + 2;
}

class PresonusMap {
  const PresonusMap({this.layout = const PresonusLayout()});
  final PresonusLayout layout;

  static final _strip = RegExp(r'^/(ch|auxin|fxrtn|bus)/(\d{2})(/.+)$');
  static final _main = RegExp(r'^/main/st(/.+)$');
  static final _dca = RegExp(r'^/dca/(\d{1,2})(/.+)$');
  static final _fxsend = RegExp(r'^/fxsend/(\d)(/.+)$');
  static final _headamp = RegExp(r'^/headamp/(\d{2})/(gain|phantom)$');
  static final _mute = RegExp(r'^/config/mute/(\d{1,2})$');
  static final _send = RegExp(r'^/mix/(\d{2})/(level|on)$');
  static final _eq = RegExp(r'^/eq/(\d)/(f|g|q)$');

  String? _group(String cat, int n) => switch (cat) {
        'ch' when n >= 1 && n <= layout.lines => 'line/ch$n',
        'auxin' when n >= 1 && n <= layout.returns => 'return/ch$n',
        'fxrtn' when n >= 1 && n <= layout.fxReturns => 'fxreturn/ch$n',
        'bus' when n >= 1 && n <= layout.auxes => 'aux/ch$n',
        _ => null,
      };

  /// Name a DCA uses for a member strip.
  static String? _memberName(String cat, int n) => switch (cat) {
        'ch' => 'line$n',
        'auxin' => 'return$n',
        'fxrtn' => 'fxreturn$n',
        _ => null,
      };

  /// The StudioLive key(s) behind an app address (several = one per bit of
  /// a DCA mask).
  List<PresonusParam> toPresonus(String addr) {
    final one = _single(addr);
    if (one != null) return [one];
    final m = _strip.firstMatch(addr);
    if (m != null && m[3] == '/grp/dca') {
      final n = int.parse(m[2]!);
      final member = _memberName(m[1]!, n);
      if (member == null || _group(m[1]!, n) == null) return const [];
      return [
        for (var d = 1; d <= layout.dcas; d++) PresonusParam('filtergroup/ch$d/$member', PresonusKind.maskBit, bit: d - 1),
      ];
    }
    return const [];
  }

  PresonusParam? _single(String addr) {
    var m = _mute.firstMatch(addr);
    if (m != null) {
      final g = int.parse(m[1]!);
      return g < 1 || g > layout.muteGroups ? null : PresonusParam('mutegroup/mutegroup$g', PresonusKind.onOff);
    }
    m = _headamp.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > layout.lines) return null;
      return m[2] == 'gain'
          ? PresonusParam('line/ch$n/preampgain', PresonusKind.preampGain)
          : PresonusParam('line/ch$n/48v', PresonusKind.onOff);
    }
    m = _dca.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > layout.dcas) return null;
      final d = 'filtergroup/ch$n';
      return switch (m[2]) {
        '/fader' => PresonusParam('$d/volume', PresonusKind.fader),
        '/on' => PresonusParam('$d/mute', PresonusKind.muteInv),
        '/config/name' => PresonusParam('$d/name', PresonusKind.name),
        '/cue' => PresonusParam('$d/solo', PresonusKind.onOff),
        _ => null,
      };
    }
    m = _fxsend.firstMatch(addr);
    if (m != null) {
      final n = int.parse(m[1]!);
      if (n < 1 || n > layout.fxBuses) return null;
      return _forStrip('fx', 'fxbus/ch$n', m[2]!);
    }
    m = _main.firstMatch(addr);
    if (m != null) return _forStrip('main', 'main/ch1', m[1]!);
    m = _strip.firstMatch(addr);
    if (m != null) {
      final g = _group(m[1]!, int.parse(m[2]!));
      return g == null ? null : _forStrip(m[1]!, g, m[3]!);
    }
    return null;
  }

  PresonusParam? _forStrip(String cat, String p, String rest) {
    final input = cat == 'ch' || cat == 'auxin' || cat == 'fxrtn';
    switch (rest) {
      case '/mix/fader':
        return PresonusParam('$p/volume', PresonusKind.fader);
      case '/mix/on':
        return PresonusParam('$p/mute', PresonusKind.muteInv);
      case '/config/name':
        return PresonusParam('$p/username', PresonusKind.name);
      case '/config/color':
        return PresonusParam('$p/color', PresonusKind.color);
      case '/mix/pan':
        return PresonusParam('$p/pan', PresonusKind.norm);
      case '/cue':
        return cat == 'fx' || cat == 'main' ? null : PresonusParam('$p/solo', PresonusKind.onOff);
      case '/mix/st':
        if (input) return PresonusParam('$p/lr', PresonusKind.onOff);
        return cat == 'bus' ? PresonusParam('$p/lr_assign', PresonusKind.onOff) : null;
      case '/eq/on':
        return PresonusParam('$p/eq/eqallon', PresonusKind.onOff);
      case '/preamp/hpf':
        return cat == 'ch' || cat == 'bus' ? PresonusParam('$p/filter/hpf', PresonusKind.norm) : null;
      case '/preamp/invert':
        return cat == 'ch' ? PresonusParam('$p/polarity', PresonusKind.onOff) : null;
      case '/preamp/trim':
        return cat == 'ch' ? PresonusParam('$p/digitalgain', PresonusKind.norm) : null;
    }
    final eq = _eq.firstMatch(rest);
    if (eq != null) {
      final band = int.parse(eq[1]!);
      if (band < 1 || band > 4) return null;
      final f = switch (eq[2]) { 'f' => 'eqfreq', 'g' => 'eqgain', _ => 'eqq' };
      return PresonusParam('$p/eq/$f$band', PresonusKind.norm);
    }
    if (rest.startsWith('/gate/')) {
      if (cat != 'ch') return null;
      final g = '$p/gate';
      return switch (rest.substring(6)) {
        'on' => PresonusParam('$g/on', PresonusKind.onOff),
        'mode' => PresonusParam('$g/expander', PresonusKind.gateMode),
        'thr' => PresonusParam('$g/threshold', PresonusKind.norm),
        'range' => PresonusParam('$g/range', PresonusKind.norm),
        'attack' => PresonusParam('$g/attack', PresonusKind.norm),
        'release' => PresonusParam('$g/release', PresonusKind.norm),
        _ => null,
      };
    }
    if (rest.startsWith('/dyn/')) {
      final c = '$p/comp';
      return switch (rest.substring(5)) {
        'on' => PresonusParam('$c/on', PresonusKind.onOff),
        'thr' => PresonusParam('$c/threshold', PresonusKind.norm),
        'attack' => PresonusParam('$c/attack', PresonusKind.norm),
        'release' => PresonusParam('$c/release', PresonusKind.norm),
        'mgain' => PresonusParam('$c/gain', PresonusKind.norm),
        'auto' => PresonusParam('$c/automode', PresonusKind.onOff),
        _ => null,
      };
    }
    final s = _send.firstMatch(rest);
    if (s != null && input) {
      final k = int.parse(s[1]!);
      final level = s[2] == 'level';
      if (k >= 1 && k <= layout.auxes) {
        return level ? PresonusParam('$p/aux$k', PresonusKind.fader) : PresonusParam('$p/assign_aux$k', PresonusKind.onOff);
      }
      final f = k - layout.auxes;
      if (f >= 1 && f <= layout.fxBuses) {
        return level
            ? PresonusParam('$p/FX${String.fromCharCode(0x40 + f)}', PresonusKind.fader)
            : PresonusParam('$p/assign_fx$f', PresonusKind.onOff);
      }
    }
    return null;
  }

  static final _fixed = RegExp(r'/eq/\d/type$');
  static final _hpOn = RegExp(r'^/ch/\d{2}/preamp/hpon$');
  static final _dcaColor = RegExp(r'^/dca/\d{1,2}/config/color$');
  static final _noCue = RegExp(r'^/(fxsend/\d|main/st)/cue$');
  static final _gateHold = RegExp(r'/gate/hold$');

  /// App values the console doesn't have (answered by the link itself).
  static Object? constantFor(String addr) {
    if (_fixed.hasMatch(addr)) return 2; // bands shown as bells
    if (_hpOn.hasMatch(addr)) return 1; // the HPF is always in; its lowest setting is "off"
    if (_dcaColor.hasMatch(addr)) return 0;
    if (_noCue.hasMatch(addr)) return 0;
    if (_gateHold.hasMatch(addr)) return 0; // StudioLive gates have no hold
    return null;
  }

  // ---------------------------------------------------------------- values

  /// StudioLive fader curve (dB → 0..1), from presonus-studiolive-api.
  static double dbToWire(double db) {
    if (db <= -84) return 0;
    if (db >= 10) return 1;
    final x = db;
    final pct = (72.5204177782 + 2.473473992 * x + 0.026567557 * x * x + 0.0000880866 * x * x * x).clamp(0, 100);
    return pct / 100;
  }

  static double wireToDb(double w) {
    if (w <= 0) return double.negativeInfinity;
    if (w >= 1) return 10;
    var lo = -84.0, hi = 10.0;
    for (var i = 0; i < 40; i++) {
      final mid = (lo + hi) / 2;
      if (dbToWire(mid) < w) {
        lo = mid;
      } else {
        hi = mid;
      }
    }
    return (lo + hi) / 2;
  }

  /// App value → wire value (double / String / List<int> RGBA); null = can't.
  Object? encode(PresonusKind kind, Object v, {double gainMax = 60}) {
    if (kind == PresonusKind.name) return v.toString().replaceAll(RegExp(r'[\x00-\x1f]'), ' ');
    if (v is! num || !v.isFinite) return null;
    final f = v.toDouble();
    final n = f.clamp(0.0, 1.0);
    switch (kind) {
      case PresonusKind.fader:
        return n <= 0 ? 0.0 : dbToWire(faderToDb(n));
      case PresonusKind.muteInv:
        return f != 0 ? 0.0 : 1.0;
      case PresonusKind.onOff:
      case PresonusKind.maskBit:
        return f != 0 ? 1.0 : 0.0;
      case PresonusKind.norm:
        return n;
      case PresonusKind.preampGain:
        return (headampGainLaw.toReal(n).clamp(0, gainMax) / gainMax).toDouble();
      case PresonusKind.gateMode:
        return f.toInt() <= 2 ? 1.0 : 0.0; // expander vs gate
      case PresonusKind.color:
        return colorOut(f.toInt());
      case PresonusKind.name:
        return null;
    }
  }

  /// Wire value → app value (null = not understood).
  Object? decode(PresonusKind kind, Object? v, {double gainMax = 60}) {
    if (v == null) return null;
    switch (kind) {
      case PresonusKind.name:
        return v is String ? v : null;
      case PresonusKind.color:
        return v is String ? colorIn(v) : (v is int ? colorIn(intColorHex(v)) : null);
      default:
        break;
    }
    final d = v is bool ? (v ? 1.0 : 0.0) : (v is num ? v.toDouble() : null);
    if (d == null || !d.isFinite) return null;
    switch (kind) {
      case PresonusKind.fader:
        final db = wireToDb(d);
        return db.isInfinite ? 0.0 : dbToFader(db);
      case PresonusKind.muteInv:
        return d >= 0.5 ? 0 : 1;
      case PresonusKind.onOff:
      case PresonusKind.maskBit:
        return d >= 0.5 ? 1 : 0;
      case PresonusKind.norm:
        return d.clamp(0.0, 1.0);
      case PresonusKind.preampGain:
        return headampGainLaw.toNorm(d.clamp(0.0, 1.0) * gainMax);
      case PresonusKind.gateMode:
        return d >= 0.5 ? 0 : 3;
      default:
        return null;
    }
  }

  // ---------------------------------------------------------------- colours

  static const _rgb = [
    (0x60, 0x60, 0x60), (0xff, 0x00, 0x00), (0x00, 0xff, 0x00), (0xff, 0xff, 0x00),
    (0x00, 0x00, 0xff), (0xff, 0x00, 0xff), (0x00, 0xff, 0xff), (0xff, 0xff, 0xff),
  ];

  /// App colour → RGBA bytes.
  static List<int> colorOut(int app) {
    final (r, g, b) = _rgb[(app % 8).clamp(0, 7)];
    return [r, g, b, 0xff];
  }

  /// "rrggbbaa" → nearest app colour.
  static int colorIn(String hex) {
    if (hex.length < 6) return 0;
    final r = int.tryParse(hex.substring(0, 2), radix: 16) ?? 0;
    final g = int.tryParse(hex.substring(2, 4), radix: 16) ?? 0;
    final b = int.tryParse(hex.substring(4, 6), radix: 16) ?? 0;
    if (r + g + b < 60) return 0;
    var best = 1;
    var bestD = 1 << 30;
    for (var i = 1; i < _rgb.length; i++) {
      final (cr, cg, cb) = _rgb[i];
      final dist = (cr - r) * (cr - r) + (cg - g) * (cg - g) + (cb - b) * (cb - b);
      if (dist < bestD) {
        bestD = dist;
        best = i;
      }
    }
    return best;
  }

  /// State-tree colours are little-endian int32 of the RGBA bytes.
  static String intColorHex(int v) {
    final b = [v & 0xff, (v >> 8) & 0xff, (v >> 16) & 0xff, (v >> 24) & 0xff];
    return b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();
  }

  // ---------------------------------------------------------------- meters

  /// Raw meter value (linear, 65535 = 0 dBFS) → 1/256 dB.
  static int meterWord(int raw) {
    if (raw <= 0) return -32768;
    final db = 20 * math.log(raw / 65535) / math.ln10;
    return (db * 256).round().clamp(-32767, 32767);
  }
}
