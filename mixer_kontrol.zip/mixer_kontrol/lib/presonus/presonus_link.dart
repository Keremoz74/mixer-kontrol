import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../mixer/mixer_profile.dart';
import '../osc/mixer_link.dart';
import '../osc/osc_message.dart';
import 'presonus_map.dart';

/// One UCNet packet: "UC\0\x01" | size u16 LE | code (2) | c-bytes (4) | body.
class UcPacket {
  UcPacket(this.code, this.body);
  final String code;
  final Uint8List body;

  static const header = [0x55, 0x43, 0x00, 0x01];
  static const cBytes = [0x68, 0x00, 0x65, 0x00];

  static Uint8List encode(String code, List<int> body, {List<int> cbytes = cBytes}) {
    final size = 2 + 4 + body.length;
    return Uint8List.fromList([...header, size & 0xff, size >> 8, ...ascii.encode(code), ...cbytes, ...body]);
  }

  /// Key\0 + 2 bytes + float32 LE.
  static List<int> pv(String key, double v) {
    final f = ByteData(4)..setFloat32(0, v, Endian.little);
    return [...utf8.encode(key), 0, 0, 0, ...f.buffer.asUint8List()];
  }

  static List<int> ps(String key, String v) => [...utf8.encode(key), 0, 0, 0, ...utf8.encode(v), 0];
  static List<int> pc(String key, List<int> bytes) => [...utf8.encode(key), 0, 0, 0, ...bytes];

  static List<int> json(Map<String, Object?> m) {
    final b = utf8.encode(const JsonEncoder.withIndent(' ').convert(m));
    return [b.length & 0xff, (b.length >> 8) & 0xff, 0, 0, ...b];
  }
}

/// Splits a TCP stream into packets, resyncing on garbage.
class UcDecoder {
  final List<int> _buf = [];
  static const maxBuffer = 4 << 20;

  List<UcPacket> add(List<int> data) {
    _buf.addAll(data);
    if (_buf.length > maxBuffer) _buf.clear();
    final out = <UcPacket>[];
    while (_buf.length >= 6) {
      if (!(_buf[0] == 0x55 && _buf[1] == 0x43 && _buf[2] == 0 && _buf[3] == 1)) {
        var i = 1;
        while (i + 3 < _buf.length && !(_buf[i] == 0x55 && _buf[i + 1] == 0x43 && _buf[i + 2] == 0 && _buf[i + 3] == 1)) {
          i++;
        }
        _buf.removeRange(0, i + 3 < _buf.length ? i : _buf.length - 3);
        continue;
      }
      final size = _buf[4] | (_buf[5] << 8);
      if (size < 6) {
        _buf.removeRange(0, 4);
        continue;
      }
      if (_buf.length < 6 + size) break;
      final p = Uint8List.fromList(_buf.sublist(6, 6 + size));
      _buf.removeRange(0, 6 + size);
      out.add(UcPacket(ascii.decode(p.sublist(0, 2), allowInvalid: true), Uint8List.sublistView(p, 6)));
    }
    return out;
  }
}

/// Minimal UBJSON reader (the console's state tree).
class Ubjson {
  Ubjson(this.d);
  final Uint8List d;
  int p = 0;
  int _depth = 0;

  late final ByteData _bd = ByteData.sublistView(d);

  static Object? decode(Uint8List data) => Ubjson(data)._value(null);

  int _int() {
    final t = d[p++];
    return switch (t) {
      0x69 => _bd.getInt8(p++), // i
      0x55 => d[p++], // U
      0x49 => () { final v = _bd.getInt16(p); p += 2; return v; }(), // I
      0x6c => () { final v = _bd.getInt32(p); p += 4; return v; }(), // l
      0x4c => () { final v = _bd.getInt64(p); p += 8; return v; }(), // L
      _ => throw const FormatException('UBJSON: int expected'),
    };
  }

  Object? _value(int? type) {
    final t = type ?? d[p++];
    switch (t) {
      case 0x5a: // Z
      case 0x4e: // N
        return null;
      case 0x54: // T
        return true;
      case 0x46: // F
        return false;
      case 0x69:
      case 0x55:
      case 0x49:
      case 0x6c:
      case 0x4c:
        p--;
        if (type != null) {
          // typed container: the marker isn't repeated
          p++;
          return _typedInt(t);
        }
        return _int();
      case 0x64: // d
        final v = _bd.getFloat32(p);
        p += 4;
        return v;
      case 0x44: // D
        final v = _bd.getFloat64(p);
        p += 8;
        return v;
      case 0x43: // C
        return String.fromCharCode(d[p++]);
      case 0x53: // S
      case 0x48: // H
        final n = _int();
        if (n < 0 || p + n > d.length) throw const FormatException('UBJSON: string past end');
        final s = utf8.decode(d.sublist(p, p + n), allowMalformed: true);
        p += n;
        return s;
      case 0x5b: // [
      case 0x7b: // {
        if (++_depth > 64) throw const FormatException('UBJSON: too deep');
        final obj = t == 0x7b;
        int? typ, count;
        if (d[p] == 0x24) {
          typ = d[p + 1];
          p += 2;
        }
        if (d[p] == 0x23) {
          p++;
          count = _int();
        }
        final map = <String, Object?>{};
        final list = <Object?>[];
        var i = 0;
        while (count != null ? i < count : d[p] != (obj ? 0x7d : 0x5d)) {
          if (obj) {
            final n = _int();
            final k = utf8.decode(d.sublist(p, p + n), allowMalformed: true);
            p += n;
            map[k] = _value(typ);
          } else {
            list.add(_value(typ));
          }
          i++;
          if (i > 1000000) throw const FormatException('UBJSON: too many items');
        }
        if (count == null) p++;
        _depth--;
        return obj ? map : list;
      default:
        throw FormatException('UBJSON: marker ${t.toRadixString(16)}');
    }
  }

  int _typedInt(int t) {
    switch (t) {
      case 0x69:
        return _bd.getInt8(p++);
      case 0x55:
        return d[p++];
      case 0x49:
        final v = _bd.getInt16(p);
        p += 2;
        return v;
      case 0x6c:
        final v = _bd.getInt32(p);
        p += 4;
        return v;
      default:
        final v = _bd.getInt64(p);
        p += 8;
        return v;
    }
  }
}

/// Connection to a PreSonus StudioLive Series III over UCNet (TCP 53000).
///
/// On subscribing, the console sends its whole state (zlib-compressed
/// UBJSON); after that every change arrives as a parameter packet. Meters
/// stream over UDP to the port the app announces.
class PresonusLink implements MixerLink {
  PresonusLink._(this.host, this.port);

  final String host;
  final int port;
  Socket? _socket;
  StreamSubscription<List<int>>? _sub;
  final _decoder = UcDecoder();
  final _out = StreamController<OscMessage>.broadcast();
  bool _closed = false;
  Timer? _retry;
  Completer<void>? _synced;

  PresonusMap map = const PresonusMap();
  static const defaultPort = 53000;
  static const meterId = '/meters/presonus';
  static const aliveAddr = '/-stat/presonus/alive';

  /// Flat state: key ("line/ch1/volume") → value.
  final Map<String, Object?> state = {};
  final Map<String, Map<String, Object?>> _ranges = {};
  final Map<String, Map<String, PresonusParam>> _back = {};
  final Map<String, int> _masks = {};
  final List<int> _chunks = [];

  static Future<PresonusLink> connect(String host, {int port = defaultPort, Duration timeout = const Duration(seconds: 3)}) async {
    final l = PresonusLink._(host, port);
    await l._open(timeout);
    return l;
  }

  Future<void> _open(Duration timeout) async {
    final s = await Socket.connect(host, port, timeout: timeout);
    s.setOption(SocketOption.tcpNoDelay, true);
    _socket = s;
    _synced = Completer<void>();
    _sub = s.listen(_onBytes, onError: (_) => _lost(), onDone: _lost, cancelOnError: true);
    _send('JM', UcPacket.json({
      'id': 'Subscribe',
      'clientName': 'OzMix',
      'clientInternalName': 'ucremoteapp',
      'clientType': 'Android',
      'clientDescription': 'OzMix Control',
      'clientIdentifier': 'ozmix-control',
      'clientOptions': 'perm users levl redu rtan',
      'clientEncoding': 23106,
    }));
    if (_meterSock != null) _send('UM', [_meterSock!.port & 0xff, _meterSock!.port >> 8], cbytes: const [0, 0, 0x65, 0]);
  }

  /// Waits for the console's full state; false if it didn't come.
  Future<bool> sync({Duration timeout = const Duration(seconds: 6)}) async {
    try {
      await _synced!.future.timeout(timeout);
      return true;
    } catch (_) {
      return false;
    }
  }

  void _lost() {
    _sub?.cancel();
    _sub = null;
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    if (_closed) return;
    _retry ??= Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_closed || _socket != null) return;
      try {
        await _open(const Duration(seconds: 2));
        _retry?.cancel();
        _retry = null;
      } catch (_) {}
    });
  }

  void _send(String code, List<int> body, {List<int> cbytes = UcPacket.cBytes}) {
    final s = _socket;
    if (s == null) return;
    try {
      s.add(UcPacket.encode(code, body, cbytes: cbytes));
    } catch (_) {
      _lost();
    }
  }

  void _emit(String addr, Object v) {
    if (!_out.isClosed) _out.add(OscMessage(addr, [v]));
  }

  // ---------------------------------------------------------------- incoming

  void _onBytes(List<int> data) {
    for (final p in _decoder.add(data)) {
      try {
        _onPacket(p);
      } catch (_) {
        // malformed packet: ignore
      }
    }
  }

  static String _norm(String key) => key.replaceAll('.', '/');

  void _onPacket(UcPacket p) {
    final b = p.body;
    switch (p.code) {
      case 'ZB':
        if (b.length > 4) _loadState(Uint8List.sublistView(b, 4));
      case 'CK':
        if (b.length < 16) return;
        final bd = ByteData.sublistView(b);
        final offset = bd.getUint32(4, Endian.little);
        final total = bd.getUint32(8, Endian.little);
        final size = bd.getUint32(12, Endian.little);
        if (offset == 0) _chunks.clear();
        if (total > (16 << 20) || offset != _chunks.length) {
          _chunks.clear();
          return;
        }
        _chunks.addAll(b.sublist(16, (16 + size).clamp(16, b.length)));
        if (offset + size >= total) {
          final all = Uint8List.fromList(_chunks);
          _chunks.clear();
          _loadState(all);
        }
      case 'PV':
        final i = b.indexOf(0);
        if (i <= 0 || b.length < i + 7) return;
        final key = _norm(utf8.decode(b.sublist(0, i), allowMalformed: true));
        if (b[i + 1] != 0 || b[i + 2] != 0) return; // not a plain value
        final v = ByteData.sublistView(b, i + 3, i + 7).getFloat32(0, Endian.little);
        _set(key, v.toDouble());
      case 'PS':
        final i = b.indexOf(0);
        if (i <= 0 || b.length < i + 3) return;
        final key = _norm(utf8.decode(b.sublist(0, i), allowMalformed: true));
        var end = b.indexOf(0, i + 3);
        if (end < 0) end = b.length;
        _set(key, utf8.decode(b.sublist(i + 3, end), allowMalformed: true));
      case 'PC':
        final i = b.indexOf(0);
        if (i <= 0 || b.length < i + 3) return;
        final key = _norm(utf8.decode(b.sublist(0, i), allowMalformed: true));
        _set(key, b.sublist(i + 3).map((x) => x.toRadixString(16).padLeft(2, '0')).join());
      case 'FD':
        _emit(aliveAddr, 1);
    }
  }

  void _loadState(Uint8List compressed) {
    final raw = Uint8List.fromList(ZLibCodec().decode(compressed));
    final tree = Ubjson.decode(raw);
    if (tree is! Map) return;
    _walk(tree.cast<String, Object?>(), '');
    if (!(_synced?.isCompleted ?? true)) _synced!.complete();
    for (final k in _back.keys.toList()) {
      if (state.containsKey(k)) _dispatch(k);
    }
  }

  void _walk(Map<String, Object?> node, String prefix) {
    final values = node['values'];
    if (values is Map) {
      values.forEach((k, v) => state['$prefix$k'] = v);
    }
    final ranges = node['ranges'];
    if (ranges is Map) {
      ranges.forEach((k, v) {
        if (v is Map) _ranges['$prefix$k'] = v.cast<String, Object?>();
      });
    }
    final kids = node['children'];
    if (kids is Map) {
      kids.forEach((k, v) {
        if (v is Map) _walk(v.cast<String, Object?>(), '$prefix$k/');
      });
    }
  }

  void _set(String key, Object? v) {
    state[key] = v;
    _dispatch(key);
  }

  double _gainMax(String key) {
    final r = _ranges[key];
    final max = r?['max'];
    return max is num && max > 0 ? max.toDouble() : 60;
  }

  void _dispatch(String key) {
    final hits = _back[key];
    if (hits == null) return;
    final v = state[key];
    hits.forEach((addr, p) {
      if (p.kind == PresonusKind.maskBit) {
        final on = map.decode(p.kind, v);
        if (on is! int) return;
        final m = _masks[addr] ?? 0;
        final next = on != 0 ? (m | (1 << p.bit)) : (m & ~(1 << p.bit));
        _masks[addr] = next;
        _emit(addr, next);
        return;
      }
      final out = map.decode(p.kind, v, gainMax: _gainMax(key));
      if (out != null) _emit(addr, out);
    });
  }

  // ---------------------------------------------------------------- outgoing

  @override
  Stream<OscMessage> get messages => _out.stream;

  void _register(String addr, PresonusParam p) => (_back[p.key] ??= {})[addr] = p;

  @override
  void send(OscMessage m) {
    final a = m.address;
    switch (a) {
      case '/xremote':
        return;
      case '/xinfo':
        // keep-alive the way the console's own apps do it: KA + a tiny file request
        _send('KA', const []);
        _send('FR', const [0x00, 0x01, 0x46, 0x74, 0x62, 0x72, 0x00, 0x00]);
        return;
      case '/meters':
        if (m.args.isNotEmpty && m.args.first == meterId) _wantMeters();
        return;
    }
    final fixed = PresonusMap.constantFor(a);
    if (fixed != null) {
      if (m.args.isEmpty) _emit(a, fixed);
      return;
    }
    final params = map.toPresonus(a);
    if (params.isEmpty) return;
    for (final p in params) {
      _register(a, p);
    }
    if (m.args.isEmpty) {
      for (final p in params) {
        if (state.containsKey(p.key)) _dispatch(p.key);
      }
      return;
    }
    final v = m.args.first;
    if (params.first.kind == PresonusKind.maskBit) {
      if (v is! num) return;
      final mask = v.toInt();
      _masks[a] = mask;
      for (final p in params) {
        final on = (mask >> p.bit) & 1 == 1;
        state[p.key] = on ? 1.0 : 0.0;
        _send('PV', UcPacket.pv(p.key, on ? 1.0 : 0.0));
      }
      return;
    }
    final p = params.first;
    final out = map.encode(p.kind, v, gainMax: _gainMax(p.key));
    if (out is double) {
      state[p.key] = out;
      _send('PV', UcPacket.pv(p.key, out));
    } else if (out is String) {
      state[p.key] = out;
      _send('PS', UcPacket.ps(p.key, out));
    } else if (out is List<int>) {
      _send('PC', UcPacket.pc(p.key, out));
    }
  }

  @override
  Future<OscMessage?> request(String address, {Duration timeout = const Duration(milliseconds: 800)}) async {
    final reply = messages.firstWhere((m) => m.address == address).timeout(timeout);
    send(OscMessage(address));
    try {
      return await reply;
    } catch (_) {
      return null;
    }
  }

  void learn(Iterable<String> addrs) {
    for (final a in addrs) {
      for (final p in map.toPresonus(a)) {
        _register(a, p);
      }
    }
  }

  /// Console model and sizes, from the state it sent.
  (String, PresonusLayout) readLayout() {
    int count(String group) {
      final re = RegExp('^$group/ch(\\d+)/');
      var max = 0;
      for (final k in state.keys) {
        final m = re.firstMatch(k);
        if (m != null) {
          final n = int.parse(m[1]!);
          if (n > max && n <= 128) max = n;
        }
      }
      return max;
    }

    var mutes = 0;
    for (var g = 1; g <= 32; g++) {
      if (state.containsKey('mutegroup/mutegroup$g')) mutes = g;
    }
    final name = state['global/mixer_name'];
    final model = name is String && name.trim().isNotEmpty ? name.trim() : 'StudioLive';
    final guess = PresonusLayout.forModel(model);
    final lines = count('line');
    final layout = lines == 0
        ? guess
        : PresonusLayout(
            lines: lines,
            returns: count('return'),
            fxReturns: count('fxreturn'),
            auxes: count('aux'),
            fxBuses: count('fxbus'),
            dcas: count('filtergroup'),
            muteGroups: mutes,
          );
    map = PresonusMap(layout: layout);
    return (model, layout);
  }

  static Iterable<String> profileAddresses(MixerProfile p) sync* {
    yield* p.queryAddresses;
    yield* p.snapshotAddresses();
    for (final s in p.allStrips) {
      yield* p.detailAddresses(s);
    }
    for (final s in p.inputs) {
      if (s.type == StripType.channel) {
        yield '/headamp/${two(s.index)}/gain';
        yield '/headamp/${two(s.index)}/phantom';
      }
    }
  }

  // ---------------------------------------------------------------- meters

  RawDatagramSocket? _meterSock;
  DateTime _meterWanted = DateTime.fromMillisecondsSinceEpoch(0);
  bool _opening = false;
  Timer? _meterTimer;
  late List<int> _raw = List<int>.filled(map.layout.meterCount, 0);

  void _wantMeters() {
    _meterWanted = DateTime.now();
    if (_meterSock != null || _opening || _closed) return;
    _openMeters();
  }

  Future<void> _openMeters() async {
    _opening = true;
    try {
      final u = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      if (_closed) {
        u.close();
        return;
      }
      final hostAddr = InternetAddress.tryParse(host);
      u.listen((e) {
        if (e != RawSocketEvent.read) return;
        final dg = u.receive();
        if (dg == null || dg.data.length > 16384) return;
        if (hostAddr != null && dg.address != hostAddr) return;
        _onMeterPacket(dg.data);
      });
      _meterSock = u;
      _raw = List<int>.filled(map.layout.meterCount, 0);
      _send('UM', [u.port & 0xff, u.port >> 8], cbytes: const [0, 0, 0x65, 0]);
      _meterTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        if (DateTime.now().difference(_meterWanted) > const Duration(seconds: 9)) _dropMeters();
      });
    } catch (_) {
      _meterSock = null;
    } finally {
      _opening = false;
    }
  }

  void _dropMeters() {
    _meterTimer?.cancel();
    _meterTimer = null;
    _meterSock?.close();
    _meterSock = null;
  }

  /// "levl" frame: "UC\0\x01" | port | "MS" | c-bytes | "levl" | 2 zero
  /// bytes | count u16 | count × u16 | groups u8 | groups × (id i16 BE,
  /// offset i16, count i16).
  void _onMeterPacket(Uint8List d) {
    if (d.length < 21 || d[0] != 0x55 || d[1] != 0x43 || d[6] != 0x4d || d[7] != 0x53) return;
    if (String.fromCharCodes(d.sublist(12, 16)) != 'levl') return;
    final bd = ByteData.sublistView(d);
    final count = bd.getUint16(18, Endian.little);
    final gAt = 20 + count * 2;
    if (gAt >= d.length) return;
    final groups = d[gAt];
    if (gAt + 1 + groups * 6 > d.length) return;
    final l = map.layout;
    final seen = <int>{};
    void put(int group, int at, int n) {
      for (var i = 0; i < groups; i++) {
        final o = gAt + 1 + i * 6;
        if (bd.getInt16(o) != group) continue;
        final off = bd.getInt16(o + 2, Endian.little), cnt = bd.getInt16(o + 4, Endian.little);
        for (var k = 0; k < n; k++) {
          final idx = off + k;
          _raw[at + k] = k < cnt && idx >= 0 && idx < count ? bd.getUint16(20 + idx * 2, Endian.little) : 0;
        }
        seen.add(group);
        return;
      }
    }

    put(0x0000, l.meterLine, l.lines);
    put(0x0100, l.meterReturn, l.returns * 2);
    put(0x0200, l.meterFxReturn, l.fxReturns * 2);
    put(0x0405, l.meterAux, l.auxes);
    if (!seen.contains(0x0405)) put(0x0400, l.meterAux, l.auxes);
    put(0x0705, l.meterMain, 2);
    if (!seen.contains(0x0705)) put(0x0700, l.meterMain, 2);
    if (seen.isEmpty) return;
    final out = ByteData(4 + _raw.length * 2);
    out.setInt32(0, _raw.length, Endian.little);
    for (var i = 0; i < _raw.length; i++) {
      out.setInt16(4 + i * 2, PresonusMap.meterWord(_raw[i]), Endian.little);
    }
    if (!_out.isClosed) _out.add(OscMessage(meterId, [out.buffer.asUint8List()]));
  }

  @override
  void close() {
    _send('JM', UcPacket.json({'id': 'Unsubscribe'}));
    _closed = true;
    _retry?.cancel();
    _dropMeters();
    _sub?.cancel();
    try {
      _socket?.destroy();
    } catch (_) {}
    _socket = null;
    _out.close();
  }
}
