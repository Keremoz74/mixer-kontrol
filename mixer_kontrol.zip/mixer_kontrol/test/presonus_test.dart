// PreSonus StudioLive III driver: framing, UBJSON, address translation and
// sessions against a software stand-in speaking UCNet.

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/meters.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/presonus/presonus_link.dart';
import 'package:mixer_kontrol/presonus/presonus_map.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';

List<int> ubInt(int n) {
  if (n >= -128 && n <= 127) return [0x69, n & 0xff];
  final b = ByteData(4)..setInt32(0, n);
  return [0x6c, ...b.buffer.asUint8List()];
}

List<int> ub(Object? v) {
  if (v == null) return [0x5a];
  if (v == true) return [0x54];
  if (v == false) return [0x46];
  if (v is int) return ubInt(v);
  if (v is double) {
    final b = ByteData(4)..setFloat32(0, v);
    return [0x64, ...b.buffer.asUint8List()];
  }
  if (v is String) {
    final b = utf8.encode(v);
    return [0x53, ...ubInt(b.length), ...b];
  }
  if (v is Map) {
    return [
      0x7b,
      for (final e in v.entries) ...[...ubInt(utf8.encode('${e.key}').length), ...utf8.encode('${e.key}'), ...ub(e.value)],
      0x7d,
    ];
  }
  throw ArgumentError(v.runtimeType);
}

/// A fake StudioLive with [state] as flat keys ("line/ch1/volume").
class FakeStudioLive {
  FakeStudioLive(this.state, {this.ranges = const {}, this.chunked = true});
  final Map<String, Object> state;
  final Map<String, Map<String, Object>> ranges;
  final bool chunked;
  late ServerSocket _server;
  final List<Socket> clients = [];
  final List<String> received = [];
  int? meterPort;
  int get port => _server.port;

  Map<String, Object?> _tree() {
    final root = <String, Object?>{'id': 'Synchronize'};
    Map<String, Object?> nodeAt(List<String> parts) {
      var n = root;
      for (final p in parts) {
        final kids = (n['children'] ??= <String, Object?>{}) as Map<String, Object?>;
        n = (kids[p] ??= <String, Object?>{}) as Map<String, Object?>;
      }
      return n;
    }

    state.forEach((k, v) {
      final parts = k.split('/');
      final n = nodeAt(parts.sublist(0, parts.length - 1));
      ((n['values'] ??= <String, Object?>{}) as Map<String, Object?>)[parts.last] = v is bool ? (v ? 1 : 0) : v;
      final r = ranges[k];
      if (r != null) ((n['ranges'] ??= <String, Object?>{}) as Map<String, Object?>)[parts.last] = r;
    });
    return root;
  }

  Future<void> start() async {
    _server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    _server.listen((s) {
      clients.add(s);
      final dec = UcDecoder();
      s.listen((d) {
        for (final p in dec.add(d)) {
          _handle(s, p);
        }
      }, onError: (_) {});
    });
  }

  void _handle(Socket s, UcPacket p) {
    final b = p.body;
    switch (p.code) {
      case 'JM':
        final msg = jsonDecode(utf8.decode(b.sublist(4))) as Map;
        received.add('JM ${msg['id']}');
        if (msg['id'] == 'Subscribe') {
          s.add(UcPacket.encode('JM', UcPacket.json({'id': 'SubscriptionReply'})));
          final comp = ZLibCodec().encode(ub(_tree()));
          if (!chunked) {
            s.add(UcPacket.encode('ZB', [comp.length & 0xff, (comp.length >> 8) & 0xff, 0, 0, ...comp]));
          } else {
            const step = 4000;
            for (var off = 0; off < comp.length; off += step) {
              final part = comp.sublist(off, off + step > comp.length ? comp.length : off + step);
              final h = ByteData(16)
                ..setUint16(0, 0)
                ..setUint8(2, 0x5a)
                ..setUint8(3, 0x42)
                ..setUint32(4, off, Endian.little)
                ..setUint32(8, comp.length, Endian.little)
                ..setUint32(12, part.length, Endian.little);
              s.add(UcPacket.encode('CK', [...h.buffer.asUint8List(), ...part]));
            }
          }
        }
      case 'PV':
        final i = b.indexOf(0);
        final key = utf8.decode(b.sublist(0, i));
        final v = ByteData.sublistView(b, i + 3, i + 7).getFloat32(0, Endian.little);
        state[key] = v;
        received.add('PV $key=${v.toStringAsFixed(3)}');
        for (final c in clients) {
          c.add(UcPacket.encode('PV', b));
        }
      case 'PS':
        final i = b.indexOf(0);
        final key = utf8.decode(b.sublist(0, i));
        final v = utf8.decode(b.sublist(i + 3, b.indexOf(0, i + 3)));
        state[key] = v;
        received.add('PS $key=$v');
      case 'PC':
        final i = b.indexOf(0);
        received.add('PC ${utf8.decode(b.sublist(0, i))}=${b.sublist(i + 3).map((x) => x.toRadixString(16).padLeft(2, '0')).join()}');
      case 'UM':
        meterPort = b[0] | (b[1] << 8);
        received.add('UM $meterPort');
      default:
        received.add(p.code);
    }
  }

  /// A change made on the console.
  void surface(String key, double v) {
    state[key] = v;
    for (final c in clients) {
      c.add(UcPacket.encode('PV', UcPacket.pv(key, v)));
    }
  }

  void surfaceName(String key, String v) {
    for (final c in clients) {
      c.add(UcPacket.encode('PS', UcPacket.ps(key, v)));
    }
  }

  Future<void> sendMeters(List<(int, List<int>)> groups) async {
    final vals = <int>[];
    final desc = <int>[];
    for (final (g, v) in groups) {
      final d = ByteData(6)
        ..setInt16(0, g)
        ..setInt16(2, vals.length, Endian.little)
        ..setInt16(4, v.length, Endian.little);
      desc.addAll(d.buffer.asUint8List());
      vals.addAll(v);
    }
    final body = BytesBuilder()
      ..add([0x55, 0x43, 0, 1, 0x08, 0xcf])
      ..add(ascii.encode('MS'))
      ..add([0x65, 0, 0x68, 0])
      ..add(ascii.encode('levl'))
      ..add([0, 0, vals.length & 0xff, vals.length >> 8]);
    for (final v in vals) {
      body.add([v & 0xff, v >> 8]);
    }
    body.add([groups.length, ...desc]);
    final u = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, 0);
    u.send(body.toBytes(), InternetAddress.loopbackIPv4, meterPort!);
    u.close();
  }

  Future<void> stop() async {
    for (final c in clients) {
      c.destroy();
    }
    await _server.close();
  }
}

Map<String, Object> studioLive16() {
  final s = <String, Object>{'global/mixer_name': 'StudioLive 16'};
  void strip(String p, {bool sends = true}) {
    s['$p/volume'] = 0.0;
    s['$p/mute'] = false;
    s['$p/username'] = '';
    s['$p/color'] = 0;
    s['$p/pan'] = 0.5;
    s['$p/solo'] = false;
    for (var b = 1; b <= 4; b++) {
      s['$p/eq/eqfreq$b'] = 0.5;
      s['$p/eq/eqgain$b'] = 0.5;
      s['$p/eq/eqq$b'] = 0.5;
    }
    s['$p/eq/eqallon'] = 0;
    if (sends) {
      for (var a = 1; a <= 8; a++) {
        s['$p/aux$a'] = 0.0;
        s['$p/assign_aux$a'] = true;
      }
      for (var f = 1; f <= 4; f++) {
        s['$p/FX${String.fromCharCode(0x40 + f)}'] = 0.0;
        s['$p/assign_fx$f'] = true;
      }
      s['$p/lr'] = 1;
    }
  }

  for (var i = 1; i <= 16; i++) {
    strip('line/ch$i');
    s['line/ch$i/preampgain'] = 0.0;
    s['line/ch$i/48v'] = false;
    s['line/ch$i/polarity'] = 0;
    s['line/ch$i/filter/hpf'] = 0.0;
    for (final k in ['on', 'threshold', 'range', 'attack', 'release', 'expander']) {
      s['line/ch$i/gate/$k'] = 0.0;
    }
    for (final k in ['on', 'threshold', 'attack', 'release', 'gain', 'automode']) {
      s['line/ch$i/comp/$k'] = 0.0;
    }
  }
  for (var i = 1; i <= 2; i++) {
    strip('return/ch$i');
  }
  for (var i = 1; i <= 4; i++) {
    strip('fxreturn/ch$i');
  }
  for (var i = 1; i <= 8; i++) {
    strip('aux/ch$i', sends: false);
    s['aux/ch$i/lr_assign'] = 0;
    s['aux/ch$i/filter/hpf'] = 0.0;
    for (final k in ['on', 'threshold', 'attack', 'release', 'gain', 'automode']) {
      s['aux/ch$i/comp/$k'] = 0.0;
    }
  }
  for (var i = 1; i <= 4; i++) {
    strip('fxbus/ch$i', sends: false);
  }
  strip('main/ch1', sends: false);
  for (final k in ['on', 'threshold', 'attack', 'release', 'gain', 'automode']) {
    s['main/ch1/comp/$k'] = 0.0;
  }
  for (var d = 1; d <= 8; d++) {
    s['filtergroup/ch$d/volume'] = 0.73;
    s['filtergroup/ch$d/mute'] = false;
    s['filtergroup/ch$d/name'] = 'DCA $d';
    s['filtergroup/ch$d/solo'] = false;
    for (var i = 1; i <= 16; i++) {
      s['filtergroup/ch$d/line$i'] = 0;
    }
    for (var i = 1; i <= 2; i++) {
      s['filtergroup/ch$d/return$i'] = 0;
    }
    for (var i = 1; i <= 4; i++) {
      s['filtergroup/ch$d/fxreturn$i'] = 0;
    }
  }
  for (var g = 1; g <= 8; g++) {
    s['mutegroup/mutegroup$g'] = 0;
  }
  return s;
}

Future<void> _until(bool Function() ok, {int ms = 4000}) async {
  final sw = Stopwatch()..start();
  while (!ok() && sw.elapsedMilliseconds < ms) {
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}

void main() {
  const map = PresonusMap(layout: PresonusLayout(lines: 16, returns: 2, fxReturns: 4, auxes: 8, fxBuses: 4, dcas: 8));

  test('framing and UBJSON', () {
    final pkt = UcPacket.encode('PV', UcPacket.pv('line/ch1/mute', 1));
    final dec = UcDecoder();
    // garbage first, then the packet split in two
    final got = [...dec.add([1, 2, 3, ...pkt.sublist(0, 7)]), ...dec.add(pkt.sublist(7))];
    expect(got.single.code, 'PV');
    final tree = Ubjson.decode(Uint8List.fromList(ub({'a': 1, 'b': 'x', 'c': {'d': 2.5, 'e': true}, 'f': null})));
    expect(tree, {'a': 1, 'b': 'x', 'c': {'d': 2.5, 'e': true}, 'f': null});
    // typed, counted containers
    final typed = Uint8List.fromList([0x5b, 0x24, 0x69, 0x23, 0x69, 3, 1, 2, 3]);
    expect(Ubjson.decode(typed), [1, 2, 3]);
    expect(() => Ubjson.decode(Uint8List.fromList([0x53, 0x69, 50, 0x41])), throwsA(anything));
  });

  test('a compressed state that inflates too far is refused', () {
    final bomb = Uint8List.fromList(ZLibCodec(level: 9).encode(Uint8List(PresonusLink.maxInflated + 1024)));
    expect(bomb.length, lessThan(1 << 20)); // small on the wire…
    expect(PresonusLink.inflate(bomb), isNull); // …and refused
    final ok = Uint8List.fromList(ZLibCodec().encode(ub({'a': 1})));
    expect(Ubjson.decode(PresonusLink.inflate(ok)!), {'a': 1});
    expect(PresonusLink.inflate(Uint8List.fromList([1, 2, 3, 4])), isNull);
  });

  test('app addresses map to StudioLive keys', () {
    String one(String a) => map.toPresonus(a).single.key;
    expect(one('/ch/01/mix/fader'), 'line/ch1/volume');
    expect(map.toPresonus('/ch/17/mix/fader'), isEmpty);
    expect(one('/auxin/02/mix/on'), 'return/ch2/mute');
    expect(one('/fxrtn/03/config/name'), 'fxreturn/ch3/username');
    expect(one('/bus/08/mix/fader'), 'aux/ch8/volume');
    expect(one('/fxsend/2/mix/fader'), 'fxbus/ch2/volume');
    expect(one('/main/st/eq/3/g'), 'main/ch1/eq/eqgain3');
    expect(one('/ch/05/mix/03/level'), 'line/ch5/aux3');
    expect(one('/ch/05/mix/03/on'), 'line/ch5/assign_aux3');
    expect(one('/ch/05/mix/10/level'), 'line/ch5/FXB');
    expect(one('/ch/05/mix/st'), 'line/ch5/lr');
    expect(one('/bus/02/mix/st'), 'aux/ch2/lr_assign');
    expect(one('/headamp/05/gain'), 'line/ch5/preampgain');
    expect(one('/dca/3/config/name'), 'filtergroup/ch3/name');
    expect(one('/config/mute/2'), 'mutegroup/mutegroup2');
    expect(map.toPresonus('/ch/05/grp/dca').map((p) => p.key).last, 'filtergroup/ch8/line5');
    expect(map.toPresonus('/fxrtn/02/grp/dca').first.key, 'filtergroup/ch1/fxreturn2');
    expect(PresonusMap.constantFor('/ch/01/eq/1/type'), 2);
    expect(PresonusMap.constantFor('/ch/01/preamp/hpon'), 1);
  });

  test('values convert both ways', () {
    // the console's own curve: 0 dB ≈ 0.725, -84 dB = 0
    expect(PresonusMap.dbToWire(0), closeTo(0.725, 0.001));
    expect(PresonusMap.wireToDb(PresonusMap.dbToWire(-20)), closeTo(-20, 0.05));
    expect(map.encode(PresonusKind.fader, dbToFader(0)) as double, closeTo(0.725, 0.002));
    expect(map.decode(PresonusKind.fader, 0.0), 0.0);
    expect(map.decode(PresonusKind.fader, 0.725) as double, closeTo(dbToFader(0), 0.01));
    expect(map.encode(PresonusKind.muteInv, 1), 0.0);
    expect(map.decode(PresonusKind.muteInv, true), 0);
    expect(map.encode(PresonusKind.preampGain, headampGainLaw.toNorm(30)) as double, closeTo(0.5, 1e-9));
    expect(map.decode(PresonusKind.preampGain, 0.5) as double, closeTo(headampGainLaw.toNorm(30), 1e-9));
    expect(map.encode(PresonusKind.color, 1), [0xff, 0, 0, 0xff]);
    expect(PresonusMap.colorIn('ff0000ff'), 1);
    expect(PresonusMap.colorIn(PresonusMap.intColorHex(0xff00ff00)), 2);
    expect(map.decode(PresonusKind.gateMode, 1.0), 0);
  });

  test('every StudioLive size: profile addresses translate, demo works', () {
    for (final m in PresonusLayout.models) {
      final l = PresonusLayout.forModel(m);
      final p = MixerProfile.presonus(m, l);
      final pm = PresonusMap(layout: l);
      final missing = [
        for (final a in PresonusLink.profileAddresses(p))
          if (pm.toPresonus(a).isEmpty && PresonusMap.constantFor(a) == null && !a.endsWith('/preamp/trim')) a,
      ];
      expect(missing, isEmpty, reason: m);
      final d = MixerController.demo(MixerFamily.presonus, model: m);
      expect(d.profile.isExternal, isTrue);
      d.dispose();
    }
  });

  test('session with a fake StudioLive: state, sizes, set, changes, DCA, meters', () async {
    final fake = FakeStudioLive(studioLive16(), ranges: {
      for (var i = 1; i <= 16; i++) 'line/ch$i/preampgain': {'min': 0, 'max': 60, 'def': 0},
    });
    fake.state['line/ch3/volume'] = 0.725;
    fake.state['line/ch3/username'] = 'Pastor';
    fake.state['line/ch3/mute'] = true;
    fake.state['line/ch3/preampgain'] = 0.5;
    fake.state['filtergroup/ch2/line3'] = 1;
    await fake.start();
    final link = await PresonusLink.connect('127.0.0.1', port: fake.port);
    expect(await link.sync(), isTrue);
    final (model, layout) = link.readLayout();
    expect(model, 'StudioLive 16');
    expect([layout.lines, layout.returns, layout.fxReturns, layout.auxes, layout.fxBuses, layout.dcas, layout.muteGroups],
        [16, 2, 4, 8, 4, 8, 8]);
    final profile = MixerProfile.presonus(model, layout);
    link.learn(PresonusLink.profileAddresses(profile));

    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);
    for (final a in ['/ch/03/mix/fader', '/ch/03/config/name', '/ch/03/mix/on', '/headamp/03/gain', '/ch/03/grp/dca']) {
      link.send(OscMessage(a));
    }
    await _until(() => ['/ch/03/mix/fader', '/ch/03/config/name', '/ch/03/mix/on', '/headamp/03/gain', '/ch/03/grp/dca']
        .every(got.containsKey));
    expect(got['/ch/03/mix/fader'] as double, closeTo(dbToFader(0), 0.01));
    expect(got['/ch/03/config/name'], 'Pastor');
    expect(got['/ch/03/mix/on'], 0);
    expect(got['/headamp/03/gain'] as double, closeTo(headampGainLaw.toNorm(30), 1e-6));
    expect(got['/ch/03/grp/dca'], 2);

    // app changes become PV / PS / PC packets
    link.send(OscMessage('/ch/01/mix/02/level', [dbToFader(0)]));
    link.send(const OscMessage('/ch/01/mix/on', [0]));
    link.send(const OscMessage('/ch/01/config/name', ['Kick']));
    link.send(const OscMessage('/ch/01/config/color', [2]));
    link.send(const OscMessage('/ch/04/grp/dca', [5]));
    await _until(() => fake.received.any((r) => r.startsWith('PC')) &&
        fake.received.where((r) => r.contains('/line4=')).length >= 8);
    expect(fake.received, contains('PV line/ch1/aux2=0.725'));
    expect(fake.received, contains('PV line/ch1/mute=1.000'));
    expect(fake.received, contains('PS line/ch1/username=Kick'));
    expect(fake.received, contains('PC line/ch1/color=00ff00ff'));
    expect(fake.received, contains('PV filtergroup/ch1/line4=1.000'));
    expect(fake.received, contains('PV filtergroup/ch2/line4=0.000'));
    expect(fake.received, contains('PV filtergroup/ch3/line4=1.000'));

    // changes on the console
    fake.surface('aux/ch6/mute', 1);
    fake.surfaceName('aux/ch6/username', 'Drums');
    await _until(() => got['/bus/06/mix/on'] == 0 && got['/bus/06/config/name'] == 'Drums');
    expect(got['/bus/06/mix/on'], 0);
    expect(got['/bus/06/config/name'], 'Drums');

    // meters: the app announces its UDP port; levl frames come back
    link.send(const OscMessage('/meters', [PresonusLink.meterId]));
    await _until(() => fake.meterPort != null);
    await fake.sendMeters([
      (0x0000, [65535, 32768, for (var i = 2; i < 16; i++) 0]),
      (0x0405, List.filled(8, 16384)),
      (0x0705, [65535, 65535]),
    ]);
    await _until(() => got.containsKey(PresonusLink.meterId));
    final mv = decodeMeterBlob(got[PresonusLink.meterId] as dynamic, MeterFormat.int16Db);
    expect(mv.length, layout.meterCount);
    expect(mv[0], closeTo(0, 0.01));
    expect(mv[1], closeTo(-6.02, 0.05));
    expect(mv[2], double.negativeInfinity);
    expect(mv[layout.meterAux], closeTo(-12.04, 0.05));
    expect(mv[layout.meterMain], closeTo(0, 0.01));
    // a console that sends input levels only in a later stage
    await fake.sendMeters([(0x0005, [16384, for (var i = 1; i < 16; i++) 0])]);
    await _until(() => decodeMeterBlob(got[PresonusLink.meterId] as dynamic, MeterFormat.int16Db)[0] < -6);
    expect(decodeMeterBlob(got[PresonusLink.meterId] as dynamic, MeterFormat.int16Db)[0], closeTo(-12.04, 0.05));

    // keep-alive and garbage
    link.send(const OscMessage('/xinfo'));
    await _until(() => fake.received.contains('KA'));
    for (final c in fake.clients) {
      c.add([0x55, 0x43, 0, 1, 3, 0, 1, 2, 3]);
      c.add(UcPacket.encode('ZB', [0, 0, 0, 0, 1, 2, 3, 4, 5]));
      c.add(UcPacket.encode('PV', [0x41, 0x42]));
    }
    await Future<void>.delayed(const Duration(milliseconds: 150));
    fake.surface('line/ch2/mute', 1);
    await _until(() => got['/ch/02/mix/on'] == 0);
    expect(got['/ch/02/mix/on'], 0, reason: 'still working after garbage');

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('a whole StudioLive profile syncs (single ZB state)', () async {
    final fake = FakeStudioLive(studioLive16(), chunked: false);
    await fake.start();
    final link = await PresonusLink.connect('127.0.0.1', port: fake.port);
    expect(await link.sync(), isTrue);
    final (model, layout) = link.readLayout();
    final p = MixerProfile.presonus(model, layout);
    final seen = <String>{};
    final sub = link.messages.listen((m) => seen.add(m.address));
    final want = p.queryAddresses.toSet();
    for (final a in want) {
      link.send(OscMessage(a));
    }
    await _until(() => seen.containsAll(want), ms: 5000);
    expect(want.difference(seen), isEmpty);
    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('connect fails cleanly when nothing listens', () async {
    final s = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = s.port;
    await s.close();
    await expectLater(PresonusLink.connect('127.0.0.1', port: port, timeout: const Duration(seconds: 1)), throwsA(anything));
  });
}
