// Allen & Heath driver: address translation, values, and sessions against a
// software stand-in that speaks MIDI over TCP.

import 'dart:async';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/ah/ah_layout.dart';
import 'package:mixer_kontrol/ah/ah_link.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';

class FakeAh {
  late ServerSocket server;
  final List<Socket> clients = [];
  final List<int> received = [];
  int get port => server.port;

  /// Bytes to answer with when a request arrives (matched by prefix).
  final List<(List<int>, List<int>)> replies = [];

  Future<void> start() async {
    server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((s) {
      clients.add(s);
      s.listen((data) {
        received.addAll(data);
        for (final (req, rep) in replies) {
          if (_contains(received, req)) s.add(rep);
        }
      }, onError: (_) {});
    });
  }

  static bool _contains(List<int> hay, List<int> needle) {
    outer:
    for (var i = 0; i + needle.length <= hay.length; i++) {
      for (var j = 0; j < needle.length; j++) {
        if (hay[i + j] != needle[j]) continue outer;
      }
      return true;
    }
    return false;
  }

  bool sent(List<int> bytes) => _contains(received, bytes);

  void push(List<int> bytes) {
    for (final c in clients) {
      c.add(bytes);
    }
  }

  Future<void> stop() async {
    for (final c in clients) {
      c.destroy();
    }
    await server.close();
  }
}

Future<void> _until(bool Function() ok, {int ms = 3000}) async {
  final sw = Stopwatch()..start();
  while (!ok() && sw.elapsedMilliseconds < ms) {
    await Future<void>.delayed(const Duration(milliseconds: 20));
  }
}

void main() {
  test('levels round trip in every dialect', () {
    for (final model in ['SQ', 'CQ', 'QU32', 'DLIVE']) {
      final m = AhMap(model);
      for (final db in [-40.0, -20.0, -10.0, -3.0, 0.0, 5.0, 10.0]) {
        final back = m.levelDb(m.levelValue(db));
        expect(back, closeTo(db, model == 'DLIVE' ? 0.3 : 0.6), reason: '$model $db');
      }
      expect(m.levelValue(double.negativeInfinity), 0, reason: model);
      expect(m.levelDb(0), double.negativeInfinity, reason: model);
    }
    // SQ linear taper: 0 dB = 15196
    expect(AhMap('SQ').levelValue(0), 15196);
    expect(AhMap('DLIVE').levelValue(10), 127);
  });

  test('addresses map to the documented messages', () {
    final sq = AhMap('SQ');
    // input 1 fader = input→LR level 40:00; input 3 to mix 2 = 40:44 + 12*2 + 1
    var p = sq.toAh('/ch/01/mix/fader')!;
    expect((p.a, p.b), (0x40, 0x00));
    p = sq.toAh('/ch/03/mix/02/level')!;
    expect((p.a << 7) + p.b, (0x40 << 7) + 0x44 + 12 * 2 + 1);
    p = sq.toAh('/ch/01/mix/13/level')!; // FX 1 (after 12 mixes)
    expect((p.a, p.b), (0x4C, 0x14));
    p = sq.toAh('/main/st/mix/on')!;
    expect((p.a, p.b), (0x00, 0x44));
    p = sq.toAh('/dca/2/fader')!;
    expect((p.a, p.b), (0x4F, 0x21));
    expect(sq.setBytes(sq.toAh('/ch/01/mix/on')!, 1), [0xB0, 0x63, 0, 0xB0, 0x62, 0, 0xB0, 0x06, 0, 0xB0, 0x26, 1]);
    expect(sq.getBytes(sq.toAh('/ch/01/mix/fader')!), [0xB0, 0x63, 0x40, 0xB0, 0x62, 0x00, 0xB0, 0x60, 0x7F]);
    // CQ: stereo inputs are SQ inputs 24, 26, 28, 30
    final cq = AhMap('CQ');
    p = cq.toAh('/auxin/02/mix/on')!;
    expect((p.a, p.b), (0x00, 26));

    final qu = AhMap('QU24');
    expect(qu.setBytes(qu.toAh('/ch/01/mix/fader')!, 0x62), [0xB0, 0x63, 0x20, 0xB0, 0x62, 0x17, 0xB0, 0x06, 0x62, 0xB0, 0x26, 0x07]);
    expect(qu.setBytes(qu.toAh('/ch/02/mix/on')!, 1), [0x90, 0x21, 0x7F, 0x90, 0x21, 0x00]);
    p = qu.toAh('/ch/01/mix/09/level')!; // FX 2 after 7 mixes → send index 17
    expect((p.b, p.c), (0x20, 17));

    final dl = AhMap('DLIVE');
    expect(dl.setBytes(dl.toAh('/bus/03/mix/fader')!, 100), [0xB2, 0x63, 2, 0xB2, 0x62, 0x17, 0xB2, 0x06, 100]);
    expect(dl.setBytes(dl.toAh('/dca/1/on')!, 1), [0x94, 0x36, 0x7F, 0x94, 0x36, 0x00]);
    expect(dl.setBytes(dl.toAh('/ch/05/mix/02/level')!, 90),
        [...AhMap.dliveHeader, 0, 0x0D, 4, 2, 1, 90, 0xF7]);
    expect(dl.toAh('/headamp/03/gain'), isNotNull);
    expect(AhMap('SQ').toAh('/headamp/03/gain'), isNull);
    expect(dl.encode(AhKind.eqFreq, freqLaw.toNorm(1000)), (freqLaw.toNorm(1000) * 127).round());
    expect(dl.decode(AhKind.assign, 0x3F), 0);
    expect(dl.decode(AhKind.assign, 0x7F), 1);
    expect(dl.sceneBytes(130), [0xB0, 0x00, 1, 0xC0, 1]);
  });

  test('profiles: every model builds and its addresses translate', () {
    for (final (_, model) in AhLayout.models) {
      final p = MixerProfile.allenHeath(model);
      final m = AhMap(model);
      final bad = p.queryAddresses
          .where((a) => !a.contains('/config/color') && !a.contains('/config/name') && !a.contains('/eq/'))
          .where((a) => !RegExp(r'^/(bus/\d\d|main/st)/mix/\d\d/').hasMatch(a)) // matrix sends: partly
          .where((a) => m.toAh(a) == null)
          .where((a) => !RegExp(r'/mix/\d\d/on$').hasMatch(a)) // Qu has no send on/off
          .toSet();
      expect(bad, isEmpty, reason: '$model: ${bad.take(5).join(', ')}');
      expect(p.hasFx || p.hasMeters || p.consoleCanSave, isFalse);
      expect(p.hasDynamics, ahDialectFor(model) == AhDialect.qu, reason: model);
      // EQ + gain on Qu and dLive / Avantis channels; SQ / CQ have none over MIDI
      final proc = ahDialectFor(model) == AhDialect.qu || ahDialectFor(model) == AhDialect.dlive;
      expect(p.inputs.first.hasEq, proc, reason: model);
      final d = MixerController.demo(MixerFamily.allenHeath, model: model);
      expect(d.profile.isAh, isTrue);
      d.dispose();
    }
  });

  test('SQ session: get, set and changes from the desk', () async {
    final fake = FakeAh();
    // answer the fader request for input 1 with -10 dB
    final v = AhMap('SQ').levelValue(-10);
    fake.replies.add(([0xB0, 0x63, 0x40, 0xB0, 0x62, 0x00, 0xB0, 0x60, 0x7F],
        [0xB0, 0x63, 0x40, 0xB0, 0x62, 0x00, 0xB0, 0x06, v >> 7, 0xB0, 0x26, v & 0x7F]));
    await fake.start();
    final link = await AhLink.connect('127.0.0.1', 'SQ', port: fake.port);
    link.learn(AhLink.profileAddresses(MixerProfile.allenHeath('SQ')));
    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);

    link.send(const OscMessage('/ch/01/mix/fader'));
    await _until(() => got.containsKey('/ch/01/mix/fader'));
    expect(faderToDb(got['/ch/01/mix/fader'] as double), closeTo(-10, 0.2));

    link.send(const OscMessage('/ch/02/mix/on', [0])); // mute
    await _until(() => fake.sent([0xB0, 0x63, 0, 0xB0, 0x62, 1, 0xB0, 0x06, 0, 0xB0, 0x26, 1]));
    expect(fake.sent([0xB0, 0x63, 0, 0xB0, 0x62, 1, 0xB0, 0x06, 0, 0xB0, 0x26, 1]), isTrue);

    // desk unmutes Mix 3 (running status, as consoles do)
    fake.push([0xB0, 0x63, 0x00, 0x62, 0x47, 0x06, 0x00, 0x26, 0x00]);
    await _until(() => got.containsKey('/bus/03/mix/on'));
    expect(got['/bus/03/mix/on'], 1);

    // scene change on the desk
    fake.push([0xB0, 0x00, 0x00, 0xC0, 0x04]);
    await _until(() => got.containsKey('/-snap/index'));
    expect(got['/-snap/index'], 5);

    // junk is ignored
    fake.push([0xF0, 1, 2, 3, 0xF7, 0x45, 0x12, 0xB0, 0x63, 0x7F, 0x62, 0x7F, 0x06, 1, 0x26, 2]);
    await Future<void>.delayed(const Duration(milliseconds: 100));

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('dLive session: names, mutes, faders, sends', () async {
    final fake = FakeAh();
    await fake.start();
    final link = await AhLink.connect('127.0.0.1', 'DLIVE', port: fake.port);
    link.learn(AhLink.profileAddresses(MixerProfile.allenHeath('DLIVE')));
    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);

    link.send(const OscMessage('/ch/04/config/name'));
    await _until(() => fake.sent([...AhMap.dliveHeader, 0, 0x01, 3, 0xF7]));
    fake.push([...AhMap.dliveHeader, 0, 0x02, 3, ...'Vox'.codeUnits, 0xF7]);
    fake.push([0x90, 5, 0x7F, 0x90, 5, 0x00]); // ch 6 muted
    fake.push([0xB2, 0x63, 1, 0x62, 0x17, 0x06, 107]); // aux 2 at 0 dB
    fake.push([...AhMap.dliveHeader, 0, 0x0D, 0, 2, 3, 127, 0xF7]); // ch1 → aux 4 at +10
    await _until(() => got.length >= 4);
    expect(got['/ch/04/config/name'], 'Vox');
    expect(got['/ch/06/mix/on'], 0);
    expect(faderToDb(got['/bus/02/mix/fader'] as double), closeTo(0, 0.3));
    expect(faderToDb(got['/ch/01/mix/04/level'] as double), closeTo(10, 0.3));

    link.send(const OscMessage('/headamp/02/gain', [0.5]));
    link.send(const OscMessage('/ch/02/eq/1/g', [0.5]));
    await _until(() => fake.sent([0xE0, 1]));
    expect(fake.sent([0xE0, 1]), isTrue);
    expect(fake.sent([0xB0, 0x63, 1, 0xB0, 0x62, 0x1D, 0xB0, 0x06, 0x3F]), isTrue); // 0 dB

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('Qu asks for the whole state once and reads names', () async {
    final fake = FakeAh();
    await fake.start();
    final link = await AhLink.connect('127.0.0.1', 'QU16', port: fake.port);
    link.learn(AhLink.profileAddresses(MixerProfile.allenHeath('QU16')));
    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);
    link.send(const OscMessage('/ch/01/mix/fader'));
    link.send(const OscMessage('/ch/02/mix/fader'));
    await _until(() => fake.sent([...AhMap.quAllCall, 0x10, 0x01, 0xF7]));
    expect(fake.sent([...AhMap.quAllCall, 0x10, 0x01, 0xF7]), isTrue);
    fake.push([0xB0, 0x63, 0x20, 0xB0, 0x62, 0x17, 0xB0, 0x06, 0x62, 0xB0, 0x26, 0x07]);
    fake.push([...AhMap.quHeader, 0x02, 0x21, ...'Kick'.codeUnits, 0xF7]);
    link.send(const OscMessage('/ch/02/config/name'));
    await _until(() => got.length >= 2);
    expect(faderToDb(got['/ch/01/mix/fader'] as double), closeTo(0, 0.5));
    expect(got['/ch/02/config/name'], 'Kick');
    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('Qu channel processing and dLive formulas follow the protocol documents', () {
    final qu = AhMap('QU32');
    expect(qu.setBytes(qu.toAh('/ch/01/eq/2/g')!, qu.encode(AhKind.quEqGain, eqGainLaw.toNorm(0))!),
        [0xB0, 0x63, 0x20, 0xB0, 0x62, 0x05, 0xB0, 0x06, 0x40, 0xB0, 0x26, 0x07]);
    expect(qu.toAh('/headamp/01/gain')!.b, 0x19);
    expect(qu.toAh('/headamp/01/phantom')!.b, 0x69);
    expect(qu.toAh('/ch/01/gate/thr')!.b, 0x44);
    expect(qu.toAh('/ch/01/dyn/thr')!.b, 0x66);
    expect(qu.toAh('/bus/01/dyn/on')!.b, 0x68);
    expect(qu.toAh('/ch/01/mix/02/on')!.b, 0x55);
    expect(qu.toAh('/ch/01/eq/1/type')!.b, 0x04);
    expect(qu.encode(AhKind.quEqTypeLow, 1), 0x06);
    expect(qu.decode(AhKind.quEqTypeHigh, 0x06), 4);
    for (final (k, n) in [
      (AhKind.quEqGain, 0.6), (AhKind.quGain, 0.5), (AhKind.gateThr, 0.5), (AhKind.compThr, 0.7),
      (AhKind.quHpf, 0.4), (AhKind.compGain, 0.3), (AhKind.pan, 0.5),
    ]) {
      expect(qu.decode(k, qu.encode(k, n)!) as double, closeTo(n, 0.03), reason: '$k');
    }
    final dl = AhMap('DLIVE');
    // HPF: 100 Hz per the dLive document's formula
    expect(dl.encode(AhKind.hpfFreq, hpfLaw.toNorm(100)), (127 * (4608 * 4.643856 - 10699) / 41314).floor());
    expect(dl.decode(AhKind.hpfFreq, dl.encode(AhKind.hpfFreq, hpfLaw.toNorm(100))!) as double, closeTo(hpfLaw.toNorm(100), 0.02));
    expect(dl.encode(AhKind.eqGain, eqGainLaw.toNorm(15)), 0x7E);
    expect(dl.encode(AhKind.dlEqTypeLow, 0), 0x04);
    expect(dl.getBytes(dl.toAh('/ch/01/preamp/hpf')!), [...AhMap.dliveHeader, 0, 0x05, 0x0B, 0x30, 0, 0xF7]);
  });
}
