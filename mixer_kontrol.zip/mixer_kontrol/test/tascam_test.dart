// TASCAM Sonicview driver: Ember+ encoding, address translation, values,
// and sessions against a software Ember+ provider shaped like a Sonicview.

import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/ember/ember.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/meters.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/tascam/tascam_link.dart';
import 'package:mixer_kontrol/tascam/tascam_map.dart';
import 'package:mixer_kontrol/tascam/tascam_tables.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';

class _Node {
  _Node(this.name, this.number, this.path);
  final String name;
  final int number;
  final List<int> path;
  final List<_Node> kids = [];
  bool isParam = false;
  Object? value;
  List<String>? enumeration;
}

/// A fake Sonicview: an Ember+ provider with the parameters the app uses.
class FakeSonicview {
  FakeSonicview({this.product = 'Sonicview 24'});
  final String product;
  late ServerSocket _server;
  final List<Socket> clients = [];
  final _root = _Node('', 0, const []);
  final Map<String, _Node> byName = {};
  final List<String> sets = [];
  int directories = 0;
  int get port => _server.port;

  _Node _ensure(String name) {
    final hit = byName[name];
    if (hit != null) return hit;
    final i = name.lastIndexOf('/');
    final parent = i < 0 ? _root : _ensure(name.substring(0, i));
    final n = _Node(name, parent.kids.length + 1, [...parent.path, parent.kids.length + 1]);
    parent.kids.add(n);
    byName[name] = n;
    return n;
  }

  void param(String name, Object value, {List<String>? enumeration}) {
    final n = _ensure(name)
      ..isParam = true
      ..value = value
      ..enumeration = enumeration;
    byName[name] = n;
  }

  void build(MixerProfile p) {
    param('sonicview/identity/product', product);
    const map = TascamMap();
    for (final a in TascamLink.profileAddresses(p)) {
      for (final t in map.toTascam(a)) {
        if (byName[t.path]?.isParam ?? false) continue;
        switch (t.kind) {
          case TascamKind.name:
          case TascamKind.sceneName:
            param(t.path, '');
          case TascamKind.onOff:
          case TascamKind.muteInv:
          case TascamKind.maskBit:
            param(t.path, false);
          case TascamKind.sceneEmpty:
            param(t.path, true);
          case TascamKind.eqTypeLow:
            param(t.path, 0, enumeration: ['bell', 'lo_shelf']);
          case TascamKind.eqTypeHigh:
            param(t.path, 0, enumeration: ['bell', 'hi_shelf', 'lpf']);
          case TascamKind.gateMode:
            param(t.path, 0, enumeration: ['gate', 'exp', 'de-esser']);
          case TascamKind.compMode:
            param(t.path, 0, enumeration: ['comp', 'ducker']);
          default:
            param(t.path, 0);
        }
      }
    }
    for (var n = 1; n <= 128; n++) {
      param('sonicview/snapshots/snapshot_$n/recall', false);
    }
    const s = 'sonicview/meter_application/setting';
    param('$s/sv_meter_interval', 2);
    param('$s/sv_meter_udp_port', 41624);
    param('$s/sv_meter_ip_connect', '');
    param('$s/sv_meter_ip_disconnect', '');
  }

  Future<void> start() async {
    _server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    _server.listen((s) {
      clients.add(s);
      final dec = S101Decoder();
      s.listen((d) {
        for (final f in dec.add(d)) {
          if (f.command == S101.cmdKeepAliveRequest) {
            s.add(S101.keepAliveResponse());
          } else if (f.command == S101.cmdEmber) {
            _handle(s, f.payload);
          }
        }
      }, onError: (_) {});
    });
  }

  void _handle(Socket s, Uint8List ber) {
    for (final r in BerReader(ber).readAll()) {
      for (final coll in r.children) {
        for (final w in coll.children) {
          final e = w.inner()!;
          if (e.tag.isApp(Glow.command)) {
            directories++;
            _reply(s, _root);
          } else if (e.tag.isApp(Glow.qualifiedNode)) {
            final path = Ber.decodeRelOid(e.ctx(0)!.inner()!.content);
            final n = _find(path);
            directories++;
            if (n != null) _reply(s, n);
          } else if (e.tag.isApp(Glow.qualifiedParameter)) {
            final path = Ber.decodeRelOid(e.ctx(0)!.inner()!.content);
            final n = _find(path);
            final v = e.ctx(1)!.inner()!.ctx(2)!.inner()!;
            if (n == null) continue;
            n.value = Ber.decodeValue(v);
            sets.add('${n.name}=${n.value}');
            _push(n);
          }
        }
      }
    }
  }

  _Node? _find(List<int> path) {
    var n = _root;
    for (final i in path) {
      if (i < 1 || i > n.kids.length) return null;
      n = n.kids[i - 1];
    }
    return n;
  }

  List<int> _contents(_Node k) => BerWriter.set([
        ...BerWriter.ctx(0, BerWriter.utf8String(k.name.split('/').last)),
        if (k.isParam && k.value != null) ...BerWriter.ctx(2, BerWriter.value(k.value!)),
        if (k.enumeration != null) ...BerWriter.ctx(7, BerWriter.utf8String(k.enumeration!.join('\n'))),
      ]);

  void _reply(Socket s, _Node n) {
    final kids = [
      for (final k in n.kids)
        ...BerWriter.ctx(0, BerWriter.app(k.isParam ? Glow.parameter : Glow.node, [
          ...BerWriter.ctx(0, BerWriter.integer(k.number)),
          ...BerWriter.ctx(1, _contents(k)),
        ])),
    ];
    final List<int> el;
    if (n == _root) {
      el = kids;
    } else {
      el = BerWriter.ctx(0, BerWriter.app(Glow.qualifiedNode, [
        ...BerWriter.ctx(0, BerWriter.relOid(n.path)),
        ...BerWriter.ctx(2, BerWriter.app(Glow.elementCollection, kids)),
      ]));
    }
    s.add(S101.ember(BerWriter.app(Glow.root, BerWriter.app(Glow.rootElementCollection, el))));
  }

  void _push(_Node n) {
    final el = BerWriter.ctx(0, BerWriter.app(Glow.qualifiedParameter, [
      ...BerWriter.ctx(0, BerWriter.relOid(n.path)),
      ...BerWriter.ctx(1, BerWriter.set(BerWriter.ctx(2, BerWriter.value(n.value!)))),
    ]));
    final msg = S101.ember(BerWriter.app(Glow.root, BerWriter.app(Glow.rootElementCollection, el)));
    for (final c in clients) {
      c.add(msg);
    }
  }

  /// A change made on the console.
  void surface(String name, Object value) {
    final n = byName[name]!;
    n.value = value;
    _push(n);
  }

  Future<void> stop() async {
    for (final c in clients) {
      c.destroy();
    }
    await _server.close();
  }
}

Uint8List meterPacket(Map<int, List<int>> blocks) {
  final data = <int>[];
  blocks.forEach((tag, vals) {
    data
      ..addAll([tag & 0xff, tag >> 8, (vals.length * 2) & 0xff, (vals.length * 2) >> 8])
      ..addAll([for (final v in vals) ...[v & 0xff, v >> 8]]);
  });
  final crc = TascamMap.crc16Xmodem(data);
  return Uint8List.fromList([
    ...'SV_METER'.codeUnits, 0, 0, ...'DATA'.codeUnits, ...List.filled(10, 0),
    1, 0, 1, 0, crc & 0xff, crc >> 8, data.length & 0xff, data.length >> 8,
    ...data,
  ]);
}

Future<void> _until(bool Function() ok, {int ms = 4000}) async {
  final sw = Stopwatch()..start();
  while (!ok() && sw.elapsedMilliseconds < ms) {
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}

void main() {
  const map = TascamMap();

  test('BER and S101 round trips', () {
    for (final v in [0, 1, -1, 127, 128, -129, 1023, 341322, -32768, 1 << 40]) {
      expect(Ber.decodeInt(Uint8List.fromList(Ber.encodeInt(v))), v);
    }
    for (final v in [0.0, 1.5, -2.25, 1000.0, 0.1, -144.0]) {
      expect(Ber.decodeReal(Uint8List.fromList(Ber.encodeReal(v))), closeTo(v, 1e-12));
    }
    expect(Ber.decodeRelOid(Uint8List.fromList(Ber.encodeRelOid([1, 200, 3, 70000]))), [1, 200, 3, 70000]);
    // a frame with every escaped byte value survives
    final glow = Glow.setValue([1, 2, 254], 'xþÿ');
    final dec = S101Decoder();
    final frames = dec.add(S101.ember(glow));
    expect(frames.single.payload, glow);
    // split delivery and garbage in between
    final bytes = [0x12, 0x34, ...S101.ember(glow), 0xfe, 1, 2, 0xff, ...S101.ember(glow)];
    final got = <S101Frame>[];
    for (var i = 0; i < bytes.length; i += 3) {
      got.addAll(dec.add(bytes.sublist(i, i + 3 > bytes.length ? bytes.length : i + 3)));
    }
    expect(got.length, 2);
    // indefinite lengths are understood
    final indef = Uint8List.fromList([0x60, 0x80, 0x6b, 0x80, 0xa0, 0x80, 0x61, 0x80, 0xa0, 0x03, 0x02, 0x01, 0x05,
      0xa1, 0x80, 0x31, 0x80, 0xa0, 0x80, 0x0c, 0x01, 0x78, 0, 0, 0xa2, 0x80, 0x02, 0x01, 0x07, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0]);
    final els = parseGlow(indef);
    expect(els.single.path, [5]);
    expect(els.single.identifier, 'x');
    expect(els.single.value, 7);
  });

  test('app addresses map to Sonicview parameters', () {
    String one(String a) => map.toTascam(a).single.path;
    expect(one('/ch/01/mix/fader'), 'sonicview/channels/channel_1/fader');
    expect(one('/ch/40/mix/on'), 'sonicview/channels/channel_40/mute');
    expect(map.toTascam('/ch/41/mix/on'), isEmpty);
    expect(one('/auxin/02/config/name'), 'sonicview/channels/channel_stin_2/user_module_label');
    expect(one('/fxrtn/04/mix/pan'), 'sonicview/channels/channel_fxrtn_4/pan_bal');
    expect(one('/bus/22/eq/1/type'), 'sonicview/channels/channel_mix_22/eq/lo_band/eq_lo_band_type');
    expect(one('/main/st/dyn/thr'), 'sonicview/channels/channel_main_lr/dynamics_2/comp/dyn2_comp_threshold');
    expect(one('/ch/03/mix/05/level'), 'sonicview/send/bus_mix_5/send_lvl/send_lvl_mix5_channel_3');
    expect(one('/fxrtn/02/mix/05/on'), 'sonicview/send/bus_mix_5/send_sw/send_sw_mix5_bus_fx_2');
    expect(one('/ch/03/mix/24/level'), 'sonicview/send/bus_fx_2/send_lvl/send_lvl_fx2_channel_3');
    expect(one('/bus/04/mix/st'), 'sonicview/send/bus_main_lr/send_sw/send_sw_bus_mix_4');
    expect(one('/ch/07/gate/release'), 'sonicview/channels/channel_7/dynamics_1/gate/dyn1_gate_decay');
    expect(one('/ch/07/preamp/hpf'), 'sonicview/channels/channel_7/eq/hpf/hpf_freq');
    expect(one('/headamp/24/gain'), 'sonicview/sources/analog_24/analog_gain');
    expect(const TascamMap(layout: TascamLayout(analogInputs: 16)).toTascam('/headamp/17/gain'), isEmpty);
    expect(one('/dca/8/on'), 'sonicview/channels/channel_dca_8/mute');
    expect(one('/fxsend/3/mix/fader'), 'sonicview/fx/fx_3/fx_input_level');
    expect(one('/config/mute/8'), 'sonicview/channels/channel_mutegroup_8/mute');
    expect(map.toTascam('/ch/05/grp/dca').length, 8);
    expect(map.toTascam('/ch/05/grp/mute').last.path, 'sonicview/channels/channel_5/mutegroup8_assign');
    expect(map.toTascam('/-snap/128/name').length, 2);
    expect(TascamMap.constantFor('/ch/01/config/color'), 0);
    expect(TascamMap.constantFor('/ch/01/eq/2/type'), 2);
  });

  test('values convert both ways in console units', () {
    expect(map.encode(TascamKind.fader, dbToFader(0)), 816);
    expect(map.encode(TascamKind.fader, 0.0), 0);
    expect(TascamTables.faderDb[map.encode(TascamKind.fader, dbToFader(-10)) as int], closeTo(-10, 0.3));
    expect(map.decode(TascamKind.fader, 816) as double, closeTo(dbToFader(0), 1e-9));
    expect(map.decode(TascamKind.fader, 0), 0.0);
    expect(map.encode(TascamKind.muteInv, 1), false);
    expect(map.decode(TascamKind.muteInv, true), 0);
    expect(map.encode(TascamKind.pan, 0.5), 100);
    expect(TascamTables.eqFreq[map.encode(TascamKind.eqFreq, freqLaw.toNorm(1000)) as int], closeTo(1000, 60));
    expect(map.encode(TascamKind.eqGain, eqGainLaw.toNorm(-6)), -60);
    expect(map.decode(TascamKind.eqGain, 180) as double, 1.0); // +18 dB shown at the app's +15 limit
    expect(map.encode(TascamKind.eqTypeLow, 1, enumeration: ['bell', 'lo_shelf']), 1);
    expect(map.decode(TascamKind.eqTypeHigh, 2, enumeration: ['bell', 'hi_shelf', 'lpf']), 5);
    expect(map.encode(TascamKind.gateThr, gateThrLaw.toNorm(-30)), 50);
    expect(map.encode(TascamKind.gateRange, gateRangeLaw.toNorm(40)), 20);
    expect(map.decode(TascamKind.gateRange, 20) as double, closeTo(gateRangeLaw.toNorm(40), 1e-9));
    expect(map.encode(TascamKind.compThr, compThrLaw.toNorm(-20)), 29);
    expect(TascamTables.compRatio[map.encode(TascamKind.compRatio, 6) as int], 4.0); // 4:1
    expect(map.decode(TascamKind.compRatio, 15), 6);
    expect(map.encode(TascamKind.haGain, headampGainLaw.toNorm(30)), 30);
    expect(map.encode(TascamKind.haGain, 0.0), 12); // the console's minimum
    expect(TascamTables.trimDb[map.encode(TascamKind.trim, trimLaw.toNorm(-6)) as int], -6);
  });

  test('meter pages decode into the app blob', () {
    final raw = List<int>.filled(TascamMap.meterCount, 0);
    final p = meterPacket({
      0x0001: [for (var i = 0; i < 40; i++) i == 0 ? 0x7fff : 0x0fff],
      0x0007: [0x7fff, 0x3fff, 0, 0],
      0x0014: List.filled(22, 0x2000),
      0x001A: [0x7fff, 0x7fff],
    });
    expect(TascamMap.readMeterPacket(p, raw), isTrue);
    expect(TascamMap.meterWord(raw[0]) / 256, closeTo(0, 0.01));
    expect(TascamMap.meterWord(raw[41]) / 256, closeTo(-6.02, 0.05));
    expect(TascamMap.meterWord(raw[42]), -32768);
    expect(TascamMap.meterWord(raw[52]) / 256, closeTo(-12.04, 0.05));
    // a damaged packet is refused
    final bad = Uint8List.fromList(p)..[40] ^= 0xff;
    expect(TascamMap.readMeterPacket(bad, raw), isFalse);
    expect(TascamMap.readMeterPacket(Uint8List(10), raw), isFalse);
  });

  test('every Sonicview: profile addresses all translate, demo works', () {
    for (final m in TascamLayout.models) {
      final p = MixerProfile.tascam(m);
      final tm = TascamMap(layout: TascamLayout.forModel(m));
      final missing = [
        for (final a in TascamLink.profileAddresses(p))
          if (tm.toTascam(a).isEmpty && TascamMap.constantFor(a) == null &&
              !(a.startsWith('/headamp/') && int.parse(a.substring(9, 11)) > tm.layout.analogInputs) &&
              a != MixerProfile.yamahaSceneCurrentAddr && a != MixerProfile.monitorLevelAddr)
            a,
      ];
      expect(missing, isEmpty, reason: m);
      final d = MixerController.demo(MixerFamily.tascam, model: m);
      expect(d.profile.inputs.length, 46);
      d.dispose();
    }
  });

  test('session with a fake Sonicview: browse, sync, set, changes, masks, meters, snapshots', () async {
    final fake = FakeSonicview();
    final profile = MixerProfile.tascam('Sonicview 24');
    fake.build(profile);
    await fake.start();
    final link = await TascamLink.connect('127.0.0.1', port: fake.port);
    expect(await link.ready(), isTrue);
    expect(await link.askProduct(), 'Sonicview 24');
    link.learn(TascamLink.profileAddresses(profile));

    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);

    fake.byName['sonicview/channels/channel_3/fader']!.value = 816;
    fake.byName['sonicview/channels/channel_3/user_module_label']!.value = 'Pastor';
    fake.byName['sonicview/channels/channel_3/eq/lm_band/eq_band_gain']!.value = -60;
    fake.byName['sonicview/channels/channel_3/mute']!.value = true;
    link.send(const OscMessage('/ch/03/mix/fader'));
    link.send(const OscMessage('/ch/03/config/name'));
    link.send(const OscMessage('/ch/03/eq/2/g'));
    link.send(const OscMessage('/ch/03/mix/on'));
    await _until(() => got.length >= 4);
    expect(got['/ch/03/mix/fader'] as double, closeTo(dbToFader(0), 1e-9));
    expect(got['/ch/03/config/name'], 'Pastor');
    expect(got['/ch/03/eq/2/g'] as double, closeTo(eqGainLaw.toNorm(-6), 1e-9));
    expect(got['/ch/03/mix/on'], 0);

    // app changes become Ember+ sets
    link.send(const OscMessage('/ch/01/mix/04/level', [0.0]));
    link.send(const OscMessage('/ch/01/mix/on', [0]));
    link.send(const OscMessage('/ch/01/eq/1/type', [1]));
    await _until(() => fake.sets.length >= 3);
    expect(fake.sets, contains('sonicview/send/bus_mix_4/send_lvl/send_lvl_mix4_channel_1=0'));
    expect(fake.sets, contains('sonicview/channels/channel_1/mute=true'));
    expect(fake.sets, contains('sonicview/channels/channel_1/eq/lo_band/eq_lo_band_type=1'));

    // DCA mask: one switch per DCA
    link.send(const OscMessage('/ch/05/grp/dca', [5]));
    await _until(() => fake.sets.where((s) => s.contains('channel_5/dca')).length >= 8);
    expect(fake.byName['sonicview/channels/channel_5/dca1_assgin']!.value, true);
    expect(fake.byName['sonicview/channels/channel_5/dca2_assgin']!.value, false);
    expect(fake.byName['sonicview/channels/channel_5/dca3_assgin']!.value, true);
    fake.surface('sonicview/channels/channel_5/dca8_assgin', true);
    await _until(() => got['/ch/05/grp/dca'] == 5 | 128);
    expect(got['/ch/05/grp/dca'], 5 | 128);

    // changes on the console are pushed
    fake.surface('sonicview/channels/channel_mix_6/mute', true);
    fake.surface('sonicview/channels/channel_1/solo', true);
    await _until(() => got['/bus/06/mix/on'] == 0 && got['/ch/01/cue'] == 1);
    expect(got['/bus/06/mix/on'], 0);
    expect(got['/ch/01/cue'], 1);

    // snapshots: names (empty slots blank) and recall
    fake.byName['sonicview/snapshots/snapshot_7/name']!.value = 'Sermon';
    fake.byName['sonicview/snapshots/snapshot_7/empty']!.value = false;
    link.send(OscMessage(MixerProfile.yamahaSceneNameAddr(7)));
    link.send(OscMessage(MixerProfile.yamahaSceneNameAddr(8)));
    await _until(() => got[MixerProfile.yamahaSceneNameAddr(7)] == 'Sermon' &&
        got.containsKey(MixerProfile.yamahaSceneNameAddr(8)));
    expect(got[MixerProfile.yamahaSceneNameAddr(7)], 'Sermon');
    expect(got[MixerProfile.yamahaSceneNameAddr(8)], '');
    link.send(const OscMessage('/-snap/load', [7]));
    await _until(() => fake.sets.contains('sonicview/snapshots/snapshot_7/recall=true'));
    expect(fake.sets, contains('sonicview/snapshots/snapshot_7/recall=true'));

    // meters: the app's IP goes to the console, pages come back on UDP
    link.send(const OscMessage('/meters', [TascamLink.meterId]));
    await _until(() => fake.sets.any((s) => s.startsWith('sonicview/meter_application/setting/sv_meter_ip_connect=')));
    expect(fake.sets, contains('sonicview/meter_application/setting/sv_meter_ip_connect=127.0.0.1'));
    final tx = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, 0);
    final udpPort = fake.byName['sonicview/meter_application/setting/sv_meter_udp_port']!.value as int;
    tx.send(meterPacket({0x0001: List.filled(40, 0x7fff), 0x001A: [0x4000, 0x4000]}),
        InternetAddress.loopbackIPv4, udpPort);
    await _until(() => got.containsKey(TascamLink.meterId));
    final mv = decodeMeterBlob(got[TascamLink.meterId] as dynamic, MeterFormat.int16Db);
    expect(mv.length, TascamMap.meterCount);
    expect(mv[0], closeTo(0, 0.01));
    expect(mv[74], closeTo(-6.02, 0.05));
    tx.close();

    // keep-alive is answered
    link.send(const OscMessage('/xinfo'));
    await _until(() => got.containsKey(TascamLink.aliveAddr));
    expect(got[TascamLink.aliveAddr], 1);

    // garbage on the wire is ignored
    for (final c in fake.clients) {
      c.add([0xfe, 1, 2, 3, 4, 5, 6, 7, 0xff, 0x00, 0x11]);
      c.add(S101.ember([0x60, 0x05, 0x6b, 0x03, 0xa0, 0x01]));
    }
    await Future<void>.delayed(const Duration(milliseconds: 150));

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('a whole Sonicview profile syncs against the fake console', () async {
    final fake = FakeSonicview(product: 'Sonicview 16');
    final p = MixerProfile.tascam('Sonicview 16');
    fake.build(p);
    await fake.start();
    final link = await TascamLink.connect('127.0.0.1', port: fake.port);
    expect(await link.ready(), isTrue);
    link.useModel('Sonicview 16');
    final seen = <String>{};
    final sub = link.messages.listen((m) => seen.add(m.address));
    final want = {
      for (final a in p.queryAddresses)
        if (a != MixerProfile.monitorLevelAddr) a,
    };
    for (final a in want) {
      link.send(OscMessage(a));
    }
    await _until(() => seen.containsAll(want), ms: 15000);
    expect(want.difference(seen), isEmpty);
    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('connect fails cleanly when nothing listens', () async {
    final s = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = s.port;
    await s.close();
    await expectLater(TascamLink.connect('127.0.0.1', port: port, timeout: const Duration(seconds: 1)), throwsA(anything));
  });
}
