// Signed make-up: 0 dB in the middle, the negative side taken off the fader.

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/eq_presets.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';

void main() {
  for (final fam in MixerFamily.values) {
    test('negative make-up via the fader ($fam)', () {
      final c = MixerController.demo(fam);
      final s = c.profile.allStrips.firstWhere((x) => x.type == StripType.channel);
      double faderDb() => faderToDb(c.faderOf(s.faderAddr));

      c.set(s.faderAddr, dbToFader(-10));
      c.set(s.dynAddr('on'), 1);
      c.setMakeupDb(s, 3);
      expect(makeupLaw.toReal(c.numOf(s.dynAddr('mgain'), 0)), closeTo(3, 0.01));
      expect(faderDb(), closeTo(-10, 0.05));

      // down to -6: console make-up 0, fader 6 dB lower
      c.setMakeupDb(s, -6);
      expect(c.numOf(s.dynAddr('mgain'), 0), 0);
      expect(c.makeupDb(s), closeTo(-6, 0.01));
      expect(faderDb(), closeTo(-16, 0.05));

      // further to -8 only takes the extra 2 dB
      c.setMakeupDb(s, -8);
      expect(faderDb(), closeTo(-18, 0.05));

      // compressor off gives the level back, on takes it again
      c.set(s.dynAddr('on'), 0);
      expect(faderDb(), closeTo(-10, 0.05));
      c.set(s.dynAddr('on'), 1);
      expect(faderDb(), closeTo(-18, 0.05));

      // the user moves the fader meanwhile: the difference is kept
      c.set(s.faderAddr, dbToFader(-20));
      c.setMakeupDb(s, 0);
      expect(faderDb(), closeTo(-12, 0.05));
      expect(c.makeupDb(s), 0);

      // a preset with make-up restores the fader first
      c.setMakeupDb(s, -5);
      expect(faderDb(), closeTo(-17, 0.05));
      applyChannelPreset(c, s, channelEqPresets.firstWhere((p) => p.name == 'Lead vocal (male)'));
      expect(faderDb(), closeTo(-12, 0.05));
      expect(c.makeupDb(s), closeTo(3, 0.01));
      c.dispose();
    });
  }
}
