// Renders the mixer picker (brand grid, every brand's models, a model
// sheet) to PNG and prints them base64-encoded, so the pictures can be
// checked without a device. Fails on any layout overflow.

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/ui/app_style.dart';
import 'package:mixer_kontrol/ui/mixer_art.dart';
import 'package:mixer_kontrol/ui/mixer_catalog.dart';
import 'package:mixer_kontrol/ui/mixer_picker.dart';
import 'package:mixer_kontrol/ui/undo_toast.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> _loadRealFonts() async {
  final root = Platform.environment['FLUTTER_ROOT'];
  if (root == null) return;
  final dir = Directory('$root/bin/cache/artifacts/material_fonts');
  if (!dir.existsSync()) return;
  final roboto = FontLoader('Roboto');
  final icons = FontLoader('MaterialIcons');
  for (final f in dir.listSync().whereType<File>()) {
    final name = f.uri.pathSegments.last;
    final bytes = f.readAsBytes().then((b) => ByteData.view(b.buffer));
    if (name.startsWith('Roboto-') && !name.contains('Condensed')) roboto.addFont(bytes);
    if (name.startsWith('MaterialIcons-Regular')) icons.addFont(bytes);
  }
  await roboto.load();
  await icons.load();
}

final _shot = GlobalKey();

Widget _app(Widget home) => RepaintBoundary(
      key: _shot,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(brightness: Brightness.dark, useMaterial3: true, fontFamily: 'Roboto'),
        home: home,
      ),
    );

Future<void> _capture(WidgetTester tester, String name) async {
  await tester.runAsync(() async {
    final b = _shot.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final img = await b.toImage(pixelRatio: 1.0);
    final png = await img.toByteData(format: ui.ImageByteFormat.png);
    final s = base64Encode(png!.buffer.asUint8List());
    const chunk = 3000;
    for (var i = 0; i < s.length; i += chunk) {
      // ignore: avoid_print
      print('PNGB64 $name ${s.substring(i, i + chunk > s.length ? s.length : i + chunk)}');
    }
  });
}

void main() {
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await _loadRealFonts();
  });

  for (final (label, w, h) in const [('tablet', 1280.0, 800.0), ('phone', 412.0, 900.0)]) {
    testWidgets('mixer picker on $label', (tester) async {
      tester.view.physicalSize = Size(w, h);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.reset);

      String host() => '192.168.1.50';
      Future<void> connect(MixerModel m, String h) async {}
      void demo(MixerModel m) {}

      await tester.pumpWidget(_app(AppBackground(
        child: Scaffold(
          appBar: AppBar(title: const Text('Select your mixer')),
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: BrandGrid(lastHost: host, onConnect: connect, onDemo: demo),
              ),
            ),
          ),
        ),
      )));
      await tester.pumpAndSettle();
      await _capture(tester, '${label}_brands');

      for (final b in MixerCatalog.brands) {
        await tester.pumpWidget(_app(ModelPickerScreen(brand: b, lastHost: host, onConnect: connect, onDemo: demo)));
        await tester.pumpAndSettle();
        if (label == 'tablet') await _capture(tester, '${label}_${b.replaceAll(RegExp(r'[^A-Za-z]'), '')}');
        // scroll to the end too: nothing may overflow anywhere
        await tester.drag(find.byType(GridView), const Offset(0, -3000));
        await tester.pumpAndSettle();
      }

      // every drawing large, to check the details
      if (label == 'tablet') {
        final all = MixerCatalog.brands.expand(MixerCatalog.of).toList();
        for (var page = 0; page * 24 < all.length; page++) {
          final part = all.skip(page * 24).take(24).toList();
          await tester.pumpWidget(_app(ColoredBox(
            color: const Color(0xFF0B1020),
            child: Wrap(
              children: [
                for (final m in part)
                  SizedBox(
                    width: 213,
                    height: 200,
                    child: Column(children: [
                      MixerArt(spec: m.art, accent: MixerCatalog.accentOf(m.brand), width: 200, height: 130),
                      Text(m.name, style: const TextStyle(fontSize: 12, color: Colors.white)),
                    ]),
                  ),
              ],
            ),
          )));
          await tester.pumpAndSettle();
          await _capture(tester, 'tablet_art$page');
        }
      }

      // the undo note: small, bottom-right, gone after 3 s
      var undone = false;
      await tester.pumpWidget(_app(Scaffold(
        body: Builder(
          builder: (context) => Center(
            child: FilledButton(
              onPressed: () => showUndoToast(context, 'Applied "Vocal - Female"', () => undone = true),
              child: const Text('apply'),
            ),
          ),
        ),
      )));
      await tester.tap(find.text('apply'));
      await tester.pumpAndSettle();
      final bar = tester.getRect(find.descendant(of: find.byType(SnackBar), matching: find.byType(Material)).first);
      expect(bar.width, lessThanOrEqualTo(320));
      expect(bar.right, closeTo(w - 12, 1));
      await _capture(tester, '${label}_undo');
      await tester.tap(find.text('Undo'));
      expect(undone, isTrue);
      await tester.tap(find.text('apply'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 300));
      expect(find.byType(SnackBar), findsOneWidget);
      await tester.pump(const Duration(seconds: 3));
      await tester.pumpAndSettle();
      expect(find.byType(SnackBar), findsNothing, reason: 'gone after 3 s');

      // the sheet of one model
      await tester.pumpWidget(_app(ModelPickerScreen(brand: 'Yamaha', lastHost: host, onConnect: connect, onDemo: demo)));
      await tester.pumpAndSettle();
      await tester.tap(find.text('DM7').first);
      await tester.pumpAndSettle();
      await _capture(tester, '${label}_sheet');
    });
  }
}
