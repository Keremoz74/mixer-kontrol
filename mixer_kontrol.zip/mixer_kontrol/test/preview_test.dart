// Renders the mixer picker (brand grid, every brand's models, a model
// sheet) to PNG and prints them base64-encoded, so the pictures can be
// checked without a device. Fails on any layout overflow.

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/ui/app_style.dart';
import 'package:mixer_kontrol/ui/channel_strip.dart';
import 'package:mixer_kontrol/ui/fader.dart';
import 'package:mixer_kontrol/ui/mixer_screen.dart';
import 'package:mixer_kontrol/ui/mixer_art.dart';
import 'package:mixer_kontrol/ui/mixer_catalog.dart';
import 'package:mixer_kontrol/ui/mixer_picker.dart';
import 'package:mixer_kontrol/ui/undo_toast.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> _loadRealFonts() async {
  final root = Platform.environment['FLUTTER_ROOT'];
  if (root == null) return;
  final dir = Directory('$root/bin/cache/artifacts/material_fonts');
  if (!dir.existsSync()) return;
  final roboto = FontLoader('Roboto');
  final icons = FontLoader('MaterialIcons');
  for (final f in dir.listSync().whereType<File>()) {
    final name = f.uri.pathSegments.last;
    final bytes = f.readAsBytes().then((b) => ByteData.view(b.buffer));
    if (name.startsWith('Roboto-') && !name.contains('Condensed')) roboto.addFont(bytes);
    if (name.startsWith('MaterialIcons-Regular')) icons.addFont(bytes);
  }
  await roboto.load();
  await icons.load();
}

final _shot = GlobalKey();

Widget _app(Widget home) => RepaintBoundary(
      key: _shot,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(brightness: Brightness.dark, useMaterial3: true, fontFamily: 'Roboto'),
        home: home,
      ),
    );

Future<void> _capture(WidgetTester tester, String name) async {
  await tester.runAsync(() async {
    final b = _shot.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final img = await b.toImage(pixelRatio: 1.0);
    final png = await img.toByteData(format: ui.ImageByteFormat.png);
    final s = base64Encode(png!.buffer.asUint8List());
    const chunk = 3000;
    for (var i = 0; i < s.length; i += chunk) {
      // ignore: avoid_print
      print('PNGB64 $name ${s.substring(i, i + chunk > s.length ? s.length : i + chunk)}');
    }
  });
}

void main() {
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await _loadRealFonts();
  });

  for (final (label, w, h) in const [('tablet', 1280.0, 800.0), ('phone', 412.0, 900.0)]) {
    testWidgets('mixer picker on $label', (tester) async {
      tester.view.physicalSize = Size(w, h);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.reset);

      String host() => '192.168.1.50';
      Future<void> connect(MixerModel m, String h) async {}
      void demo(MixerModel m) {}

      await tester.pumpWidget(_app(AppBackground(
        child: Scaffold(
          appBar: AppBar(title: const Text('Select your mixer')),
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: BrandGrid(lastHost: host, onConnect: connect, onDemo: demo),
              ),
            ),
          ),
        ),
      )));
      await tester.pumpAndSettle();
      await _capture(tester, '${label}_brands');

      // tapping a brand opens its models in a window in the middle
      await tester.tap(find.text('Yamaha'));
      await tester.pumpAndSettle();
      expect(find.byType(Dialog), findsOneWidget);
      expect(find.text('TF1'), findsOneWidget);
      await _capture(tester, '${label}_dialog');
      await tester.tap(find.byTooltip('Close'));
      await tester.pumpAndSettle();
      expect(find.byType(Dialog), findsNothing);

      for (final b in MixerCatalog.brands) {
        await tester.pumpWidget(_app(ModelPickerScreen(brand: b, lastHost: host, onConnect: connect, onDemo: demo)));
        await tester.pumpAndSettle();
        if (label == 'tablet') await _capture(tester, '${label}_${b.replaceAll(RegExp(r'[^A-Za-z]'), '')}');
        // scroll to the end too: nothing may overflow anywhere
        await tester.drag(find.byType(GridView), const Offset(0, -3000));
        await tester.pumpAndSettle();
      }

      // every drawing large, to check the details
      if (label == 'tablet') {
        final all = MixerCatalog.brands.expand(MixerCatalog.of).toList();
        for (var page = 0; page * 16 < all.length; page++) {
          final part = all.skip(page * 16).take(16).toList();
          await tester.pumpWidget(_app(Material(
            color: const Color(0xFF0B1020),
            child: Wrap(
              children: [
                for (final m in part)
                  SizedBox(
                    width: 320,
                    height: 200,
                    child: Column(children: [
                      MixerArt(spec: m.art, accent: MixerCatalog.accentOf(m.brand), width: 300, height: 170),
                      Text('${m.brand} ${m.name}', style: const TextStyle(fontSize: 13, color: Colors.white)),
                    ]),
                  ),
              ],
            ),
          )));
          await tester.pumpAndSettle();
          await _capture(tester, 'tablet_art$page');
        }
      }

      // the undo note: small, bottom-right, gone after 3 s
      var undone = false;
      await tester.pumpWidget(_app(Scaffold(
        body: Builder(
          builder: (context) => Center(
            child: FilledButton(
              onPressed: () => showUndoToast(context, 'Applied "Vocal - Female"', () => undone = true),
              child: const Text('apply'),
            ),
          ),
        ),
      )));
      await tester.tap(find.text('apply'));
      await tester.pumpAndSettle();
      final bar = tester.getRect(find.descendant(of: find.byType(SnackBar), matching: find.byType(Material)).first);
      expect(bar.width, lessThanOrEqualTo(320));
      expect(bar.right, closeTo(w - 12, 1));
      await _capture(tester, '${label}_undo');
      await tester.tap(find.text('Undo'));
      expect(undone, isTrue);
      await tester.tap(find.text('apply'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 300));
      expect(find.byType(SnackBar), findsOneWidget);
      await tester.pump(const Duration(seconds: 3));
      await tester.pumpAndSettle();
      expect(find.byType(SnackBar), findsNothing, reason: 'gone after 3 s');

      // the sheet of one model
      await tester
          .pumpWidget(_app(ModelPickerScreen(brand: 'Yamaha', lastHost: host, onConnect: connect, onDemo: demo)));
      await tester.pumpAndSettle();
      await tester.tap(find.text('DM7').first);
      await tester.pumpAndSettle();
      await _capture(tester, '${label}_sheet');
    });
  }

  // the mixer in portrait: the tab bar (Inputs / Buses / Matrix / DCA /
  // Layers) must keep every label on one line
  testWidgets('mixer tabs in portrait', (tester) async {
    tester.view.physicalSize = const Size(412, 900);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    final c = MixerController.demo(MixerFamily.x32);
    await tester.pumpWidget(_app(MixerScreen(controller: c)));
    await tester.pump(const Duration(seconds: 1));
    for (final t in ['Inputs', 'Buses', 'Matrix', 'DCA', 'Layers']) {
      final f = find.text(t);
      expect(f, findsWidgets, reason: t);
      // one line: the text is no taller than a single line of 12 px type
      expect(tester.getSize(f.first).height, lessThan(20), reason: '$t wraps');
    }
    await _capture(tester, 'phone_mixer');
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 2));
  });

  // the mixer in landscape: the bank and mix pills must sit fully on screen,
  // also with large system text
  for (final (label, w, h, scale) in const [('land', 900.0, 412.0, 1.0), ('landbig', 860.0, 400.0, 1.3)]) {
    testWidgets('mixer header in $label', (tester) async {
      tester.view.physicalSize = Size(w, h);
      tester.view.devicePixelRatio = 1.0;
      tester.platformDispatcher.textScaleFactorTestValue = scale;
      addTearDown(tester.view.reset);
      addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);
      final c = MixerController.demo(MixerFamily.x32);
      await tester.pumpWidget(_app(MixerScreen(controller: c)));
      await tester.pump(const Duration(seconds: 1));
      final drops = find.byIcon(Icons.arrow_drop_down);
      expect(drops, findsWidgets);
      for (final e in drops.evaluate()) {
        final r = tester.getRect(find.byWidget(e.widget).first);
        expect(r.right, lessThanOrEqualTo(w), reason: 'a pill runs off the screen');
      }
      // the mix name is shown in full (shrunk if need be, never cut to "Mai…")
      final name = find.descendant(of: find.byType(FittedBox), matching: find.text('Main LR'));
      expect(name, findsOneWidget);
      // and the title in full too
      expect(find.descendant(of: find.byType(FittedBox), matching: find.textContaining('Demo')), findsOneWidget);
      await _capture(tester, 'phone_$label');
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 2));
    });
  }

  // strips per page: 8 / 16 / full screen, picked in the bank menu and kept;
  // a page never scrolls sideways: exactly 8 / 16 / all strips share the width
  for (final (label, w, h) in const [('tablet', 1280.0, 800.0), ('land', 900.0, 412.0), ('phone', 412.0, 900.0)]) {
    testWidgets('page size on $label', (tester) async {
      SharedPreferences.setMockInitialValues({});
      tester.view.physicalSize = Size(w, h);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.reset);
      Future<void> pick(String item) async {
        await tester.tap(find.byTooltip('Channel bank'));
        await tester.pumpAndSettle();
        await tester.tap(find.text(item).last);
        await tester.pumpAndSettle();
      }

      // every strip built is fully on screen (a scrolling row would build
      // strips past the edge too) and wide enough to use
      void allOnScreen(String what) {
        final rects = find.byType(ChannelStrip).evaluate().map((e) => tester.getRect(find.byWidget(e.widget))).toList();
        expect(rects.length, greaterThan(2), reason: what);
        for (final r in rects) {
          expect(r.right, lessThanOrEqualTo(w + 0.5), reason: '$what scrolls');
        }
        expect(find.text('FX').hitTestable(), findsWidgets, reason: '$what: FX shortcut');
      }

      final c = MixerController.demo(MixerFamily.x32);
      await tester.pumpWidget(_app(MixerScreen(controller: c)));
      await tester.pump(const Duration(seconds: 1));
      expect(find.text('1-8'), findsWidgets);

      allOnScreen('8');
      await pick('16');
      allOnScreen('16');
      expect(find.text('1-16'), findsWidgets);
      expect(find.byType(ChannelStrip), findsNWidgets(17));
      await _capture(tester, '${label}_page16');

      await pick('Full screen');
      allOnScreen('full');
      expect(find.text('1-32'), findsWidgets);
      expect(find.byType(ChannelStrip), findsNWidgets(33));
      await _capture(tester, '${label}_full');
      // a fader still moves in a slim strip
      final before = c.param('/ch/01/mix/fader').value;
      await tester.drag(find.byType(VerticalFader).first, const Offset(0, -60));
      await tester.pump(const Duration(milliseconds: 300));
      expect(c.param('/ch/01/mix/fader').value, isNot(before));

      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getInt('bank_size'), 0, reason: 'kept for next time');
      await pick('8');
      expect(find.text('1-8'), findsWidgets);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 2));
    });
  }
}
