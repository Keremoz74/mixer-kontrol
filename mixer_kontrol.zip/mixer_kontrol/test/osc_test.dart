import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/fx_catalog.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/mixer/snapshot_store.dart';
import 'package:mixer_kontrol/osc/meters.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/util/dyn_math.dart';
import 'package:mixer_kontrol/util/eq_math.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';

void main() {
  test('OSC float round trip', () {
    final m = OscMessage('/ch/01/mix/fader', [0.75]);
    final d = OscMessage.decode(m.encode())!;
    expect(d.address, '/ch/01/mix/fader');
    expect(d.args.single as double, closeTo(0.75, 1e-6));
  });

  test('OSC string/int round trip and padding', () {
    final bytes = const OscMessage('/info').encode();
    expect(bytes.length, 12); // "/info\0\0\0" + ",\0\0\0"
    final d = OscMessage.decode(OscMessage('/xinfo', ['192.168.1.5', 'Sahne', 'XR18', '1.17']).encode())!;
    expect(d.args, ['192.168.1.5', 'Sahne', 'XR18', '1.17']);
    final i = OscMessage.decode(const OscMessage('/ch/01/mix/on', [0]).encode())!;
    expect(i.args.single, 0);
  });

  test('fader law', () {
    expect(faderToDb(0.75), closeTo(0, 1e-9));
    expect(faderToDb(1.0), closeTo(10, 1e-9));
    expect(dbToFader(0), closeTo(0.75, 1e-9));
    expect(dbToFader(-40), closeTo(0.1875, 1e-9));
    expect(formatDb(0), '-∞');
  });

  test('X32 meter blob: little-endian count + linear floats', () {
    final bd = ByteData(12)
      ..setInt32(0, 2, Endian.little)
      ..setFloat32(4, 1.0, Endian.little)
      ..setFloat32(8, 0.1, Endian.little);
    final v = decodeMeterBlob(bd.buffer.asUint8List(), MeterFormat.float32Linear);
    expect(v.length, 2);
    expect(v[0], closeTo(0, 1e-4));
    expect(v[1], closeTo(-20, 1e-4));
  });

  test('XR meter blob: int16 at 1/256 dB, -32768 = silence', () {
    final bd = ByteData(10)
      ..setInt32(0, 3, Endian.little)
      ..setInt16(4, 0, Endian.little)
      ..setInt16(6, -5120, Endian.little)
      ..setInt16(8, -32768, Endian.little);
    final v = decodeMeterBlob(bd.buffer.asUint8List(), MeterFormat.int16Db);
    expect(v, [0.0, -20.0, double.negativeInfinity]);
  });

  test('meter blob survives a full OSC round trip', () {
    final blob = (ByteData(8)
          ..setInt32(0, 1, Endian.little)
          ..setFloat32(4, 0.5, Endian.little))
        .buffer
        .asUint8List();
    final d = OscMessage.decode(OscMessage('/meters/0', [blob]).encode())!;
    final v = decodeMeterBlob(d.args.single as Uint8List, MeterFormat.float32Linear);
    expect(v.single, closeTo(-6.02, 0.01));
  });

  test('meter indices', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.buses.first.meterIdx, [48]);
    expect(x32.main.meterIdx, [22, 23]);
    expect(xr.inputs.firstWhere((s) => s.prefix == '/rtn/4').meterIdx, [24, 25]);
    expect(xr.buses.firstWhere((s) => s.prefix == '/fxsend/1').meterIdx, [32]);
    expect(xr.dcas.first.hasMeter, isFalse);
  });

  test('parameter laws', () {
    expect(freqLaw.toReal(0), closeTo(20, 1e-9));
    expect(freqLaw.toReal(1), closeTo(20000, 1e-6));
    expect(freqLaw.toNorm(freqLaw.toReal(0.37)), closeTo(0.37, 1e-9));
    expect(qLaw.toReal(0), closeTo(10, 1e-9));
    expect(qLaw.toReal(1), closeTo(0.3, 1e-9));
    expect(panLaw.toReal(0.5), closeTo(0, 1e-9));
    expect(headampGainLaw.toReal(0), -12);
    expect(hpfLaw.toNorm(400), 1);
    expect(formatPan(-50), 'L50');
    expect(formatHz(2500), '2.50 kHz');
  });

  test('EQ curve math', () {
    expect(bandResponseDb(EqType.peq, 1000, 6, 2, 1000), closeTo(6, 1e-6));
    expect(bandResponseDb(EqType.lowCut, 100, 0, 0.707, 100), closeTo(-3, 0.05));
    expect(bandResponseDb(EqType.lowShelf, 100, 6, 0.707, 20), closeTo(6, 0.05));
    expect(bandResponseDb(EqType.highCut, 10000, 0, 0.707, 1000), closeTo(0, 0.01));
  });

  test('dynamics laws and curves', () {
    expect(compRatios[6], 4.0);
    expect(formatRatio(compRatios[0]), '1.1:1');
    expect(formatRatio(compRatios[11]), '100:1');
    expect(holdLaw.toReal(1), closeTo(2000, 1e-6));
    expect(releaseLaw.toReal(0), closeTo(5, 1e-9));
    expect(formatMs(1500), '1.50 s');
    expect(gateOut(-60, mode: 3, thr: -50, range: 40), -100);
    expect(gateOut(-40, mode: 3, thr: -50, range: 40), -40);
    expect(gateOut(-60, mode: 0, thr: -50, range: 40), -70); // 1:2 expander
    expect(compOut(0, mode: 0, thr: -20, ratio: 4, knee: 0, makeup: 0), -15);
    expect(compOut(-30, mode: 0, thr: -20, ratio: 4, knee: 0, makeup: 6), -24);
    // Soft knee joins the straight parts without a step
    expect(compOut(-24, mode: 0, thr: -20, ratio: 4, knee: 2, makeup: 0), closeTo(-24, 1e-9));
    expect(compOut(-16, mode: 0, thr: -20, ratio: 4, knee: 2, makeup: 0), closeTo(-19, 1e-9));
  });

  test('channel detail addresses', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    final x1 = x32.inputs.first;
    final r5 = xr.inputs[4];
    expect(x1.eqAddr(2, 'f'), '/ch/01/eq/2/f');
    expect(x32.detailAddresses(x1), contains('/ch/01/preamp/trim'));
    expect(x32.detailAddresses(x1), contains('/ch/01/config/source'));
    expect(xr.detailAddresses(r5), containsAll(['/ch/05/gate/thr', '/ch/05/dyn/ratio']));
    expect(xr.detailAddresses(r5), isNot(contains('/ch/05/preamp/trim')));
    expect(xr.headampDependencies(r5), isEmpty);
  });

  group('X32 preamp resolution', () {
    int? Function(String) reader(Map<String, int> m) => (a) => m[a];
    const blocks = MixerProfile.x32RoutingBlocks;

    test('default routing: ch 5 ← In 5 ← AN1-8 → Local 5', () {
      final idx = MixerProfile.x32HeadampIndex(5, reader({
        '/ch/05/config/source': 5,
        blocks[0]: 0,
      }));
      expect(idx, 4);
      expect(MixerProfile.x32HeadampName(idx!), 'Local 5');
      expect(MixerProfile.x32HeadampPrefix(idx), '/headamp/004');
    });

    test('In 9-16 fed by AES50-A 17-24 (stage box)', () {
      final idx = MixerProfile.x32HeadampIndex(12, reader({
        '/ch/12/config/source': 12, // In 12 → block 9-16, 4th slot
        blocks[1]: 6, // A17-24
      }));
      expect(idx, 32 + 16 + 3);
      expect(MixerProfile.x32HeadampName(idx!), 'AES50-A 20');
    });

    test('AES50-B and card', () {
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 1, blocks[0]: 10})), 80);
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 1, blocks[0]: 16})), -1);
    });

    test('user routing (FW 4+)', () {
      final m = {'/ch/03/config/source': 3, blocks[0]: 20, '/config/userrout/in/03': 40};
      expect(MixerProfile.x32HeadampIndex(3, reader(m)), 32 + 7); // AES50-A 8
      m['/config/userrout/in/03'] = 150; // card input
      expect(MixerProfile.x32HeadampIndex(3, reader(m)), -1);
    });

    test('sources without a preamp, and unknown values', () {
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 0})), -1); // OFF
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 39})), -1); // USB
      expect(MixerProfile.x32HeadampIndex(1, reader({})), isNull);
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 1})), isNull);
    });
  });

  test('FX catalog', () {
    expect(fxFullList.length, 61); // /fx/N/type 0-60
    expect(fxInsertList.length, 34); // X32 /fx/5-8/type 0-33
    for (final code in [...fxFullList, ...fxInsertList]) {
      expect(fxCatalog.containsKey(code), isTrue, reason: code);
    }
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.fxSlots, 8);
    expect(xr.fxSlots, 4);
    expect(x32.fxTypesForSlot(5), same(fxInsertList));
    expect(xr.fxTypesForSlot(4), same(fxFullList));
    expect(x32.fxParAddr(2, 7), '/fx/2/par/07');
  });

  test('snapshots never touch preamps or routing', () {
    for (final p in [
      MixerProfile.forFamily(MixerFamily.x32, 'X32'),
      MixerProfile.forFamily(MixerFamily.xr, 'XR18'),
    ]) {
      final addrs = p.snapshotAddresses();
      expect(addrs.where((a) => a.startsWith('/headamp')), isEmpty);
      expect(addrs.where((a) => a.startsWith('/config/routing') || a.contains('/config/source')), isEmpty);
      expect(addrs, contains('/ch/01/eq/1/f'));
      expect(addrs, contains('/fx/1/type'));
    }
  });

  test('snapshot JSON keeps value types', () {
    final s = Snapshot(
      id: 'a',
      name: 'Test',
      family: MixerFamily.xr,
      model: 'XR18',
      savedAt: DateTime.fromMillisecondsSinceEpoch(1000),
      values: {'/ch/01/mix/fader': 1.0, '/ch/01/mix/on': 1, '/ch/01/config/name': 'Vox'},
    );
    final back = Snapshot.fromJson(jsonDecode(jsonEncode(s.toJson())) as Map<String, dynamic>)!;
    expect(back.values['/ch/01/mix/fader'], isA<double>());
    expect(back.values['/ch/01/mix/on'], isA<int>());
    expect(back.values['/ch/01/config/name'], 'Vox');
    expect(back.family, MixerFamily.xr);
  });

  test('EQ on buses and Main LR', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.inputs.first.eqBands, 4);
    expect(x32.buses.first.eqBands, 6);
    expect(x32.main.eqBands, 6);
    expect(x32.dcas.first.hasEq, isFalse);
    expect(xr.buses.firstWhere((s) => s.prefix == '/fxsend/1').hasEq, isFalse);
    expect(x32.detailAddresses(x32.buses.first), contains('/bus/01/eq/6/f'));
    expect(x32.detailAddresses(x32.main), contains('/main/st/eq/1/type'));
    expect(xr.detailAddresses(xr.main), contains('/lr/eq/6/q'));
    expect(x32.detailAddresses(x32.main).where((a) => a.contains('headamp')), isEmpty);
    expect(x32.snapshotAddresses(), contains('/bus/16/eq/3/g'));
    expect(xr.snapshotAddresses(), contains('/lr/eq/on'));
    expect(eqDefaultType(1, 6), 1);
    expect(eqDefaultType(6, 6), 4);
    expect(eqDefaultFreq(4, 4), 10000);
    expect(x32.fxSourceAddr(2), '/fx/2/source/l');
  });

  test('console snapshot / scene library addresses', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(xr.consoleSlots.first, 1);
    expect(xr.consoleSlots.last, 64);
    expect(xr.consoleNameAddr(7), '/-snap/07/name');
    expect(xr.consoleHasDataAddr(7), isNull);
    expect(x32.consoleSlots.first, 0);
    expect(x32.consoleSlots.last, 99);
    expect(x32.consoleNameAddr(5), '/-show/showfile/scene/005/name');
    expect(x32.consoleHasDataAddr(5), '/-show/showfile/scene/005/hasdata');
    expect(x32.consoleLibraryAddresses.length, 1 + 200);
  });

  test('channel banks', () {
    List<String> labels(List<Strip> s) => [for (final b in makeBanks(s)) b.label];
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    final xr12 = MixerProfile.forFamily(MixerFamily.xr, 'XR12');
    expect(labels(x32.inputs), ['1-8', '9-16', '17-24', '25-32', 'Aux 1-8', 'FX 1-8']);
    expect(labels(x32.buses), ['Bus 1-8', 'Bus 9-16', 'Matrix']);
    expect(labels(x32.dcas), ['DCA']);
    expect(labels(xr.inputs), ['1-8', '9-16', 'Aux/FX']);
    expect(labels(xr.buses), ['Bus 1-6', 'FX Send']);
    expect(labels(xr12.inputs), ['1-8', '9-12', 'Aux/FX']);
    expect(makeBanks(x32.inputs)[1].strips.first.prefix, '/ch/09');
  });

  test('model detection and addresses', () {
    expect(MixerProfile.familyFromModel('X32'), MixerFamily.x32);
    expect(MixerProfile.familyFromModel('XR18'), MixerFamily.xr);
    expect(MixerProfile.familyFromModel('MR18'), MixerFamily.xr);
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.buses.first.faderAddr, '/bus/01/mix/fader');
    expect(xr.buses.first.faderAddr, '/bus/1/mix/fader');
    expect(x32.main.faderAddr, '/main/st/mix/fader');
    expect(xr.main.faderAddr, '/lr/mix/fader');
    expect(xr.inputs.first.sendLevelAddr(xr.sendTargets[6]), '/ch/01/mix/07/level');
    expect(x32.dcas.first.onAddr, '/dca/1/on');
  });
}
