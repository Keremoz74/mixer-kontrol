import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/copy_paste.dart';
import 'package:mixer_kontrol/mixer/eq_presets.dart';
import 'package:mixer_kontrol/mixer/fx_catalog.dart';
import 'package:mixer_kontrol/mixer/inserts.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/mixer/snapshot_store.dart';
import 'package:mixer_kontrol/osc/meters.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/util/dyn_math.dart';
import 'package:mixer_kontrol/util/eq_math.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';

import 'package:mixer_kontrol/mixer/rta.dart';

void main() {
  test('OSC float round trip', () {
    final m = OscMessage('/ch/01/mix/fader', [0.75]);
    final d = OscMessage.decode(m.encode())!;
    expect(d.address, '/ch/01/mix/fader');
    expect(d.args.single as double, closeTo(0.75, 1e-6));
  });

  test('OSC string/int round trip and padding', () {
    final bytes = const OscMessage('/info').encode();
    expect(bytes.length, 12); // "/info\0\0\0" + ",\0\0\0"
    final d = OscMessage.decode(OscMessage('/xinfo', ['192.168.1.5', 'Sahne', 'XR18', '1.17']).encode())!;
    expect(d.args, ['192.168.1.5', 'Sahne', 'XR18', '1.17']);
    final i = OscMessage.decode(const OscMessage('/ch/01/mix/on', [0]).encode())!;
    expect(i.args.single, 0);
  });

  test('fader law', () {
    expect(faderToDb(0.75), closeTo(0, 1e-9));
    expect(faderToDb(1.0), closeTo(10, 1e-9));
    expect(dbToFader(0), closeTo(0.75, 1e-9));
    expect(dbToFader(-40), closeTo(0.1875, 1e-9));
    expect(formatDb(0), '-∞');
  });

  test('X32 meter blob: little-endian count + linear floats', () {
    final bd = ByteData(12)
      ..setInt32(0, 2, Endian.little)
      ..setFloat32(4, 1.0, Endian.little)
      ..setFloat32(8, 0.1, Endian.little);
    final v = decodeMeterBlob(bd.buffer.asUint8List(), MeterFormat.float32Linear);
    expect(v.length, 2);
    expect(v[0], closeTo(0, 1e-4));
    expect(v[1], closeTo(-20, 1e-4));
  });

  test('XR meter blob: int16 at 1/256 dB, -32768 = silence', () {
    final bd = ByteData(10)
      ..setInt32(0, 3, Endian.little)
      ..setInt16(4, 0, Endian.little)
      ..setInt16(6, -5120, Endian.little)
      ..setInt16(8, -32768, Endian.little);
    final v = decodeMeterBlob(bd.buffer.asUint8List(), MeterFormat.int16Db);
    expect(v, [0.0, -20.0, double.negativeInfinity]);
  });

  test('meter blob survives a full OSC round trip', () {
    final blob = (ByteData(8)
          ..setInt32(0, 1, Endian.little)
          ..setFloat32(4, 0.5, Endian.little))
        .buffer
        .asUint8List();
    final d = OscMessage.decode(OscMessage('/meters/0', [blob]).encode())!;
    final v = decodeMeterBlob(d.args.single as Uint8List, MeterFormat.float32Linear);
    expect(v.single, closeTo(-6.02, 0.01));
  });

  test('meter indices', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.buses.first.meterIdx, [48]);
    expect(x32.main.meterIdx, [22, 23]);
    expect(xr.inputs.firstWhere((s) => s.prefix == '/rtn/4').meterIdx, [24, 25]);
    expect(xr.buses.firstWhere((s) => s.prefix == '/fxsend/1').meterIdx, [32]);
    expect(xr.dcas.first.hasMeter, isFalse);
  });

  test('parameter laws', () {
    expect(freqLaw.toReal(0), closeTo(20, 1e-9));
    expect(freqLaw.toReal(1), closeTo(20000, 1e-6));
    expect(freqLaw.toNorm(freqLaw.toReal(0.37)), closeTo(0.37, 1e-9));
    expect(qLaw.toReal(0), closeTo(10, 1e-9));
    expect(qLaw.toReal(1), closeTo(0.3, 1e-9));
    expect(panLaw.toReal(0.5), closeTo(0, 1e-9));
    expect(headampGainLaw.toReal(0), -12);
    expect(hpfLaw.toNorm(400), 1);
    expect(formatPan(-50), 'L50');
    expect(formatHz(2500), '2.50 kHz');
  });

  test('EQ curve math', () {
    expect(bandResponseDb(EqType.peq, 1000, 6, 2, 1000), closeTo(6, 1e-6));
    expect(bandResponseDb(EqType.lowCut, 100, 0, 0.707, 100), closeTo(-3, 0.05));
    expect(bandResponseDb(EqType.lowShelf, 100, 6, 0.707, 20), closeTo(6, 0.05));
    expect(bandResponseDb(EqType.highCut, 10000, 0, 0.707, 1000), closeTo(0, 0.01));
  });

  test('dynamics laws and curves', () {
    expect(compRatios[6], 4.0);
    expect(formatRatio(compRatios[0]), '1.1:1');
    expect(formatRatio(compRatios[11]), '100:1');
    expect(holdLaw.toReal(1), closeTo(2000, 1e-6));
    expect(releaseLaw.toReal(0), closeTo(5, 1e-9));
    expect(formatMs(1500), '1.50 s');
    expect(gateOut(-60, mode: 3, thr: -50, range: 40), -100);
    expect(gateOut(-40, mode: 3, thr: -50, range: 40), -40);
    expect(gateOut(-60, mode: 0, thr: -50, range: 40), -70); // 1:2 expander
    expect(compOut(0, mode: 0, thr: -20, ratio: 4, knee: 0, makeup: 0), -15);
    expect(compOut(-30, mode: 0, thr: -20, ratio: 4, knee: 0, makeup: 6), -24);
    // Soft knee joins the straight parts without a step
    expect(compOut(-24, mode: 0, thr: -20, ratio: 4, knee: 2, makeup: 0), closeTo(-24, 1e-9));
    expect(compOut(-16, mode: 0, thr: -20, ratio: 4, knee: 2, makeup: 0), closeTo(-19, 1e-9));
  });

  test('channel detail addresses', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    final x1 = x32.inputs.first;
    final r5 = xr.inputs[4];
    expect(x1.eqAddr(2, 'f'), '/ch/01/eq/2/f');
    expect(x32.detailAddresses(x1), contains('/ch/01/preamp/trim'));
    expect(x32.detailAddresses(x1), contains('/ch/01/config/source'));
    expect(xr.detailAddresses(r5), containsAll(['/ch/05/gate/thr', '/ch/05/dyn/ratio']));
    expect(xr.detailAddresses(r5), isNot(contains('/ch/05/preamp/trim')));
    expect(xr.headampDependencies(r5), isEmpty);
  });

  group('X32 preamp resolution', () {
    int? Function(String) reader(Map<String, int> m) => (a) => m[a];
    const blocks = MixerProfile.x32RoutingBlocks;

    test('default routing: ch 5 ← In 5 ← AN1-8 → Local 5', () {
      final idx = MixerProfile.x32HeadampIndex(5, reader({
        '/ch/05/config/source': 5,
        blocks[0]: 0,
      }));
      expect(idx, 4);
      expect(MixerProfile.x32HeadampName(idx!), 'Local 5');
      expect(MixerProfile.x32HeadampPrefix(idx), '/headamp/004');
    });

    test('In 9-16 fed by AES50-A 17-24 (stage box)', () {
      final idx = MixerProfile.x32HeadampIndex(12, reader({
        '/ch/12/config/source': 12, // In 12 → block 9-16, 4th slot
        blocks[1]: 6, // A17-24
      }));
      expect(idx, 32 + 16 + 3);
      expect(MixerProfile.x32HeadampName(idx!), 'AES50-A 20');
    });

    test('AES50-B and card', () {
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 1, blocks[0]: 10})), 80);
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 1, blocks[0]: 16})), -1);
    });

    test('user routing (FW 4+)', () {
      final m = {'/ch/03/config/source': 3, blocks[0]: 20, '/config/userrout/in/03': 40};
      expect(MixerProfile.x32HeadampIndex(3, reader(m)), 32 + 7); // AES50-A 8
      m['/config/userrout/in/03'] = 150; // card input
      expect(MixerProfile.x32HeadampIndex(3, reader(m)), -1);
    });

    test('sources without a preamp, and unknown values', () {
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 0})), -1); // OFF
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 39})), -1); // USB
      expect(MixerProfile.x32HeadampIndex(1, reader({})), isNull);
      expect(MixerProfile.x32HeadampIndex(1, reader({'/ch/01/config/source': 1})), isNull);
    });
  });

  test('FX catalog', () {
    expect(fxFullList.length, 61); // /fx/N/type 0-60
    expect(fxInsertList.length, 34); // X32 /fx/5-8/type 0-33
    for (final code in [...fxFullList, ...fxInsertList]) {
      expect(fxCatalog.containsKey(code), isTrue, reason: code);
    }
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.fxSlots, 8);
    expect(xr.fxSlots, 4);
    expect(x32.fxTypesForSlot(5), same(fxInsertList));
    expect(xr.fxTypesForSlot(4), same(fxFullList));
    expect(x32.fxParAddr(2, 7), '/fx/2/par/07');
  });

  test('snapshots never touch preamps or routing', () {
    for (final p in [
      MixerProfile.forFamily(MixerFamily.x32, 'X32'),
      MixerProfile.forFamily(MixerFamily.xr, 'XR18'),
    ]) {
      final addrs = p.snapshotAddresses();
      expect(addrs.where((a) => a.startsWith('/headamp')), isEmpty);
      expect(addrs.where((a) => a.startsWith('/config/routing') || a.contains('/config/source')), isEmpty);
      expect(addrs, contains('/ch/01/eq/1/f'));
      expect(addrs, contains('/fx/1/type'));
    }
  });

  test('snapshot JSON keeps value types', () {
    final s = Snapshot(
      id: 'a',
      name: 'Test',
      family: MixerFamily.xr,
      model: 'XR18',
      savedAt: DateTime.fromMillisecondsSinceEpoch(1000),
      values: {'/ch/01/mix/fader': 1.0, '/ch/01/mix/on': 1, '/ch/01/config/name': 'Vox'},
    );
    final back = Snapshot.fromJson(jsonDecode(jsonEncode(s.toJson())) as Map<String, dynamic>)!;
    expect(back.values['/ch/01/mix/fader'], isA<double>());
    expect(back.values['/ch/01/mix/on'], isA<int>());
    expect(back.values['/ch/01/config/name'], 'Vox');
    expect(back.family, MixerFamily.xr);
  });

  test('EQ on buses and Main LR', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.inputs.first.eqBands, 4);
    expect(x32.buses.first.eqBands, 6);
    expect(x32.main.eqBands, 6);
    expect(x32.dcas.first.hasEq, isFalse);
    expect(xr.buses.firstWhere((s) => s.prefix == '/fxsend/1').hasEq, isFalse);
    expect(x32.detailAddresses(x32.buses.first), contains('/bus/01/eq/6/f'));
    expect(x32.detailAddresses(x32.main), contains('/main/st/eq/1/type'));
    expect(xr.detailAddresses(xr.main), contains('/lr/eq/6/q'));
    expect(x32.detailAddresses(x32.main).where((a) => a.contains('headamp')), isEmpty);
    expect(x32.snapshotAddresses(), contains('/bus/16/eq/3/g'));
    expect(xr.snapshotAddresses(), contains('/lr/eq/on'));
    expect(eqDefaultType(1, 6), 1);
    expect(eqDefaultType(6, 6), 4);
    expect(eqDefaultFreq(4, 4), 10000);
    expect(x32.fxSourceAddr(2), '/fx/2/source/l');
  });

  test('console snapshot / scene library addresses', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(xr.consoleSlots.first, 1);
    expect(xr.consoleSlots.last, 64);
    expect(xr.consoleNameAddr(7), '/-snap/07/name');
    expect(xr.consoleHasDataAddr(7), isNull);
    expect(x32.consoleSlots.first, 0);
    expect(x32.consoleSlots.last, 99);
    expect(x32.consoleNameAddr(5), '/-show/showfile/scene/005/name');
    expect(x32.consoleHasDataAddr(5), '/-show/showfile/scene/005/hasdata');
    expect(x32.consoleLibraryAddresses.length, 1 + 200);
  });

  test('EQ presets stay inside console ranges', () {
    for (final p in channelEqPresets) {
      expect(p.bands.length, 4, reason: p.name);
      expect(eqPresetCategories, contains(p.category), reason: p.name);
      if (p.lowCutHz != null) expect(p.lowCutHz!, inInclusiveRange(20, 400), reason: p.name);
      for (final b in p.bands) {
        expect(b.hz, inInclusiveRange(20, 20000), reason: p.name);
        expect(b.db, inInclusiveRange(-15, 15), reason: p.name);
        expect(b.q, inInclusiveRange(0.3, 10), reason: p.name);
      }
    }
    expect(flatBands(6).length, 6);
    expect(flatBands(6).every((b) => b.db == 0), isTrue);
  });

  test('insert values and plugin catalog', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.insertValue(1, 0), 1);
    expect(x32.insertValue(8, 1), 16);
    expect(x32.insertSlot(16), 8);
    expect(x32.insertSide(16), 1);
    expect(x32.insertSlot(17), isNull); // AUX1, external
    expect(x32.insertLabel(17), 'Aux 1 (external)');
    expect(xr.insertLabel(4), 'FX2 B');
    expect(xr.insertSelAddr(xr.inputs.first), '/ch/01/insert/fxslot');
    expect(x32.insertSelAddr(x32.inputs.first), '/ch/01/insert/sel');
    expect(xr.supportsInsert(xr.main), isFalse);
    expect(x32.supportsInsert(x32.main), isTrue);
    for (final pl in pluginCatalog) {
      expect(fxFullList.contains(pl.code), isTrue, reason: pl.code);
    }
    for (final name in presetDynamics.keys) {
      expect(channelEqPresets.any((p) => p.name == name), isTrue, reason: name);
    }
  });

  test('matrix sends and copy sections', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.matrices.length, 6);
    expect(x32.mixBuses.length, 16);
    expect(xr.hasMatrix, isFalse);
    expect(xr.matrixSendAddresses, isEmpty);
    final m2 = x32.matrixTargets[1];
    expect(x32.mixBuses.first.sendLevelAddr(m2), '/bus/01/mix/02/level');
    expect(x32.main.sendLevelAddr(m2), '/main/st/mix/02/level');
    expect(x32.snapshotAddresses(), contains('/main/st/mix/06/on'));
    final ch1 = x32.inputs.first;
    expect(sectionsFor(x32, ch1), containsAll([CopySection.eq, CopySection.gate, CopySection.sends]));
    expect(sectionAddresses(x32, ch1, CopySection.eq).where((a) => a.contains('headamp')), isEmpty);
    expect(sectionsFor(x32, x32.dcas.first), [CopySection.faderMute, CopySection.nameColor]);
    expect(sectionAddresses(x32, x32.mixBuses.first, CopySection.sends), contains('/bus/01/mix/06/on'));
  });

  test('only known mixer addresses are stored', () {
    expect(MixerController.acceptsAddress('/ch/01/mix/fader'), isTrue);
    expect(MixerController.acceptsAddress('/lr/eq/1/f'), isTrue);
    expect(MixerController.acceptsAddress('/-show/showfile/scene/005/name'), isTrue);
    expect(MixerController.acceptsAddress('/evil/anything'), isFalse);
    expect(MixerController.acceptsAddress('/ch/../../x'), isFalse);
    expect(MixerController.acceptsAddress('/ch/${'x' * 100}'), isFalse);
    expect(MixerController.acceptsAddress('/lrx'), isFalse);
  });

  test('channel banks', () {
    List<String> labels(List<Strip> s) => [for (final b in makeBanks(s)) b.label];
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    final xr12 = MixerProfile.forFamily(MixerFamily.xr, 'XR12');
    expect(labels(x32.inputs), ['1-8', '9-16', '17-24', '25-32', 'Aux 1-8', 'FX 1-8']);
    expect(labels(x32.buses), ['Bus 1-8', 'Bus 9-16', 'Matrix']);
    expect(labels(x32.dcas), ['DCA']);
    expect(labels(xr.inputs), ['1-8', '9-16', 'Aux/FX']);
    expect(labels(xr.buses), ['Bus 1-6', 'FX Send']);
    expect(labels(xr12.inputs), ['1-8', '9-12', 'Aux/FX']);
    expect(makeBanks(x32.inputs)[1].strips.first.prefix, '/ch/09');
  });

  test('model detection and addresses', () {
    expect(MixerProfile.familyFromModel('X32'), MixerFamily.x32);
    expect(MixerProfile.familyFromModel('XR18'), MixerFamily.xr);
    expect(MixerProfile.familyFromModel('MR18'), MixerFamily.xr);
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.buses.first.faderAddr, '/bus/01/mix/fader');
    expect(xr.buses.first.faderAddr, '/bus/1/mix/fader');
    expect(x32.main.faderAddr, '/main/st/mix/fader');
    expect(xr.main.faderAddr, '/lr/mix/fader');
    expect(xr.inputs.first.sendLevelAddr(xr.sendTargets[6]), '/ch/01/mix/07/level');
    expect(x32.dcas.first.onAddr, '/dca/1/on');
  });

  test('bus send point and link addresses', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.busTargets.length, 16);
    expect(xr.busTargets.length, 6);
    expect(x32.tapAddr(x32.inputs.first, 4), '/ch/01/mix/03/type');
    expect(x32.tapAddr(x32.inputs.first, 3), '/ch/01/mix/03/type');
    expect(xr.tapAddr(xr.inputs.first, 4), '/ch/01/mix/04/tap');
    expect(x32.busLinkAddr(4), '/config/buslink/3-4');
    expect(xr.busLinkAddr(5), '/config/buslink/5-6');
    expect(x32.queryAddresses, contains('/ch/32/mix/15/type'));
    expect(xr.queryAddresses, contains('/config/buslink/1-2'));
  });

  test('solo, groups, assign and links', () {
    final x32 = MixerProfile.forFamily(MixerFamily.x32, 'X32');
    final xr = MixerProfile.forFamily(MixerFamily.xr, 'XR18');
    expect(x32.soloAddr(x32.inputs.first), '/-stat/solosw/01');
    expect(x32.soloAddr(x32.main), '/-stat/solosw/71');
    expect(x32.soloAddr(x32.dcas.first), '/-stat/solosw/73');
    expect(xr.soloAddr(xr.main), '/-stat/solosw/32');
    expect(x32.muteGroupCount, 6);
    expect(xr.muteGroupCount, 4);
    expect(x32.dcaMaskAddr(x32.inputs.first), '/ch/01/grp/dca');
    expect(x32.mainAssignAddr(x32.inputs.first), '/ch/01/mix/st');
    expect(xr.mainAssignAddr(xr.inputs.first), '/ch/01/mix/lr');
    expect(x32.linkAddr(x32.inputs[3]), '/config/chlink/3-4');
    expect(xr.linkAddr(xr.inputs[14]), '/config/chlink/15-16');
    expect(x32.mono?.faderAddr, '/main/m/mix/fader');
    expect(xr.mono, isNull);
    expect(x32.groupAddresses, contains('/config/mute/6'));
  });

  test('RTA decode and feedback peaks', () {
    final bd = ByteData(4 + 200);
    bd.setInt32(0, 50, Endian.little);
    for (var i = 0; i < 100; i++) {
      bd.setInt16(4 + i * 2, ((i == 60 ? -10 : -50) * 256), Endian.little);
    }
    final db = decodeRtaBlob(bd.buffer.asUint8List());
    expect(db.length, 100);
    expect(db[60], -10);
    final peaks = findFeedbackPeaks(db);
    expect(peaks, isNotEmpty);
    expect(peaks.first.hz, closeTo(rtaBinHz(60, 100), 1));
  });
}

