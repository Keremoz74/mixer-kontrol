// Copy several strips at once and paste each onto a target of its own.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/copy_paste.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/ui/strip_actions.dart';
import 'package:mixer_kontrol/util/param_law.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() {
    stripClipboard = null;
    SharedPreferences.setMockInitialValues({});
    pasteSectionsChoice = {...copyDefaultSections};
  });

  test('copy 10, paste onto 10 others in order; undo', () async {
    final c = MixerController.demo(MixerFamily.x32);
    final ins = c.profile.inputs.where((s) => s.type == StripType.channel).toList();
    for (var i = 0; i < 10; i++) {
      c.set(ins[i].eqAddr(2, 'g'), eqGainLaw.toNorm(-10.0 + i));
      c.set(ins[i].panAddr, 0.1 * i);
    }
    final before20 = c.param(ins[20].eqAddr(2, 'g')).value;
    final clip = await copyStrips(c, ins.sublist(0, 10).reversed.toList());
    expect(clip.multi, isTrue);
    expect(clip.sources.map((s) => s.prefix), ins.sublist(0, 10).map((s) => s.prefix), reason: 'console order');

    final map = defaultPasteMap(c.profile, clip, ins[16]); // Ch 17 …
    expect(map.values.map((t) => t!.prefix), ins.sublist(16, 26).map((s) => s.prefix));
    // one skipped, one sent elsewhere
    map[ins[9].prefix] = null;
    map[ins[3].prefix] = ins[30];
    final undo = pasteMapped(c, clip, map, {CopySection.eq, CopySection.pan});
    expect(eqGainLaw.toReal((c.param(ins[16].eqAddr(2, 'g')).value as num).toDouble()), closeTo(-10, 0.1));
    expect(eqGainLaw.toReal((c.param(ins[24].eqAddr(2, 'g')).value as num).toDouble()), closeTo(-2, 0.1));
    expect(eqGainLaw.toReal((c.param(ins[30].eqAddr(2, 'g')).value as num).toDouble()), closeTo(-7, 0.1));
    expect(c.param(ins[25].panAddr).value, isNot(closeTo(0.9, 1e-6)), reason: 'skipped');
    expect(c.param(ins[20].eqAddr(2, 'g')).value, isNot(before20), reason: 'Ch 5 → Ch 21');
    undo.forEach(c.set);
    expect(c.param(ins[20].eqAddr(2, 'g')).value, before20);
    c.dispose();
  });

  test('past the last strip: the rest is skipped', () async {
    final c = MixerController.demo(MixerFamily.x32);
    final ins = c.profile.inputs.where((s) => s.type == StripType.channel).toList();
    final clip = await copyStrips(c, ins.sublist(0, 4));
    final map = defaultPasteMap(c.profile, clip, ins[30]);
    expect(map.values.where((t) => t != null).length, 2);
    c.dispose();
  });

  testWidgets('long-press menu: copy several, paste where each goes', (tester) async {
    tester.view.physicalSize = const Size(1280, 900);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    final c = MixerController.demo(MixerFamily.x32);
    final ins = c.profile.inputs.where((s) => s.type == StripType.channel).toList();
    c.set(ins[1].panAddr, 0.0);
    c.set(ins[2].panAddr, 1.0);
    Strip target = ins[0];
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (context) => Center(
            child: FilledButton(onPressed: () => showStripActions(context, c, target), child: const Text('menu')),
          ),
        ),
      ),
    ));

    // copy Ch 1 (preselected), Ch 2, Ch 3
    await tester.tap(find.text('menu'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Copy several…'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(FilterChip, ins[1].defaultLabel));
    await tester.tap(find.widgetWithText(FilterChip, ins[2].defaultLabel));
    await tester.pump();
    await tester.tap(find.text('Copy 3'));
    await tester.pumpAndSettle();
    expect(stripClipboard!.sources.length, 3);
    await tester.pump(const Duration(seconds: 5)); // snackbar away

    // paste from Ch 17: onto Ch 17, 18, 19
    target = ins[16];
    await tester.tap(find.text('menu'));
    await tester.pumpAndSettle();
    expect(find.text('Paste 3 copied strips'), findsOneWidget);
    await tester.tap(find.text('Paste 3 copied strips'));
    await tester.pumpAndSettle();
    expect(find.text(ins[16].defaultLabel), findsWidgets);
    expect(find.text(ins[18].defaultLabel), findsWidgets);
    await tester.tap(find.text('Paste 3'));
    await tester.pumpAndSettle();
    expect(c.param(ins[17].panAddr).value, 0.0);
    expect(c.param(ins[18].panAddr).value, 1.0);
    c.dispose();
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 4));
  });

  testWidgets('single paste: name and colour come along by default; choice kept', (tester) async {
    SharedPreferences.setMockInitialValues({});
    pasteSectionsChoice = {...copyDefaultSections};
    tester.view.physicalSize = const Size(1280, 900);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    final c = MixerController.demo(MixerFamily.x32);
    final ins = c.profile.inputs.where((s) => s.type == StripType.channel).toList();
    c.set(ins[0].nameAddr, 'Vokal');
    c.set(ins[0].colorAddr, 3);
    Strip target = ins[0];
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (context) => Center(
            child: FilledButton(onPressed: () => showStripActions(context, c, target), child: const Text('menu')),
          ),
        ),
      ),
    ));
    await tester.tap(find.text('menu'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Copy settings'));
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 5));
    target = ins[4];
    await tester.tap(find.text('menu'));
    await tester.pumpAndSettle();
    await tester.tap(find.textContaining('Paste from'));
    await tester.pumpAndSettle();
    // untick Pan this time: the next paste remembers it
    await tester.tap(find.widgetWithText(CheckboxListTile, 'Pan'));
    await tester.pump();
    await tester.tap(find.text('Paste to 1'));
    await tester.pumpAndSettle();
    expect(c.param(ins[4].nameAddr).value, 'Vokal');
    expect(c.param(ins[4].colorAddr).value, 3);
    expect(pasteSectionsChoice.contains(CopySection.pan), isFalse);
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getStringList('paste_sections'), isNot(contains('pan')));
    c.dispose();
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 4));
  });

  test('every setting by default: gain, +48V, fader, mute, name onto the target preamp', () async {
    final c = MixerController.demo(MixerFamily.x32);
    final ins = c.profile.inputs.where((s) => s.type == StripType.channel).toList();
    final g0 = gainAddrOf(c, ins[0])!, g4 = gainAddrOf(c, ins[4])!;
    expect(g0, isNot(g4));
    c.set(g0, headampGainLaw.toNorm(38));
    c.set(phantomAddrOf(c, ins[0])!, 1);
    c.set(ins[0].faderAddr, 0.3);
    c.set(ins[0].onAddr, 0);
    c.set(ins[0].nameAddr, 'hgg');
    final clip = await copyStrips(c, [ins[0]]);
    final undo = pasteStrip(c, clip, [ins[4]], copyDefaultSections);
    expect(headampGainLaw.toReal((c.param(g4).value as num).toDouble()), closeTo(38, 0.6));
    expect(c.param(phantomAddrOf(c, ins[4])!).value, 1);
    expect(c.param(ins[4].faderAddr).value, 0.3);
    expect(c.param(ins[4].onAddr).value, 0);
    expect(c.param(ins[4].nameAddr).value, 'hgg');
    undo.forEach(c.set);
    expect(c.param(ins[4].faderAddr).value, isNot(0.3));
    c.dispose();
  });
}
