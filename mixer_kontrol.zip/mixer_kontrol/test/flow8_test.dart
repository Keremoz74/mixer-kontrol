// Behringer FLOW 8 over MIDI: address ↔ CC map, the link (state kept on
// the device, bus mutes, low cut on/off, answers to queries), and the mixer
// screen with the FLOW 8 profile.

import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/flow/ble_midi.dart';
import 'package:mixer_kontrol/flow/flow8_link.dart';
import 'package:mixer_kontrol/flow/flow8_map.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/ui/channel_detail_screen.dart';
import 'package:mixer_kontrol/ui/mixer_screen.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';
import 'package:shared_preferences/shared_preferences.dart';

List<int> cc(int ch, int n, int v) => [0xB0 | (ch - 1), n, v];

void main() {
  const map = Flow8Map();

  group('map (FLOW 8 MIDI implementation)', () {
    test('input controls', () {
      FlowParam p(String a) => map.toFlow(a)!;
      expect([p('/ch/01/mix/fader').channel, p('/ch/01/mix/fader').cc], [1, 7]);
      expect([p('/ch/05/mix/pan').channel, p('/ch/05/mix/pan').cc], [5, 10]);
      expect(p('/ch/07/mix/on').cc, 5);
      expect(p('/ch/02/cue').cc, 6);
      expect([for (var b = 1; b <= 4; b++) p('/ch/03/eq/$b/g').cc], [1, 2, 3, 4]);
      expect(p('/headamp/04/gain').cc, 8);
      expect(p('/headamp/02/phantom').cc, 12);
      expect(map.toFlow('/headamp/03/phantom'), isNull, reason: '48 V on Ch 1 and 2 only');
      expect(map.toFlow('/headamp/07/gain'), isNull, reason: 'no gain on USB/BT');
      expect(p('/ch/06/preamp/hpf').cc, 9);
      expect(map.toFlow('/ch/07/preamp/hpf'), isNull);
      expect([for (var k = 1; k <= 4; k++) p('/ch/01/mix/${k.toString().padLeft(2, '0')}/level').cc], [14, 15, 16, 17]);
      expect(map.toFlow('/ch/08/mix/fader'), isNull);
    });

    test('buses', () {
      expect([map.toFlow('/main/st/mix/fader')!.channel, map.toFlow('/main/st/mix/fader')!.cc], [8, 7]);
      expect(map.toFlow('/main/st/mix/pan')!.cc, 10);
      expect(map.toFlow('/bus/01/mix/fader')!.channel, 9);
      expect(map.toFlow('/bus/02/mix/fader')!.channel, 10);
      expect(map.toFlow('/fxsend/1/mix/fader')!.channel, 11);
      expect(map.toFlow('/fxsend/2/mix/fader')!.channel, 12);
    });

    test('every CC maps back to its address', () {
      for (final a in [
        '/ch/01/mix/fader',
        '/ch/04/mix/pan',
        '/ch/05/mix/on',
        '/ch/06/cue',
        '/ch/02/eq/3/g',
        '/ch/07/mix/04/level',
        '/headamp/01/gain',
        '/headamp/02/phantom',
        '/ch/03/preamp/hpf',
        '/main/st/mix/fader',
        '/main/st/mix/pan',
        '/bus/02/mix/fader',
        '/fxsend/1/mix/fader',
      ]) {
        final p = map.toFlow(a)!;
        expect(map.toApp(p.channel, p.cc), a);
      }
    });

    test('values', () {
      expect(Flow8Map.levelCc(0), 0, reason: '-inf = off');
      expect(Flow8Map.levelCc(dbToFader(10)), 127);
      expect(Flow8Map.levelCc(dbToFader(-70)), 1);
      expect(faderToDb(Flow8Map.levelFromCc(Flow8Map.levelCc(dbToFader(0)))), closeTo(0, 0.4));
      expect(Flow8Map.balanceCc(0.5), 64);
      expect(Flow8Map.balanceCc(0), 0);
      expect(Flow8Map.balanceCc(1), 127);
      expect(Flow8Map.eqCc(0.5), 64);
      expect(Flow8Map.eqCc(0), 0);
      expect(Flow8Map.eqCc(1), 127);
      expect(eqGainLaw.toReal(Flow8Map.eqFromCc(Flow8Map.eqCc(eqGainLaw.toNorm(-6)))), closeTo(-6, 0.3));
      expect(Flow8Map.gainCc(headampGainLaw.toNorm(60)), 127);
      expect(headampGainLaw.toReal(Flow8Map.gainFromCc(Flow8Map.gainCc(headampGainLaw.toNorm(20)))), closeTo(20, 0.7));
      expect(Flow8Map.lowCutCc(0), 0, reason: '20 Hz');
      expect(hpfLaw.toReal(Flow8Map.lowCutFromCc(Flow8Map.lowCutCc(hpfLaw.toNorm(100)))), closeTo(100, 4));
    });
  });

  group('link', () {
    late List<List<int>> sent;
    late StreamController<Uint8List> fromMixer;
    late Flow8Link link;
    late List<OscMessage> got;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      sent = [];
      fromMixer = StreamController<Uint8List>();
      link = Flow8Link(sendBytes: (b) => sent.add(b.toList()), incoming: fromMixer.stream);
      got = [];
      link.messages.listen(got.add);
      await link.restore();
    });
    tearDown(() => link.close());

    test('controls become CCs', () {
      link.send(OscMessage('/ch/01/mix/fader', [dbToFader(0)]));
      link.send(const OscMessage('/ch/01/mix/on', [0]));
      link.send(const OscMessage('/ch/03/mix/pan', [0.5]));
      link.send(OscMessage('/ch/02/eq/1/g', [eqGainLaw.toNorm(15)]));
      link.send(const OscMessage('/headamp/01/phantom', [1]));
      link.send(const OscMessage('/ch/01/mix/03/level', [0.0]));
      expect(sent, [
        cc(1, 7, Flow8Map.levelCc(dbToFader(0))),
        cc(1, 5, 127),
        cc(3, 10, 64),
        cc(2, 1, 127),
        cc(1, 12, 127),
        cc(1, 16, 0),
      ]);
    });

    test('bus mute: level off, unmute: level back', () {
      link.send(OscMessage('/bus/01/mix/fader', [dbToFader(-10)]));
      final lvl = Flow8Map.levelCc(dbToFader(-10));
      link.send(const OscMessage('/bus/01/mix/on', [0]));
      link.send(OscMessage('/bus/01/mix/fader', [dbToFader(0)])); // muted: stays silent
      link.send(const OscMessage('/bus/01/mix/on', [1]));
      expect(sent, [cc(9, 7, lvl), cc(9, 7, 0), cc(9, 7, Flow8Map.levelCc(dbToFader(0)))]);
    });

    test('low cut: off sends 20 Hz, on sends the frequency', () {
      link.send(OscMessage('/ch/02/preamp/hpf', [hpfLaw.toNorm(100)])); // off: nothing yet
      expect(sent, isEmpty);
      link.send(const OscMessage('/ch/02/preamp/hpon', [1]));
      link.send(const OscMessage('/ch/02/preamp/hpon', [0]));
      expect(sent, [cc(2, 9, Flow8Map.lowCutCc(hpfLaw.toNorm(100))), cc(2, 9, 0)]);
    });

    test('queries: last value, else a default; fixed EQ put back', () async {
      link.send(const OscMessage('/ch/04/mix/pan', [0.2]));
      link.send(const OscMessage('/ch/04/mix/pan'));
      link.send(const OscMessage('/ch/05/mix/fader'));
      link.send(OscMessage('/ch/01/eq/2/f', [freqLaw.toNorm(5000)])); // fixed on the FLOW 8
      link.send(const OscMessage('/xinfo'));
      await Future<void>.delayed(Duration.zero);
      final byAddr = {for (final m in got) m.address: m.args.first};
      expect(byAddr['/ch/04/mix/pan'], 0.2);
      expect(faderToDb((byAddr['/ch/05/mix/fader'] as num).toDouble()), closeTo(0, 0.01));
      expect(freqLaw.toReal((byAddr['/ch/01/eq/2/f'] as num).toDouble()), closeTo(300, 1));
      expect(byAddr['/xinfo'], 'midi');
      expect(sent, [cc(4, 10, Flow8Map.balanceCc(0.2))], reason: 'fixed EQ sends nothing');
    });

    test('values are kept on the device for next time', () async {
      link.send(const OscMessage('/ch/06/mix/pan', [0.9]));
      await Future<void>.delayed(const Duration(milliseconds: 1200));
      final again = Flow8Link(sendBytes: (_) {});
      await again.restore();
      expect((await again.request('/ch/06/mix/pan'))!.args.first, 0.9);
      again.close();
    });

    test('CCs from the mixer become changes', () async {
      fromMixer.add(Uint8List.fromList([...cc(2, 7, 0), ...cc(8, 10, 64)]));
      await Future<void>.delayed(Duration.zero);
      expect(got.map((m) => '${m.address}=${m.args.first}'), ['/ch/02/mix/fader=0.0', '/main/st/mix/pan=0.5']);
    });
  });

  group('profile', () {
    test('7 inputs, MON 1/2, FX 1/2, MAIN', () {
      final p = MixerProfile.flow8('FLOW 8');
      expect(p.inputs.map((s) => s.defaultLabel), ['CH 1', 'CH 2', 'CH 3', 'CH 4', 'CH 5/6', 'CH 7/8', 'USB/BT']);
      expect(p.sendTargets.map((t) => t.label), ['MON 1', 'MON 2', 'FX 1', 'FX 2']);
      expect(p.eqGainOnly, isTrue);
      expect(p.hasDynamics, isFalse);
      expect(p.dcas, isEmpty);
      // every send of every input reaches the FLOW 8
      for (final s in p.inputs) {
        expect(map.toFlow(s.faderAddr), isNotNull);
        for (final t in p.sendTargets) {
          expect(map.toFlow(s.sendLevelAddr(t)), isNotNull, reason: '${s.defaultLabel} → ${t.label}');
        }
      }
    });

    test('gain / 48 V where the FLOW 8 has them', () {
      final c = MixerController.demo(MixerFamily.flow);
      final ins = c.profile.inputs;
      expect(c.headampFor(ins[0]).phantomAddr, '/headamp/01/phantom');
      expect(c.headampFor(ins[2]).phantomAddr, isNull);
      expect(c.headampFor(ins[5]).gainAddr, '/headamp/06/gain');
      expect(c.headampFor(ins[6]).gainAddr, isNull);
      c.dispose();
    });
  });

  testWidgets('mixer screen and gain-only EQ page', (tester) async {
    SharedPreferences.setMockInitialValues({});
    tester.view.physicalSize = const Size(900, 412);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    final c = MixerController.demo(MixerFamily.flow);
    final s = c.profile.inputs.first;
    await tester.pumpWidget(MaterialApp(home: ChannelDetailScreen(controller: c, strip: s)));
    await tester.pump(const Duration(seconds: 1));
    expect(find.text('Frequency'), findsNothing, reason: 'fixed-frequency EQ');
    expect(find.text('Gain'), findsWidgets);
    expect(find.text('Dynamics'), findsNothing);
    // (the mixer screen owns the controller and disposes it)
    await tester.pumpWidget(MaterialApp(home: MixerScreen(controller: c)));
    await tester.pump(const Duration(seconds: 1));
    expect(find.text('USB/BT'), findsWidgets);
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 2));
  });

  test('Bluetooth MIDI framing', () {
    expect(bleMidiPacket([0xB0, 5, 127]), [0x80, 0x80, 0xB0, 5, 127]);
    // header, timestamp, CC; timestamp, CC
    expect(bleMidiDecode([0x80, 0x81, 0xB0, 7, 100, 0x82, 0xB1, 7, 3]), [0xB0, 7, 100, 0xB1, 7, 3]);
    expect(bleMidiDecode([0x00, 1, 2]), isEmpty);
    expect(parseHex('b0 05 7F'), [0xB0, 5, 127]);
    expect(parseHex('xyz'), isNull);
  });
}
