// Pasting onto a real console over the network: hundreds of values per strip
// must reach a console whose UDP buffer drops bursts (as an X32's does).

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/copy_paste.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/util/param_law.dart';

import 'sim/fake_mixer.dart';

void main() {
  test('paste 10 strips onto an X32 that drops bursts', () async {
    final fake = FakeMixer(x32: true, model: 'X32', name: 'Test', net: const NetConditions(burstLimit: 30));
    await fake.start();
    final c = await MixerController.connect('127.0.0.1', family: MixerFamily.x32);
    // initial sync done (as when someone has been working for a while)
    for (var w = 0; w < 300 && (c.syncing || c.state != ConnState.connected); w++) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    await Future<void>.delayed(const Duration(seconds: 1));
    final ins = c.profile.inputs.where((s) => s.type == StripType.channel).toList();
    for (var i = 0; i < 10; i++) {
      c.set(ins[i].eqAddr(2, 'g'), eqGainLaw.toNorm(-9.0 + i));
      c.set(ins[i].nameAddr, 'Src ${i + 1}');
      c.set(ins[i].panAddr, i / 10);
      await Future<void>.delayed(const Duration(milliseconds: 30));
    }
    await Future<void>.delayed(const Duration(milliseconds: 500));
    final clip = await copyStrips(c, ins.sublist(0, 10));
    final map = defaultPasteMap(c.profile, clip, ins[16]);
    final sw = Stopwatch()..start();
    final undo = pasteMapped(c, clip, map, {...CopySection.values});
    // sent in paced batches, read back, the missing ones sent again
    for (var w = 0; w < 150 && fake.state[ins[25].nameAddr] != 'Src 10'; w++) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    await Future<void>.delayed(const Duration(seconds: 4));
    // ignore: avoid_print
    print('paste took ~${sw.elapsedMilliseconds} ms, console dropped ${fake.dropped} packets');
    for (var i = 0; i < 10; i++) {
      final t = ins[16 + i];
      expect(fake.state[t.nameAddr], 'Src ${i + 1}', reason: '${t.defaultLabel} name on the console');
      expect(eqGainLaw.toReal((fake.state[t.eqAddr(2, 'g')] as num).toDouble()), closeTo(-9.0 + i, 0.2));
      expect((fake.state[t.panAddr] as num).toDouble(), closeTo(i / 10, 0.01));
    }
    // and every pasted value arrived, not just these
    final missing = <String>[];
    for (var i = 0; i < 10; i++) {
      final src = ins[i], t = ins[16 + i];
      for (final sec in CopySection.values) {
        for (final a in sectionAddresses(c.profile, src, sec)) {
          final v = clip.values[a];
          if (v == null) continue;
          final ta = t.prefix + a.substring(src.prefix.length);
          final got = fake.state[ta];
          if (got != v && !(got is num && v is num && (got - v).abs() < 1e-4)) missing.add(ta);
        }
      }
    }
    expect(missing, isEmpty, reason: '${missing.length} values lost, e.g. ${missing.take(5)}');
    // undo too
    await c.setMany(undo);
    await Future<void>.delayed(const Duration(seconds: 2));
    expect(fake.state[ins[16].nameAddr], isNot('Src 1'));
    c.dispose();
    await fake.stop();
  }, timeout: const Timeout(Duration(minutes: 2)));
}
