// Yamaha driver: address translation, values, and a session against a
// software stand-in for a console speaking the remote control protocol.

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/yamaha/yamaha_link.dart';
import 'package:mixer_kontrol/yamaha/yamaha_map.dart';

/// A tiny fake Yamaha console: TCP, line protocol, a few channel kinds.
class FakeYamaha {
  FakeYamaha({this.inputs = 32, this.stereo = 2, this.fx = 2, this.mixes = 20, this.dcas = 8, this.model = 'TF5'});
  final int inputs, stereo, fx, mixes, dcas;
  final String model;
  late ServerSocket _server;
  final List<Socket> _clients = [];
  final Map<String, String> state = {};
  final List<String> received = [];
  int get port => _server.port;

  int _count(String cat) => switch (cat) {
        'InCh' => inputs,
        'StInCh' => stereo,
        'FxRtnCh' => fx,
        'Mix' => mixes,
        'DCA' => dcas,
        'St' => 1,
        _ => 0,
      };

  Future<void> start() async {
    _server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    _server.listen((s) {
      _clients.add(s);
      utf8.decoder.bind(s).transform(const LineSplitter()).listen((line) => _handle(s, line), onError: (_) {});
    });
  }

  void _handle(Socket s, String line) {
    received.add(line);
    final t = YamahaMap.tokenize(line);
    if (t.isEmpty) return;
    if (t[0] == 'devinfo' && t.length >= 2 && t[1] == 'productname') {
      s.write('OK devinfo productname "$model"\n');
      return;
    }
    if ((t[0] == 'get' || t[0] == 'set') && t.length >= 4) {
      final path = t[1];
      final cat = path.startsWith(YamahaMap.root) ? path.substring(YamahaMap.root.length).split('/').first : '';
      final x = int.tryParse(t[2]) ?? -1;
      if (x < 0 || x >= _count(cat)) {
        s.write('ERROR ${t[0]} InvalidArgument\n');
        return;
      }
      final key = '$path ${t[2]} ${t[3]}';
      if (t[0] == 'get') {
        s.write('OK get $key ${state[key] ?? _default(path)}\n');
      } else {
        if (t.length < 5) return;
        final raw = line.split(' ').sublist(4).join(' ').trim();
        state[key] = raw;
        s.write('OK set $key $raw\n');
        for (final o in _clients) {
          if (o != s) o.write('NOTIFY set $key $raw\n');
        }
      }
    }
  }

  String _default(String path) {
    if (path.endsWith('/Level')) return '-32768';
    if (path.endsWith('/On')) return '1';
    if (path.endsWith('/Name')) return '""';
    if (path.endsWith('/Color')) return '"Blue"';
    return '0';
  }

  /// A change made on the console surface.
  void surface(String key, String raw) {
    state[key] = raw;
    for (final o in _clients) {
      o.write('NOTIFY set $key $raw\n');
    }
  }

  Future<void> stop() async {
    for (final c in _clients) {
      c.destroy();
    }
    await _server.close();
  }
}

Future<void> _until(bool Function() ok, {int ms = 3000}) async {
  final sw = Stopwatch()..start();
  while (!ok() && sw.elapsedMilliseconds < ms) {
    await Future<void>.delayed(const Duration(milliseconds: 20));
  }
}

void main() {
  test('app addresses map to Yamaha parameters and back', () {
    const cases = {
      '/ch/01/mix/fader': ('MIXER:Current/InCh/Fader/Level', 0, 0),
      '/ch/32/mix/on': ('MIXER:Current/InCh/Fader/On', 31, 0),
      '/ch/05/config/name': ('MIXER:Current/InCh/Label/Name', 4, 0),
      '/auxin/02/config/color': ('MIXER:Current/StInCh/Label/Color', 1, 0),
      '/fxrtn/01/mix/fader': ('MIXER:Current/FxRtnCh/Fader/Level', 0, 0),
      '/bus/20/mix/fader': ('MIXER:Current/Mix/Fader/Level', 19, 0),
      '/ch/03/mix/12/level': ('MIXER:Current/InCh/ToMix/Level', 2, 11),
      '/auxin/01/mix/02/on': ('MIXER:Current/StInCh/ToMix/On', 0, 1),
      '/main/st/mix/fader': ('MIXER:Current/St/Fader/Level', 0, 0),
      '/main/st/mix/on': ('MIXER:Current/St/Fader/On', 0, 0),
      '/dca/8/fader': ('MIXER:Current/DCA/Fader/Level', 7, 0),
      '/dca/1/config/name': ('MIXER:Current/DCA/Label/Name', 0, 0),
    };
    cases.forEach((app, y) {
      final p = YamahaMap.toYamaha(app);
      expect(p, isNotNull, reason: app);
      expect((p!.path, p.x, p.y), y, reason: app);
      expect(YamahaMap.toApp(p.path, p.x, p.y), app, reason: app);
    });
    // not mapped (yet): ignored rather than sent wrongly
    for (final a in ['/ch/01/eq/1/g', '/-stat/solosw/01', '/bus/01/mix/03/level', '/ch/../config/name', '/xremote']) {
      expect(YamahaMap.toYamaha(a), isNull, reason: a);
    }
    expect(YamahaMap.toApp('MIXER:Current/Mix/ToMix/Level', 0, 0), isNull);
    expect(YamahaMap.toApp('MIXER:Current/InCh/Fader/Level', -1, 0), isNull);
    expect(YamahaMap.toApp('OTHER:Current/InCh/Fader/Level', 0, 0), isNull);
  });

  test('levels, switches, names and colours convert both ways', () {
    expect(YamahaMap.encode(YamahaKind.level, 0.0), '-32768');
    expect(YamahaMap.encode(YamahaKind.level, unityFader), '0');
    expect(YamahaMap.encode(YamahaKind.level, 1.0), '1000');
    expect(YamahaMap.encode(YamahaKind.level, double.nan), isNull);
    expect(YamahaMap.encode(YamahaKind.level, 'x'), isNull);
    expect(YamahaMap.decode(YamahaKind.level, '-32768'), 0.0);
    expect(YamahaMap.decode(YamahaKind.level, '0'), closeTo(unityFader, 1e-9));
    expect(YamahaMap.decode(YamahaKind.level, '-1000') as double, closeTo(dbToFader(-10), 1e-9));
    expect(YamahaMap.decode(YamahaKind.level, '99999') as double, 1.0);
    expect(YamahaMap.decode(YamahaKind.level, 'junk'), isNull);
    for (final f in [0.1, 0.3, 0.5, 0.62, 0.75, 0.9]) {
      final back = YamahaMap.decode(YamahaKind.level, YamahaMap.encode(YamahaKind.level, f)!) as double;
      expect(back, closeTo(f, 0.002), reason: '$f');
    }
    expect(YamahaMap.encode(YamahaKind.onOff, 1), '1');
    expect(YamahaMap.decode(YamahaKind.onOff, '0'), 0);
    expect(YamahaMap.encode(YamahaKind.name, 'Lead "Vox"'), '"Lead \'Vox\'"');
    expect(YamahaMap.encode(YamahaKind.color, 1), '"Red"');
    expect(YamahaMap.decode(YamahaKind.color, 'SkyBlue'), 6);
    expect(YamahaMap.decode(YamahaKind.color, 'Unknown'), 0);
    expect(YamahaMap.tokenize('OK get MIXER:Current/InCh/Label/Name 0 0 "Lead Vox"'),
        ['OK', 'get', 'MIXER:Current/InCh/Label/Name', '0', '0', 'Lead Vox']);
    expect(YamahaMap.tokenize('NOTIFY set P 1 2 ""'), ['NOTIFY', 'set', 'P', '1', '2', '']);
  });

  test('Yamaha profile: counts, words, only mapped features', () {
    final p = MixerProfile.yamaha('TF5', const YamahaLayout(inputs: 32, stereoInputs: 2, fxReturns: 2, mixes: 20, dcas: 8));
    expect(p.inputs.length, 36);
    expect(p.busTargets.length, 20);
    expect(p.busTargets.first.label, 'AUX 1');
    expect(p.main.defaultLabel, 'STEREO');
    expect(p.hasFx || p.hasSolo || p.hasRouting || p.hasMeters, isFalse);
    expect(p.muteGroupCount, 0);
    expect(p.inputs.first.hasDetail, isFalse);
    // Everything the app asks for on connect can be translated.
    final unmapped = p.queryAddresses.where((a) => YamahaMap.toYamaha(a) == null).toList();
    expect(unmapped, isEmpty, reason: unmapped.take(5).join(', '));
    final snap = p.snapshotAddresses().where((a) => YamahaMap.toYamaha(a) == null).toList();
    expect(snap, isEmpty, reason: snap.take(5).join(', '));
    expect(YamahaLayout.forModel('DM3').mixWord, 'MIX');
    // demo works without a console
    final d = MixerController.demo(MixerFamily.yamaha);
    expect(d.profile.isYamaha, isTrue);
    d.dispose();
  });

  test('session with a fake Yamaha: layout, sync, set, NOTIFY, keep-alive', () async {
    final fake = FakeYamaha(inputs: 16, stereo: 1, fx: 2, mixes: 6, dcas: 8, model: 'DM3');
    await fake.start();
    final link = await YamahaLink.connect('127.0.0.1', port: fake.port);
    expect(await link.askProductName(), 'DM3');
    final layout = await link.readLayout('DM3');
    expect(layout.inputs, 16);
    expect(layout.stereoInputs, 1);
    expect(layout.fxReturns, 2);
    expect(layout.mixes, 6);
    expect(layout.dcas, 8);
    expect(layout.mixWord, 'MIX');

    // values flow in as app addresses
    fake.state['MIXER:Current/InCh/Fader/Level 2 0'] = '-1000';
    fake.state['MIXER:Current/InCh/Label/Name 2 0'] = '"Pastor"';
    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);
    link.send(const OscMessage('/ch/03/mix/fader'));
    link.send(const OscMessage('/ch/03/config/name'));
    await _until(() => got.length >= 2);
    expect(got['/ch/03/mix/fader'] as double, closeTo(dbToFader(-10), 1e-9));
    expect(got['/ch/03/config/name'], 'Pastor');

    // app changes become "set" lines
    link.send(const OscMessage('/ch/01/mix/04/level', [0.75]));
    link.send(const OscMessage('/dca/2/on', [0]));
    link.send(const OscMessage('/ch/01/eq/1/g', [0.5])); // not mapped: never sent
    await _until(() => fake.received.where((l) => l.startsWith('set')).length >= 2);
    expect(fake.received, contains('set MIXER:Current/InCh/ToMix/Level 0 3 0'));
    expect(fake.received, contains('set MIXER:Current/DCA/Fader/On 1 0 0'));
    expect(fake.received.any((l) => l.contains('EQ') || l.contains('eq')), isFalse);

    // changes on the console arrive as NOTIFY
    fake.surface('MIXER:Current/Mix/Fader/On 5 0', '0');
    await _until(() => got.containsKey('/bus/06/mix/on'));
    expect(got['/bus/06/mix/on'], 0);

    // keep-alive asks for something real
    link.send(const OscMessage('/xinfo'));
    await _until(() => fake.received.contains('get MIXER:Current/St/Fader/Level 0 0'));
    expect(fake.received, contains('get MIXER:Current/St/Fader/Level 0 0'));

    // hostile / broken lines are ignored
    fake.surface('MIXER:Current/InCh/Fader/Level 999 0', '0');
    fake.surface('MIXER:Current/Evil/Fader/Level 0 0', '0');
    for (final c in fake._clients) {
      c.write('garbage line without meaning\n');
      c.write('NOTIFY set MIXER:Current/InCh/Fader/Level x y z\n');
    }
    await Future<void>.delayed(const Duration(milliseconds: 100));
    expect(got.keys.where((k) => k.contains('1000') || k.contains('Evil')), isEmpty);

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('controller connects to a fake Yamaha and stays in sync', () async {
    final fake = FakeYamaha(model: 'TF5');
    await fake.start();
    // the controller uses the default port; point a link at the fake through
    // the public connect by temporarily serving on that port is not possible,
    // so exercise the link + profile path the controller uses.
    final link = await YamahaLink.connect('127.0.0.1', port: fake.port);
    final model = await link.askProductName() ?? 'Yamaha';
    final layout = await link.readLayout(model);
    final p = MixerProfile.yamaha(model, layout);
    expect(p.model, 'TF5');
    expect(p.inputs.where((s) => s.type == StripType.channel).length, 32);
    expect(p.busTargets.length, 20);
    final seen = <String>{};
    final sub = link.messages.listen((m) => seen.add(m.address));
    for (final a in p.queryAddresses) {
      link.send(OscMessage(a));
    }
    final want = p.queryAddresses.toSet();
    await _until(() => seen.containsAll(want), ms: 8000);
    expect(want.difference(seen), isEmpty);
    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('connect fails cleanly when nothing listens', () async {
    final s = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = s.port;
    await s.close();
    await expectLater(YamahaLink.connect('127.0.0.1', port: port, timeout: const Duration(seconds: 1)), throwsA(anything));
  });
}
