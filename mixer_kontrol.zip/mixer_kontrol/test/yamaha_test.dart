// Yamaha driver: address translation, values, and sessions against a
// software stand-in for a console speaking the remote control protocol.

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/meters.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';
import 'package:mixer_kontrol/yamaha/yamaha_link.dart';
import 'package:mixer_kontrol/yamaha/yamaha_map.dart';

/// A small fake Yamaha console: TCP, line protocol.
class FakeYamaha {
  FakeYamaha({
    this.inputs = 40,
    this.stereo = 4,
    this.fx = 4,
    this.mixes = 20,
    this.mtrx = 4,
    this.dcas = 8,
    this.fxBuses = 2,
    this.mutes = 6,
    this.model = 'TF5',
  });
  final int inputs, stereo, fx, mixes, mtrx, dcas, fxBuses, mutes;
  final String model;
  late ServerSocket _server;
  final List<Socket> clients = [];
  final Map<String, String> state = {};
  final List<String> received = [];
  int scene = 3;
  int get port => _server.port;

  int _count(String cat) => switch (cat) {
        'InCh' => inputs,
        'StInCh' => stereo,
        'FxRtnCh' => fx,
        'Mix' => mixes,
        'Mtrx' => mtrx,
        'DCA' => dcas,
        'St' => 2,
        'MuteMaster' || 'MuteGrpCtrl' => mutes,
        'Monitor' => 1,
        'Cue' => 999,
        'Fx' => fxBuses,
        _ => 0,
      };

  Future<void> start() async {
    _server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    _server.listen((s) {
      clients.add(s);
      utf8.decoder.bind(s).transform(const LineSplitter()).listen((line) => _handle(s, line), onError: (_) {});
    });
  }

  void _handle(Socket s, String line) {
    received.add(line);
    final t = YamahaMap.tokenize(line);
    if (t.isEmpty) return;
    switch (t[0]) {
      case 'devinfo':
        s.write('OK devinfo productname "$model"\n');
        return;
      case 'mtrstart':
        final vals = List.generate(_count(t[1].split('/')[1]), (i) => (100 + i % 20).toRadixString(16)).join(' ');
        s.write('NOTIFY mtr ${t[1]} mtr $vals\n');
        return;
      case 'sscurrent_ex':
        s.write('OK sscurrent_ex ${t[1]} $scene\n');
        return;
      case 'ssinfo_ex':
        s.write('OK ssinfo_ex ${t[1]} ${t[2]} "" "Scene ${t[2]}" "" 0\n');
        return;
      case 'ssrecall_ex':
        scene = int.parse(t[2]);
        s.write('OK ssrecall_ex ${t[1]} ${t[2]}\n');
        return;
    }
    if ((t[0] == 'get' || t[0] == 'set') && t.length >= 4) {
      final path = t[1];
      final parts = path.split(':').last.split('/');
      final cat = parts[1] == 'Cue' ? parts[2] : (path.startsWith('IO:') ? 'InCh' : parts[1]);
      final x = int.tryParse(t[2]) ?? -1, y = int.tryParse(t[3]) ?? -1;
      final yMax = path.contains('/ToFx/') ? fxBuses : (path.contains('/ToMix/') ? mixes : 64);
      if (x < 0 || x >= _count(cat) || y < 0 || y >= yMax) {
        s.write('ERROR ${t[0]} InvalidArgument\n');
        return;
      }
      final key = '$path ${t[2]} ${t[3]}';
      if (t[0] == 'get') {
        s.write('OK get $key ${state[key] ?? _default(path)}\n');
      } else {
        if (t.length < 5) return;
        final raw = line.split(' ').sublist(4).join(' ').trim();
        state[key] = raw;
        s.write('OK set $key $raw\n');
        for (final o in clients) {
          if (o != s) o.write('NOTIFY set $key $raw\n');
        }
      }
    }
  }

  String _default(String path) {
    if (path.endsWith('/Level')) return '-32768';
    if (path.endsWith('/On')) return '1';
    if (path.endsWith('/Name')) return '""';
    if (path.endsWith('/Color')) return '"Blue"';
    if (path.endsWith('/Type')) return '"Gate"';
    if (path.endsWith('/Freq')) return '10000';
    if (path.endsWith('/Q')) return '1400';
    if (path.endsWith('/Threshold')) return '-200';
    if (path.endsWith('/Ratio')) return '40';
    if (path.endsWith('/Hold') || path.endsWith('/Release') || path.endsWith('/Decay')) return '100000';
    return '0';
  }

  /// A change made on the console surface.
  void surface(String key, String raw) {
    state[key] = raw;
    for (final o in clients) {
      o.write('NOTIFY set $key $raw\n');
    }
  }

  Future<void> stop() async {
    for (final c in clients) {
      c.destroy();
    }
    await _server.close();
  }
}

Future<void> _until(bool Function() ok, {int ms = 4000}) async {
  final sw = Stopwatch()..start();
  while (!ok() && sw.elapsedMilliseconds < ms) {
    await Future<void>.delayed(const Duration(milliseconds: 20));
  }
}

void main() {
  final tf = YamahaMap(dialect: YamahaDialect.tf, mixes: 20, fxSends: 2, dcas: 8);

  test('app addresses map to Yamaha parameters', () {
    const cases = {
      '/ch/01/mix/fader': ('MIXER:Current/InCh/Fader/Level', 0, 0),
      '/ch/40/mix/on': ('MIXER:Current/InCh/Fader/On', 39, 0),
      '/ch/05/config/name': ('MIXER:Current/InCh/Label/Name', 4, 0),
      '/auxin/02/config/color': ('MIXER:Current/StInCh/Label/Color', 1, 0),
      '/fxrtn/01/mix/fader': ('MIXER:Current/FxRtnCh/Fader/Level', 0, 0),
      '/bus/20/mix/fader': ('MIXER:Current/Mix/Fader/Level', 19, 0),
      '/mtx/02/mix/on': ('MIXER:Current/Mtrx/Fader/On', 1, 0),
      '/ch/03/mix/12/level': ('MIXER:Current/InCh/ToMix/Level', 2, 11),
      '/ch/03/mix/21/level': ('MIXER:Current/InCh/ToFx/Level', 2, 0),
      '/auxin/01/mix/22/on': ('MIXER:Current/StInCh/ToFx/On', 0, 1),
      '/bus/02/mix/03/level': ('MIXER:Current/Mix/ToMtrx/Level', 1, 2),
      '/main/st/mix/01/on': ('MIXER:Current/St/ToMtrx/On', 0, 0),
      '/main/st/mix/fader': ('MIXER:Current/St/Fader/Level', 0, 0),
      '/dca/8/fader': ('MIXER:Current/DCA/Fader/Level', 7, 0),
      '/dca/1/config/name': ('MIXER:Current/DCA/Label/Name', 0, 0),
      '/ch/01/mix/pan': ('MIXER:Current/InCh/ToSt/Pan', 0, 0),
      '/ch/01/mix/st': ('MIXER:Current/InCh/ToSt/On', 0, 0),
      '/ch/07/cue': ('MIXER:Current/Cue/InCh/On', 6, 0),
      '/dca/2/cue': ('MIXER:Current/Cue/DCA/On', 1, 0),
      '/ch/01/eq/on': ('MIXER:Current/InCh/PEQ/On', 0, 0),
      '/ch/01/eq/3/f': ('MIXER:Current/InCh/PEQ/Band/Freq', 0, 2),
      '/bus/04/eq/2/g': ('MIXER:Current/Mix/PEQ/Band/Gain', 3, 1),
      '/ch/01/eq/1/type': ('MIXER:Current/InCh/PEQ/LowShelving/On', 0, 0),
      '/ch/01/eq/4/type': ('MIXER:Current/InCh/PEQ/HighShelving/On', 0, 0),
      '/ch/02/preamp/hpf': ('MIXER:Current/InCh/HPF/Freq', 1, 0),
      '/ch/02/gate/thr': ('MIXER:Current/InCh/Dyna1/Threshold', 1, 0),
      '/ch/02/gate/release': ('MIXER:Current/InCh/Dyna1/Decay', 1, 0),
      '/ch/02/dyn/ratio': ('MIXER:Current/InCh/Dyna2/Ratio', 1, 0),
      '/bus/01/dyn/thr': ('MIXER:Current/Mix/Dyna1/Threshold', 0, 0),
      '/headamp/03/gain': ('IO:Current/InCh/HAGain', 2, 0),
      '/headamp/03/phantom': ('IO:Current/InCh/48VOn', 2, 0),
      '/config/mute/2': ('MIXER:Current/MuteMaster/On', 1, 0),
      '/config/solo/level': ('MIXER:Current/Monitor/Fader/Level', 0, 0),
    };
    cases.forEach((app, want) {
      final p = tf.toYamaha(app);
      expect(p, isNotNull, reason: app);
      expect((p!.path, p.x, p.y), want, reason: app);
    });
    // dialect differences
    final cl = YamahaMap(dialect: YamahaDialect.clql, mixes: 24, dcas: 16);
    expect(cl.toYamaha('/headamp/01/gain')!.path, 'MIXER:Current/InCh/Port/HA/Gain');
    expect(cl.toYamaha('/headamp/01/phantom'), isNull);
    expect(YamahaMap(dialect: YamahaDialect.dm3).toYamaha('/config/mute/1')!.path, 'MIXER:Current/MuteGrpCtrl/On');
    expect(cl.toYamaha('/ch/01/mix/25/level'), isNull); // no FX buses on CL
    // DCA mask → one switch per DCA
    final dca = tf.dcaMaskParams('/ch/05/grp/dca');
    expect(dca.length, 8);
    expect((dca.last.path, dca.last.x, dca.last.y), ('MIXER:Current/InCh/DCA/Assign', 4, 7));
    // not mapped: ignored rather than sent wrongly
    for (final a in ['/ch/01/dyn/knee', '/-stat/solosw/01', '/fx/1/type', '/ch/../config/name', '/xremote', '/ch/01/eq/5/g']) {
      expect(tf.toYamaha(a), isNull, reason: a);
    }
  });

  test('values convert both ways in console units', () {
    expect(tf.encode(YamahaKind.level, 0.0), '-32768');
    expect(tf.encode(YamahaKind.level, unityFader), '0');
    expect(tf.encode(YamahaKind.level, 1.0), '1000');
    expect(tf.encode(YamahaKind.level, double.nan), isNull);
    expect(tf.decode(YamahaKind.level, '-32768'), 0.0);
    expect(tf.decode(YamahaKind.level, '-1000') as double, closeTo(dbToFader(-10), 1e-9));
    for (final f in [0.1, 0.3, 0.5, 0.62, 0.75, 0.9]) {
      expect(tf.decode(YamahaKind.level, tf.encode(YamahaKind.level, f)!) as double, closeTo(f, 0.002));
    }
    expect(tf.encode(YamahaKind.freq, freqLaw.toNorm(1000)), '10000');
    expect(tf.encode(YamahaKind.eqGain, eqGainLaw.toNorm(-6)), '-600');
    expect(tf.encode(YamahaKind.q, qLaw.toNorm(1.4)), '1400');
    expect(tf.encode(YamahaKind.gateThr, gateThrLaw.toNorm(-40)), '-400');
    expect(tf.encode(YamahaKind.range, gateRangeLaw.toNorm(40)), '-4000');
    expect(tf.encode(YamahaKind.ratio, 6), '40'); // 4:1
    expect(tf.decode(YamahaKind.ratio, '40'), 6);
    expect(tf.encode(YamahaKind.pan, 1.0), '63');
    expect(tf.decode(YamahaKind.pan, '0') as double, closeTo(0.5, 1e-9));
    expect(tf.encode(YamahaKind.haGain, headampGainLaw.toNorm(30)), '30');
    expect(YamahaMap(dialect: YamahaDialect.clql).encode(YamahaKind.haGain, headampGainLaw.toNorm(30)), '3000');
    expect(tf.encode(YamahaKind.eqTypeLow, 1), '1');
    expect(tf.decode(YamahaKind.eqTypeLow, '0'), 2);
    expect(tf.decode(YamahaKind.eqTypeHigh, '1'), 4);
    expect(tf.encode(YamahaKind.gateMode, 4), '"Ducking"');
    expect(YamahaMap(dialect: YamahaDialect.dm7).encode(YamahaKind.gateMode, 3), '"GATE"');
    expect(tf.decode(YamahaKind.gateMode, 'EXPANDER'), 0);
    for (final (k, n) in [
      (YamahaKind.freq, 0.4), (YamahaKind.eqGain, 0.7), (YamahaKind.q, 0.3), (YamahaKind.hpf, 0.5),
      (YamahaKind.gateThr, 0.6), (YamahaKind.compThr, 0.5), (YamahaKind.attack, 0.25), (YamahaKind.releaseMs, 0.5),
      (YamahaKind.holdMs, 0.5), (YamahaKind.makeup, 0.25), (YamahaKind.range, 0.5),
    ]) {
      expect(tf.decode(k, tf.encode(k, n)!) as double, closeTo(n, 0.01), reason: '$k');
    }
    expect(tf.encode(YamahaKind.name, 'Lead "Vox"'), '"Lead \'Vox\'"');
    expect(tf.encode(YamahaKind.color, 1), '"Red"');
    expect(tf.decode(YamahaKind.color, 'SkyBlue'), 6);
    expect(tf.meterDb(126), 0);
    expect(tf.meterDb(0), double.negativeInfinity);
    expect(YamahaMap(dialect: YamahaDialect.dm7).meterDb(0), double.negativeInfinity);
    expect(YamahaMap.dm7MeterTable.length, 256);
    expect(YamahaMap.tokenize('OK get MIXER:Current/InCh/Label/Name 0 0 "Lead Vox"'),
        ['OK', 'get', 'MIXER:Current/InCh/Label/Name', '0', '0', 'Lead Vox']);
  });

  test('every Yamaha series: profile addresses all translate', () {
    for (final m in ['TF5', 'DM3', 'DM7', 'QL5', 'CL5']) {
      final l = YamahaLayout.forModel(m);
      final p = MixerProfile.yamaha(m, l);
      final map = YamahaMap(dialect: yamahaDialectFor(m), mixes: l.mixes, fxSends: l.fxSends, dcas: l.dcas);
      bool ok(String a) =>
          map.toYamaha(a) != null ||
          YamahaMap.constantFor(a) != null ||
          map.dcaMaskParams(a).isNotEmpty ||
          MixerProfile.yamahaSceneFromNameAddr(a) != null ||
          a == MixerProfile.yamahaSceneCurrentAddr;
      final bad = [
        ...p.queryAddresses,
        ...p.snapshotAddresses(),
        ...p.consoleLibraryAddresses,
      ].where((a) => !ok(a)).toSet();
      expect(bad, isEmpty, reason: '$m: ${bad.take(5).join(', ')}');
      expect(p.hasSolo && p.hasMeters && p.hasConsoleLibrary, isTrue, reason: m);
      expect(p.hasFx || p.hasRouting || p.hasRecorder || p.hasAnalyzer, isFalse, reason: m);
      final d = MixerController.demo(MixerFamily.yamaha, model: m);
      expect(d.profile.inputs.first.hasDetail, isTrue);
      d.dispose();
    }
    expect(MixerProfile.yamaha('DM7', YamahaLayout.forModel('DM7')).busTargets.length, 48);
    expect(MixerProfile.yamaha('TF5', YamahaLayout.forModel('TF5')).sendTargets.last.label, 'FX 2');
  });

  test('session with a fake TF: layout, sync, set, NOTIFY, DCA, meters, scenes', () async {
    final fake = FakeYamaha();
    await fake.start();
    final link = await YamahaLink.connect('127.0.0.1', port: fake.port);
    expect(await link.askProductName(), 'TF5');
    final l = await link.readLayout('TF5');
    expect([l.inputs, l.stereoInputs, l.fxReturns, l.mixes, l.matrices, l.dcas, l.fxSends, l.muteGroups],
        [40, 4, 4, 20, 4, 8, 2, 6]);
    expect(l.mixWord, 'AUX');

    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);

    fake.state['MIXER:Current/InCh/Fader/Level 2 0'] = '-1000';
    fake.state['MIXER:Current/InCh/Label/Name 2 0'] = '"Pastor"';
    fake.state['MIXER:Current/InCh/PEQ/Band/Gain 2 1'] = '-600';
    link.send(const OscMessage('/ch/03/mix/fader'));
    link.send(const OscMessage('/ch/03/config/name'));
    link.send(const OscMessage('/ch/03/eq/2/g'));
    await _until(() => got.length >= 3);
    expect(got['/ch/03/mix/fader'] as double, closeTo(dbToFader(-10), 1e-9));
    expect(got['/ch/03/config/name'], 'Pastor');
    expect(got['/ch/03/eq/2/g'] as double, closeTo(eqGainLaw.toNorm(-6), 1e-9));

    // app changes become "set" lines; unmapped ones are never sent
    link.send(const OscMessage('/ch/01/mix/04/level', [0.75]));
    link.send(const OscMessage('/ch/01/mix/21/on', [0]));
    link.send(const OscMessage('/dca/2/on', [0]));
    link.send(const OscMessage('/ch/01/dyn/knee', [0.5]));
    await _until(() => fake.received.where((x) => x.startsWith('set')).length >= 3);
    expect(fake.received, contains('set MIXER:Current/InCh/ToMix/Level 0 3 0'));
    expect(fake.received, contains('set MIXER:Current/InCh/ToFx/On 0 0 0'));
    expect(fake.received, contains('set MIXER:Current/DCA/Fader/On 1 0 0'));
    expect(fake.received.any((x) => x.contains('Knee')), isFalse);

    // DCA mask: one switch per DCA, assembled back into a mask
    link.send(const OscMessage('/ch/05/grp/dca', [5])); // DCA 1 + 3
    await _until(() => fake.received.where((x) => x.contains('DCA/Assign')).length >= 8);
    expect(fake.state['MIXER:Current/InCh/DCA/Assign 4 0'], '1');
    expect(fake.state['MIXER:Current/InCh/DCA/Assign 4 1'], '0');
    expect(fake.state['MIXER:Current/InCh/DCA/Assign 4 2'], '1');
    fake.surface('MIXER:Current/InCh/DCA/Assign 4 7', '1');
    await _until(() => got['/ch/05/grp/dca'] == 5 | 128);
    expect(got['/ch/05/grp/dca'], 5 | 128);

    // changes on the console arrive as NOTIFY
    fake.surface('MIXER:Current/Mix/Fader/On 5 0', '0');
    fake.surface('MIXER:Current/Cue/InCh/On 0 0', '1');
    await _until(() => got.containsKey('/bus/06/mix/on') && got.containsKey('/ch/01/cue'));
    expect(got['/bus/06/mix/on'], 0);
    expect(got['/ch/01/cue'], 1);

    // meters arrive as the app's meter blobs
    link.send(const OscMessage('/meters', ['/meters/yamaha/InCh']));
    await _until(() => got.containsKey('/meters/yamaha/InCh'));
    expect(fake.received, contains('mtrstart MIXER:Current/InCh/PreFader 100'));
    final mv = decodeMeterBlob(got['/meters/yamaha/InCh'] as dynamic, MeterFormat.int16Db);
    expect(mv.length, 40);
    expect(mv.first, closeTo(100 - 126, 0.01));

    // scenes: current, names, recall, store
    link.send(const OscMessage(MixerProfile.yamahaSceneCurrentAddr));
    link.send(OscMessage(MixerProfile.yamahaSceneNameAddr(7)));
    await _until(() => got.containsKey(MixerProfile.yamahaSceneNameAddr(7)) && got.containsKey('/-snap/index'));
    expect(got['/-snap/index'], 3);
    expect(got[MixerProfile.yamahaSceneNameAddr(7)], 'Scene 7');
    link.send(const OscMessage('/-snap/load', [9]));
    link.send(const OscMessage('/-snap/save', [10]));
    await _until(() => fake.received.contains('ssupdate_ex scene_a 10'));
    expect(fake.received, contains('ssrecall_ex scene_a 9'));
    expect(fake.received, contains('ssupdate_ex scene_a 10'));

    // keep-alive asks for something real
    link.send(const OscMessage('/xinfo'));
    await _until(() => fake.received.contains('get MIXER:Current/St/Fader/Level 0 0'));
    expect(fake.received, contains('get MIXER:Current/St/Fader/Level 0 0'));

    // hostile / broken lines are ignored
    for (final c in fake.clients) {
      c.write('garbage line without meaning\n');
      c.write('NOTIFY set MIXER:Current/InCh/Fader/Level x y z\n');
      c.write('NOTIFY set MIXER:Current/Evil/Fader/Level 0 0 0\n');
      c.write('NOTIFY mtr MIXER:Current/Unknown/PreFader mtr ff ff\n');
    }
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(got.keys.where((k) => k.contains('Evil') || k.contains('Unknown')), isEmpty);

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('a whole profile syncs against a fake console (every series)', () async {
    for (final (model, f) in [
      ('TF5', FakeYamaha()),
      ('DM3', FakeYamaha(inputs: 16, stereo: 2, fx: 4, mixes: 6, mtrx: 2, dcas: 8, mutes: 6, model: 'DM3')),
      ('CL5', FakeYamaha(inputs: 72, stereo: 16, fx: 0, mixes: 24, mtrx: 8, dcas: 16, fxBuses: 0, mutes: 8, model: 'CL5')),
    ]) {
      await f.start();
      final link = await YamahaLink.connect('127.0.0.1', port: f.port);
      final l = await link.readLayout(model);
      final p = MixerProfile.yamaha(model, l);
      final seen = <String>{};
      final sub = link.messages.listen((m) => seen.add(m.address));
      final want = p.queryAddresses.toSet();
      for (final a in want) {
        link.send(OscMessage(a));
      }
      await _until(() => seen.containsAll(want), ms: 10000);
      expect(want.difference(seen), isEmpty, reason: model);
      await sub.cancel();
      link.close();
      await f.stop();
    }
  });

  test('connect fails cleanly when nothing listens', () async {
    final s = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = s.port;
    await s.close();
    await expectLater(YamahaLink.connect('127.0.0.1', port: port, timeout: const Duration(seconds: 1)), throwsA(anything));
  });
}
