// X32 / XR aux inputs: an EQ page and a trim (gain) knob on the strip.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/mixer/rta.dart';
import 'package:mixer_kontrol/ui/channel_detail_screen.dart';
import 'package:mixer_kontrol/ui/channel_strip.dart';
import 'package:mixer_kontrol/ui/gain_knob.dart';
import 'package:mixer_kontrol/util/param_law.dart';

void main() {
  test('X32 and XR aux inputs have EQ and trim', () {
    final x = MixerController.demo(MixerFamily.x32);
    final aux = x.profile.inputs.where((s) => s.type == StripType.auxIn).toList();
    expect(aux, hasLength(8));
    for (final s in aux) {
      expect(s.eqBands, 4);
      expect(s.inputTrimAddr, '${s.prefix}/preamp/trim');
      expect(s.eqAddr(1, 'f'), '${s.prefix}/eq/1/f');
    }
    final xr = MixerController.demo(MixerFamily.xr);
    final a = xr.profile.inputs.singleWhere((s) => s.type == StripType.auxIn);
    expect(a.eqBands, 4);
    expect(a.inputTrimAddr, '/rtn/aux/preamp/rtntrim');
    expect(a.eqOnAddr, '/rtn/aux/eq/on');
    x.dispose();
    xr.dispose();
  });

  for (final family in [MixerFamily.x32, MixerFamily.xr]) {
    testWidgets('${family.name} aux strip: trim knob and EQ page', (tester) async {
      final c = MixerController.demo(family);
      final s = c.profile.inputs.firstWhere((s) => s.type == StripType.auxIn);
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(height: 600, child: ChannelStrip(controller: c, strip: s, width: 70)),
          ),
        ),
      ));
      await tester.pump(const Duration(milliseconds: 300));
      expect(find.byType(TrimKnob), findsOneWidget);
      expect(find.text('TRIM'), findsOneWidget);

      // drag up: more trim, in 0.5 dB steps, never past +18
      await tester.drag(find.byType(TrimKnob), const Offset(0, -40));
      await tester.pump(const Duration(milliseconds: 300));
      final db = trimLaw.toReal((c.param(s.inputTrimAddr!).value as num).toDouble());
      expect(db, greaterThan(0));
      expect(db, lessThanOrEqualTo(18));
      expect((db * 2).roundToDouble(), closeTo(db * 2, 1e-6));

      // tap: the strip's page with the EQ and the trim
      await tester.tap(find.byType(TrimKnob));
      await tester.pumpAndSettle();
      expect(find.byType(ChannelDetailScreen), findsOneWidget);
      expect(find.text('Trim'), findsOneWidget);
      c.dispose();
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 2));
    });
  }

  // (RTA) a cut in the EQ shows in the spectrum: the console's RTA is set to
  // post-EQ, and the demo shapes its spectrum with the EQ curve
  for (final family in [MixerFamily.x32, MixerFamily.xr]) {
    test('${family.name} RTA follows the EQ', () async {
      final c = MixerController.demo(family);
      final s = c.profile.inputs.first;
      c.set(s.eqOnAddr, 1);
      c.set(s.eqAddr(3, 'type'), 2); // PEQ
      c.set(s.eqAddr(3, 'f'), freqLaw.toNorm(1710));
      c.set(s.eqAddr(3, 'g'), eqGainLaw.toNorm(-13.5));
      c.set(s.eqAddr(3, 'q'), qLaw.toNorm(2));
      expect(c.eqCurveDb(s, 1710), closeTo(-13.5, 1.0));
      expect(c.eqCurveDb(s, 200).abs(), lessThan(3));

      c.watchRta(s);
      expect(c.param(family == MixerFamily.x32 ? '/-prefs/rta/pos' : '/-stat/rta/pos').value, 1);
      await Future<void>.delayed(const Duration(milliseconds: 800));
      final db = c.rta.db;
      expect(db, hasLength(rtaBins));
      int bin(double hz) {
        var best = 0;
        for (var i = 0; i < rtaBins; i++) {
          if ((rtaBinHz(i, rtaBins) - hz).abs() < (rtaBinHz(best, rtaBins) - hz).abs()) best = i;
        }
        return best;
      }

      // the cut bin sits well below its neighbours an octave away
      final cut = db[bin(1710)];
      expect(cut, lessThan(db[bin(600)] - 6));
      c.unwatchRta();
      c.dispose();
    });
  }
}
