// X32 / XR aux inputs: an EQ page and a trim (gain) knob on the strip.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/mixer/rta.dart';
import 'package:mixer_kontrol/ui/channel_detail_screen.dart';
import 'package:mixer_kontrol/ui/channel_strip.dart';
import 'package:mixer_kontrol/ui/gain_knob.dart';
import 'package:mixer_kontrol/util/param_law.dart';

void main() {
  test('X32 and XR aux inputs have EQ and trim', () {
    final x = MixerController.demo(MixerFamily.x32);
    final aux = x.profile.inputs.where((s) => s.type == StripType.auxIn).toList();
    expect(aux, hasLength(8));
    for (final s in aux) {
      expect(s.eqBands, 4);
      expect(s.inputTrimAddr, '${s.prefix}/preamp/trim');
      expect(s.eqAddr(1, 'f'), '${s.prefix}/eq/1/f');
    }
    final xr = MixerController.demo(MixerFamily.xr);
    final a = xr.profile.inputs.singleWhere((s) => s.type == StripType.auxIn);
    expect(a.eqBands, 4);
    expect(a.inputTrimAddr, '/rtn/aux/preamp/rtntrim');
    expect(a.eqOnAddr, '/rtn/aux/eq/on');
    x.dispose();
    xr.dispose();
  });

  for (final family in [MixerFamily.x32, MixerFamily.xr]) {
    testWidgets('${family.name} aux strip: trim knob and EQ page', (tester) async {
      final c = MixerController.demo(family);
      final s = c.profile.inputs.firstWhere((s) => s.type == StripType.auxIn);
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(height: 600, child: ChannelStrip(controller: c, strip: s, width: 70)),
          ),
        ),
      ));
      await tester.pump(const Duration(milliseconds: 300));
      expect(find.byType(TrimKnob), findsOneWidget);
      expect(find.text('TRIM'), findsOneWidget);

      // drag up: more trim, in 0.5 dB steps, never past +18
      await tester.drag(find.byType(TrimKnob), const Offset(0, -40));
      await tester.pump(const Duration(milliseconds: 300));
      final db = trimLaw.toReal((c.param(s.inputTrimAddr!).value as num).toDouble());
      expect(db, greaterThan(0));
      expect(db, lessThanOrEqualTo(18));
      expect((db * 2).roundToDouble(), closeTo(db * 2, 1e-6));

      // tap: the strip's page with the EQ and the trim
      await tester.tap(find.byType(TrimKnob));
      await tester.pumpAndSettle();
      expect(find.byType(ChannelDetailScreen), findsOneWidget);
      expect(find.text('Trim'), findsOneWidget);
      c.dispose();
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 2));
    });
  }

  // (RTA) a cut in the EQ shows in the spectrum: the console sends its RTA
  // pre-EQ and the EQ screen adds the curve, at full resolution
  for (final family in [MixerFamily.x32, MixerFamily.xr]) {
    test('${family.name} RTA: pre-EQ spectrum, EQ curve added', () async {
      final c = MixerController.demo(family);
      final s = c.profile.inputs.first;
      c.set(s.eqOnAddr, 1);
      c.set(s.eqAddr(3, 'type'), 2); // PEQ
      c.set(s.eqAddr(3, 'f'), freqLaw.toNorm(603));
      c.set(s.eqAddr(3, 'g'), eqGainLaw.toNorm(-15));
      c.set(s.eqAddr(3, 'q'), qLaw.toNorm(5.8));
      // a narrow cut: full depth at its frequency, little a third away
      expect(c.eqCurveDb(s, 603), closeTo(-15, 1.0));
      expect(c.eqCurveDb(s, 480), greaterThan(-6));

      c.watchRta(s);
      expect(c.param(family == MixerFamily.x32 ? '/-prefs/rta/pos' : '/-stat/rta/pos').value, 0);
      await Future<void>.delayed(const Duration(milliseconds: 800));
      expect(c.rta.db, hasLength(rtaBins));
      c.unwatchRta();
      c.dispose();
    });
  }

  test('RTA auto range: up at once, down only after a quiet while, still in between', () async {
    final r = RtaData();
    List<double> flat(double v) => List.filled(rtaBins, v);
    r.update(flat(-60));
    final t1 = r.followTop();
    expect(t1, greaterThanOrEqualTo(-57));
    expect(t1 - 36, lessThan(-60), reason: 'signal inside the window');
    r.update(flat(-20));
    final t2 = r.followTop();
    expect(t2, greaterThanOrEqualTo(-17), reason: 'louder: up at once');
    r.update(flat(-24));
    expect(r.followTop(), t2, reason: 'a bit quieter: the window stands still');
    r.update(flat(-50));
    expect(r.followTop(), t2, reason: 'quiet only briefly: still');
    await Future<void>.delayed(const Duration(milliseconds: 3200));
    r.update(flat(-50));
    expect(r.followTop(), lessThan(t2), reason: 'quiet for a while: comes down');
  });
}
