// The same 100 users on their own device sizes: each drives the real screens
// (demo console of their family) with role-guided steps plus random taps,
// drags and long presses. Every exception and layout overflow is collected.
//
// Results: build/sim/ui_report.json

import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/ui/app_style.dart';
import 'package:mixer_kontrol/ui/mixer_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'users.dart';

var _nav = GlobalKey<NavigatorState>();

class _Launcher extends StatelessWidget {
  const _Launcher({required this.family});
  final MixerFamily family;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: FilledButton(
            key: const ValueKey('launch'),
            onPressed: () {
              final c = MixerController.demo(family);
              Navigator.of(context).push(MaterialPageRoute<void>(
                settings: const RouteSettings(name: 'mixer'),
                builder: (_) => MixerScreen(controller: c),
              ));
            },
            child: const Text('launch'),
          ),
        ),
      );
}

Widget _app(MixerFamily family) => MaterialApp(
      navigatorKey: _nav,
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: AppStyle.glowBlue, brightness: Brightness.dark),
        scaffoldBackgroundColor: Colors.transparent,
      ),
      home: _Launcher(family: family),
    );

class UiIssue {
  UiIssue(this.kind, this.where, this.message);
  final String kind; // overflow, exception, plugin
  final String where;
  final String message;
  Map<String, String> toJson() => {'kind': kind, 'where': where, 'message': message};
}

const _menuItems = [
  'FX Rack', 'Snapshots', 'Recorder', 'User guide', 'Meters', 'Feedback finder', 'Routing & outputs',
  'Automix', 'Talkback & oscillator', 'My layers', 'MIDI controller', 'Personal monitor mode',
];

final Map<String, Map<String, Object>> _results = {};

/// The test font draws every glyph as a full square, far wider than real
/// text; load the real Roboto + Material icons so overflows are realistic.
Future<void> _loadRealFonts() async {
  final root = Platform.environment['FLUTTER_ROOT'];
  if (root == null) return;
  final dir = Directory('$root/bin/cache/artifacts/material_fonts');
  if (!dir.existsSync()) return;
  final roboto = FontLoader('Roboto');
  final icons = FontLoader('MaterialIcons');
  for (final f in dir.listSync().whereType<File>()) {
    final name = f.uri.pathSegments.last;
    final bytes = f.readAsBytes().then((b) => ByteData.view(b.buffer));
    if (name.startsWith('Roboto-') && !name.contains('Condensed')) roboto.addFont(bytes);
    if (name.startsWith('MaterialIcons-Regular')) icons.addFont(bytes);
  }
  await roboto.load();
  await icons.load();
  _realFonts = true;
}

var _realFonts = false;

void _mockPlugins() {
  SharedPreferences.setMockInitialValues({});
  final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  Future<Object?> generic(MethodCall call) async {
    final n = call.method.toLowerCase();
    if (n.startsWith('has') || n.startsWith('is') || n.startsWith('check')) return false;
    if (n.contains('directory') || n.contains('path')) return Directory.systemTemp.path;
    if (n.contains('devices')) return <Object>[];
    return null;
  }

  for (final ch in const [
    'plugins.flutter.io/path_provider',
    'com.llfbandit.record/messages',
    'com.llfbandit.record',
    'plugins.invisiblewrench.com/flutter_midi_command',
    'dev.fluttercommunity.plus/share',
  ]) {
    m.setMockMethodCallHandler(MethodChannel(ch), generic);
  }
}

void main() {
  final users = makeUsers();

  setUpAll(() async {
    _mockPlugins();
    await _loadRealFonts();
  });

  // The 100 users on X32 / XR, then 20 of them again on a Yamaha (beta).
  final runs = [
    for (final u in users) (u, u.x32 ? MixerFamily.x32 : MixerFamily.xr, '${u.id}'),
    for (final u in users.take(20)) (u, MixerFamily.yamaha, 'Y${u.id}'),
  ];
  for (final (u, family, key) in runs) {
    testWidgets('user $key: ${roleNames[u.role]} · ${family == MixerFamily.yamaha ? 'Yamaha TF' : u.model} · ${u.device.name}', (tester) async {
      _nav = GlobalKey<NavigatorState>();
      final issues = <UiIssue>[];
      _results[key] = {'user': u.toJson(), 'family': family.name, 'steps': 0, 'completed': false, 'issues': <Map<String, String>>[]};
      var where = 'start';
      final oldOnError = FlutterError.onError;
      void record(String kind, String msg) {
        if (issues.where((i) => i.message == msg && i.where == where).isEmpty) {
          issues.add(UiIssue(kind, where, msg));
          (_results[key]!['issues'] as List).add(issues.last.toJson());
        }
      }

      FlutterError.onError = (d) {
        final msg = d.exceptionAsString();
        final kind = msg.contains('overflowed')
            ? 'overflow'
            : (msg.contains('MissingPluginException') ? 'plugin' : 'exception');
        var stack = (d.stack?.toString() ?? '').split('\n').where((l) => l.contains('mixer_kontrol/')).take(4).join(' | ');
        if (kind == 'overflow') {
          // where the overflowing widget is created in our code
          final loc = RegExp(r'mixer_kontrol/(lib/[\w/]+\.dart:\d+:\d+)').firstMatch(d.toString());
          stack = loc?.group(1) ?? 'unknown';
        }
        record(kind, '${msg.split('\n').take(3).join(' ')}${stack.isEmpty ? '' : '  @ $stack'}');
        // A real exception (not a layout overflow) is handed to the test
        // framework too, so the run shows its full stack trace.
        if (kind == 'exception') oldOnError?.call(d);
      };
      addTearDown(() {
        // ignore: avoid_print
        print('SIMJSON ${jsonEncode(_results[key])}');
        FlutterError.onError = oldOnError;
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });
      final r = math.Random(u.seed);
      tester.view.physicalSize = u.device.size * 2;
      tester.view.devicePixelRatio = 2;
      var steps = 0;

      Future<void> settle([int ms = 350]) async {
        for (var t = 0; t < ms; t += 120) {
          await tester.pump(const Duration(milliseconds: 120));
        }
        final e = tester.takeException();
        if (e != null) record('exception', '$e'.split('\n').first);
      }

      Future<void> tapText(String t) async {
        final f = find.text(t);
        if (f.evaluate().isNotEmpty) {
          await tester.tap(f.first, warnIfMissed: false);
          await settle();
        }
      }

      Future<void> tapTooltip(String t) async {
        final f = find.byTooltip(t);
        if (f.evaluate().isNotEmpty) {
          await tester.tap(f.first, warnIfMissed: false);
          await settle();
        }
      }

      Future<void> backToMixer() async {
        _nav.currentState?.popUntil((route) => route.settings.name == 'mixer' || route.isFirst);
        await settle();
        if (find.byKey(const ValueKey('launch')).evaluate().isNotEmpty) {
          await tester.tap(find.byKey(const ValueKey('launch')));
          await settle(600);
        }
      }

      Future<void> monkey(int n) async {
        final w = u.device.size.width, h = u.device.size.height;
        for (var i = 0; i < n; i++) {
          steps++;
          _results[key]!['steps'] = steps;
          final at = Offset(r.nextDouble() * w, r.nextDouble() * h);
          final k = r.nextInt(10);
          try {
            if (k < 6) {
              await tester.tapAt(at);
            } else if (k < 8) {
              await tester.dragFrom(at, Offset((r.nextDouble() - 0.5) * w * 0.6, (r.nextDouble() - 0.5) * h * 0.6));
            } else if (k < 9) {
              await tester.longPressAt(at);
            } else {
              final g = await tester.startGesture(at);
              await tester.pump(const Duration(milliseconds: 40));
              await g.moveBy(Offset(0, (r.nextDouble() - 0.5) * 200));
              await g.up();
            }
          } catch (e) {
            record('exception', 'gesture: $e'.split('\n').first);
          }
          await settle(240);
          // never wander off for long: dialogs / pages are closed now and then
          if (r.nextInt(12) == 0) await backToMixer();
        }
      }

      await tester.pumpWidget(_app(family));
      await settle();
      await tester.tap(find.byKey(const ValueKey('launch')));
      await settle(600);

      // role-guided visits of the main pages
      where = 'mixer';
      for (final tab in const ['Buses', 'AUX', 'DCA', 'My layers', 'Matrix', 'Inputs']) {
        where = 'tab $tab';
        await tapTooltip(tab);
        await monkey(3);
      }
      final visits = [..._menuItems]..shuffle(r);
      for (final item in visits.take(u.role == Role.beginner ? _menuItems.length : 6)) {
        where = 'menu $item';
        await backToMixer();
        await tapTooltip('More');
        await tapText(item);
        await monkey(6);
      }
      where = 'monitor & lock';
      await backToMixer();
      await tapTooltip('Monitor & solo');
      await backToMixer();
      await tapTooltip('Mute lock off (tap to lock)');
      await monkey(4);
      where = 'free play';
      await backToMixer();
      await monkey(u.role == Role.beginner ? 40 : 20);

      // tidy up: leave every page, dispose the console (stops its timers)
      _nav.currentState?.popUntil((route) => route.isFirst);
      await settle();
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 2));
      _results[key]!['completed'] = true;
    }, timeout: const Timeout(Duration(minutes: 3)));
  }

  tearDownAll(() {
    final dir = Directory('build/sim')..createSync(recursive: true);
    File('${dir.path}/ui_report.json').writeAsStringSync(const JsonEncoder.withIndent(' ').convert(_results));
    var n = 0;
    final kinds = <String, int>{};
    for (final r in _results.values) {
      for (final i in (r['issues'] as List)) {
        n++;
        final k = (i as Map)['kind'] as String;
        kinds[k] = (kinds[k] ?? 0) + 1;
      }
    }
    // ignore: avoid_print
    print('UI monkey: ${_results.length} users, $n issues $kinds (real fonts: $_realFonts)');
  });
}
