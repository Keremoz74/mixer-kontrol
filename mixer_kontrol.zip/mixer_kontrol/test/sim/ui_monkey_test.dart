// The same 100 users on their own device sizes: each drives the real screens
// (demo console of their family) with role-guided steps plus random taps,
// drags and long presses. Every exception and layout overflow is collected.
//
// Results: build/sim/ui_report.json

import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/ui/app_style.dart';
import 'package:mixer_kontrol/ui/mixer_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'users.dart';

final _nav = GlobalKey<NavigatorState>();

class _Launcher extends StatelessWidget {
  const _Launcher({required this.x32});
  final bool x32;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: FilledButton(
            key: const ValueKey('launch'),
            onPressed: () {
              final c = MixerController.demo(x32 ? MixerFamily.x32 : MixerFamily.xr);
              Navigator.of(context).push(MaterialPageRoute<void>(
                settings: const RouteSettings(name: 'mixer'),
                builder: (_) => MixerScreen(controller: c),
              ));
            },
            child: const Text('launch'),
          ),
        ),
      );
}

Widget _app(bool x32) => MaterialApp(
      navigatorKey: _nav,
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: AppStyle.glowBlue, brightness: Brightness.dark),
        scaffoldBackgroundColor: Colors.transparent,
      ),
      home: _Launcher(x32: x32),
    );

class UiIssue {
  UiIssue(this.kind, this.where, this.message);
  final String kind; // overflow, exception, plugin
  final String where;
  final String message;
  Map<String, String> toJson() => {'kind': kind, 'where': where, 'message': message};
}

const _menuItems = [
  'FX Rack', 'Snapshots', 'Recorder', 'User guide', 'Meters', 'Feedback finder', 'Routing & outputs',
  'Automix', 'Talkback & oscillator', 'My layers', 'MIDI controller', 'Personal monitor mode',
];

final Map<String, Map<String, Object>> _results = {};

void _mockPlugins() {
  SharedPreferences.setMockInitialValues({});
  final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  Future<Object?> generic(MethodCall call) async {
    final n = call.method.toLowerCase();
    if (n.startsWith('has') || n.startsWith('is') || n.startsWith('check')) return false;
    if (n.contains('directory') || n.contains('path')) return Directory.systemTemp.path;
    if (n.contains('devices')) return <Object>[];
    return null;
  }

  for (final ch in const [
    'plugins.flutter.io/path_provider',
    'com.llfbandit.record/messages',
    'com.llfbandit.record',
    'plugins.invisiblewrench.com/flutter_midi_command',
    'dev.fluttercommunity.plus/share',
  ]) {
    m.setMockMethodCallHandler(MethodChannel(ch), generic);
  }
}

void main() {
  final users = makeUsers();

  setUpAll(_mockPlugins);

  for (final u in users) {
    testWidgets('user ${u.id}: ${roleNames[u.role]} · ${u.model} · ${u.device.name}', (tester) async {
      final issues = <UiIssue>[];
      var where = 'start';
      final oldOnError = FlutterError.onError;
      FlutterError.onError = (d) {
        final msg = d.exceptionAsString();
        final kind = msg.contains('overflowed')
            ? 'overflow'
            : (msg.contains('MissingPluginException') ? 'plugin' : 'exception');
        if (issues.where((i) => i.message == msg && i.where == where).isEmpty) {
          issues.add(UiIssue(kind, where, msg.split('\n').take(3).join(' ')));
        }
      };
      final r = math.Random(u.seed);
      tester.view.physicalSize = u.device.size * 2;
      tester.view.devicePixelRatio = 2;
      var steps = 0;

      Future<void> settle([int ms = 350]) async {
        for (var t = 0; t < ms; t += 120) {
          await tester.pump(const Duration(milliseconds: 120));
        }
        final e = tester.takeException();
        if (e != null) issues.add(UiIssue('exception', where, '$e'.split('\n').first));
      }

      Future<void> tapText(String t) async {
        final f = find.text(t);
        if (f.evaluate().isNotEmpty) {
          await tester.tap(f.first, warnIfMissed: false);
          await settle();
        }
      }

      Future<void> tapTooltip(String t) async {
        final f = find.byTooltip(t);
        if (f.evaluate().isNotEmpty) {
          await tester.tap(f.first, warnIfMissed: false);
          await settle();
        }
      }

      Future<void> backToMixer() async {
        _nav.currentState?.popUntil((route) => route.settings.name == 'mixer' || route.isFirst);
        await settle();
        if (find.byKey(const ValueKey('launch')).evaluate().isNotEmpty) {
          await tester.tap(find.byKey(const ValueKey('launch')));
          await settle(600);
        }
      }

      Future<void> monkey(int n) async {
        final w = u.device.size.width, h = u.device.size.height;
        for (var i = 0; i < n; i++) {
          steps++;
          final at = Offset(r.nextDouble() * w, r.nextDouble() * h);
          final k = r.nextInt(10);
          try {
            if (k < 6) {
              await tester.tapAt(at);
            } else if (k < 8) {
              await tester.dragFrom(at, Offset((r.nextDouble() - 0.5) * w * 0.6, (r.nextDouble() - 0.5) * h * 0.6));
            } else if (k < 9) {
              await tester.longPressAt(at);
            } else {
              final g = await tester.startGesture(at);
              await tester.pump(const Duration(milliseconds: 40));
              await g.moveBy(Offset(0, (r.nextDouble() - 0.5) * 200));
              await g.up();
            }
          } catch (e) {
            issues.add(UiIssue('exception', where, 'gesture: $e'.split('\n').first));
          }
          await settle(240);
          // never wander off for long: dialogs / pages are closed now and then
          if (r.nextInt(12) == 0) await backToMixer();
        }
      }

      await tester.pumpWidget(_app(u.x32));
      await settle();
      await tester.tap(find.byKey(const ValueKey('launch')));
      await settle(600);

      // role-guided visits of the main pages
      where = 'mixer';
      for (final tab in const ['Buses', 'DCA', 'My layers', 'Matrix', 'Inputs']) {
        where = 'tab $tab';
        await tapTooltip(tab);
        await monkey(3);
      }
      final visits = [..._menuItems]..shuffle(r);
      for (final item in visits.take(u.role == Role.beginner ? _menuItems.length : 6)) {
        where = 'menu $item';
        await backToMixer();
        await tapTooltip('More');
        await tapText(item);
        await monkey(6);
      }
      where = 'monitor & lock';
      await backToMixer();
      await tapTooltip('Monitor & solo');
      await backToMixer();
      await tapTooltip('Mute lock off (tap to lock)');
      await monkey(4);
      where = 'free play';
      await backToMixer();
      await monkey(u.role == Role.beginner ? 40 : 20);

      // tidy up: leave every page, dispose the console (stops its timers)
      _nav.currentState?.popUntil((route) => route.isFirst);
      await settle();
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 2));
      FlutterError.onError = oldOnError;
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();

      _results['${u.id}'] = {
        'user': u.toJson(),
        'steps': steps,
        'issues': [for (final i in issues) i.toJson()],
      };
    }, timeout: const Timeout(Duration(minutes: 4)));
  }

  tearDownAll(() {
    final dir = Directory('build/sim')..createSync(recursive: true);
    File('${dir.path}/ui_report.json').writeAsStringSync(const JsonEncoder.withIndent(' ').convert(_results));
    var n = 0;
    final kinds = <String, int>{};
    for (final r in _results.values) {
      for (final i in (r['issues'] as List)) {
        n++;
        final k = (i as Map)['kind'] as String;
        kinds[k] = (kinds[k] ?? 0) + 1;
      }
    }
    // ignore: avoid_print
    print('UI monkey: ${_results.length} users, $n issues $kinds');
  });
}
