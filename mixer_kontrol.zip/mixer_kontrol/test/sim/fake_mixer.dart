// A software stand-in for a Behringer X32 / M32 or XR / MR console, speaking
// OSC over real UDP on localhost, so the app's own networking and state code
// can be exercised under controlled network conditions.

import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:mixer_kontrol/osc/osc_message.dart';

class NetConditions {
  const NetConditions({
    this.latencyMs = 0,
    this.jitterMs = 0,
    this.dropRate = 0,
    this.dupRate = 0,
    this.bigEndianMeters = false,
    this.garbagePerSecond = 0,
    this.ignoreQueryRate = 0,
  });

  final int latencyMs;
  final int jitterMs;

  /// Fraction of packets lost (each direction).
  final double dropRate;
  final double dupRate;
  final bool bigEndianMeters;

  /// Malformed / hostile packets per second sent to subscribed clients.
  final int garbagePerSecond;

  /// Fraction of queries the console doesn't answer (busy firmware).
  final double ignoreQueryRate;

  Map<String, Object> toJson() => {
        'latencyMs': latencyMs,
        'jitterMs': jitterMs,
        'dropRate': dropRate,
        'dupRate': dupRate,
        'bigEndianMeters': bigEndianMeters,
        'garbagePerSecond': garbagePerSecond,
        'ignoreQueryRate': ignoreQueryRate,
      };
}

class _Sub {
  _Sub(this.addr, this.port);
  final InternetAddress addr;
  final int port;
  DateTime xremoteUntil = DateTime.fromMillisecondsSinceEpoch(0);
  final Map<String, DateTime> meters = {};
  String get key => '${addr.address}:$port';
}

class FakeMixer {
  FakeMixer({required this.x32, required this.model, required this.name, required this.net, int seed = 1})
      : _rnd = math.Random(seed);

  final bool x32;
  final String model;
  final String name;
  NetConditions net;
  final math.Random _rnd;

  late RawDatagramSocket _sock;
  final Map<String, Object> state = {};
  final Map<String, _Sub> _subs = {};
  Timer? _meterTimer;
  Timer? _garbageTimer;

  /// While true the console is "unplugged": nothing in, nothing out.
  bool offline = false;

  // statistics
  int rx = 0, tx = 0, dropped = 0, queries = 0, sets = 0, garbageSent = 0, meterPackets = 0;
  final Set<String> unknownCommands = {};

  /// Diagnostics: meter subscriptions received and meter packets sent, per id.
  final Map<String, int> meterSubsRx = {};
  final Map<String, int> meterSent = {};

  int get port => x32 ? 10023 : 10024;
  InternetAddress? lastClientAddr;
  int? lastClientPort;

  Future<void> start() async {
    _sock = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, port, reuseAddress: true);
    _sock.listen((e) {
      if (e != RawSocketEvent.read) return;
      final dg = _sock.receive();
      if (dg == null || offline) return;
      rx++;
      if (_rnd.nextDouble() < net.dropRate) {
        dropped++;
        return;
      }
      final m = OscMessage.decode(dg.data);
      if (m == null) return;
      lastClientAddr = dg.address;
      lastClientPort = dg.port;
      _handle(m, dg.address, dg.port);
    });
    _meterTimer = Timer.periodic(const Duration(milliseconds: 50), (_) => _sendMeters());
    if (net.garbagePerSecond > 0) {
      _garbageTimer = Timer.periodic(Duration(milliseconds: 1000 ~/ net.garbagePerSecond), (_) => _sendGarbage());
    }
  }

  Future<void> stop() async {
    _meterTimer?.cancel();
    _garbageTimer?.cancel();
    _sock.close();
    await Future<void>.delayed(const Duration(milliseconds: 50));
  }

  _Sub _sub(InternetAddress a, int p) => _subs.putIfAbsent('${a.address}:$p', () => _Sub(a, p));

  void _send(OscMessage m, InternetAddress a, int p) => _sendRaw(m.encode(), a, p);

  void _sendRaw(Uint8List bytes, InternetAddress a, int p) {
    if (offline) return;
    if (_rnd.nextDouble() < net.dropRate) {
      dropped++;
      return;
    }
    final copies = _rnd.nextDouble() < net.dupRate ? 2 : 1;
    for (var i = 0; i < copies; i++) {
      final delay = net.latencyMs + (net.jitterMs > 0 ? _rnd.nextInt(net.jitterMs + 1) : 0);
      void go() {
        try {
          _sock.send(bytes, a, p);
          tx++;
        } catch (_) {}
      }

      delay <= 0 ? go() : Timer(Duration(milliseconds: delay), go);
    }
  }

  void _handle(OscMessage m, InternetAddress a, int p) {
    final addr = m.address;
    if (addr == '/xinfo') {
      _send(OscMessage('/xinfo', ['127.0.0.1', name, model, x32 ? '4.06' : '1.22']), a, p);
      return;
    }
    if (addr == '/xremote') {
      _sub(a, p).xremoteUntil = DateTime.now().add(const Duration(seconds: 10));
      return;
    }
    if (addr == '/meters') {
      if (m.args.isNotEmpty && m.args.first is String) {
        _sub(a, p).meters[m.args.first as String] = DateTime.now().add(const Duration(seconds: 10));
        meterSubsRx[m.args.first as String] = (meterSubsRx[m.args.first as String] ?? 0) + 1;
      }
      return;
    }
    if (addr == '/-action/clearsolo') {
      for (final k in state.keys.where((k) => k.startsWith('/-stat/solosw/')).toList()) {
        _set(k, 0, null);
      }
      _set('/-stat/solo', 0, null);
      return;
    }
    if (addr == '/save' || addr == '/delete' || addr.startsWith('/-snap/load') ||
        addr.startsWith('/-snap/save') || addr.startsWith('/-snap/delete') || addr == '/-action/goscene') {
      sets++;
      return;
    }
    if (m.args.isEmpty) {
      queries++;
      if (_rnd.nextDouble() < net.ignoreQueryRate) return;
      _send(OscMessage(addr, [state[addr] ?? _default(addr)]), a, p);
      return;
    }
    if (m.args.length == 1 && (addr == '/-snap/name')) {
      sets++;
      return;
    }
    sets++;
    _set(addr, m.args.first, '${a.address}:$p');
  }

  /// Stores a value and, like the console, tells every other /xremote client.
  void _set(String addr, Object v, String? fromKey) {
    state[addr] = v;
    final now = DateTime.now();
    for (final s in _subs.values) {
      if (s.key == fromKey) continue;
      if (s.xremoteUntil.isAfter(now)) _send(OscMessage(addr, [v]), s.addr, s.port);
    }
    // the console mirrors the partner of a linked channel pair
  }

  /// Changes a value "on the console surface" (someone at the desk).
  void surfaceChange(String addr, Object v) => _set(addr, v, null);

  static final _floaty = RegExp(
      r'(fader|level|/f$|/g$|/q$|gain|trim|hpf|/pan$|thr$|range$|attack$|hold$|release$|knee$|mgain$|/mix$|weight$|time$|/par/\d+$|mlevel$|/f1$)');

  Object _default(String addr) {
    if (addr.endsWith('/name') || addr.endsWith('/file')) return '';
    if (_floaty.hasMatch(addr)) return 0.5;
    if (addr.endsWith('/on') && !addr.contains('/delay/') && !addr.contains('insert') &&
        !addr.contains('/gate/') && !addr.contains('/dyn/') && !addr.contains('/osc/')) {
      return 1;
    }
    return 0;
  }

  // ------------------------------------------------------------ meters

  int _meterCount(String id) {
    if (x32) {
      return switch (id) {
        '/meters/0' => 70,
        '/meters/1' => 96,
        '/meters/2' => 49,
        '/meters/15' => 50,
        _ => 0,
      };
    }
    return switch (id) {
      '/meters/1' => 40,
      '/meters/4' => 100,
      '/meters/6' => 40,
      _ => 0,
    };
  }

  Uint8List _meterBlob(String id) {
    final n = _meterCount(id);
    final endian = net.bigEndianMeters ? Endian.big : Endian.little;
    final x32Floats = x32 && id != '/meters/15';
    final valueBytes = x32Floats ? n * 4 : (x32 ? n * 4 : n * 2); // X32 RTA: 50 ints = 100 shorts
    final bd = ByteData(4 + valueBytes);
    bd.setInt32(0, n, endian);
    if (x32Floats) {
      for (var i = 0; i < n; i++) {
        bd.setFloat32(4 + i * 4, _rnd.nextDouble() * 0.5, endian);
      }
    } else {
      final shorts = valueBytes ~/ 2;
      for (var i = 0; i < shorts; i++) {
        bd.setInt16(4 + i * 2, (-60 + _rnd.nextInt(50)) * 256, endian);
      }
    }
    return bd.buffer.asUint8List();
  }

  void _sendMeters() {
    if (offline) return;
    final now = DateTime.now();
    for (final s in _subs.values) {
      s.meters.removeWhere((_, until) => until.isBefore(now));
      for (final id in s.meters.keys) {
        if (_meterCount(id) == 0) {
          unknownCommands.add('meters $id');
          continue;
        }
        meterPackets++;
        meterSent[id] = (meterSent[id] ?? 0) + 1;
        _send(OscMessage(id, [_meterBlob(id)]), s.addr, s.port);
      }
    }
  }

  // ------------------------------------------------------------ hostile traffic

  void _sendGarbage() {
    if (offline) return;
    final now = DateTime.now();
    for (final s in _subs.values) {
      if (!s.xremoteUntil.isAfter(now)) continue;
      garbageSent++;
      final kind = _rnd.nextInt(8);
      Uint8List bytes;
      switch (kind) {
        case 0: // random bytes
          bytes = Uint8List.fromList(List.generate(_rnd.nextInt(200) + 1, (_) => _rnd.nextInt(256)));
        case 1: // address outside the allowlist
          bytes = OscMessage('/evil/${_rnd.nextInt(1 << 30)}', [1]).encode();
        case 2: // path traversal style
          bytes = OscMessage('/ch/../config/x${_rnd.nextInt(999)}', [1]).encode();
        case 3: // huge string value on a real address
          bytes = OscMessage('/ch/01/config/name', ['X' * 5000]).encode();
        case 4: // wrong type on a fader
          bytes = OscMessage('/ch/02/mix/fader', ['not a number']).encode();
        case 5: // out of range values
          bytes = OscMessage('/ch/03/mix/fader', [_rnd.nextBool() ? 99.0 : -5.0]).encode();
        case 6: // truncated message
          final full = OscMessage('/bus/01/mix/fader', [0.3]).encode();
          bytes = Uint8List.sublistView(full, 0, full.length - 3);
        default: // blob where a value is expected
          bytes = OscMessage('/main/st/mix/fader', [Uint8List(8)]).encode();
      }
      _sendRaw(bytes, s.addr, s.port);
    }
  }
}
