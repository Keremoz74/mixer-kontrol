// 100 different users, each with their own console, network, device and way
// of working. Deterministic (seeded) so a run can be repeated exactly.

import 'dart:math' as math;

import 'package:flutter/material.dart' show Size;

import 'fake_mixer.dart';

enum Role { foh, monitor, musician, showOperator, tech, beginner, streamer, worship }

const roleNames = {
  Role.foh: 'FOH engineer',
  Role.monitor: 'Monitor engineer',
  Role.musician: 'Musician (personal mix)',
  Role.showOperator: 'Show / scene operator',
  Role.tech: 'System tech',
  Role.beginner: 'First-time user',
  Role.streamer: 'Stream / recording',
  Role.worship: 'Church volunteer',
};

class Device {
  const Device(this.name, this.size);
  final String name;
  final Size size;
}

const devices = [
  Device('Small phone portrait', Size(320, 640)),
  Device('Phone portrait', Size(393, 852)),
  Device('Phone landscape', Size(852, 393)),
  Device('Small phone landscape', Size(640, 320)),
  Device('7" tablet portrait', Size(600, 960)),
  Device('7" tablet landscape', Size(960, 600)),
  Device('10" tablet landscape', Size(1280, 800)),
  Device('12" tablet landscape', Size(1366, 1024)),
  Device('Foldable open', Size(884, 1104)),
];

class Network {
  const Network(this.name, this.cond);
  final String name;
  final NetConditions cond;
}

const networks = [
  Network('Wired / clean', NetConditions()),
  Network('Good Wi-Fi', NetConditions(latencyMs: 3, jitterMs: 4)),
  Network('Busy Wi-Fi', NetConditions(latencyMs: 25, jitterMs: 40, dropRate: 0.02)),
  Network('Mixer\'s own Wi-Fi, far away', NetConditions(latencyMs: 40, jitterMs: 80, dropRate: 0.06, dupRate: 0.01)),
  Network('Crowded venue Wi-Fi', NetConditions(latencyMs: 80, jitterMs: 150, dropRate: 0.12, dupRate: 0.02)),
  Network('Very slow link', NetConditions(latencyMs: 450, jitterMs: 300, dropRate: 0.03)),
  Network('Busy console firmware', NetConditions(latencyMs: 5, ignoreQueryRate: 0.15)),
  Network('Big-endian meters firmware', NetConditions(latencyMs: 2, bigEndianMeters: true)),
  Network('Hostile device on network', NetConditions(latencyMs: 3, garbagePerSecond: 40)),
];

class UserProfile {
  UserProfile({
    required this.id,
    required this.role,
    required this.x32,
    required this.model,
    required this.device,
    required this.network,
    required this.autoDetect,
    required this.outage,
    required this.deskChanges,
    required this.actions,
    required this.seed,
  });

  final int id;
  final Role role;
  final bool x32;
  final String model;
  final Device device;
  final Network network;

  /// Connects without choosing X32 / XR first (model auto-detect).
  final bool autoDetect;

  /// The mixer is unplugged for a while in the middle of the session.
  final bool outage;

  /// Someone also changes things on the console surface meanwhile.
  final bool deskChanges;
  final int actions;
  final int seed;

  Map<String, Object> toJson() => {
        'id': id,
        'role': roleNames[role]!,
        'mixer': model,
        'device': device.name,
        'network': network.name,
        'autoDetect': autoDetect,
        'outage': outage,
        'deskChanges': deskChanges,
        'actions': actions,
      };
}

List<UserProfile> makeUsers({int count = 100, int seed = 2026}) {
  final r = math.Random(seed);
  const x32Models = ['X32', 'X32 COMPACT', 'X32 PRODUCER', 'X32 RACK', 'M32', 'M32R'];
  const xrModels = ['XR18', 'XR16', 'XR12', 'MR18', 'X18'];
  final roles = Role.values;
  return [
    for (var i = 0; i < count; i++)
      () {
        final x32 = i.isEven;
        final models = x32 ? x32Models : xrModels;
        // every network shows up ~11 times, outage for every 12th user
        return UserProfile(
          id: i + 1,
          role: roles[(i * 7 + r.nextInt(3)) % roles.length],
          x32: x32,
          model: models[r.nextInt(models.length)],
          device: devices[(i + r.nextInt(devices.length)) % devices.length],
          network: networks[i % networks.length],
          autoDetect: r.nextDouble() < 0.3,
          outage: i % 12 == 5,
          deskChanges: r.nextDouble() < 0.4,
          actions: 80 + r.nextInt(120),
          seed: seed * 1000 + i,
        );
      }(),
  ];
}
