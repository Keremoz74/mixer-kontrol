// 100 users, one after the other, each against a fake console under their own
// network conditions. Uses the app's real OSC client and MixerController.
//
// Results: build/sim/logic_report.json (+ a summary on stdout).

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/copy_paste.dart';
import 'package:mixer_kontrol/mixer/inserts.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/mixer/routing.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';

import 'fake_mixer.dart';
import 'users.dart';

class Finding {
  Finding(this.severity, this.code, this.detail);
  final String severity; // critical, major, minor, info
  final String code;
  final String detail;
  Map<String, String> toJson() => {'severity': severity, 'code': code, 'detail': detail};
}

class SessionResult {
  SessionResult(this.user);
  final UserProfile user;
  final List<Finding> findings = [];
  final Map<String, Object> metrics = {};
  final List<String> errors = [];
  bool connected = false;

  Map<String, Object> toJson() => {
        'user': user.toJson(),
        'connected': connected,
        'metrics': metrics,
        'errors': errors.take(20).toList(),
        'errorCount': errors.length,
        'findings': [for (final f in findings) f.toJson()],
      };
}

bool _same(Object? a, Object? b) {
  if (a is num && b is num) return (a - b).abs() < 1e-3;
  return a == b;
}

Future<void> _gap(math.Random r, UserProfile u) =>
    Future<void>.delayed(Duration(milliseconds: 3 + r.nextInt(u.role == Role.beginner ? 40 : 15)));

Strip _pick(math.Random r, List<Strip> l) => l[r.nextInt(l.length)];

/// One user action of their role. Returns a short label (for the log).
Future<String> _act(MixerController c, UserProfile u, math.Random r, SendTarget myBus) async {
  final p = c.profile;
  final inputs = p.inputs;
  final channels = [for (final s in inputs) if (s.type == StripType.channel) s];
  final buses = p.mixBuses.isEmpty ? p.buses : p.mixBuses;
  final all = p.allStrips;
  final roll = r.nextInt(100);
  switch (u.role) {
    case Role.musician:
      // Personal monitor mode: only the sends to their own bus.
      final s = _pick(r, inputs);
      if (roll < 85) {
        c.setFader(s.sendLevelAddr(myBus), r.nextDouble());
        return 'send level';
      }
      c.setFlag(s.sendOnAddr(myBus), r.nextBool());
      return 'send on/off';
    case Role.monitor:
      if (roll < 50) {
        final tgt = p.sendTargets[r.nextInt(p.sendTargets.length)];
        c.setFader(_pick(r, inputs).sendLevelAddr(tgt), r.nextDouble());
        return 'send level';
      }
      if (roll < 65) {
        c.setBusTap(_pick(r, p.busTargets), r.nextInt(6));
        return 'bus tap';
      }
      if (roll < 75) {
        c.setBusLinked(_pick(r, p.busTargets), r.nextBool());
        return 'bus link';
      }
      if (roll < 90) {
        c.toggleSolo(_pick(r, all));
        return 'solo';
      }
      c.clearSolo();
      return 'clear solo';
    case Role.showOperator:
      if (roll < 30) {
        final snap = c.captureSnapshot();
        await c.recallSnapshot(snap);
        return 'snapshot capture+recall (${snap.length})';
      }
      if (roll < 50) {
        c.consoleSave(p.consoleSlotFirst + r.nextInt(10), 'Scene ${r.nextInt(99)}');
        return 'console save';
      }
      if (roll < 60) {
        await c.consoleLoad(p.consoleSlotFirst + r.nextInt(10));
        return 'console load';
      }
      if (roll < 80) {
        final src = _pick(r, channels);
        final clip = await copyStrip(c, src);
        final targets = pasteTargets(p, clip).where((t) => t.prefix != src.prefix).take(1 + r.nextInt(4));
        pasteStrip(c, clip, targets, copyDefaultSections);
        return 'copy/paste';
      }
      c.setFader(_pick(r, all).faderAddr, r.nextDouble());
      return 'fader';
    case Role.tech:
      if (roll < 15) {
        c.watchRta(_pick(r, [p.main, ...buses, ...channels]));
        return 'rta on';
      }
      if (roll < 20) {
        c.unwatchRta();
        return 'rta off';
      }
      if (roll < 30) {
        c.watchGainReduction();
        return 'gr on';
      }
      if (roll < 50) {
        final o = p.outputPorts[r.nextInt(p.outputPorts.length)];
        c.set(o.srcAddr, r.nextInt(p.outputSourceLabels.length));
        return 'output patch';
      }
      if (roll < 60) {
        c.setFlag(p.muteGroupAddr(1 + r.nextInt(p.muteGroupCount)), r.nextBool());
        return 'mute group';
      }
      if (roll < 70) {
        final s = _pick(r, p.automixStrips);
        c.set(p.automixGroupAddr(s), r.nextInt(3));
        return 'automix';
      }
      if (roll < 80 && p.hasTalkback) {
        c.setFlag(p.talkEngageAddr('A'), r.nextBool());
        return 'talkback';
      }
      final s = _pick(r, p.insertStrips);
      c.set(p.insertSelAddr(s), r.nextInt(3));
      return 'insert';
    case Role.beginner:
      // Taps anything, including odd values.
      if (roll < 40) {
        c.setFader(_pick(r, all).faderAddr, r.nextDouble() * 1.6 - 0.3);
        return 'fader (wild)';
      }
      if (roll < 55) {
        c.toggleOn(_pick(r, all).onAddr);
        return 'mute';
      }
      if (roll < 65) {
        c.rename(_pick(r, all), 'Çok uzun kanal adı ${'é' * r.nextInt(30)}');
        return 'rename';
      }
      if (roll < 75) {
        c.setInDca(_pick(r, p.groupStrips), 1 + r.nextInt(p.dcas.length), r.nextBool());
        return 'dca';
      }
      if (roll < 85) {
        c.toggleSolo(_pick(r, all));
        return 'solo';
      }
      c.set(_pick(r, channels).eqAddr(1 + r.nextInt(4), 'g'), r.nextDouble());
      return 'eq';
    case Role.streamer:
      if (roll < 40) {
        c.setFader(p.main.faderAddr, 0.5 + r.nextDouble() * 0.3);
        return 'main fader';
      }
      if (roll < 70) {
        final s = _pick(r, channels);
        c.set(s.dynAddr('thr'), r.nextDouble());
        c.setFlag(s.dynAddr('on'), true);
        return 'compressor';
      }
      if (roll < 85) {
        c.set(MixerProfile.tapeStateAddr, r.nextBool() ? 4 : 0);
        return 'usb recorder';
      }
      c.watchGainReduction();
      return 'gr on';
    case Role.worship:
      if (roll < 50) {
        c.setFader(_pick(r, channels).faderAddr, r.nextDouble());
        return 'fader';
      }
      if (roll < 70) {
        c.toggleOn(_pick(r, channels).onAddr);
        return 'mute';
      }
      if (roll < 85) {
        c.setFader(_pick(r, p.dcas).faderAddr, r.nextDouble());
        return 'dca fader';
      }
      c.setFlag(p.muteGroupAddr(1), r.nextBool());
      return 'mute group';
    case Role.foh:
      if (roll < 35) {
        c.setFader(_pick(r, all).faderAddr, r.nextDouble());
        return 'fader';
      }
      if (roll < 45) {
        c.toggleOn(_pick(r, all).onAddr);
        return 'mute';
      }
      if (roll < 60) {
        final s = _pick(r, [...channels, ...buses, p.main]);
        c.set(s.eqAddr(1 + r.nextInt(s.eqBands), ['f', 'g', 'q'][r.nextInt(3)]), r.nextDouble());
        return 'eq';
      }
      if (roll < 68) {
        final s = _pick(r, channels);
        final l = p.linkAddr(s);
        if (l != null) c.setFlag(l, r.nextBool());
        return 'link';
      }
      if (roll < 76) {
        c.setInMuteGroup(_pick(r, p.groupStrips), 1 + r.nextInt(p.muteGroupCount), r.nextBool());
        return 'mute group assign';
      }
      if (roll < 84) {
        c.set(p.fxParAddr(1 + r.nextInt(p.fxSlots), 1 + r.nextInt(16)), r.nextDouble());
        return 'fx param';
      }
      if (roll < 92) {
        final a = p.mainAssignAddr(_pick(r, channels));
        if (a != null) c.setFlag(a, r.nextBool());
        return 'main assign';
      }
      c.toggleSolo(_pick(r, all));
      return 'solo';
  }
}

Future<SessionResult> runSession(UserProfile u) async {
  final res = SessionResult(u);
  final r = math.Random(u.seed);
  final fake = FakeMixer(x32: u.x32, model: u.model, name: 'Sim ${u.id}', net: u.network.cond, seed: u.seed);
  await fake.start();
  MixerController? c;
  final sw = Stopwatch()..start();
  await runZonedGuarded(() async {
    // ---------------------------------------------------------------- connect
    try {
      c = await MixerController.connect('127.0.0.1', family: u.autoDetect ? null : (u.x32 ? MixerFamily.x32 : MixerFamily.xr));
      res.connected = true;
      res.metrics['connectMs'] = sw.elapsedMilliseconds;
    } catch (e) {
      res.metrics['connectMs'] = sw.elapsedMilliseconds;
      res.findings.add(Finding(
        u.network.cond.latencyMs >= 400 ? 'major' : 'critical',
        'CONNECT_FAILED',
        'Could not connect (${u.network.name}, auto-detect=${u.autoDetect}): $e',
      ));
      return;
    }
    final ctl = c!;
    final p = ctl.profile;
    if (p.family != (u.x32 ? MixerFamily.x32 : MixerFamily.xr)) {
      res.findings.add(Finding('critical', 'WRONG_FAMILY', 'Detected ${p.family} for model ${u.model}'));
    }
    if (u.model.contains('12') && !u.x32 && p.inputs.where((s) => s.type == StripType.channel).length != 12) {
      res.findings.add(Finding('minor', 'XR12_CHANNELS', 'XR12 profile has wrong channel count'));
    }

    // ---------------------------------------------------------------- initial sync
    final q = p.queryAddresses;
    final syncSw = Stopwatch()..start();
    var have = 0;
    while (syncSw.elapsedMilliseconds < 20000) {
      have = q.where((a) => ctl.param(a).value != null).length;
      if (have >= q.length * 0.995) break;
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    res.metrics['syncAddresses'] = q.length;
    res.metrics['syncedPct'] = (have * 1000 ~/ q.length) / 10;
    res.metrics['syncMs'] = syncSw.elapsedMilliseconds;
    if (have < q.length * 0.9) {
      res.findings.add(Finding('major', 'INCOMPLETE_SYNC',
          'Only ${(have * 100 / q.length).toStringAsFixed(1)} % of the mixer state arrived after 20 s (${u.network.name})'));
    }

    // ---------------------------------------------------------------- the user works
    final myBus = p.busTargets[r.nextInt(p.busTargets.length)];
    final counts = <String, int>{};
    Timer? desk;
    if (u.deskChanges) {
      // someone at the console moves faders meanwhile
      desk = Timer.periodic(const Duration(milliseconds: 70), (_) {
        final s = p.allStrips[r.nextInt(p.allStrips.length)];
        fake.surfaceChange(s.faderAddr, r.nextDouble());
      });
    }
    final outageAt = u.outage ? u.actions ~/ 2 : -1;
    for (var i = 0; i < u.actions; i++) {
      if (i == outageAt) {
        fake.offline = true;
        final t0 = Stopwatch()..start();
        while (ctl.state == ConnState.connected && t0.elapsedMilliseconds < 35000) {
          await Future<void>.delayed(const Duration(milliseconds: 250));
        }
        res.metrics['outageDetectMs'] = t0.elapsedMilliseconds;
        if (ctl.state == ConnState.connected) {
          res.findings.add(Finding('major', 'OUTAGE_NOT_DETECTED', 'Mixer gone for 35 s but the app still shows Connected'));
        }
        // keep working while offline (must not crash)
        for (var k = 0; k < 10; k++) {
          await _act(ctl, u, r, myBus);
        }
        fake.offline = false;
        final t1 = Stopwatch()..start();
        while (ctl.state != ConnState.connected && t1.elapsedMilliseconds < 30000) {
          await Future<void>.delayed(const Duration(milliseconds: 250));
        }
        res.metrics['reconnectMs'] = t1.elapsedMilliseconds;
        if (ctl.state != ConnState.connected) {
          res.findings.add(Finding('critical', 'NO_RECONNECT', 'Mixer back for 30 s but the app did not reconnect'));
        }
      }
      try {
        final label = await _act(ctl, u, r, myBus);
        counts[label.split(' (').first] = (counts[label.split(' (').first] ?? 0) + 1;
      } catch (e, st) {
        res.errors.add('$e\n${st.toString().split('\n').take(4).join('\n')}');
      }
      await _gap(r, u);
    }
    desk?.cancel();
    res.metrics['actions'] = counts;

    // ---------------------------------------------------------------- spoofed packets from another device
    if (fake.lastClientPort != null) {
      final evil = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, 0);
      evil.send(const OscMessage('/ch/05/config/name', ['HACKED']).encode(), InternetAddress.loopbackIPv4,
          fake.lastClientPort!);
      await Future<void>.delayed(const Duration(milliseconds: 150));
      evil.close();
      if (ctl.param('/ch/05/config/name').value == 'HACKED') {
        res.findings.add(Finding('critical', 'SPOOF_ACCEPTED', 'A packet from another device changed a channel name'));
      }
    }

    // ---------------------------------------------------------------- convergence
    await Future<void>.delayed(Duration(milliseconds: 800 + u.network.cond.latencyMs * 2 + u.network.cond.jitterMs));
    int mismatches({required bool onlySynced}) {
      var n = 0;
      final qs = q.toSet();
      for (final e in fake.state.entries) {
        if (onlySynced && !qs.contains(e.key)) continue;
        final v = ctl.param(e.key).value;
        if (v == null) continue;
        if (!_same(v, e.value)) n++;
      }
      return n;
    }

    final before = mismatches(onlySynced: false);
    res.metrics['mismatchAfterWork'] = before;
    res.metrics['mixerValuesTouched'] = fake.state.length;
    await ctl.refreshAll();
    await Future<void>.delayed(Duration(milliseconds: 1500 + u.network.cond.latencyMs * 2 + u.network.cond.jitterMs));
    final afterAll = mismatches(onlySynced: false);
    final afterSynced = mismatches(onlySynced: true);
    res.metrics['mismatchAfterResync'] = afterAll;
    res.metrics['mismatchAfterResyncSyncedSet'] = afterSynced;
    final lossy = u.network.cond.dropRate > 0 || u.network.cond.ignoreQueryRate > 0;
    if (afterSynced > 0 && !lossy) {
      res.findings.add(Finding('major', 'STATE_DIVERGED',
          '$afterSynced values differ from the mixer after a full resync on a clean network'));
    } else if (afterSynced > 5 && lossy) {
      res.findings.add(Finding('minor', 'STATE_DIVERGED_LOSSY',
          '$afterSynced values still differ after one resync on ${u.network.name}'));
    }
    if (afterAll > afterSynced) {
      res.findings.add(Finding('info', 'NOT_IN_RESYNC',
          '${afterAll - afterSynced} changed values are outside the Resync set (detail/routing pages re-read them when opened)'));
    }

    // ---------------------------------------------------------------- invariants
    if (ctl.paramCount > MixerController.maxParams) {
      res.findings.add(Finding('critical', 'PARAM_CAP', 'Stored ${ctl.paramCount} addresses (cap ${MixerController.maxParams})'));
    }
    res.metrics['storedAddresses'] = ctl.paramCount;
    var badAddr = 0, longText = 0, badFader = 0, badType = 0;
    for (final a in ctl.knownAddresses.toList()) {
      final v = ctl.param(a).value;
      if (!MixerController.acceptsAddress(a)) badAddr++;
      if (v is String && v.length > MixerController.maxText) longText++;
      if (a.endsWith('/fader') || a.endsWith('/level')) {
        if (v is num && (v < 0 || v > 1)) badFader++;
        if (v != null && v is! num) badType++;
      }
    }
    if (badAddr > 0) {
      res.findings.add(Finding('info', 'NON_ALLOWLIST_KEYS', '$badAddr stored keys are app-side addresses outside the allowlist'));
    }
    if (longText > 0) res.findings.add(Finding('major', 'TEXT_NOT_CLIPPED', '$longText texts longer than ${MixerController.maxText}'));
    if (badFader > 0) {
      res.findings.add(Finding(u.network.cond.garbagePerSecond > 0 ? 'major' : 'minor', 'FADER_OUT_OF_RANGE',
          '$badFader fader/level values outside 0..1 are stored (from ${u.network.cond.garbagePerSecond > 0 ? 'hostile packets' : 'app input'})'));
    }
    if (badType > 0) {
      res.findings.add(Finding('major', 'FADER_WRONG_TYPE', '$badType fader/level values are not numbers (e.g. a string from the network)'));
    }
    // meters
    final metered = p.allStrips.where((s) => s.hasMeter).toList();
    final live = metered.where((s) => ctl.meters.db(s.prefix).isFinite).length;
    res.metrics['metersLivePct'] = metered.isEmpty ? 0 : (live * 100 ~/ metered.length);
    if (live == 0 && ctl.state == ConnState.connected) {
      res.findings.add(Finding('major', 'NO_METERS', 'No meter levels arrived (${u.network.name})'));
    }
    res.metrics['mixerRx'] = fake.rx;
    res.metrics['mixerTx'] = fake.tx;
    res.metrics['dropped'] = fake.dropped;
    res.metrics['garbageSent'] = fake.garbageSent;
    if (fake.unknownCommands.isNotEmpty) res.metrics['unknownMixerRequests'] = fake.unknownCommands.toList();
  }, (e, st) {
    res.errors.add('UNCAUGHT: $e\n${st.toString().split('\n').take(4).join('\n')}');
  });
  if (res.errors.isNotEmpty) {
    res.findings.add(Finding('critical', 'EXCEPTION', '${res.errors.length} exception(s), first: ${res.errors.first.split('\n').first}'));
  }
  res.metrics['sessionMs'] = sw.elapsedMilliseconds;
  try {
    c?.dispose();
  } catch (e) {
    res.findings.add(Finding('major', 'DISPOSE_ERROR', '$e'));
  }
  await fake.stop();
  return res;
}

void main() {
  final users = makeUsers();
  final results = <SessionResult>[];

  test('100 users, one after another, each in their own conditions', () async {
    for (final u in users) {
      final r = await runSession(u);
      results.add(r);
      final f = r.findings.where((f) => f.severity != 'info').map((f) => f.code).join(',');
      // ignore: avoid_print
      print('user ${u.id.toString().padLeft(3)} ${u.model.padRight(12)} ${roleNames[u.role]!.padRight(24)} '
          '${u.network.name.padRight(28)} conn=${r.connected} sync=${r.metrics['syncedPct']}% '
          '${r.metrics['sessionMs']}ms ${f.isEmpty ? 'OK' : f}');
    }
    final dir = Directory('build/sim')..createSync(recursive: true);
    File('${dir.path}/logic_report.json')
        .writeAsStringSync(const JsonEncoder.withIndent(' ').convert([for (final r in results) r.toJson()]));
  }, timeout: const Timeout(Duration(minutes: 75)));
}
