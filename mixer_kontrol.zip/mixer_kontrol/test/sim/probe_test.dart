// Diagnostic run: the users before and including the one under study, with a
// meter / connection timeline for the studied user (repeated).

import 'package:flutter_test/flutter_test.dart';

import 'session_sim_test.dart';
import 'users.dart';

void main() {
  test('probe user 22', () async {
    final users = makeUsers();
    final u22 = users.firstWhere((u) => u.id == 22);
    // as in the full run: the users before it first
    for (final u in users.where((u) => u.id >= 15 && u.id < 22)) {
      await runSession(u);
    }
    for (var run = 1; run <= 6; run++) {
      simTrace = [];
      final r = await runSession(u22);
      final f = r.findings.where((f) => f.severity != 'info').map((f) => f.code).join(',');
      // ignore: avoid_print
      print('PROBE run $run: ${f.isEmpty ? 'OK' : f} metersLivePct=${r.metrics['metersLivePct']}');
      for (final line in simTrace!) {
        // ignore: avoid_print
        print('PROBE   $line');
      }
      simTrace = null;
    }
  }, timeout: const Timeout(Duration(minutes: 40)));
}
