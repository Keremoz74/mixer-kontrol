// Behringer WING driver: address translation, values, and sessions against a
// software stand-in for a WING (OSC on UDP, native meters on TCP + UDP).

import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mixer_kontrol/mixer/mixer_controller.dart';
import 'package:mixer_kontrol/mixer/mixer_profile.dart';
import 'package:mixer_kontrol/osc/meters.dart';
import 'package:mixer_kontrol/osc/osc_message.dart';
import 'package:mixer_kontrol/util/fader_math.dart';
import 'package:mixer_kontrol/util/param_law.dart';
import 'package:mixer_kontrol/wing/wing_link.dart';
import 'package:mixer_kontrol/wing/wing_map.dart';

/// A small fake WING.
class FakeWing {
  late RawDatagramSocket udp;
  late ServerSocket tcp;
  final Map<String, Object> state = {};
  final List<OscMessage> received = [];
  final List<int> nativeIn = [];
  InternetAddress? clientAddr;
  int? clientPort;
  int? meterPort;
  int meterRequests = 0;

  int get port => udp.port;
  int get nativePort => tcp.port;

  static const _strings = {'name', 'tags', 'leq', 'heq', 'mdl', 'det', 'env'};
  static const _ints = {'mute', 'on', 'col', 'lc', 'inv', r'$solo', r'$vph', 'knee', 'auto', r'$actidx', r'$actionidx'};

  Object _default(String path) {
    final leaf = path.split('/').last;
    if (path.endsWith('/gate/ratio')) return 'gate';
    if (path == '/?') return 'WING,127.0.0.1,Stage WING,ngc-full,S123,3.0';
    if (_strings.contains(leaf)) return leaf == 'name' ? '' : (leaf == 'leq' || leaf == 'heq' ? 'PEQ' : '');
    if (_ints.contains(leaf)) return 0;
    return 0.0;
  }

  Future<void> start() async {
    udp = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, 0);
    udp.listen((e) {
      if (e != RawSocketEvent.read) return;
      final dg = udp.receive();
      if (dg == null) return;
      clientAddr = dg.address;
      clientPort = dg.port;
      final m = OscMessage.decode(dg.data);
      if (m == null) return;
      received.add(m);
      if (m.address == '/*S') return;
      if (m.args.isEmpty) {
        final v = state[m.address] ?? _default(m.address);
        final args = v is String ? <Object>[v] : <Object>['$v', 0.5, v is int ? v : (v as num).toDouble()];
        udp.send(OscMessage(m.address, args).encode(), dg.address, dg.port);
      } else {
        state[m.address] = m.args.first;
      }
    });
    tcp = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    tcp.listen((s) => s.listen((data) {
          nativeIn.addAll(data);
          _parseNative();
        }, onError: (_) {}));
  }

  void _parseNative() {
    // meter request: df d3 d3 <port> d4 <id> <port> dc <tokens> de
    for (var i = 0; i + 4 < nativeIn.length; i++) {
      if (nativeIn[i] == 0xd3 && nativeIn[i + 1] == 0xd3) {
        meterPort = (nativeIn[i + 2] << 8) | nativeIn[i + 3];
        final start = nativeIn.indexOf(0xdc, i);
        final end = nativeIn.indexOf(0xde, start);
        if (start < 0 || end < 0) return;
        meterRequests++;
        _sendMeters(nativeIn.sublist(start + 1, end));
        nativeIn.clear();
        return;
      }
    }
  }

  void _sendMeters(List<int> tokens) {
    final words = <int>[];
    for (var i = 0; i + 1 < tokens.length; i += 2) {
      final t = tokens[i], n = tokens[i + 1];
      final sectionWords = t == 0xa5 ? 4 : 8;
      for (var w = 0; w < sectionWords; w++) {
        // channel N input L = -(20 + N) dB; buses / matrices / main out L = -6 dB
        final db = switch ((t, w)) {
          (0xa0, 0) => -(20 + n).toDouble(),
          (0xa1, 0) => -40.0,
          (_, 2) || (_, 3) => -6.0,
          _ => -90.0,
        };
        words.add((db * 256).round());
      }
    }
    final bd = ByteData(4 + words.length * 2);
    bd.setUint16(0, 1);
    for (var i = 0; i < words.length; i++) {
      bd.setInt16(4 + i * 2, words[i]);
    }
    udp.send(bd.buffer.asUint8List(), InternetAddress.loopbackIPv4, meterPort!);
  }

  /// A change made on the console (single native value, as a subscription sends).
  void surface(String path, Object v) {
    state[path] = v;
    udp.send(OscMessage(path, [v]).encode(), clientAddr!, clientPort!);
  }

  Future<void> stop() async {
    udp.close();
    await tcp.close();
  }
}

Future<void> _until(bool Function() ok, {int ms = 3000}) async {
  final sw = Stopwatch()..start();
  while (!ok() && sw.elapsedMilliseconds < ms) {
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}

void main() {
  const map = WingMap();

  test('app addresses map to WING parameters', () {
    expect(map.toWing('/ch/01/mix/fader')!.path, '/ch/1/fdr');
    expect(map.toWing('/ch/40/mix/on')!.kind, WingKind.muteInv);
    expect(map.toWing('/ch/41/mix/fader'), isNull);
    expect(map.toWing('/auxin/08/config/name')!.path, '/aux/8/name');
    expect(map.toWing('/bus/16/mix/pan')!.path, '/bus/16/pan');
    expect(map.toWing('/mtx/08/mix/fader')!.path, '/mtx/8/fdr');
    expect(map.toWing('/main/st/mix/fader')!.path, '/main/1/fdr');
    expect(map.toWing('/dca/16/on')!.path, '/dca/16/mute');
    expect(map.toWing('/config/mute/8')!.path, '/mgrp/8/mute');
    expect(map.toWing('/headamp/05/gain')!.path, r'/ch/5/in/set/$g');
    expect(map.toWing('/headamp/05/phantom')!.path, r'/ch/5/in/set/$vph');
    expect(map.toWing('/ch/03/mix/12/level')!.path, '/ch/3/send/12/lvl');
    expect(map.toWing('/bus/02/mix/03/on')!.path, '/bus/2/send/MX3/on');
    expect(map.toWing('/main/st/mix/08/level')!.path, '/main/1/send/MX8/lvl');
    expect(map.toWing('/ch/03/mix/st')!.path, '/ch/3/main/1/on');
    expect(map.toWing('/ch/03/eq/1/g')!.path, '/ch/3/eq/lg');
    expect(map.toWing('/ch/03/eq/2/f')!.path, '/ch/3/eq/1f');
    expect(map.toWing('/ch/03/eq/5/q')!.path, '/ch/3/eq/4q');
    expect(map.toWing('/ch/03/eq/6/type')!.path, '/ch/3/eq/heq');
    expect(map.toWing('/ch/03/eq/3/type'), isNull);
    expect(WingMap.constantFor('/ch/03/eq/3/type'), 2);
    expect(map.toWing('/ch/03/preamp/hpf')!.path, '/ch/3/flt/lcf');
    expect(map.toWing('/auxin/03/preamp/hpf'), isNull);
    expect(map.toWing('/ch/03/gate/release')!.path, '/ch/3/gate/rel');
    expect(map.toWing('/auxin/01/gate/on'), isNull);
    expect(map.toWing('/bus/01/dyn/mgain')!.path, '/bus/1/dyn/gain');
    expect(map.toWing('/ch/09/grp/dca')!.path, '/ch/9/tags');
    expect(map.toWing('/ch/09/cue')!.path, r'/ch/9/$solo');
  });

  test('values convert both ways in console units', () {
    expect(map.encode(WingKind.level, dbToFader(-10)) as double, closeTo(-10, 0.01));
    expect(map.encode(WingKind.level, 0.0), -144.0);
    expect(map.decode(WingKind.level, -144.0), 0.0);
    expect(map.decode(WingKind.level, '-oo'), 0.0);
    expect(map.encode(WingKind.muteInv, 1), 0);
    expect(map.decode(WingKind.muteInv, 1), 0);
    expect(map.encode(WingKind.freq, freqLaw.toNorm(1000)) as double, closeTo(1000, 0.5));
    expect(map.decode(WingKind.q, 2.0) as double, closeTo(qLaw.toNorm(2), 1e-9));
    expect(map.encode(WingKind.eqTypeLow, 1), 'SHV');
    expect(map.decode(WingKind.eqTypeHigh, 'SHV'), 4);
    expect(map.encode(WingKind.ratio, 6), 4.0);
    expect(map.decode(WingKind.ratio, 3.9), 6);
    expect(map.encode(WingKind.haGain, 1.0), 45.5); // clamped to the console's range
    expect(map.encode(WingKind.gateMode, 3), 'gate');
    expect(map.decode(WingKind.gateMode, '1:3'), 1);
    expect(map.decode(WingKind.dynMode, 'EXP'), 1);
    expect(WingMap.colorIn(WingMap.colorOut(1)), 1);
    expect(WingMap.colorIn(WingMap.colorOut(4)), 4);
    // a get reply carries text, raw and value; a subscription only the value
    expect(WingMap.valueOf(['-3.0', 0.7, -3.0]), -3.0);
    expect(WingMap.valueOf([-3.0]), -3.0);
    expect(WingMap.valueOf(['PEQ']), 'PEQ');
  });

  test('DCA and mute group membership live in the tags', () {
    expect(WingMap.tagMask('#D1,#D3,#M2,vocals', 'D'), 5);
    expect(WingMap.tagMask('#D1,#D3,#M2,vocals', 'M'), 2);
    expect(WingMap.withMask('#D1,#M2,vocals', 'D', 6, 16), '#D2,#D3,#M2,vocals');
    expect(WingMap.withMask('#D1,#M2', 'M', 0, 8), '#D1');
    expect(WingMap.tagMask('', 'D'), 0);
  });

  test('every WING model: profile addresses all translate', () {
    for (final m in WingLayout.models) {
      final p = MixerProfile.wing(m);
      final missing = [
        for (final a in WingLink.profileAddresses(p))
          if (map.toWing(a) == null && WingMap.constantFor(a) == null) a,
      ];
      expect(missing, isEmpty, reason: m);
      final d = MixerController.demo(MixerFamily.wing, model: m);
      expect(d.profile.inputs.length, 48);
      expect(d.profile.isExternal, isTrue);
      d.dispose();
    }
  });

  test('session with a fake WING: identify, sync, set, changes, tags, meters, scenes', () async {
    final fake = FakeWing();
    await fake.start();
    final link = await WingLink.open('127.0.0.1', port: fake.port, nativePort: fake.nativePort);
    final id = await link.identify();
    expect(id?.name, 'Stage WING');
    link.learn(WingLink.profileAddresses(MixerProfile.wing('WING')));

    final got = <String, Object>{};
    final sub = link.messages.listen((m) => got[m.address] = m.args.first);

    fake.state['/ch/3/fdr'] = -10.0;
    fake.state['/ch/3/name'] = 'Pastor';
    fake.state['/ch/3/eq/1g'] = -6.0;
    fake.state['/ch/3/mute'] = 1;
    link.send(const OscMessage('/ch/03/mix/fader'));
    link.send(const OscMessage('/ch/03/config/name'));
    link.send(const OscMessage('/ch/03/eq/2/g'));
    link.send(const OscMessage('/ch/03/mix/on'));
    await _until(() => got.length >= 4);
    expect(got['/ch/03/mix/fader'] as double, closeTo(dbToFader(-10), 1e-6));
    expect(got['/ch/03/config/name'], 'Pastor');
    expect(got['/ch/03/eq/2/g'] as double, closeTo(eqGainLaw.toNorm(-6), 1e-6));
    expect(got['/ch/03/mix/on'], 0);

    // app changes become WING sets in native units
    link.send(OscMessage('/ch/01/mix/04/level', [dbToFader(-5)]));
    link.send(const OscMessage('/ch/01/mix/on', [0]));
    link.send(OscMessage('/ch/01/eq/1/f', [freqLaw.toNorm(120)]));
    link.send(const OscMessage('/ch/01/dyn/det', [1]));
    await _until(() => fake.state.containsKey('/ch/1/dyn/det'));
    expect(fake.state['/ch/1/send/4/lvl'] as double, closeTo(-5, 0.01));
    expect(fake.state['/ch/1/mute'], 1);
    expect(fake.state['/ch/1/eq/lf'] as double, closeTo(120, 0.1));
    expect(fake.state['/ch/1/dyn/det'], 'RMS');

    // DCA mask written into the tags, keeping other tags
    fake.state['/ch/5/tags'] = '#M2,vox';
    link.send(const OscMessage('/ch/05/grp/dca'));
    await _until(() => got.containsKey('/ch/05/grp/dca'));
    expect(got['/ch/05/grp/dca'], 0);
    link.send(const OscMessage('/ch/05/grp/dca', [5]));
    await _until(() => '${fake.state['/ch/5/tags']}'.contains('#D'));
    expect(fake.state['/ch/5/tags'], '#D1,#D3,#M2,vox');
    fake.surface('/ch/5/tags', '#D8,#M1');
    await _until(() => got['/ch/05/grp/dca'] == 128 && got['/ch/05/grp/mute'] == 1);
    expect(got['/ch/05/grp/dca'], 128);
    expect(got['/ch/05/grp/mute'], 1);

    // changes on the console arrive through the subscription
    link.send(const OscMessage('/xremote'));
    await _until(() => fake.received.any((m) => m.address == '/*S'));
    fake.surface('/bus/6/mute', 1);
    fake.surface(r'/ch/1/$solo', 1);
    await _until(() => got.containsKey('/bus/06/mix/on') && got.containsKey('/ch/01/cue'));
    expect(got['/bus/06/mix/on'], 0);
    expect(got['/ch/01/cue'], 1);

    // meters: native request on TCP, report on UDP, turned into the app blob
    link.send(const OscMessage('/meters', [WingLink.meterId]));
    await _until(() => got.containsKey(WingLink.meterId));
    expect(fake.meterRequests, 1);
    final mv = decodeMeterBlob(got[WingLink.meterId] as dynamic, MeterFormat.int16Db);
    expect(mv.length, WingMap.meterCount);
    expect(mv[0], closeTo(-20, 0.01)); // ch 1 input
    expect(mv[39], closeTo(-59, 0.01)); // ch 40 input
    expect(mv[48], closeTo(-6, 0.01)); // bus 1 output
    expect(mv[72], closeTo(-6, 0.01)); // main L

    // scenes: current index and recall
    fake.state[r'/$ctl/lib/$actidx'] = 4;
    link.send(const OscMessage(MixerProfile.yamahaSceneCurrentAddr));
    await _until(() => got.containsKey('/-snap/index'));
    expect(got['/-snap/index'], 4);
    link.send(const OscMessage('/-snap/load', [7]));
    await _until(() => fake.state[r'/$ctl/lib/$action'] == 'GO');
    expect(fake.state[r'/$ctl/lib/$actionidx'], 7);

    // hostile packets are ignored
    final evil = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, 0);
    evil.send(const OscMessage('/ch/2/fdr', [5.0]).encode(), InternetAddress.loopbackIPv4,
        link.localPort);
    fake.surface('/ch/99/fdr', 3.0);
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(got.containsKey('/ch/02/mix/fader'), isFalse);
    evil.close();

    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('a whole WING profile syncs against the fake console', () async {
    final fake = FakeWing();
    await fake.start();
    final link = await WingLink.open('127.0.0.1', port: fake.port, nativePort: fake.nativePort);
    final p = MixerProfile.wing('WING');
    final seen = <String>{};
    final sub = link.messages.listen((m) => seen.add(m.address));
    final want = p.queryAddresses.toSet();
    // like the app: batches, and another round for anything not answered
    for (var round = 0; round < 4 && !seen.containsAll(want); round++) {
      var n = 0;
      for (final a in want.difference(seen)) {
        link.send(OscMessage(a));
        if (++n % 50 == 0) await Future<void>.delayed(const Duration(milliseconds: 5));
      }
      await _until(() => seen.containsAll(want), ms: 3000);
    }
    expect(want.difference(seen), isEmpty);
    await sub.cancel();
    link.close();
    await fake.stop();
  });

  test('identify gives up cleanly when nothing answers', () async {
    final s = await RawDatagramSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = s.port;
    s.close();
    final link = await WingLink.open('127.0.0.1', port: port, nativePort: 1);
    expect(await link.identify(timeout: const Duration(milliseconds: 300)), isNull);
    link.close();
  });
}
