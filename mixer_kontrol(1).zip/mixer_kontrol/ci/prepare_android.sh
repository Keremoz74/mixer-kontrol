#!/usr/bin/env bash
# Prepares the generated Android project. Lives in the zip, so permissions,
# app name and icons can change without touching the GitHub workflow file.
set -euo pipefail

flutter create --platforms=android --org com.mixerkontrol .
rm -f test/widget_test.dart

MANIFEST=android/app/src/main/AndroidManifest.xml

# Permissions: network (mixer control) and audio input (record to tablet).
PERMS='<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <uses-feature android:name="android.hardware.microphone" android:required="false"/>\n    <uses-feature android:name="android.hardware.usb.host" android:required="false"/>\n    <application'
sed -i "s#<application#${PERMS}#" "$MANIFEST"

# Minimum Android version: the audio recording library needs API 23+;
# 24 (Android 7) covers practically every tablet in use.
for G in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$G" ]; then
    sed -i -E 's/minSdk(Version)? *=? *flutter\.minSdkVersion/minSdk = 24/' "$G"
    grep -n "minSdk" "$G" || true
  fi
done

# App name and launcher icon.
cp -r branding/android/res/. android/app/src/main/res/
APP_NAME="$(cat branding/app_name.txt)"
sed -i "s#android:label=\"[^\"]*\"#android:label=\"$APP_NAME\"#" "$MANIFEST"

echo "---- AndroidManifest.xml ----"
cat "$MANIFEST"
