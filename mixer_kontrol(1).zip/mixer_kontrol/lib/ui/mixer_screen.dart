import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../mixer/mixer_controller.dart';
import '../mixer/mixer_profile.dart';
import 'app_style.dart';
import 'channel_strip.dart';

class MixerScreen extends StatefulWidget {
  const MixerScreen({super.key, required this.controller});
  final MixerController controller;

  @override
  State<MixerScreen> createState() => _MixerScreenState();
}

class _MixerScreenState extends State<MixerScreen> {
  int _tab = 0; // 0 inputs, 1 buses, 2 DCA
  SendTarget? _send; // null = Main LR mix

  MixerController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    // Full screen: every pixel of height goes to the faders.
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    c.dispose();
    super.dispose();
  }

  String _targetLabel(SendTarget t) {
    final n = c.param(t.master.nameAddr).value;
    return n is String && n.trim().isNotEmpty ? n : t.label;
  }

  @override
  Widget build(BuildContext context) {
    final p = c.profile;
    final size = MediaQuery.sizeOf(context);
    final compact = size.height < 500; // phone in landscape
    final isTablet = size.shortestSide >= 600;
    final stripW = isTablet ? 86.0 : 66.0;

    final strips = switch (_tab) {
      0 => p.inputs,
      1 => p.buses,
      _ => p.dcas,
    };
    final sendsOn = _send != null && _tab == 0;
    final pinned = sendsOn ? _send!.master : p.main;

    final stripsArea = Row(
      children: [
        Expanded(
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            itemCount: strips.length,
            itemBuilder: (context, i) => ChannelStrip(
              key: ValueKey('${strips[i].prefix}-${_send?.mixIndex}'),
              controller: c,
              strip: strips[i],
              sendTarget: sendsOn ? _send : null,
              width: stripW,
              compact: compact,
            ),
          ),
        ),
        Container(width: 1, margin: const EdgeInsets.symmetric(vertical: 8), color: Colors.white12),
        const SizedBox(width: 4),
        ChannelStrip(
          controller: c,
          strip: pinned,
          width: stripW + 10,
          isMaster: true,
          compact: compact,
        ),
        const SizedBox(width: 6),
      ],
    );

    return AppBackground(
      child: Scaffold(
        appBar: compact ? null : _appBar(),
        body: SafeArea(
          top: compact,
          child: Column(
            children: [
              if (compact)
                _compactBar(sendsOn)
              else ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
                  child: _tabSelector(dense: false),
                ),
                if (_tab == 0) _mixChips(),
                if (sendsOn) _sendsBanner(),
              ],
              Expanded(child: stripsArea),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- bars

  PreferredSizeWidget _appBar() {
    return AppBar(
      toolbarHeight: 48,
      title: ListenableBuilder(
        listenable: c,
        builder: (context, _) => Text(
          '${c.mixerName} · ${c.profile.model}',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
      ),
      actions: [
        ListenableBuilder(listenable: c, builder: (context, _) => _StatusChip(controller: c)),
        if (!c.isDemo)
          IconButton(tooltip: 'Yeniden senkronize et', icon: const Icon(Icons.sync), onPressed: c.refreshAll),
        const SizedBox(width: 4),
      ],
    );
  }

  /// Landscape phone: everything on one 44 px row.
  Widget _compactBar(bool sendsOn) {
    return SizedBox(
      height: 46,
      child: Row(
        children: [
          IconButton(
            tooltip: 'Bağlantıyı kes',
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: ListenableBuilder(
              listenable: c,
              builder: (context, _) => Text(
                '${c.mixerName} · ${c.profile.model}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          _tabSelector(dense: true),
          if (_tab == 0) ...[
            const SizedBox(width: 8),
            _mixMenu(sendsOn),
          ],
          const SizedBox(width: 8),
          ListenableBuilder(listenable: c, builder: (context, _) => _StatusChip(controller: c)),
          if (!c.isDemo)
            IconButton(tooltip: 'Yeniden senkronize et', icon: const Icon(Icons.sync), onPressed: c.refreshAll),
          const SizedBox(width: 4),
        ],
      ),
    );
  }

  Widget _tabSelector({required bool dense}) {
    return SegmentedButton<int>(
      showSelectedIcon: false,
      style: dense
          ? const ButtonStyle(
              visualDensity: VisualDensity(horizontal: -2, vertical: -3),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            )
          : null,
      segments: [
        ButtonSegment(value: 0, label: const Text('Girişler'), icon: dense ? null : const Icon(Icons.mic)),
        ButtonSegment(value: 1, label: const Text('Buslar'), icon: dense ? null : const Icon(Icons.call_split)),
        ButtonSegment(value: 2, label: const Text('DCA'), icon: dense ? null : const Icon(Icons.tune)),
      ],
      selected: {_tab},
      onSelectionChanged: (s) => setState(() => _tab = s.first),
    );
  }

  /// Landscape: the mix choice is a drop-down instead of a whole row of chips.
  Widget _mixMenu(bool sendsOn) {
    final label = _send == null ? 'Ana LR' : _targetLabel(_send!);
    return PopupMenuButton<int>(
      tooltip: 'Fader\'ların kontrol ettiği mix',
      initialValue: _send?.mixIndex ?? 0,
      onSelected: (v) => setState(() {
        _send = v == 0 ? null : c.profile.sendTargets.firstWhere((t) => t.mixIndex == v);
      }),
      itemBuilder: (context) => [
        const PopupMenuItem(value: 0, child: Text('Ana LR')),
        for (final t in c.profile.sendTargets)
          PopupMenuItem(value: t.mixIndex, child: Text(_targetLabel(t))),
      ],
      child: Container(
        height: 34,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(17),
          color: sendsOn ? sendsAccent.withValues(alpha: 0.22) : Colors.white.withValues(alpha: 0.06),
          border: Border.all(color: sendsOn ? sendsAccent : Colors.white24),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Mix: $label',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: sendsOn ? sendsAccent : Colors.white,
              ),
            ),
            Icon(Icons.arrow_drop_down, color: sendsOn ? sendsAccent : Colors.white70),
          ],
        ),
      ),
    );
  }

  Widget _sendsBanner() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
      padding: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: sendsAccent.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        'Faderlar ${_targetLabel(_send!)} gönderimlerini gösteriyor',
        textAlign: TextAlign.center,
        style: const TextStyle(color: sendsAccent, fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }

  /// Portrait / tablet: "sends on fader" as a scrollable row of chips.
  Widget _mixChips() {
    final targets = c.profile.sendTargets;
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: ChoiceChip(
              label: const Text('Ana LR'),
              selected: _send == null,
              onSelected: (_) => setState(() => _send = null),
            ),
          ),
          for (final t in targets)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ListenableBuilder(
                listenable: c.param(t.master.nameAddr),
                builder: (context, _) {
                  final selected = _send?.mixIndex == t.mixIndex;
                  return ChoiceChip(
                    label: Text(_targetLabel(t)),
                    selected: selected,
                    selectedColor: sendsAccent.withValues(alpha: 0.35),
                    onSelected: (_) => setState(() => _send = selected ? null : t),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.controller});
  final MixerController controller;

  @override
  Widget build(BuildContext context) {
    final (text, color) = controller.isDemo
        ? ('Demo', const Color(0xFF8B5CF6))
        : controller.state == ConnState.connected
            ? ('Bağlı', const Color(0xFF3DD68C))
            : ('Bağlantı yok', AppStyle.muteRed);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color, blurRadius: 6)],
            ),
          ),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
        ],
      ),
    );
  }
}
