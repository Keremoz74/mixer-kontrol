# OzMix Control — for X32 · M32 · X Air · MR

Tek, sade arayüzle hem Behringer X32 / Midas M32 hem de XR12/16/18 / MR18 mikserlerini kontrol eden Flutter uygulaması (iOS + Android, telefon + tablet).

## v0.18 — Kayıt (Recorder)
- Mikser ekranında **Recorder** (⏺ simgesi / yatayda ⋮ menüsü), iki sekme:
  - **Mixer USB stick:** konsolun kendi USB bellek kaydedicisi (X32/M32, XR12/XR16; XR18'de yok): Record, Pause, Play, Stop, süre ve dosya adı. `/-stat/tape/state` (0 stop, 2 play XR12'de doğrulandı; 4 record, 1/3 pause)
  - **Record to tablet:** mikserin USB ses çıkışı kabloyla tablete (USB-C OTG); giriş seçimi, seviye göstergesi, 48 kHz stereo WAV. Kayıtlar listelenir, **paylaş** (WhatsApp, Drive…) veya sil
  - Tablet ilk iki USB kanalını kaydeder: mikserde Main LR'yi USB / kart çıkışı 1-2'ye yönlendir
- Android ayarları (izinler, ad, ikon, minSdk 24) artık zip içindeki `ci/prepare_android.sh` betiğinde; derleme dosyası bir kez güncellenmeli

## v0.17 — EQ'da iki parmakla Q
- EQ grafiğinde **iki parmak (pinch):** seçili bandın Q'su; parmakları aç = geniş band (düşük Q), kapat = dar band. Ekranda canlı "Band 2 · Q 1.4" göstergesi
- Tek parmak eskisi gibi frekans/kazanç; pinch bitince kalan parmak bandı zıplatmaz
- Q yalnızca PEQ/VEQ bantlarında değişir (shelf/cut bantlarında uyarı gösterilir)

## v0.16 — Kopyala/yapıştır ve Matrix sayfası
- **Kopyala/yapıştır:** bir şeridin adına uzun bas → *Copy settings*; başka bir şeride uzun bas → *Paste* → neyin (EQ, gate, kompresör, faz/trim, pan, gönderimler, fader/mute, ad/renk) ve hangi şeritlere yapıştırılacağını seç; Undo ile geri alınır
  - Aynı türdeki şeritler arasında (kanal→kanal, bus→bus…); preamp gain, +48V ve insert asla kopyalanmaz
  - Uzun basış menüsünde ad ve renk düzenleme de var
- **Matrix sekmesi (X32):** Matrix 1-6 çıkışları; *Mix* menüsünden bir matrix seçince Bus 1-16 ve Main LR faderları o matrix'e gönderimi gösterir (sağdaki şerit matrix master'ı). Bus sekmesinde artık yalnızca mix buslar var
  - Adresler: `/bus/NN/mix/MM/level|on`, `/main/st/mix/MM/level|on` (MM = 01-06); gerçek X32'de doğrulanacak

## v0.15 — Plugin (insert) ve kanal presetleri
- Kanal sayfasında **Insert** sekmesi (bus/matrix/Main LR'de de; XR'de Main LR'nin insert'i yok): konsolun kendi efektlerini kanala plugin gibi takma
  - **Add plugin:** De-Esser, Fair/Leisure/Ultimo Comp, Pitch Shifter, Enhancer, Exciter, Guitar Amp, Tube Stage, Combinator, Wave Designer, Limiter, GEQ, TruEQ, Xtec EQ1/EQ5
  - Uygulama uygun FX slotunu bulur ve önerir: aynı efekti çalıştıran slotun boş yarısı (dual efektler iki mono kanala hizmet eder), sonra X32'de 5-8 insert slotları; send efekti olarak kullanılan slotlar için uyarı
  - **Edit** ile FX Rack o slotta açılır; Pre/Post (X32), aç/kapa, Change, Remove
  - XR insert adresleri belgeden doğrulandı; X32 `/insert/sel` (OFF, FX1L…FX8R, AUX1-6) ve `/insert/pos` gerçek X32'de doğrulanacak
- **Kanal presetleri** (kanal sayfası üst çubuğundaki ✨): EQ + low cut + gate + kompresör tek dokunuşta; Undo ile geri alınır. EQ sayfasındaki Presets yalnızca EQ uygular

## v0.14 — Şeritlerde gain düğmesi ve EQ presetleri
- **Gain:** her giriş kanalında küçük düğme; yukarı-aşağı sürükle (≈0.25 dB/piksel, 0.5 dB adım, zıplamaz). +48V açıksa kırmızı nokta. Dokununca kanalın giriş sayfası açılır
  - X32'de doğru preamp yönlendirmeden okunur; kaynakta preamp yoksa "no preamp" görünür
- **EQ presetleri:** EQ sayfasında **Presets** → Vocals (erkek/kadın vokal, vokal arka, konuşma, koro), Guitars (akustik, elektro), Bass, Drums (kick, snare, tom, overhead), Keys (piyano, pad), Other (playback); ayrıca **Flat** (sıfırla)
  - Low cut de presetle ayarlanır; uygulamadan sonra **Undo** ile geri alınabilir
  - Presetler uygulamanın kendi başlangıç ayarlarıdır (konsolun fabrika kütüphanesi değil)

## v0.13 — Mikserin kendi snapshot / scene kütüphanesi
- Snapshots ekranında iki sekme: **On mixer** (konsolun hafızası) ve **On this device** (uygulamanın kayıtları)
- **On mixer:** XR'nin 64 snapshot'ı / X32'nin 100 scene'i adlarıyla listelenir; son yüklenen işaretlenir
  - **Load:** konsol kaydı geri çağırır, ardından uygulama tüm değerleri yeniden okur
  - **Save to mixer:** ilk boş slota (veya listeden seçilen slota) adıyla kaydeder; menüden üzerine yazma ve silme
  - Konsoldaki kayıtlar uygulamadan bağımsızdır; uygulama silinse de konsolda kalır
- XR komutları (`/-snap/NN/name`, `/-snap/load|save|delete`, `/-snap/index`) gerçek XR18 (FW 1.16) üzerinde test edilmiş bir projeden doğrulandı
- X32 komutları: ad `/-show/showfile/scene/NNN/name`, dolu mu `.../hasdata`, yükleme `/-action/goscene`, kayıt `/save "scene"`, silme `/delete "scene"`; gerçek X32'de doğrulanacak

## v0.12 — Şeritlerde EQ/FX kısayolları, bus ve Main LR EQ
- Her şeridin adının altında **EQ** düğmesi: kanalın EQ eğrisinin canlı küçük resmi; dokununca EQ sayfası açılır
- Giriş kanallarında yanında **FX** düğmesi: FX 1-4'e gönderim (efekt adı, aç/kapa, seviye) hızlı panelde
  - XR: FX gönderimleri sabit (mix 07-10)
  - X32: her FX slotunu hangi bus'ın beslediği konsoldan okunur (`/fx/N/source`), ör. "Hall Reverb · via Bus 13"
- **Bus, Matrix ve Main LR EQ:** 6 bant (Low Cut, Shelf, PEQ, VEQ, High Cut), sürüklenebilir eğri; adına veya EQ düğmesine dokunarak açılır
- Bus/Main EQ'su snapshot'lara da kaydedilir

## v0.11 — OzMix Control adı ve logo
- Uygulama adı **OzMix Control**, alt başlık "for X32 · M32 · X Air · MR"
- Logo: parlayan O halkası içinde üç fader (uygulama renkleri); Android uyarlanabilir ikon dahil
- Ad ve ikon `branding/` klasöründen gelir: `app_name.txt` ve `android/res/`; değiştirmek için derleme dosyasına dokunmak gerekmez
- Derleme, adı ne olursa olsun en son yüklenen zip'i kullanır

## v0.10 — Kanal renkleri ve mikser çizimleri
- Kanal adına **uzun basınca** açılan pencerede ad + renk: 8 konsol rengi (Off, Red, Green, Yellow, Blue, Magenta, Cyan, White) ve **Inverted** (koyu zemin, renkli yazı); canlı önizleme
- Inverted renkler şeritlerde de konsoldaki gibi görünür
- Bağlantı ekranında markasız, özgün çizimler: masaüstü konsol (X32/M32 ailesi) ve kompakt kutu (XR/MR ailesi)
- Yayın adı "Mixer Control", sabit imza anahtarı (güncellemeler silmeden kurulur)

## v0.9 — FX Rack ve Snapshot kütüphanesi
- **FX Rack** (üst çubuk ✨ simgesi, yatayda ⋮ menüsü): X32'de 8 slot (5-8 yalnızca insert efektleri), XR'de 4 slot
  - Efekt seçimi kategorilere göre: Reverb, Delay, Modulation, Combination, EQ, Dynamics (Fair/Leisure/Ultimo Comp, Limiter, De-Esser…), Enhance, Amp & drive, Pitch
  - Efekt değiştirmeden önce onay; konsol yeni efektin ayarlarını sıfırlar, uygulama okur
  - Parametreler şimdilik numaralı (Parameter 1…16, istenirse 64'e kadar), % olarak
- **Snapshots** (🔖 simgesi): mix'i telefona kaydet, geri çağır, adını değiştir, güncelle, sil
  - Kaydedilenler: fader, mute, ad, renk, gönderimler, pan, EQ, low cut, faz, trim, gate, kompresör, FX tipleri ve parametreleri
  - **Kaydedilmeyenler (bilerek):** preamp gain, +48V ve giriş yönlendirmesi; bir snapshot asla fantom beslemeyi açamaz
  - Geri çağırmada önce FX tipleri, sonra kalan her şey gönderilir; ilerleme çubuğu gösterilir
  - X32'de kaydedilen snapshot yalnızca X32/M32'de, XR'de kaydedilen yalnızca XR/MR'de çağrılabilir

## v0.8 — İngilizce arayüz, belirgin Main LR, sade bus seçimi
- Uygulamanın tüm metinleri İngilizce (Inputs, Buses, Sends, Dynamics, Threshold…)
- **Main LR** turkuaz çerçeve, turkuaz fader dolgusu ve hafif ışıkla diğer şeritlerden ayrışır; bir bus'a geçildiğinde sabit şerit o bus'ın master'ı olur ve turuncu görünür
- Bus seçimi tek bir **"Mix: Main LR ▾"** düğmesinde; dokununca tüm mix'ler bus renkleri ve adlarıyla düzenli bir ızgarada açılır
- Dikey ekranda grup ve mix seçimi tek satırda (eski iki uzun çip satırı kaldırıldı)

## v0.7 — Kanal grupları ve kanal gönderimleri
- **Gruplar:** Girişler 1-8, 9-16, 17-24, 25-32, Aux, FX (XR'de 1-8, 9-16, Aux/FX); Buslar 1-8, 9-16, Matrix (XR'de Bus 1-6, FX Send); DCA. "Tümü" ile hepsi tek sırada kaydırılır
- Yatay telefonda grup seçimi üst çubukta açılır menü, dikeyde çip satırı; her sekme kendi grubunu hatırlar
- Grup ekrana sığıyorsa şeritler genişleyip tüm ekranı doldurur (kaydırma gerekmez)
- **Kanal sayfasında "Gönderim" sekmesi:** kanalın tüm bus ve FX gönderimleri tek ekranda; her biri için aç/kapa ve seviye (dB). Tablette ve yatayda iki sütun
- Bus'a göre "sends on fader" (üstteki Mix menüsü) aynen duruyor; iki yön birlikte kullanılabilir
- Yatay telefonda kanal sayfasının sekmeleri başlık satırına taşındı

## v0.6 — Yatay yerleşim ve yeni görünüm
- Telefon yatayken üstteki üç satır tek ince çubuğa indi: geri, başlık, sekmeler, **Mix** açılır menüsü ve durum
- Mikser ekranı tam ekran (durum çubuğu gizli); faderlar yüksekliğin büyük kısmını kullanır
- Kanal adı altta tekrar yazılmıyor; özel ad verilmiş kanalda numara adın üstünde küçük görünür
- Yeni görünüm: koyu mavi zemin üzerinde yumuşak ışık hüzmeleri, cam etkili şeritler, metalik fader kapakları (dokununca parlar), parlayan seviye çizgisi, LED tipi metreler, parlayan MUTE
- Tablette fader yanında dB ölçeği yazıları

## v0.5 — Gate ve kompresör
Kanal sayfasında iki sekme var: **EQ · Giriş** ve **Dinamik** (sekmeler dokunarak değişir; kaydırma EQ sürüklemesiyle çakışmasın diye kapalı). Gate ya da kompresör açıksa sekmede renkli nokta görünür.
- **Gate:** aç/kapa, mod (Exp 1:2 / 1:3 / 1:4, Gate, Duck), eşik (-80…0 dB), aralık (3…60 dB), attack, hold, release
- **Kompresör:** aç/kapa, Comp/Exp, eşik (-60…0 dB), oran (1.1:1 … 100:1), knee, makeup (0…24 dB), attack, hold, release, paralel mix (%0–100), Auto, Peak/RMS, Lin/Log
- **Transfer eğrisi:** giriş-çıkış grafiği gate ve kompresörün birlikte etkisini canlı gösterir; eşikler renkli çizgilerle işaretli
- Telefonda grafik üstte, ayarlar altında; tablette ayarlar solda, grafik sağda

## v0.4 — X32'de doğru preamp (güvenlik)
- Gain ve +48V artık tahmin edilen değil, **gerçekten kullanılan** preamp'a gider. Zincir konsoldan okunur:
  kanal kaynağı (`/ch/NN/config/source`) → giriş bloğu (`/config/routing/IN/...`: Local, AES50-A/B, Kart, Kullanıcı) → gerekirse kullanıcı yönlendirmesi (`/config/userrout/in/NN`, FW 4+)
- Giriş kartında hangi preamp olduğu yazar (ör. "Preamp: AES50-A 20")
- Yönlendirme okunana kadar gain ve +48V kapalıdır; kaynak USB/Kart/FX/Bus ise preamp kontrolü gösterilmez
- Konsolda yönlendirme değişirse ekran canlı olarak yeni preamp'a geçer
- +48V açmadan önce preamp adını söyleyen bir onay penceresi çıkar
- XR'de kanal N her zaman fiziksel giriş N'nin preamp'ını kullanır, ek okuma gerekmez

## v0.3 — Kanal detay ekranı
Mikser ekranında bir kanalın **adına dokunun** (uzun basış hâlâ yeniden adlandırır).
- **EQ eğrisi:** 4 bant, numaralı noktaları sürükleyin (sağa-sola frekans, yukarı-aşağı kazanç). Eğri, Low Cut dahil gerçek filtre formülleriyle çizilir
- Bant tipi (Low Cut, Low Shelf, PEQ, VEQ, High Shelf, High Cut), frekans, kazanç ve Q kaydırıcıları; EQ aç/kapa
- **Giriş:** preamp gain (-12…+60 dB), +48V, faz çevirme, Low Cut ve frekansı (20–400 Hz); X32'de dijital trim (±18 dB)
- **Pan:** L100…C…R100, değere çift dokunarak ortalanır
- Telefonda EQ üstte sabit, ayarlar altta kayar; tablette ve yatay telefonda ayarlar solda, EQ sağda
- Mute düğmesi üst çubukta

## v0.2 — Seviye göstergeleri
- Her fader'ın yanında -60…0 dBFS metre (yeşil / sarı -18 dB'den, kırmızı -6 dB'den), üstte clip noktası
- X32: `/meters/0` (kanal, aux, FX dönüş, bus, matrix) ve `/meters/2` (Ana LR); doğrusal float değerler
- XR: `/meters/1` (kanal, aux, FX dönüş, bus, FX send, Ana LR); 1/256 dB'lik 16-bit değerler
- Abonelik 8 sn'de bir yenilenir; bağlantı koparsa metreler sıfırlanır (donmuş seviye gösterilmez)
- Stereo kaynaklarda (Ana LR, XR Aux/FX dönüş) L/R'nin yükseği gösterilir
- Demo modunda hareketli örnek metreler

## v0.1
- Ağdaki mikserleri otomatik bulma (`/xinfo` yayını) ve IP ile manuel bağlantı
- Model algılama: X32 için port 10023, XR için 10024; arayüz aynı kalır, adresler profile göre değişir
- Kanal, Aux/FX dönüş, Bus, Matrix (X32), FX Send (XR), DCA ve Ana LR faderleri
- Mute, kanal adı ve renkleri (uzun basarak yeniden adlandırma)
- **Sends on fader:** üstten bir bus seçin, giriş faderleri o mix'e gönderimi kontrol eder, sağdaki sabit fader bus master olur
- Canlı senkron (`/xremote`, 8 sn'de bir yenilenir), bağlantı kopunca uyarı ve dönünce otomatik yeniden senkron
- Göreli fader sürükleme (parmak fader'ı zıplatmaz), çift dokunuşla 0 dB
- Mikser olmadan denemek için X32 ve XR18 demo modu

## Kurulum
1. Flutter 3.27 veya üstünü kurun: https://docs.flutter.dev/get-started/install
2. Bu klasörde platform dosyalarını oluşturun (mevcut `lib/` dosyalarına dokunmaz):
   ```
   flutter create --platforms=ios,android --org com.sizinfirma .
   ```
   Oluşan `test/widget_test.dart` dosyasını silin (şablon sayaç testidir).
3. `flutter pub get`
4. `flutter test` ile OSC ve fader testlerini çalıştırın.
5. `flutter run` ile cihazda açın. Önce **Demo** ile arayüzü deneyebilirsiniz.

### Android
`android/app/src/main/AndroidManifest.xml` içinde `<manifest>` altına ekleyin (release sürüm için gerekli):
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

### iOS
`ios/Runner/Info.plist` içine ekleyin (yerel ağ izni, iOS 14+):
```xml
<key>NSLocalNetworkUsageDescription</key>
<string>Mikserinizi kontrol etmek için yerel ağa erişim gerekiyor.</string>
```
iOS'ta otomatik bulma (broadcast) için Apple'dan `com.apple.developer.networking.multicast` yetkisi istenmesi gerekir. Bu yetki gelene kadar IP ile bağlantı sorunsuz çalışır.

## Yapı
```
lib/
  osc/        OSC kodlama/çözme, UDP istemcisi, ağ taraması
  mixer/      MixerProfile (X32 ↔ XR farkları), MixerController (canlı durum)
  ui/         Bağlantı ekranı, mikser ekranı, kanal şeridi, fader
  util/       Fader/dB, parametre ölçekleri, EQ ve dinamik eğri hesapları
```
Yeni bir model eklemek ya da adres düzeltmek için yalnızca `mixer_profile.dart` değiştirilir.

## Gerçek mikserde doğrulanacaklar
- XR12'nin 12 kanal olarak listelenmesi
- XR'de FX gönderimlerinin `mix/07..10` adresleri
- Ana LR için ad/renk adresleri (`/main/st/config/...`, `/lr/config/...`)
- Metre verisinin byte sırası: belgelere göre little-endian; kod sayı alanından sırayı kendisi doğruluyor
- XR `/meters/1` içindeki 5 stereo çiftin sırası (Aux önce, sonra FX 1-4 varsayıldı)
- EQ ölçekleri: frekans 20 Hz–20 kHz log, kazanç ±15 dB, Q 10→0.3 log; gain -12…+60 dB
- X32 preamp çözümlemesi: `/config/routing/IN` ve `/config/userrout/in` değer sıraları belgeye göre; X32 Rack/Compact'ta yerel giriş sayısı 16'dır
- Gate modu sırası (Exp 1:2, 1:3, 1:4, Gate, Duck) XR FW 1.25'te teyitli; X32'de de aynı olmalı
- Transfer eğrisindeki knee genişliği yaklaşık çizilir (knee değeri başına 4 dB); sesi etkilemez, yalnızca görsel

- FX tip sırası X32 belgesinden; XR'nin de aynı 61 efektli sırayı kullandığı varsayıldı (XR'de bir efekt seçip konsoldaki adla karşılaştırın)
- FX parametre değerlerinin float (0-1) olarak gönderimi
- Bus/Main EQ adresleri: X32 `/bus/NN/eq/1-6`, `/mtx/NN/eq/1-6`, `/main/st/eq/1-6`; XR `/bus/N/eq/1-6`, `/lr/eq/1-6` (XR'de bus/LR EQ modu PEQ olmalı; GEQ modunda bu sayfa etkisizdir)

## Sıradaki adımlar
- FX parametrelerine ad ve birim (konsolda doğrulandıkça, efekt efekt)
- Kanal insert'leri (FX slotunu kanala takma) ve FX kaynak seçimi
- Gain reduction göstergeleri (gate/kompresör ne kadar kısıyor)
- Bus EQ (6 bant), bus/ana çıkış dinamikleri
- Kanal görünürlüğü/sıralama, sahne (scene/snapshot) çağırma
- Ekranın kapanmaması (wakelock) ve kişisel monitör modu
